// 渐变设置
export const linerGradient = (deg, from, to) => {
	return `linear-gradient(${deg}deg, ${from} ,${to})`
};

export const PRIMARY_C = `#D7060F`;



export const PRIMARY = `primary`;
export const SUCCESS = `success`;
export const ERROR = `error`;
export const WARN = `warn`;
export const INFO = `info`;
export const PRIMARY_RGBA = `primary-rgba`;
export const SUCCESS_RGBA = `success-rgba`;
export const ERROR_RGBA = `error-rgba`;
export const WARN_RGBA = `warn-rgba`;
export const INFO_RGBA = `info-rgba`;
export const BLACK_10 = `black-10`;
export const BLACK_30 = `black-30`;
export const BLACK_70 = `black-70`;
export const WHITE_30 = `white-30`;
export const WHITE_70 = `white-70`;

export const getColor = (val) => {
	const temp = {
		[PRIMARY]: `var(--${PRIMARY})`,
		[SUCCESS]: `var(--${SUCCESS})`,
		[ERROR]: `var(--${ERROR})`,
		[WARN]: `var(--${WARN})`,
		[INFO]: `var(--${INFO})`,
		[PRIMARY_RGBA]: `var(--${PRIMARY_RGBA})`,
		[SUCCESS_RGBA]: `var(--${SUCCESS_RGBA})`,
		[ERROR_RGBA]: `var(--${ERROR_RGBA})`,
		[WARN_RGBA]: `var(--${WARN_RGBA})`,
		[INFO_RGBA]: `var(--${INFO_RGBA})`,
		[BLACK_10]: `var(--${BLACK_10})`,
		[BLACK_30]: `var(--${BLACK_30})`,
		[BLACK_70]: `var(--${BLACK_70})`,
		[WHITE_30]: `var(--${WHITE_30})`,
		[WHITE_70]: `var(--${WHITE_70})`,
	}
	console.log(temp[val]);
	return temp[val];
}

export const TXT_UNACT = `#838B9C`;
// checkbox 边框及勾选
export const CHECKBOX_COLOR_ACTIVE = PRIMARY;
export const CHECKBOX_LABEL_COLOR = '#1f212d'; // checkbox 文字
export const TRANSPARENT = 'transparent'; // 使用父级元素颜色
export const BASIC_LIGHT = `#F8F8F8`;
export const BASIC_DARK = `#121212`;
export const INPUT_BG = 'transparent'; // input背景
export const INPUT_BORDER = '#6D41FF3A'; // input边框
export const RISE = `#2EBD85`; // 涨 字色
export const FALL = `#E33B54`; // 跌 字色
export const FLAT = `#888888`; // 平 字色
export const BTN_UNLOCK = `#FFFFFF`;
export const BTN_LOCK = `#CCC`;

// 按钮或card元素的边框。
export const BASIC_BORDER = `#EAECEF`;


// 设置图片尺寸（自定义size）
export const setImageSize = (w = 24, h = 0) => {
	const _h = h > 0 ? h : w;
	return {
		width: `${w}px`,
		// 若为设置h值，则视为高=宽
		height: `${_h}px`,
	};
};