import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import md5 from '@/common/md5.min.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

import * as mock from '@/common/mock.js';


// export const HOST = `api.capitalgrou.top`.trim();
export const HOST = `api.jxwqstop.top`.trim();

export const BASE_URL = `https://${HOST}`.trim();
// export const WS_COIN_URL = `wss://ws.bxcoinws.top/ws`; // coin
export const WS_OTHER_URL = `wss://${HOST}/zonghe`.trim(); // 币

const CODE = "Qwd3N5yp";

// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;
		return true;
	} catch (err) {
		throw err
	}
}

export async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();
	if (!result) {
		return {
			message: translate(Msg.API_NETWORKNO)
		};
	} else {
		// console.log('url:', url, 'params:', params);
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": uni.getStorageSync('locale') || 'en', // 'zh-Hans'
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();
		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);
		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}?sign=${mdd}&t=${time}`;
		try {
			const response = await uni.request({
				url: `${fmtAPIURL}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});
			uni.hideLoading();
			const [err, res] = response;
			// console.log('err:', err, 'res:', res);

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					uni.removeStorageSync('token'); // 只移除token的缓存
					uni.showToast({
						title: translate(Msg.API_TOKEN_EXPIRES),
						icon: 'none'
					})
					setTimeout(() => {
						linkTo.signIn();
					}, 1000);
					return null;
				}
				// console.log('res:', res);
				// console.log('res.data:', res.data);
				if (res.data) {
					// console.log('res.data:', res.data);
					if (res.data.code == 0) {
						// console.log('res.data.data:', res.data.data);
						return res.data.data || null;

					} else {
						uni.showToast({
							title: !res.data.message ? res.message : res.data.message,
							icon: 'none'
						})
						return null;
					}
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: err.errMsg || translate(Msg.API_HTTP_ERROR),
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
export const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

export const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}


// 图片上传
export async function uploadImage(val) {
	// console.log(val)
	uni.showLoading({
		title: translate(Msg.API_UPLOAD),
	})
	let Request = "Qwd3N5yp"
	let time = parseInt(new Date().getTime() / 1000)
	let str_url = ("/api/app/upload").toLowerCase()
	let mdd = md5("XPFXMedS" + Request + str_url + time);

	const result = await uni.uploadFile({
		url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
		filePath: val,
		name: 'file',
	});
	// console.log('result:', result);
	uni.hideLoading();
	if (result[1].statusCode == 200) {
		const temp = JSON.parse(result[1].data);
		// console.log('temp:', temp);
		// this.obverseUrl = temp[0].url;
		return temp[0].url;
	} else {
		return null;
	}
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
});

// 完整账户信息
export const getAccount = async () => {
	const result = await get(`api/user/info`);
	if (!result) return false;
	return result;
}

// 精简账户信息
export const getAccountFast = async () => {
	const result = await get(`api/user/fastInfo`);
	if (!result) return false;
	return result;
}


export const getDepositRecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/recharge`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc_type,
			sn: item.order_sn,
			// reason:item.reason,
			status: item.status,
			// 以下为接口中本不含有的字段
			after: item.after * 1 || 0,
			type: `银联`,

		}
	});
}

export const getWithdrawRecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/withdraw`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc_type,
			sn: item.order_sn,
			reason: item.reason,
			status: item.status,
			id: item.id,
			// 以下为接口中本不含有的字段
			after: item.after * 1 || 0,
			type: `银联`,
		}
	});
}

export const getWithdrawCancel = async (val) => {
	uni.showLoading({
		title: translate(Msg.API_SUBMITING),
	});
	const result = await post(`api/app/qx`, {
		id: val
	});
	if (!result) return false;
	console.log(result);
	return result;
}

export const getSearch = async (keyword = '', type) => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/product/list`, {
		key: keyword,
		page: 1,
		limit: 30,
		gp_index: type
	});
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(item => {
		if (item.gid && item.gid > 0) {
			return {
				id: item.gid,
				logo: item.logo || '',
				name: item.name || '',
				code: item.code || '',
				price: item.current_price || 0,
				rate: item.rate || 0,
				rateNum: item.rate_num || 0,
				type_id: item.project_type_id || 0,
			}
		}
	});
}

export const getTrack = async (val = 0) => {
	const result = await get(`api/user/collect_list`, {
		current: val
	});
	if (!result) return false;
	return result.list.map(item => {
		return {
			logo: item.goods.logo,
			name: item.goods.name,
			code: item.goods.code,
			price: item.goods.current_price * 1 || 0,
			rate: item.goods.rate * 1 || 0,
			rateNum: item.goods.rate_num || 0,
		}
	});
}

// =========================================
//       以下是模拟数据, 需联调接口数据
// ==========================================

// home 理财速递
export const getFinanceNews = async () => {
	const result = await mock.getFinanceNews();
	if (!result) return false;
	console.log(result);
	return result;
}

// 首页曲线图数据
export const getHomeCurves = async () => {
	const result = await mock.getHomeCurves();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 指数 市场概述
export const getKPIDashboardDetail = async () => {
	const result = await mock.getKPIDashboardDetail();
	if (!result) return false;
	console.log(result);
	return result;
}


// 市场 沪深 全市场
export const getHSALL = async () => {
	const result = await mock.getHSALL();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 顶部数据
export const getHSBest = async () => {
	const result = await mock.getHSBest();
	if (!result) return false;
	console.log(result);
	return result;
}

// 交易页面 最新数据
export const getLatests = async (val = '') => {
	console.log(val);
	const result = await mock.getLatests();
	if (!result) return false;
	console.log(result);
	return result;
}
export const getRanking = async (val = '') => {
	console.log(val);
	const result = await mock.getRanking();
	if (!result) return false;
	console.log(result);
	return result;
}

// AH 比价
export const getAH = async () => {
	const result = await mock.getAH();
	if (!result) return false;
	console.log(result);
	return result;
}

// 数据中心 顶部数据
export const getDataCenterTop = async () => {
	const result = await mock.getDataCenterTop();
	if (!result) return false;
	console.log(result);
	return result;
}

// 数据中心 列表数据
export const getDateCenterList = async () => {
	const result = await mock.getDateCenterList();
	if (!result) return false;
	console.log(result);
	return result;
}

// 沪深ETF
export const getHSETF = async () => {
	const result = await mock.getHSETF();
	if (!result) return false;
	console.log(result);
	return result;
}

// 龙虎榜
export const getLongHu = async () => {
	const result = await mock.getLongHu();
	if (!result) return false;
	console.log(result);
	return result;
}

// 资金流向
export const getDashboard = async () => {
	const result = await mock.getDashboard();
	if (!result) return false;
	console.log(result);
	return result;
}

// 次新股
export const getRecent = async () => {
	const result = await mock.getRecent();
	if (!result) return false;
	console.log(result);
	return result;
}

// 大盘风向
export const getTrend = async () => {
	const result = await mock.getTrend();
	if (!result) return false;
	console.log(result);
	return result;
}

// 仅麒麟研报
export const getReport = async () => {
	const result = await mock.getReport();
	if (!result) return false;
	console.log(result);
	return result;
}

// 仅麒麟榜单 最佳&精英 (传参选中年份)
export const getReporeRanking = async (val = '') => {
	const result = await mock.getReporeRanking();
	if (!result) return false;
	console.log(result);
	return result;
}
// 仅麒麟研报 未来之星 (传参选中年份)
export const getReportStar = async (val = '') => {
	const result = await mock.getReportStar();
	if (!result) return false;
	console.log(result);
	return result;
}

// 持仓 投资收益
export const getROI = async () => {
	const result = await mock.getROI();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 资金流向
export const getFundFlow = async () => {
	const result = await mock.getFundFlow();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 涨幅分布详情数据
export const getPMDDetail = async () => {
	const result = await mock.getPMDDetail();
	if (!result) return false;
	console.log(result);
	return result;
}


// 市场通用页面列表数据
export const getMarketCommons = async (val = '') => {
	console.log(val);
	// 此处需根据传入的api，处理不同的接口请求，并将数据格式化为统一格式渲染
	const result = await mock.getMarketCommons();
	if (!result) return false;
	console.log(result);
	return result;
}







//  热点资讯
export const getNews = async (val = 0) => {
	const result = await get(`api/goods/get_news`, {
		current: val
	});
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(item => {
		return {
			title: item.title,
			url: item.url,
			dt: item.created_at,
			pic: item.pic,
			origin: `21世纪经济报道`,
			read: 99,
		}
	});
};

export const getGoodsTop = async (val = 0) => {
	const result = await get(`api/goods/top1`, {
		// current1: this.current1,
		// stockid: this.klineindex , stockId: 141,
	});
	console.log(result);
	return result;
	// this.top1 = result.top1 // 三个数据
	// this.article = result.article; // 8个新闻
	// this.industryList = result.bottom; // 16条数据
}



export const getStocks = async (val = 0) => {
	const result = await get(`api/goods/top1`, {
		// current: 0,
		gp_index: val,
	});
	if (!result) return false;
	const temp = result.top1.length <= 0 ? [] : result.top1.filter(item => item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.name,
			code: item.code,
			rate: item.rate * 1 || 0,
			price: item.current_price * 1 || 0,
			rateNum: item.rate_num * 1 || 0,
			type: item.project_type_id,
		}
	});
};

export const getPaiHang = async (val = 0) => {
	const result = await get(`api/goods/paihang`, {
		gp_index: val
	});
	console.log(result);
	if (!result) return false;
	const temp = result.length <= 0 ? [] : result.filter(item => item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.name,
			code: item.code,
			rate: item.rate * 1 || 0,
			price: item.current_price * 1 || 0,
			rateNum: item.rate_num * 1 || 0,
			type: item.project_type_id,
		}
	});
}

export const getMarketKPI = async (val = 0) => {
	const result = await get(`api/goods/zhibiao`, {
		current: val
	});
	if (!result) return false;
	const temp = Object.values(result).length <= 0 ? [] : Object.values(result).filter(item => item.gid > 0);
	return temp.map(item => {
		return {
			logo: item.logo,
			name: item.ko_name,
			code: item.code,
			price: item.close * 1 || 0,
			rate: item.returns * 1 || 0,
			follow: item.sc,
			gid: item.gid,
			close: item.close,
		}
	});
}



// export const getFuture = async (val = 0) => {
// 	const result = await get(`api/goods/zhibiao`, {
// 		current: val
// 	});
// 	if (!result) return false;
// 	return result;
// }



// export const getCurrency = async (val = 0) => {
// 	const result = await get(`api/goods/zhibiao`, {
// 		current: val
// 	});
// 	if (!result) return false;
// }

export const getNotifys = async (val = 0) => {
	// uni.showLoading({
	// 	title: format.text(i18n.t('api.requestData')),
	// });

	// const result =
	return [];
}

export const getFlowTrade = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/finance`);
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(item => {
		return {
			after: item.after * 1 || 0,
			before: item.before * 1 || 0,
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc,
		}
	});
}



export const getAIApplys = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/rinei/sq-list`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			status: item.status,
			statusTxt: item.zt,
			money: item.money * 1 || 0,
			success: item.success * 1 || 0,
			dt: item.created_at,
			sn: item.ordersn,
		}
	});
}

export const getAISuccess = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/rinei/order-list`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			status: item.status,
			statusTxt: item.zt, // translate(Msg.COMMON_SUCCESS)
			price: item.price * 1 || 0,
			money: item.money * 1 || 0,
			success: item.success * 1 || 0,
			dt: item.created_at,
			sn: item.ordersn,
		}
	});
}

export const getBlockGoods = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goods-bigbill/list`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			logo: item.goods.logo,
			name: item.goods.name,
			code: item.goods.code,
			current_price: item.goods.current_price * 1 || 0,
			id: item.id,
			price: item.price * 1 || 0,
			rate_num: item.goods.rate_num * 1 || 0,
			rate: item.goods.rate * 1 || 0,
			min_num: item.min_num * 1 || 0,
			max_num: item.max_num * 1 || 0,
			type: item.goods.project_type_id,
			password: item.password,
		}
	});
}

export const getBlockRecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goods-bigbill/user-order-log`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			num: item.num * 1 || 0,
			price: item.price * 1 || 0,
			current_price: item.goods.current_price * 1 || 0,
			amount: item.amount * 1 || 0,
			rate_num: item.goods.rate_num * 1 || 0,
			rate: item.goods.rate * 1 || 0,
			pl: item.yingkui * 1 || 0,
			floatPL: item.float_yingkui * 1 || 0,
			fee: item.buy_fee * 1 || 0,
			lever: item.double * 1 || 1,
			dt: item.created_at,
			desc: item.desc,
			type: item.goods.project_type_id,
			status: item.status,
		}
	});
}

export const getIPOGoods = async () => {
	const result = await mock.getIPOGoods();
	if (!result) return false;
	console.log(result);
	return result;

	// uni.showLoading({
	// 	title: translate(Msg.API_REQUEST_DATA),
	// })
	// const result = await get(`api/goods-shengou/calendar`);
	// if (!result) return false;
	// console.log(result);
	// const temp = !result || result.filter(item => item.gid && item.gid > 0);
	// return !temp || temp.length <= 0 ? [] : temp.map(item => {
	// 	return {
	// 		name: item.goods.name,
	// 		code: item.goods.code,
	// 		id: item.id,
	// 		price: item.price * 1 || 0,
	// 		// 发行金额
	// 		issuanceAmount: item.fa_amount * 1 || 0,
	// 		subDT: item.shengou_date,
	// 		onlieDT: item.online_date,
	// 		type: item.goods.project_type_id,
	// 	}
	// });
}

export const getIPOApplys = async () => {
	const result = await mock.getIPOApplys();
	if (!result) return false;
	console.log(result);
	return result;
	
	// uni.showLoading({
	// 	title: translate(Msg.API_REQUEST_DATA),
	// })
	// const result = await get(`api/goods-shengou/user-all-apply-log`);
	// if (!result) return false;
	// console.log(result);
	// const temp = !result || result.filter(item => item.gid && item.gid > 0);
	// return !temp || temp.length <= 0 ? [] : temp.map(item => {
	// 	return {
	// 		name: item.goods.name,
	// 		code: item.goods.code,
	// 		id: item.id,
	// 		type: item.goods.project_type_id,
	// 		price: item.price * 1 || 0,
	// 		applyQTY: item.apply_amount * 1 || 0, // 申购数量
	// 		applyAmount: item.apply_num_amount * 1 || 0,
	// 		msg: item.message,
	// 		// success: item.success, // 中签数
	// 		// successAmount: item.success_num_amount,
	// 		// total: item.total, // 总金额
	// 		// freeze:item.freeze, // 已认缴金额
	// 		sn: item.order_sn,
	// 		dt: item.created_at,
	// 		// 0：未中签，1:申购中，2：申购中签，3：已认缴金额，4：中签弃奖，5已上市	
	// 		// status:item.status,
	// 	}
	// });
}

export const getIPOSuccess = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goods-shengou/user-success-log`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			id: item.id,
			price: item.price * 1 || 0,
			applyAmount: item.apply_num_amount * 1 || 0,
			winning: item.success_num_amount * 1 || 0,
			success: item.success * 1 || 0,
			freeze: item.freeze * 1 || 0,
			unPayAmount: (item.success_num_amount * 1 - item.freeze * 1) * 1 || 0,
			sn: item.order_sn,
			dt: item.created_at,
			type: item.goods.project_type_id,
		}
	});
}

export const getIPOAlert = async () => {
	const result = await get(`api/goods-shengou/tanchuang`);
	if (!result) return false;
	console.log(result);
	if (result.length <= 0) return null;
	return {
		code: result[0].goods.code, // BAKAB
		name: result[0].goods.name, // Ambalaj
		success: result[0].success, // 100
		price: result[0].price, // 100
		total: result[0].success_num_amount, // success_num_amount
	}
}

export const getEAGoods = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/jijin/list`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.jj_list.filter(item => item.id && item.id > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			id: item.id,
			name: item.name,
			minAmount: item.min_price * 1 || 0,
			fudu: item.fudu * 1 || 0,
			syl: item.syl * 1 || 0,
			days: item.zhouqi * 1 || 0,
		}
	});
}

export const getEARecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/jijin/list`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.order.filter(item => item.id && item.id > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			id: item.id,
			name: item.goodname,
			price: item.price * 1 || 0,
			fudu: item.fudu * 1 || 0,
			syl: item.syl * 1 || 0,
			days: item.zhouqi * 1 || 0,
			sdt: item.time || '',
			edt: item.endtime || '',
			fee: item.shouxu_fee || 0,
		}
	});
}

export const getScrambleGoods = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	// api/goods-scramble/calendar
	const result = await get(`api/goods-scramble/calendar`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	// return !temp || temp.length <= 0 ? [] : temp.map(item => {
	// 	return {
	// 		name: item.goods.name,
	// 		code: item.goods.code,
	// 		id: item.id,
	// 		price: item.price * 1 || 0,
	// 		issuanceAmount: item.fa_amount * 1 || 0,
	// 		type: item.goods.project_type_id,
	// 	}
	// });
	return [{
		id: 1,
		name: `巨轮智能`,
		code: `sz002031`,
		price: 44378.43,
		rate: 36.79,
		rateNum: 153.79,
		dt: `2024-01-20`,
		type: 1
	}, {
		id: 1,
		name: `巨轮智能`,
		code: `sz002031`,
		price: 44378.43,
		rate: -36.79,
		rateNum: 153.79,
		dt: `2024-01-20`,
		type: 1
	}];
}


export const getScrambleApplys = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goodsscramble/userApplyLog`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			id: item.id,
			price: item.scramble.price || 0,
			applyAmount: item.apply_amount * 1 || 0,
			success: item.success * 1 || 0,
			total: item.total * 1 || 0,
			sn: item.order_sn,
			dt: item.created_at,
			type: item.goods.project_type_id,
		}
	});
}

export const getScrambleSuccess = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goods-shengou/user-success-log`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			id: item.id,
			price: item.price * 1 || 0,
			applyAmount: item.apply_amount * 1 || 0,
			winning: item.success_num_amount * 1 || 0,
			success: item.success * 1 || 0,
			sn: item.order_sn,
			dt: item.created_at,
			type: item.goods.project_type_id,
		}
	});
}

export const getDetail = async (symbol, line) => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/product/info`, {
		code: symbol,
		time_index: line
	});
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? null :
		!result[0].gid ? null : result[0];
}

// 获取当前crypto kline历史数据
export const getKlineData = async (symbol, line, type) => {
	const result = await get(`api/product/lishi`, {
		code: symbol,
		ac_time: line,
		project_type_id: type,
	})
	if (!result) return false;
	result.forEach(item => {
		item.volume = item.vol || 0;
	})
	return result;
}

// 获取配置
export const getconfig = async () => {
	const result = await get(`api/app/config`);
	console.log(`config result:`, result);
	const temp = result.reduce((map, item) => {
		map.set(item.key, item.value);
		return map;
	}, new Map());
	return temp.get('TransRate') * 1;
}