// constants.js 常量。 全局唯一硬编码
// use  $C.DARK or Vue.prototype.$C

// market/index  api/goods/list 所需
export const GPINDEX = {
	de: 1,
	us: 2,
	// crypto: 1, // crypto 接口 gp_index: 1,
	// future: 2, // 期货
	// forex: 3, // forex gp_index: 3 外汇
	// usstock: 4, // gp_index: 4 美股
	// ukstock: 6, // gp_index: 6 英股
	// eustock: 7, // gp_index: 7 欧股
	// 8和9是指标 指标是不能购买
};

export const KEY_HS = `hs`; // 滬深
export const KEY_KPI = `kpi`; // 指數
export const KEY_HK = `hk`; // 港股
export const KEY_US = `us`; // 美股

// position tabs
export const KEY_ROI = `roi`;
export const KEY_HOLD = `hold`;
export const KEY_RECORD = `record`;


export const KEY_FUTURE = `future`;
export const KEY_MARKET_ALL = `all`;
export const KEY_US_KPI = `uskpi`;
export const KEY_US_ETF = `usetf`;
export const KEY_US_PLATE = `plate`;
export const KEY_GEM = `gem`;


// 默认 语言
export const DEF_LANG = 'English';

export const KEY_LEFT = `left`;
export const KEY_RIGHT = `right`;

// 明文格式化模式 
// 标题或重要标签 每个单词首字母大写 （Title Case）
export const TITLE_CASE = "title";
// 一般描述文本 首个单词首字母大写 （Sentence Case）
export const SENTENCE_CASE = "sentence";

// 项目header的多种布局模式
export const HEADER_1 = `first`;
export const HEADER_2 = `second`;
export const HEADER_3 = `third`;

export const KEY_HOME = `home`;
export const KEY_MARKET = "market";
export const KEY_TRADE = `trade`;
export const KEY_POSITION = `position`;
export const KEY_ACCOUNT = `account`;

export const KEY_TAB_REPORT = `report`;
export const KEY_TAB_REPORTS = `reports`;
export const KEY_REPORT_TAB_BEST = `best`;
export const KEY_REPORT_TAB_ELITE = `elite`;
export const KEY_REPORT_TAB_STAR = `star`;

export const KEY_PER_TAB_HOME = `home`;
export const KEY_PER_TAB_FCST = `fcst`;
export const KEY_PER_TAB_QR = `qr`;
export const KEY_PER_TAB_PEND = `pend`;
export const KEY_PER_TAB_RELEASED = `Released`;
export const KEY_PER_HOME_ALL = `all`;
export const KEY_PER_HOME_TRACK = `track`;
export const KEY_PER_HOME_CPU = `cpu`;
export const KEY_PER_HOME_BJE = `bjexchange`;
export const KEY_PER_HOME_GEM = `gem`;
export const KEY_PER_HOME_ST = `st`;


// market key
export const KEY_INDEX = `index`;
export const KEY_RISELOSS = `riseloss`;
export const KEY_TRACK = `track`;

export const KEY_CURRENCY = `currency`;


export const KEY_DEPOSIT = `deposit`;
export const KEY_WITHDRAW = `withdraw`;

// ai 
export const KEY_GOODS = `goods`;
export const KEY_APPLY = `apply`;
export const KEY_SUCCESS = `success`;



export const KEY_AUTH = `auth`;
export const KEY_BANK = `bank`;
export const KEY_PWD = `pwd`;
export const KEY_PAY = `pay`;
export const KEY_FLOW = `flow`;