<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');
			uni.hideTabBar();
		},
		onShow: function() {
			console.log('App Show');
			uni.hideTabBar();
		},
		onHide: function() {
			console.log('App Hide');
			uni.hideTabBar();
		}
	}
</script>

<style lang="scss">
	@import "@/common/animate.css";
	@import "@/common/style.css";
	// @import "@/static/fonts/Roboto/index.css";
	@import "@/static/fonts/muli/index.css";
	// @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@100..900&display=swap');
	// @import url('https://fonts.googleapis.com/css2?family=Arimo:ital,wght@0,400..700;1,400..700&display=swap');

	@font-face {
		font-family: 'SVN';
		font-weight: 700;
		font-style: normal;
		src: url('/static/fonts/svn_gilroy_bold.otf') format('truetype');
	}

	@font-face {
		font-family: 'SVN';
		font-weight: 500;
		font-style: normal;
		src: url('/static/fonts/svn_gilroy_medium.otf') format('truetype');
	}

	@font-face {
		font-family: 'SVN';
		font-weight: 800;
		font-style: normal;
		src: url('/static/fonts/svn_gilroy_semibold.otf') format('truetype');
	}


	@media screen and (max-device-width:375px) {
		page {
			width: 100vw;
		}
	}

	@media screen and (min-device-width:376px) and (max-device-width:750px) {
		page {
			width: 100vw;
			margin: 0 auto;
		}
	}

	@media screen and (min-device-width:751px) {
		page {
			width: 750px;
			margin: 0 auto;
		}
	}

	* {
		font-family: "SVN", Arial, sans-serif;
		font-optical-sizing: none;
		font-style: normal;
		box-sizing: border-box;
	}
</style>