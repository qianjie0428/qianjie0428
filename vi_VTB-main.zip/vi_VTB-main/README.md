# vi_unname

@ # $ % & * - + ( ) ~ ^ < > | \ { } [ ] = ! " ' : ; / ?

Noto Kufi Arabic

Krub

Noto Sans Devanagari

Shippori Antique B1

Noto Sans Syriac Eastern

Noto Serif Khitan Small Script