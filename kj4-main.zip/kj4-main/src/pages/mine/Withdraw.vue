<template>
  <div class="container page" style="background-color: #1b1b1b">
    <van-nav-bar :title="curLang.Withdrawal_Center" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
      <template #right>
        <span class="nav-right" @click="$router.push({ path: '/WithdrawRecord' })">{{ curLang.Withdrawal_record
          }}</span>
      </template>
    </van-nav-bar>
    <div class="main" style="padding-top: 24px">
      <div class="withdrawMoney">
        <span>{{ curLang.Withdrawal_amount }} (₩)</span>
        <div class="money">
          <div class="moneyNumber">
            <span class="moneyType"></span>
            <van-field v-model="withdraw_money" type="number" color="#FFF" style="background-color: transparent" />
          </div>
          <span class="all" @click="allMoeny()">{{ curLang.every }}</span>
        </div>
        <div style="height: 24px"></div>
        <span>{{ curLang.Please_enter_your_password }}</span>
        <div class="money">
          <div class="moneyNumber">
            <span class="moneyType"></span>
            <van-field v-model="withdraw_pwd" type="password" color="#FFF" style="background-color: transparent" />
          </div>
        </div>

        <div class="information">
          <div class="description">
            <van-popover v-model="showPopover" trigger="click">
              <div class="popover-body" style="padding: 10px">
                <p>
                  1. {{ curLang.Single_transaction_limit_Minimum }} {{ this.withdrawRole.min }} {{ curLang.worst_maximum }}
                  {{ this.withdrawRole.max }} {{ curLang.bad_people }}
                </p>
                <p>
                  2. {{ curLang.Number_of_withdrawals }}
                  {{ this.withdrawRole.num }} {{ curLang.nd_class }}
                </p>
                <p>
                  3. {{ curLang.Arrival_time }}
                </p>
              </div>
              <!-- <template #reference @click="withdrawInfo()">
                <van-icon name="info-o" />
                mô tả hạn ngạch
              </template> -->
            </van-popover>
          </div>

          <div class="balance">
            <span>{{ curLang.Balance }}:</span>
            <span class="number">{{ Math.trunc(this.userInfo.money) }}</span>
          </div>
        </div>
      </div>
      <van-button class="withdraw_btn" type="default" @click="doWithdraw()">{{ curLang.Withdrawal }}</van-button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器

      showPopover: false,
      withdraw_money: "",
      withdraw_pwd: "",
      userInfo: {},
      withdrawRole: {},
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    back() {
      return window.history.back();
    },
    getUserInfo() {
      this.$http({
        method: "get",
        url: "user_info",
      }).then((res) => {
        if (res.code === 200) { console.log(res)
          this.userInfo = res.data;
          this.name = res.data.name;
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getUserWithdrawRole() {
      this.$http({
        method: "get",
        url: "user_get_withdraw_role",
      }).then((res) => {
        if (res.code === 200) {
          this.withdrawRole = res.data;
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    allMoeny() {
      this.withdraw_money = parseInt(this.userInfo.money);
    },
    doWithdraw() {
      if (this.withdraw_money <= 0) {
        this.$toast(this.curLang.Please_enter_the_exact_amount);
        return false;
      } else {
        this.$http({
          method: "post",
          // 等待添加密码
          data: { money: this.withdraw_money, password: this.withdraw_pwd },
          url: "user_set_withdraw",
        }).then((res) => {
          if (res.code === 200) {
            console.log("res===🚀===>", res);
            // location.reload()
            this.$toast(res.msg);
            this.getUserInfo();
            this.getUserWithdrawRole();

            // 跳转到成功页面
            this.$router.push({ path: "/WithdrawSuccess" });
          } else if (res.code === 401) {
            this.$toast(res.msg);
          }
        });
      }
    },
    withdrawInfo() {
      this.showPopover = true;
    },
  },
  created() {
    if (!localStorage.getItem("token")) {
      this.$router.push({ path: "/Login" });
    } else {
      this.getUserInfo();
      this.getUserWithdrawRole();
    }

    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    // this.curCode = this.curLang.loginCode;
    // const temp = this.$locales.filter((item) => item.value == this.curLocale);
    // console.log(temp);
    // this.langName = temp[0].text;
  },
};
</script>

<style lang="less" scoped>
@import "../../assets/css/base.css";

.van-cell {
  font-size: 35px;
  line-height: 80px;
}

.container p {
  padding: 0 15px;
  margin-top: 15px;
  font-size: 30px;
  color: #ffcc99;
}

.container .main {
  display: flex;
  flex-direction: column;
  background-color: #1b1b1b;
  height: calc(100% - 50px);
  position: relative;
}

.container .main .withdrawMoney {
  display: flex;
  flex-direction: column;
  color: #ffcc99;
  padding: 0 20px;
  white-space: nowrap;
  font-size: 35px;
  background-color: #1b1b1b;
}

.container .main .withdrawMoney span {
  padding: 10px 0;
}

.container .main .withdrawMoney .money {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  border-bottom: 1px solid #ffcc99;
}

.container .main .withdrawMoney .money .moneyNumber {
  font-size: 50px;
  display: flex;
  flex-direction: row;
}

.container .main .withdrawMoney span {
  padding: 10px 0;
}

.container .main .withdrawMoney .money .all {
  color: #ffcc99;
}

.container .main .withdrawMoney .money .moneyNumber .van-cell {
  font-size: 50px;
  padding: 0 !important;
  color: #ffcc99;
}

:deep .van-field__control {
  color: #ffcc99 !important;
}

.container .main .withdrawMoney .information {
  padding-bottom: 30px;
}

.container .main .withdrawMoney .information .description {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 10px 0;
}

.container .main .withdrawMoney span {
  padding: 10px 0;
}

.container .main .withdrawMoney .information .balance .number {
  color: #ffcc99;
}

.withdraw_btn {
  margin: 20px 30px 0;
  height: 80px;
  line-height: 1.22667rem;
  border-radius: 50px;
  color: #ffcc99;
  font-size: 30px;
  font-weight: bolder;
  border: 1px solid #ffcc99;
  background-color: transparent;

  // background: linear-gradient(
  //     90deg,#e6c3a1,#7e5678);
}
</style>
