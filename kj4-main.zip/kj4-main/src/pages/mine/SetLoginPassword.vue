<template>
  <div class="container page" style="background-color: #1b1b1b;min-height: 100vh;">
    <van-nav-bar :title="curLang.Change_login_password" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
      <template #right>
        <!-- <span class="nav-right" @click="save()">완료</span> -->
      </template>
    </van-nav-bar>

    <div style="padding:20px;">
      <label style="color: #fff; font-size: 16px; font-weight: 700; line-height: 1.8">{{curLang.Please_enter_your_existing_password}}</label>
      <div class="custom_input">
        <input v-model="old_password" type="password" :placeholder="curLang.Please_enter_your_existing_password" />
      </div>
      <label style="color: #fff; font-size: 16px; font-weight: 700; line-height: 1.8">{{curLang.Enter_your_new_password}}</label>
      <div class="custom_input">
        <input v-model="o_new_password" type="password" :placeholder="curLang.Enter_your_new_password" />
      </div>
      <label style="color: #fff; font-size: 16px; font-weight: 700; line-height: 1.8">{{curLang.enter_your_new_password}}</label>
      <div class="custom_input">
        <input v-model="t_new_password" type="password" :placeholder="curLang.enter_your_new_password" />
      </div>

      <div style="margin-top: 50px;">
        <div style="padding: 10px;color: #e0ba92;border: #e0ba92 1px solid;border-radius: 30px;text-align: center;"
          @click="save()">{{curLang.complete}}</div>
      </div>

    </div>

    <!-- <van-cell-group>
      <van-field v-model="old_password" label="이전 비밀번호" placeholder="이전 비밀번호를 입력하세요" />
      <van-field v-model="o_new_password" label="새 비밀번호" placeholder="curLang.Enter_your_new_password" />
      <van-field v-model="t_new_password" label="새 비밀번호" placeholder="새 비밀번호를 다시 입력하세요" />
    </van-cell-group> -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器
      o_new_password: "",
      t_new_password: "",
      old_password: "",
      userInfo: {}
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    back() {
      return window.history.back();
    },
    save() {
      if (this.o_new_password === "" || this.o_new_password === null || this.o_new_password === undefined) {
        this.$toast.fail(this.curLang.Please_enter_your_password);
        return false;
      }
      if (this.t_new_password === "" || this.t_new_password === null || this.t_new_password === undefined) {
        this.$toast.fail(this.curLang.Please_enter_your_password);
        return false;
      }
      if (this.old_password === "" || this.old_password === null || this.old_password === undefined) {
        this.$toast.fail(this.curLang.Enter);
        return false;
      }
      if (this.o_new_password !== this.t_new_password) {
        this.$toast(this.curLang.The_two_passwords);
        return false;
      }
      this.$http({
        method: 'get',
        data: {
          old_password: this.old_password,
          new_password: this.o_new_password,
        },
        url: 'user_set_loginpw'
      }).then(res => {
        if (res.code === 200) {
          this.$toast(res.msg);
          setTimeout(() => {
            localStorage.clear()
            this.$router.push("Login")
          }, 500);

        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      })
    },
    getUserInfo() {
      this.$http({
        method: 'get',
        url: 'user_info'
      }).then(res => {
        if (res.code === 200) {
          this.userInfo = res.data;
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      })
    }
  },
  created() {
    if (!localStorage.getItem('token')) {
      this.$router.push({ path: '/Login' })
    } else {
      this.getUserInfo();
    }

    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    // this.curCode = this.curLang.loginCode;
    // const temp = this.$locales.filter((item) => item.value == this.curLocale);
    // console.log(temp);
    // this.langName = temp[0].text;
  }
};
</script>

<style lang='less' scoped>
.custom_input {
  margin-bottom: 20px;
  background-color: transparent;
  border: 1px solid #ffcc99;
  border-radius: 6px;
  height: 68px;
  line-height: 68px;
  padding-left: 24px;
  color: #fff;
}

.custom_input input {
  background-color: transparent;
  border: none;
  outline: none;
}

.custom_input input::placeholder {
  font-size: 24px;
}


@import "../../assets/css/base.css";

.van-cell {
  font-size: 35px;
  line-height: 80px;
}
</style>
