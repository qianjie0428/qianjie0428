<template>
  <div class="container page" style="background-color: #1b1b1b; min-height: 100vh">
    <van-nav-bar :title="curLang.Basic_information" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
    </van-nav-bar>
    <div class="main-content">
      <div @click="openHerderImg()" class="item van-hairline--bottom">
        <div class="left" style="color: #fff">{{ curLang.profile }}</div>
        <div class="right" style="color: #fff;max-width: 60px;">
          <template v-if="userInfo && userInfo.header_img">
            <img class="user_img" style="border-radius: 100%;" :src="getImageSrc(userInfo.header_img)" />
          </template>
          <template v-else>
            <img class="user_img" style="border-radius: 100%;" :src="getImageSrc(`1.jpg`)" />
          </template>
          <van-icon name="arrow" color="#FFF" />
        </div>
      </div>
      <van-popup v-model="show" position="bottom" round :style="{ height: '50%' }">
        <div class="avatarbox">
          <div class="title van-hairline--bottom">
            <van-icon @click="show = false" name="cross" />
            <div style="color: #1b1b1b;" class="text">{{ curLang.Choose_your_avatar }}</div>
            <div style="color: #1b1b1b;" class="btnok" @click="check()">{{ curLang.Of_course }}</div>
          </div>
          <div class="content" style="gap: 8px;">
            <img class="user_img" style="border-radius: 100%;width: 48px;" v-for="(item, index) in 30" :key="index"
              @click="select_header_img(`${index + 1}.jpg`)" :class="{ choose: isActive === `${index + 1}.jpg` }"
              :src="getImageSrc(`${index + 1}.jpg`)" />
          </div>
        </div>
      </van-popup>
      <!-- <div class="item van-hairline--bottom" @click="toSetName()">
        <div class="left" style="color: #fff">실명</div>
        <div class="right">
          <span class="desc">{{
            this.userInfo.name ? this.userInfo.name : "설정되지 않음"
          }}</span>
          <van-icon name="arrow" color="#FFF" />
        </div>
      </div> -->
      <div class="item van-hairline--bottom" @click="toSetSex()">
        <div class="left" style="color: #fff">{{ curLang.gender }}</div>
        <div class="right">
          <span class="desc">{{
            this.userInfo.sex !== "0"
              ? this.userInfo.sex === "1"
                ? curLang.man
                : curLang.female
              : curLang.Unknown
          }}</span>
          <van-icon name="arrow" color="#FFF" />
        </div>
      </div>
      <!-- <div class="item van-hairline--bottom" @click="toSetBank()">
        <div class="left" style="color: #fff">제약 정보</div>
        <div class="right">
          <span class="desc">{{ this.isBank ? "강제" : "결석" }}</span>
          <van-icon name="arrow" color="#FFF" />
        </div>
      </div> -->
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      curLocale: "", // 当前语言代码
      langName: "", // 当前语言
      showLocale: false, // 显示语言选择器
      isActive: false,
      show: false,
      isBank: false,
      userInfo: {},
    };
  },
  computed: {
    // 当前语言
    curLang() {
      console.log(`temp:`, this.$lang[this.curLocale]);
      return this.$lang[this.curLocale];
    },
  },
  methods: {
    getImageSrc(imageName) {
      console.log(imageName);
      // console.log(require(`@/assets/${imageName}`));
      // return require(`@/assets/${imageName}`);
      console.log(`${process.env.BASE_URL}img/${imageName}`);
      return `${process.env.BASE_URL}img/${imageName}`;
    },

    back() {
      return window.history.back();
    },
    // toSetName(){
    //   this.$router.push({path:'/Setname'});
    // },
    toSetBank() {
      this.$router.push({ path: "/Setbank" });
    },
    toSetSex() {
      this.$router.push({ path: "/Setsex" });
    },
    openHerderImg() {
      this.show = true;
    },
    select_header_img(url) {
      console.log(url);
      this.isActive = url;
    },
    check() {
      this.$http({
        method: "post",
        data: { header_img: this.isActive },
        url: "user_header_img",
      }).then((res) => {
        if (res.code === 200) {
          this.getUserInfo();
          this.$toast(res.msg);
          this.show = false;
          console.log(res);
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getUserInfo() {
      this.$http({
        method: "get",
        url: "user_info",
      }).then((res) => {
        if (res.code === 200) {
          this.userInfo = res.data;
          console.log(res);
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getUserBankInfo() {
      this.$http({
        method: "get",
        url: "user_get_bank",
      }).then((res) => {
        if (res.code === 200) {
          if (res.data.is_bank) {
            this.isBank = true;
          } else {
            this.isBank = false;
          }
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
  },
  created() {
    this.curLocale = localStorage.getItem("locale") || "ko-KR";
    this.curCode = this.curLang.loginCode;
    // const temp = this.$locales.filter((item) => item.value == this.curLocale);
    // console.log(temp);
    // this.langName = temp[0].text;

    if (!localStorage.getItem("token")) {
      this.$router.push({ path: "/Login" });
    } else {
      this.getUserInfo();
      this.getUserBankInfo();
    }
  },
};
</script>

<style lang="less" scoped>
@import "../../assets/css/base.css";

.container .main-content {
  padding: 0 20px;
  background-color: transparent;
}

.container .main-content .item {
  padding: 30px 0;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  font-size: 30px;
}

.container .main-content .item .right {
  display: flex;
  flex-direction: row;
  align-items: center;
}

.container .main-content .item .right img {
  width: 90px;
}

.container .main-content .van-hairline--bottom::after {
  border-bottom-width: 3px;
}

.container .main-content .item .right .desc-cell-number,
.container .main-content .item .right .desc {
  font-size: 30px;
  font-weight: 700;
  color: #ffcc99;
}

.avatarbox {
  padding: 15px;
  color: #fff;
  height: 81%;
  background-color: #fff;
}

.avatarbox .title {
  padding: 8px 10px 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  font-size: 28px;
}

.avatarbox .content .van-image {
  width: 105px;
  height: 105px;
  margin: 2.5%;
  border-radius: 50%;
}

.avatarbox .content {
  padding-bottom: 10px;
  height: 100%;
  overflow-y: auto;
  padding-top: 20px;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
}

.avatarbox .content .choose {
  width: 95px;
  height: 95px;
  border: 6px solid #e6c3a1;
}
</style>
