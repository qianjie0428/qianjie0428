export default {
  confirm: `확인`,
  cancel: `취소`,

  loginTitle: `BLACK PINK`,
  loginAccount: `계정`,
  loginEnterName: `계정을 입력해 주세요`,
  loginPwd: `비밀번호`,
  loginEnterPwd: `비밀번호를 입력해주세요`,
  loginCode: `인증코드`,
  loginForgotPwd: `비밀번호를 잊으셨습니까?`,
  loginTipSuccess: `로그인 성공`,
  loginTipLinkTo: `회원가입`,
  loginEnterCode: `인증번호를 입력해주세요`,
  loginCodeError: `인증코드 오류`,

  // register
  registerTitle: `회원가입`,
  registerAccount: `계정`,
  registerEnterName: `아이디를 입력하세요`,
  registerPwd: `비밀번호`,
  registerEnterPwd: `비밀번호를 입력해주세요`,
  registerPwd2: `비밀번호 확인`,
  registerEnterPwd2: `비밀번호 확인`,
  inviteCode: `초대코드`,
  enterInviteCode: `초대 코드를 입력하세요`,
  registerCode: `인증코드`,
  registerTipPwd: `두 번 입력한 비밀번호가 일치하지 않습니다.`,
  registerEnterCode: `인증번호를 입력해주세요`,
  registerCodeError: `인증코드 오류`,

  //首页
  charge: `충전`,
  profile: '프로필',
  moonshine: 'BLACK PINK에 오신걸 환영합니다',
  Date_Mission: '데이트 미션',
  see_more: '더 보기',
  Cinema_Recommendations: '시네마 추천',
  Popular_Cinema: '인기 시네마',
  success: '성공',
  Mission: '미션',

  //游戏
  Data_Mission: '데이트 미션',
  Install: '데이터 미션',
  Scroll_down_to_refresh: '새로 고치려면 아래로 스크롤하세요',
  Install: '로딩 중',

  //电影
  Cinema: '시네마',
  No_more: '더 이상',

  //投注
  Betting_history: '배팅 내역',
  reservation: '예약',
  Amount_held: '보유금액',
  one: '원',
  Current_selection: '현재 선택',
  Betting_Points: '배팅포인트',
  Please_enter_the_amount: '금액을 입력해주세요',
  gun: '총',
  memo: '메모',
  ship: '배',
  cancellation: '취소',
  check: '확인',
  Round: '회차',
  winning_numbers: '당첨 번호',
  big: '대',
  cow: '소',
  match: '짝',
  hall: '홀',

  //底部按钮
  home: '홈',
  footer_game: '미션',
  footer_choose: '출장만남',
  footer_video: '동영상',
  footer_mine: '계정',

  //选择
  count: '세',
  Cup_Size: '컵 사이즈',
  Click_to_reserve_a_business_trip_meeting: '출장만남 예약클릭',
  You_must_gothrough_the_authentication_process_to_use_it:'인증절차를 받으셔야 이용하실수 있습니다',

  //我的
  charge: '충전',
  Withdrawal: '출금',
  More_information: '상세 정보',
  Balance: '잔액',
  Set_login_password: '로그인 비번 설정',
  Set_payment_password: '결제 비번 설정',
  Bank_account: '은행 계좌',
  Betting_history: '배팅 기록',
  Personal_information: '개인 정보',
  Announcement: '공지 사항',
  log_out: '로그아웃',
  Card_number: '카드 번호',
  Please_enter_your_cardnumber: '카드 번호를 입력하세요',
  name: '이름',
  money: '돈',
  Enter_the_deposit_amount: '입금 금액을 입력하세요',
  Enter_the_amount: '금액을 입력하세요',
  Submitte_for_review: '검토를 위해 제출됨',
  Please_contact_our_customer_service_department: '고객 서비스 부서에 문의하세요',
  Loading: '로딩 중',
  Create_and_enter_your_task_list: '작업 목록을 작성하고 입력하세요',
  Please_contact_the_person_in_charge: '담당자에게 문의해주세요',
  Set_up_your_payment_card: '결제 카드를 설정하세요!',
  CSKH:'CSKH에 도움을 요청하세요!',
  Offline_account:'오프라인 계정',
  Login_Sign_up:'로그인/회원가입',
  Log_in_to_enjoy_more_services:'로그인하여 더 많은 서비스를 이용하세요!',

  //提现
  Withdrawal_Center:'출금센터',
  Withdrawal_record:'출금기록',
  Withdrawal_amount:'출금금액',
  every:'모두',
  Please_enter_your_password:'비밀번호를 입력하세요',
  Single_transaction_limit_Minimum:'단일 거래 한도: 최소',
  worst_maximum:'최악, 최대',
  bad_people:'나쁜 사람들',
  Number_of_withdrawals:'인출 횟수: 같은 날의 최대 인출 횟수',
  nd_class:'2등실',
  Arrival_time:'도착 시간: 일반적으로 도착 시간은 약 5분이며, 가장 빠른 도착 시간은 2분입니다.',
  Balance:'잔액',
  Please_enter_the_exact_amount:'정확한 금액을 입력해주세요',

  Gender_Correction:'성별 수정',
  man:'남자',
  female:'여자',

  //修改登录密码
  Change_login_password:'로그인 비밀번호 변경',
  Please_enter_your_existing_password:'기존 비밀번호를 입력하세요',
  Enter_your_new_password:'새 비밀번호를 입력하세요',
  enter_your_new_password:'새 비밀번호를 재입력하세요',
  complete:'완료',
  Please_enter_your_password:'비밀번호를 입력하세요!',
  Enter:'입력하세요!',
  The_two_passwords:'입력한 두 개의 비밀번호가 일치하지 않습니다',

  //设置支付密码
  Set_payment_password:'결제 비밀번호 설정',
  Please_enter_your_payment_password:'결제 비밀번호를 입력하세요',
  Please_re_enter:'결제 비밀번호를 다시 입력하세요',
  check:'확인',
  Please_complete_it:'완료해주세요',
  The_two_passwords_do_not_match:'두 비밀번호가 일치하지 않습니다!',

  //绑定银行卡
  Bank_account_information:'은행계좌정보',
  Add_a_payment_bank_account:'결제 은행계좌를 추가하세요',
  Bank_name:'은행명',
  Depositor_s_name:'예금주명',
  Bank_account_number:'은행 계좌번호',
  NOTE:'주의: 변경이 필요하신 경우 온라인 고객 센터로 문의 부탁드립니다',
  Please_set_up_a:'은행 카드를 연결하기 전에 출금 비밀번호를 설정하세요!',

  //投注详情
  Betting_history:'배팅내역',
  Amount_bet:'배팅한 금액',
  Time_of_betting:'배팅한 시간',
  End_time:'종료 시간',

  //个人信息
  Basic_information:'기본 정보',
  Choose_your_avatar:'아바타를 선택하세요',
  Of_course:'확인',
  gender:'성별',
  Unknown:'알 수 없음',
  setting:'설정',
  Set_basic_information:'기본 정보 설정',
  Login_Password:'로그인 비밀번호',
  Fund_Password:'자금 비밀번호',
  log_out:'로그아웃',
  Your_password_has:'비밀번호 설정이 완료되었습니다. 비밀번호를 수정해야 하는 경우 고객 서비스에 문의하세요',
  Be_prepared:'준비되다',
  Not_set:'설정되지 않음',

  //公告
  No_message:'메시지 없음',


  writing:"추첨중",



};
