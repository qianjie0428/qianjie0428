export default {
  confirm: `Confirm`,
  cancel: `Cancel`,

  loginTitle: `Login`,
  loginAccount: `Account`,
  loginEnterName: `Please enter your account`,
  loginPwd: `Password`,
  loginEnterPwd: `Please enter your password`,
  loginCode: `Code`,
  loginForgotPwd: `Forgot your password?`,
  loginTipSuccess: `Login successful`,
  loginTipLinkTo: `Sign up`,
  loginEnterCode: `Please enter the verification code`,
  loginCodeError: `Verification code error`,

  //首页
  charge: `Charge`,
  profile:'Profile',
  moonshine:'Moonshine',
  Date_Mission:'Date Mission',
  see_more:'See More',
  Cinema_Recommendations:'Cinema Recommendations',
  Popular_Cinema:'Popular Cinema',
  success:'Success',
  Mission:'Mission',

  //游戏
  Data_Mission:'Data Mission',
  Install:'Install',
  Scroll_down_to_refresh:'Scroll down to refresh',
  Loading:'Loading',

  //电影
  Cinema:'Cinema',
  No_more:'No more',

  //投注
  Betting_history:'Betting History',
  reservation:'Reservation',
  Amount_held:'Amount Held',
  one:'One',
  Current_selection:'Current Selection',
  Betting_Points:'Betting Points',
  Please_enter_the_amount:'Please enter the amount',
  gun:'Gun',
  memo:'Memo',
  ship:'Ship',
  cancellation:'Cancellation',
  check:'Check',
  Round:'Round',
  winning_numbers:'Winning_Numbers',
  big:'Big',
  cow:'Cow',
  match:'Match',
  Hall:'hall',

  //底部按钮
  home: '홈',
  footer_game: 'Game',
  footer_choose: 'Choose',
  footer_video: 'Video',
  footer_mine: 'Mine',

  //选择
  count: 'Count',
  Cup_Size: 'Cup Size',
  Click_to_reserve_a_business_trip_meeting: 'Click to reserve a business trip meeting',
  You_must_gothrough_the_authentication_process_to_use_it: 'You must go through the authentication process to use it.',

  //我的
  charge: 'Charge',
  Withdrawal:'Withdrawal',
  More_information: 'More Information',
  Balance: 'Balance',
  Set_login_password: 'Set login password',
  Set_payment_password: 'Set payment password',
  Bank_account: 'Bank Account',
  Betting_history:'Betting History',
  Personal_information: 'Personal Information',
  announcement: 'Announcement',
  log_out: 'Log Out',
  Card_number: 'Card Number',
  Please_enter_your_card_number: 'Please enter your card number',
  name: 'Name',
  Enter_the_deposit_amount: 'Enter the deposit amount',
  Enter_the_amount: 'Enter the amount',
  Submitte_for_review: 'Submitted for review',
  Please_contact_our_customer_service_department: 'Please contact our customer service department',
  Loading: 'Loading',
  Create_and_enter_your_task_list: 'Create and enter your task list',
  Please_contact_the_person_in_charge: 'Please contact the person in charge',
  Set_up_your_payment_card: 'Set up your payment card!',
  CSKH:'Ask CSKH for help!',
  Offline_account:'Offline Account',
  Login_Sign_up:'Login/Sign up',
  Log_in_to_enjoy_more_services:'Log in to enjoy more services!',

  //提现
  Withdrawal_Center:'Withdrawal Center',
  Withdrawal_record:'Withdrawal Record',
  Withdrawal_Amount:'Withdrawal Amount',
  every:'Every',
  Please_enter_your_password:'Please enter your password',
  Single_transaction_limit_Minimum:'Single transaction limit: Minimum',
  worst_maximum:'worst, maximum',
  bad_people:'bad people',
  Number_of_withdrawals:'Number of withdrawals: Maximum number of withdrawals on the same day',
  nd_class:'2nd class',
  Arrival_time:'Arrival time: Typically arrival time is around 5 minutes, with the fastest arrival time being 2 minutes.',
  Balance:'Balance',
  Please_enter_the_exact_amount:'Please enter the exact amount',

  Gender_Correction:'Gender Correction',
  man:'Man',
  female:'Female',

  //修改登录密码
  Change_login_password:'Change login password',
  Please_enter_your_existing_password:'Please enter your existing password',
  Enter_your_new_password:'Enter your new password',
  enter_your_new_password:'Re-enter your new password',
  complete:'Complete',
  Please_enter_your_password:'Please enter your password!',
  Enter:'Enter!',
  The_two_passwords:'The two passwords you entered do not match',

  //设置支付密码
  Set_payment_password:'Set payment password',
  Please_enter_your_payment_password:'Please enter your payment password',
  Please_re_enter:'Please re-enter your payment password',
  check:'Check',
  Please_complete_it:'Please complete it',
  The_two_passwords_do_not_match:'The two passwords do not match!',

  //绑定银行卡
  Bank_account_information:'Bank account information',
  Add_a_payment_bank_account:'Add a payment bank account',
  Bank_name:'Bank Name',
  Depositor_s_name:'Depositor s name',
  Bank_account_number:'Bank account number',
  Bank_name:'NOTE: If you need to make changes, please contact our online customer center.',
  Please_set_up_a:'Please set up a withdrawal password before linking your bank card!',

  //投注详情
  Betting_history:'Betting history',
  Amount_bet:'Amount Bet',
  Time_of_betting:'Time of betting',
  End_time:'End Time',

  //个人信息
  Basic_information:'Basic Information',
  Choose_your_avatar:'Choose your avatar',
  Of_course:'Of Course',
  gender:'Gender',
  Unknown:'Unknown',
  setting:'Setting',
  Set_basic_information:'Set basic information',
  Login_Password:'Login Password',
  Fund_Password:'Fund Password',
  log_out:'log out',
  Your_password_has:'Your password has been set. If you need to change your password, please contact customer service.',
  Be_prepared:'Be Prepared',
  Not_set:'Not Set',

  //公告
  No_message:'No Message',




};
