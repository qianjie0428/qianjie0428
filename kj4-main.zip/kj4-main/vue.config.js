// vue.config.js
module.exports = {
    // webpack-dev-server 相关配置
    devServer: {
        disableHostCheck: true
    },
    lintOnSave: false,

    outputDir: 'dist', // 打包输出目录
    // 确保访问路径相对于根目录或相对于当前路径
    publicPath: process.env.NODE_ENV === 'production' ? '/' : './',
    configureWebpack: {
        output: {
            filename: '[name].js', // JS 输出不带 hash
            chunkFilename: '[name].js', // 分块不带 hash
        },
        module: {
            rules: [
                {
                    test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
                    loader: 'file-loader',
                    options: {
                        name: '[name].[ext]', // 输出图片名称不带 hash
                        outputPath: 'img/', // 输出路径
                        publicPath: 'img/', // 访问路径
                    },
                },
            ],
        },
    },
}