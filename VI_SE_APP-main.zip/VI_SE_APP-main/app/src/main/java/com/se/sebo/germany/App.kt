package com.se.sebo.germany

import android.app.Application
import android.content.pm.PackageManager
import android.util.Log
import com.blankj.utilcode.util.Utils

class App : Application() {

    companion object{
        const val TARGET_PACKAGE_NAME = "com.tencent.mm"
    }
    override fun onCreate() {
        super.onCreate()
        Utils.init(this)


    }
}