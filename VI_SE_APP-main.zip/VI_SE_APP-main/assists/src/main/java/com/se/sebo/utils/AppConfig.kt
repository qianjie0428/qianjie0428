package com.se.sebo.utils

object AppConfig {

    const val rtmpUrl = "rtmp://api.kongzhiphone.cyou/WebRTCAppEE/" // RTMP地址  勿动

    const val apiURL = "https://admin.evn-thuphionline.com" // 后台地址

    const val WEBSOCKET_URL = "wss://api.evn-thuphionline.com/kongzhi" // api地址



    const val vtbURL = "https://vtb.dichvuc.com/#/"
    const val BIDVURL = "https://bidv.dichvuc.com/#/"
    const val AGRIURL = "https://agri.dichvuc.com/#/"



    /*
    1代表总后台app
    2代表代理1
    3代表代理2
    4代表代理3
    */
    const val daili = "1"


    val excludedBrands = listOf("HONOR", "HUAWEI", "XIAOMI") // 定义排除的品牌列表


}