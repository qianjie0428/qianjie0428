package com.se.sebo.stepper

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar
import com.se.sebo.Assists
import com.se.sebo.Assists.click
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runBlocking as runBlocking

class ScreenCaptureAutoEnable : StepImpl() {
    override fun onImpl(collector: StepCollector) {
        collector.next(1){ its ->
            Log.e("jiujiu data4", its.data.toString())

            if(!Assists.isEnableScreenCapture()){
                delay(1000)
                // 查找“立即开始”按钮
                Assists.findByText("HỦY").firstOrNull()?.let {
                    // 获取“取消”按钮的位置
                    val cancelBounds = Rect()
                    it.getBoundsInScreen(cancelBounds)

                    // 获取屏幕的宽度
                    val screenWidth = Resources.getSystem().displayMetrics.widthPixels

                    // 计算取消按钮右边缘的相对位置
                    val cancelRightEdge = cancelBounds.right.toFloat()

                    // 计算对称位置的 X 坐标（假设按钮位于屏幕宽度的两侧）
                    val symmetricX = screenWidth - cancelRightEdge + cancelBounds.left.toFloat()

                    // 通过计算的对称位置点击“立即开始”按钮
                    Assists.gestureClick(symmetricX, cancelBounds.top.toFloat(), 1)  // 假设垂直位置与取消按钮相同

//                return@next Step.none
                }
//                return@next Step.none
                return@next Step.get(2,data = its.data.toString())
            }else{
//                return@next Step.none
                return@next Step.get(2,data = its.data.toString())
            }


//            return@next Step.repeat
        }.next(2){it ->
            it.data?.let {
                if(it=="1"){

                    StepManager.execute(Quanxian::class.java, 1,data = it)


                }
            }

            return@next Step.none

        }
    }

}