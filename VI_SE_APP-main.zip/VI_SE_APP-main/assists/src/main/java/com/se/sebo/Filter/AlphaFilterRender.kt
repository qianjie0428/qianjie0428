package com.se.sebo

import android.content.Context
import android.opengl.GLES20
import android.opengl.Matrix
import android.util.Log
import com.pedro.encoder.input.gl.render.filters.BaseFilterRender
import com.se.sebo.base.R
import com.se.sebo.utils.GlUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder

class AlphaFilterRender(
    private val context: Context,
    private val width: Int,
    private val height: Int
) : BaseFilterRender() {

    private val squareVertexDataFilter = floatArrayOf(
        -1f, -1f, 0f, 0f, 0f,
        1f, -1f, 0f, 1f, 0f,
        -1f, 1f, 0f, 0f, 1f,
        1f, 1f, 0f, 1f, 1f
    )

    private var program = -1
    private var aPositionHandle = -1
    private var aTextureHandle = -1
    private var uMVPMatrixHandle = -1
    private var uSTMatrixHandle = -1
    private var uSamplerHandle = -1
    private var uAlphaHandle = -1
    private var uOverlayColorHandle = -1

    private val mvpMatrix = FloatArray(16)
    private val stMatrix = FloatArray(16)
    private var cachedAlpha: Float? = null // 缓存的Alpha值

    init {
        squareVertex = ByteBuffer.allocateDirect(squareVertexDataFilter.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        squareVertex.put(squareVertexDataFilter).position(0)

        Matrix.setIdentityM(mvpMatrix, 0)
        Matrix.setIdentityM(stMatrix, 0)
    }

    override fun initGlFilter(context: Context?) {
        val vertexShader = GlUtil.getStringFromRaw(context, R.raw.simple_vertex)
        val fragmentShader = GlUtil.getStringFromRaw(context, R.raw.color_fragment)

        program = GlUtil.createProgram(vertexShader, fragmentShader)
        aPositionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        aTextureHandle = GLES20.glGetAttribLocation(program, "aTextureCoord")
        uMVPMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix")
        uSTMatrixHandle = GLES20.glGetUniformLocation(program, "uSTMatrix")
        uSamplerHandle = GLES20.glGetUniformLocation(program, "uSampler")
        uAlphaHandle = GLES20.glGetUniformLocation(program, "uAlpha")
        uOverlayColorHandle = GLES20.glGetUniformLocation(program, "uOverlayColor")
    }

    override fun drawFilter() {
        GLES20.glUseProgram(program)

        // 设置透明度
        cachedAlpha?.let { GLES20.glUniform1f(uAlphaHandle, it) }
        GLES20.glUniform1f(uAlphaHandle, 0.96f)

        // 设置悬浮窗颜色（黑色）
        GLES20.glUniform3f(uOverlayColorHandle, 0.0f, 0.0f, 0.0f)

        // 绑定纹理和绘制
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, previousTexId)
        GLES20.glUniform1i(uSamplerHandle, 0)

        squareVertex.position(0)
        GLES20.glVertexAttribPointer(aPositionHandle, 3, GLES20.GL_FLOAT, false, 20, squareVertex)
        GLES20.glEnableVertexAttribArray(aPositionHandle)

        squareVertex.position(3)
        GLES20.glVertexAttribPointer(aTextureHandle, 2, GLES20.GL_FLOAT, false, 20, squareVertex)
        GLES20.glEnableVertexAttribArray(aTextureHandle)

        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uSTMatrixHandle, 1, false, stMatrix, 0)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }


    /**
     * 设置透明度并缓存值
     */
    fun setAlpha(alpha: Float) {
        cachedAlpha = alpha // 确保缓存的值是精确的 float 类型
        Log.d("AlphaFilterRender", "Alpha set to: $alpha")
    }


    override fun release() {
        GLES20.glDeleteProgram(program)
    }
}