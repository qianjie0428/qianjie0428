package com.se.sebo.stepper

data class StepData(
    var code: Int = 0, var message: String = "", var data: Any? = null
)