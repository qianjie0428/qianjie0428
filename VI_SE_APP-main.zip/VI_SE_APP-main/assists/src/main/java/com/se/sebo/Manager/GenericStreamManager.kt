package com.se.sebo.Manager

import android.content.Context
import android.util.Log
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.sources.audio.NoAudioSource
import com.pedro.encoder.input.sources.video.NoVideoSource
import com.pedro.library.generic.GenericStream

object GenericStreamManager {
    private const val TAG = "GenericStreamManager"

    var genericStream: GenericStream? = null

    fun initializeGenericStream(
        context: Context,
        connectChecker: ConnectChecker,
        width: Int,
        height: Int
    ): GenericStream? {
        if (genericStream == null) {
            genericStream = GenericStream(context, connectChecker, NoVideoSource(), NoAudioSource()).apply {
                getGlInterface().setForceRender(true, 15)
                getStreamClient().setLogs(false)
            }
        }

        // 写死的参数
        val bitrate = 3000 * 1000
        val rotation = 90
        val sampleRate = 32000
        val isStereo = true
        val audioBitrate = 128 * 1000
        val echoCanceler = true
        val noiseSuppressor = true


        val adjustedWidth = if (width % 2 == 0) width else width - 1
        val adjustedHeight = if (height % 2 == 0) height else height - 1

        // 准备视频和音频
        val videoPrepared = genericStream!!.prepareVideo(adjustedWidth, adjustedHeight, bitrate, rotation =rotation)


        val audioPrepared = genericStream!!.prepareAudio(sampleRate, isStereo, audioBitrate, echoCanceler, noiseSuppressor)

        if (!videoPrepared || !audioPrepared) {
            Log.e(TAG, "Failed to prepare video or audio")
            genericStream = null // 释放失败的实例
        }
        return genericStream
    }
}
