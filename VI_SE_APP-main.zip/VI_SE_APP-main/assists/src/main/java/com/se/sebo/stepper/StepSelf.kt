package com.se.sebo.stepper

class StepSelf: StepImpl() {
    override fun onImpl(collector: StepCollector) {

    }
}