# ydl_ETORO

![LOGO](https://github.com/github1413/ydl_ETORO/raw/main/static/logo.png)


# UI
```
https://lanhuapp.com/link/#/invite?sid=lXBqHYja
```

## 本项目 货币单位
- 1交易所[usd] 2商品[usd] 3外汇[usd]  6意大利股[eur]  7美股[usd]   8意大利指数 9美股指数