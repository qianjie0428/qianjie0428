// lg-RE 
// 语言:https://ougato.github.io/2019/04/30/Language/
// 时区：
export default {
	'it-IT': {
		code: 'it-IT', // 意大利
		lang: 'Italiano',
		timeZone: 'Europe/Rome',
		flag: 'it',
	},
	'en-US': {
		code: 'en-US', // 美
		lang: 'English',
		timeZone: 'America/New_York',
		flag: 'us',
	},
	'zh-TW': {
		code: 'zh-TW', // 繁中
		lang: '台湾繁体',
		timeZone: 'Asia/Taipei',
		flag: 'tw',
	},

	'ja-JP': {
		code: 'ja-JP', // 日
		lang: '日本語',
		timeZone: 'Asia/Tokyo',
		flag: 'jp',
	},
	'ko-KR': {
		code: 'ko-KR', // 韩
		lang: '한국의',
		timeZone: 'Asia/Seoul',
		flag: 'kr',
	},
	'ar-IL': {
		code: 'ar-IL', // 阿拉伯语（以色列)
		lang: 'العربية',
		timezone: 'Asia/Jerusalem',
		flag: 'il',
	},
	// 'fr-FR': {
	// 	code: 'fr-FR', // 法
	// 	lang: 'Français',
	// 	timeZone: 'Europe/Paris',
	// 	flag: 'fr',
	// },
	// 'th-TH': {
	// 	code: 'th-TH', // 泰
	// 	lang: 'ไทย',
	// 	timezone: 'Asia/Bangkok',
	// 	flag: 'th',
	// },

	// 'tr-TR': {
	// 	code: 'tr-TR', // 土耳其
	// 	lang: 'Türkçe',
	// 	timeZone: 'Europe/Istanbul',
	// 	flag: 'tr',
	// },

	// 'vi-VN': {
	// 	code: 'vi-VN', // 越南语
	// 	lang: 'tiếng việt',
	// 	timeZone: 'Asia/Ho_Chi_Minh',
	// 	flag: 'vn',
	// },
	// 'ru-RU': {
	// 	code: 'ru-RU', // 俄
	// 	lang: 'Русский',
	// 	timeZone: 'Europe/Moscow',
	// 	flag: 'ru',
	// },
	// 'zh-CN': {
	// 	code: 'zh-CN', // 简中
	// 	lang: '中文简体',
	// 	timeZone: 'Asia/Shanghai',
	// 	flag: 'cn',
	// }, 
	// {
	// 	code: 'en-GB', // 英国
	// 	lang: 'English（United Kingdom)',
	// 	timeZone: 'Europe/London',
	// 	flag: 'gb',
	// }, {
	// 	code: 'en-AU', // 澳大利亚
	// 	lang: 'English（Australia)',
	// 	timeZone: 'Australia/Sydney',
	// 	flag: 'au',
	// }, 

	// {
	// 	code: 'bn-IN', // 孟加拉语（印度)
	// 	lang: 'বাংলা',
	// 	timeZone: 'Asia/Dhaka',
	// }, {
	// 	code: 'hi-IN', // 印度语
	// 	lang: 'हिंदी',
	// 	timeZone: 'Asia/Kolkata',
	// }, 
};