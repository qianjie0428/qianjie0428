import Vue from 'vue';
import md5 from 'js-md5';

export const HOST = `api.etorostop.top`;
export const BASE_URL = `https://${HOST}`;

// 部分项目使用websocket
export const WS_COIN_URL = `wss://${HOST}/ws`; // 币

export const WS_Zonghe_URL = `wss://${HOST}/zonghe`; // 币

export const WS_Dandu_URL = `wss://${HOST}/dandu`; // 币

// export const BASE_URL = `https://api.b-stable.top`;

// export const wsbiUrl = `wss://api.b-stable.top/ws`;

const CODE = "Qwd3N5yp";


// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		// 返回：[null,{errMsg: 'getNetworkType:ok', networkType: 'unknown'}]
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;

		return true;
	} catch (err) {
		console.log('err:' + err)
		throw err
	}
}

async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();

	if (!result) {
		return {
			message: Vue.prototype.$lang.TIP_NETWORK_TYPE_NONE
		};
	} else {
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();

		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

		// const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}`;
		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}?sign=${mdd}&t=${time}`;

		try {
			const response = await uni.request({
				url: `${fmtAPIURL}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});
			uni.hideLoading();
			const [err, res] = response;

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					const temp = uni.getStorageSync('lang') || Vue.prototype.$LANGCODE;
					uni.clearStorageSync();
					uni.setStorageSync('lang', temp);
					uni.showToast({
						title: Vue.prototype.$lang.API_TOKEN_EXPIRES,
						icon: 'none'
					});
					setTimeout(() => {
						uni.navigateTo({
							url: Vue.prototype.$paths.ACCOUNT_ACCESS
						});
					}, 1000);
					return null;
				}
				if (res.data) {
					// console.log('res.data:', res.data);
					if (res.data.code == 0) {
						// console.log('res.data.data:', res.data.data);
						return res.data.data || null;
					} else {
						uni.showToast({
							title: !res.data.message ? res.message : res.data.message,
							icon: 'none'
						});
						return null;
					}
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: err.errMsg || Vue.prototype.$lang.API_HTTP_ERROR,
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}

export default {
	BASE_URL,
	WS_COIN_URL,
	WS_Zonghe_URL,
	http,
	get,
	post,
	checkNetwork,
	WS_Dandu_URL
};


// export default async function http(url, params = {}) {
// 	console.log('url:', url, 'params:', params);
// 	const token = uni.getStorageSync("token") || '';
// 	const headers = {
// 		"Content-Type": "application/x-www-form-urlencoded",
// 		// 处理携带token
// 		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
// 		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
// 	};
// 	const time = parseInt(new Date().getTime() / 1000);
// 	const str_url = `/${url}`.toLowerCase();
// 	const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

// 	try {
// 		if (!params.hide) {
// 			// 默认显示状态
// 			uni.showLoading({
// 				title: params.title || Vue.prototype.$lang.STATUS_REQUEST,
// 			})
// 		}
// 		const response = await uni.request({
// 			url: `${BASE_URL}/api/${url}?sign=${mdd}&t=${time}`,
// 			method: params.method || 'GET',
// 			data: params.data || {},
// 			header: headers
// 		});
// 		if (!params.hide) {
// 			uni.hideLoading();
// 		}
// 		// console.log('response:', response);
// 		let [err, res] = response;
// 		if (res && res.statusCode == 200) {
// 			if (res.data.code === 999) {
// 				uni.clearStorageSync();
// 				uni.$u.toast(Vue.prototype.$lang.API_TOKEN_EXPIRES);
// 				uni.$u.sleep(1000).then(() => {
// 					uni.navigateTo({
// 						url: Vue.prototype.$paths.ACCOUNT_ACCESS
// 					});
// 				})
// 				return false;
// 			}
// 			return res.data;
// 		} else {
// 			uni.$u.toast(Vue.prototype.$lang.STATUS_HTTP_ERROR);
// 		}
// 	} catch (error) {
// 		// console.log(error);
// 		throw error;
// 	}
// };

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})