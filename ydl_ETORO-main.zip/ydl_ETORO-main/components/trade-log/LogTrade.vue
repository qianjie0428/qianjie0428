<template>
	<view style="padding-bottom: 200rpx;">
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block"
				style="margin-bottom:20rpx;padding:10px;border-radius: 0;border: none;border-bottom: 1rpx dashed #3AC2906A;">
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding: 8px 0;padding-top: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_AMOUNT_BEFORE}}
					</view>
					<view>
						<template v-if="!item.ident">
							{{`$ `+$util.formatUSD(`${item.before*1}`,3)}}
						</template>
						<template v-else>
							{{`€ `+$util.formatMoney(`${item.before*1}`,3)}}
						</template>

					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 8px 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_AMOUNT_AFTER}}
					</view>
					<view>
						<template v-if="!item.ident">
							{{`$ `+$util.formatUSD(`${item.after*1}`,3)}}
						</template>
						<template v-else>
							{{`€ `+$util.formatMoney(`${item.after*1}`,3)}}
						</template>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 8px 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
					<view style=" color: #cccccc;font-size: 12px;">
						{{$lang.LOG_TRADE_DW}}
					</view>
					<view :style="$theme.setStockRiseFall(item.money*1>0)">
						<template v-if="!item.ident">
							{{`$ `+$util.formatUSD(`${item.money*1}`,3)}}
						</template>
						<template v-else>
							{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
						</template>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 8px 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
					<view style=" color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style=" text-align: right;">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 8px 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
					<view style=" color: #cccccc;font-size: 12px;">{{$lang.LOG_TRADE_DESC}}:</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: flex-end;padding: 8px 0;">
					<text style="white-space:pre-wrap;text-align: right;font-size: 12px;">{{item.desc}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				eurToUsd: 1, // 欧转美
				usdToEur: 1
			};
		},
		beforeMount() {
			this.getList();
			this.getconfig();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/user/finance`);
				if (!result) return false;
				this.list = result;
			},
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		}
	}
</script>

<style>

</style>