export default {
	// ===== 新增 2024.11.17 start ====
	CHOOSE_ADDRESS:"Choose Address",
	
	// ===== 2024.11.15 start 作为新项目所需，内容太多，未对比 ====
	POSITION_TOTAL: "Total Assets",
	POSITION_FREEZE: "Freeze Assets",
	POSITION_BALANCE: "Balance Assets",
	POSITION_TOTAL_PL: "Total Profit",
	CENTER_TOTAL_ASSETS: "My Total Assets",
	COMMON_ALL: `All`,
	COMMON_AMOUNT:`Amount`,

	// ===== 新增 2024.10.14 start ====
	BANGKA_DIZHI: 'Wallet Address ',
	BANGKA_XINGMING: 'Nome Del Titolare Della Carta',
	BANGKA_SRXINGMING: 'Enter Nome Del Titolare Della Carta',
	BANGKA_SRMINGCHENG: 'Enter Bank Name',
	BANGKA_SRKAHAO: 'Enter Numero Della Carta Bancaria',
	BANGKA_SHOUKUAND: 'Indirizzo Del Beneficiario',
	BANGKA_SRDIZHI: 'Enter Indirizzo Del Beneficiario',
	BANGKA_YINHANGDIHZI: 'Indirizzo Della Banca',
	BANGKA_SRYINGHAOD: 'Enter Indirizzo Della Banca',
	BANGKA_LEIXING: 'Tipo Di Conto',
	BANGKA_SRLEIXING: 'Enter Tipo Di Conto',

	// ===== 新增 2024.10.08 start ====
	TRADE_DAY_STATUS_APPROVAL: ['Approved', 'Completed'],
	// ===== 新增 2024.10.04 start ====
	POSIZIONE_LONG: `Long Position`,
	POSIZIONE_SHORT: `Short Position`,

	REBATES_TIP: `Amount of Refund`,

	FANGXIANG: 'Direction',
	FANGXIANG_1: 'Long',
	FANGXIANG_2: 'Short',

	// ===== 新增 2024.09.28 start ====
	CHOOSE_BANK_CARD: `Choose Bank Card`,
	MY_BANK_CARD: `My Bank Card`,
	TRADE_DAY_STATUS: ['Pending', 'Accept', 'Reject'],

	// ===== 新增 2024.09.27 start ====
	FORGOT_PASSWORD: `Forgot Password?`,

	TRADE_WEALTH_HOLD_SELL_PRICE: 'Sell Price',
	TRADE_WEALTH_HOLD_RATE: 'Yield',
	// ===== 新增 2024.09.25 start ====
	// 市场
	MARKET_STOCK_EU: `EU Stocks`,
	MARKET_STOCK_US: `US Stocks`,
	MARKET_COIN: `Coin`,
	MARKET_FOREX: `Forex`,
	FILTER: `Filter`,
	ENTER_KEYWORD: `Enter keyword`,

	// ===== 新增 2024.09.02 start ====
	SELL_TIME: `Sell Time`,

	// ===== 新增 2024.08.20 start ====
	BANK_CARD_TITLE: `Bind Bank Card`,
	// ===== 新增 2024.08.20 end ====

	CONTRACT_CAN_CLOSE: `Can close`,
	CONTRACT_POSITIONS: `Positions`,
	COIN_CURRENT_PRICE: 'Price',
	COIN_CURRENT_QTY: 'Quantity',
	COIN_CURRENT_TOTAL: 'Total',
	COIN_CURRENT_BTN_CANCEL: 'Cancel',

	COIN_HISTORY_TRADE_FEE_buy: 'Buy Fee',

	MEIGU: 'American Stocks',
	OUGUl: 'European Stocks',


	COIN_HISTORY_TRADE_FEE: 'Close Fee',
	COIN_HISTORY_TRADE_PRICE: 'Trade Price',
	COIN_HISTORY_TRADE_QTY: 'Trade Volume',
	CONTRACT_RATE: `Risk/Reward`,
	COIN_BUY_PRICE: 'Buy Price',
	COIN_CLOSE_PRICE: 'Close Price',

	COIN_HISTORY_TIP_CANCEL: 'Cancel',
	COIN_HISTORY_TIP_TRADE: 'Trade',

	TRANSLATE_TITLE: 'Please select language',
	// 底部导航
	TABBAR_HOME: "Home",
	TABBAR_FOLLOW: "Market",
	TABBAR_MARKET: 'Market',
	TABBAR_TRADE: 'Trade',
	TABBAR_ACCOUNT: 'Account',

	// 账户管理相关 登入、注册
	SIGN_IN: "Sign In",
	SIGN_UP: "Sign in",
	SIMGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Sign up',
	USER_NAME: 'Account',
	ENTER_USER_NAME: 'Enter your email account',
	PASSWORD: 'Password',
	ENTER_PASSWORD: 'Enter Your Password',
	API_STATUS_UPLOAD: 'Uploading...',
	VERIFY_PASSWORD: 'Verify Password',
	ENTER_VERIFY_PASSWORD: 'Enter Your Password',
	INVITATION_CODE: "Inserisci Il Codice Di Invito Dell'Ente",
	COMMON_QINGCHU: 'Submitted',
	INT_ATIN_CODE: 'About Us',
	ENTER_INVITATION_CODE: 'Enter Your Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_SUCCESS_SIGNIN: 'Sign Successful',
	TIP_SUCCESS_REGISTER: 'Registration has been completed, please log in',
	TIP_SIGNIN_ING: 'Logging in',
	TIP_SIGNUP_ING: 'Registering',
	PROFILE_AUTH_VERIFIED: 'Verified',
	PROFILE_AUTH_UNVERIFIED: 'Unverified',
	PROFILE_AUTH_UNSUBMIT: 'Unsubmit',
	PROFILE_AUTH_UNAPPLY: 'Unapply',

	TRANSFER_ASSETS_TITLE: 'Funds',
	TRANSFER_RECORD_TITLE: 'Transfer Record',
	TRANSFER_RECORD_DESC: 'Desc',
	TRASNFER_RECORD_REVIEW: 'Under review', // 审核中
	TRANSFER_RECORD_PASS: 'Passed', // 已通过
	TRANSFER_RECORD_REJECT: 'Rejected', // 已拒绝
	DEPOSIT_RECORD_AMOUNT: 'Trade Amount',
	DEPOSIT_RECORD_SN: 'Order SN',
	DEPOSIT_RECORD_CT: 'Date Time',
	AUTH_TITLE: 'Auth',
	PRVITE_PACT_TITLE: 'Privte And Pact',
	AUTH_REAL_NAME: 'Real Name',
	AUTH_CARD_ID: 'ID Card',
	AUTH_CARD_F: 'Identity authentication',
	AUTH_CARD_B: 'Identity authentication',
	ADDRESS_INDEX_TITLE: 'Withdraw Address',
	ADDRESS_ADD_TITLE: 'Add Address',
	ADDRESS_TIP_ENTER_ADDRESS: 'Enter Address',
	ADDRESS_CHOOSE_COIN: 'Choose Coin',
	ADDRESS_WALLET_ADDRESS: 'Wallet Address',
	ADDRESS_WALLET_IMAGE: 'Upload Image',
	TRANSFER_CONTRACT_TITLE: 'Trade',
	TRANSFER_Options_TITLE: 'Options',
	TRANSFER_TITLE: 'Transfer',
	TRANSFER_IN_ACCOUNT: 'Transfer In Account',
	TRANSFER_OUT_ACCOUNT: 'Transfer Out Account',
	TRANSFER_TIP: 'The transfer-in account cannot be the same as the transfer-out account',
	TRANSFER_AMOUNT: 'Transfer Amount',
	TRANSFER_BALANCE: 'Balance',
	TIP_REMEMBER_PWD: 'Remember password',
	API_TOKEN_EXPIRES: 'Token Expires. Please Sign In Again',
	TIP_SIGN_OUT_SUCCESS: 'Logout successful',
	TIP_AGREE: 'I agree',
	TIP_PRVITE_PACT: 'Privte and pact',
	TIP_CHECK_AGREE: 'Please checked agree',
	DEPOSIT_ENTER_AMOUNT: 'Enter Amount',
	API_DATA_SUBMIT: 'Submitting',
	COMMON_CANCEL: 'Cancel',
	COMMON_CONFIRM: 'Confirm',
	COMMON_COPY_SUCCESS: 'Copy Success',

	// 变更登入密码、变更支付密码、变更账户信息
	TIP_OLD_PWD: 'Enter the original password',
	TIP_NEW_PWD: 'Enter a new password',
	TIP_NEW_PWD_VERIFY: 'Enter new password again',


	// 提款页面
	PAGE_TITLE_WITHDRAW: 'Withdraw',
	WITHDRAW_AMOUNT: 'my assets',
	WITHDRAW_TITLE: "Withdraw funds",
	TIP_AMOUNT_AVAIL: 'Amount Available',
	WITHDRAW_WITH_AMOUNT: 'Withdraw amount',
	TIP_AMOUNT_WITHDRAW: 'Enter the withdrawal amount',
	WITHDRAW_PAY_PWD: 'Withdrawal password',
	TIP_WITHDRAW_PWD: 'Enter payment password',
	WITHDRAWING_POST_TIP: 'Processing....',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. Cannot be withdrawn until the currently held shares are sold.`, `
2. In order to withdraw money, you need to verify your real name and verify your account before withdrawing money.`,
		`3. Withdrawal trading hours: 09:00-15:00 on weekdays (withdrawal are not allowed on weekend and public holidays).`,
		`4. The minimum amount to request a withdrawal is 3 EUR .`,
		`5. After applying for withdrawal, in principle, it will be deposited into the designated withdrawal account on the same day.`,
		`※ Payment will be completed within 2 working days (48 hours) at most.`
	],

	// 入金页面
	PAGE_TITLE_DEPOSIT: 'Deposit',
	PAGE_TITLE_DE: 'Bind account',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: 'Enter Recharge Amount',
	DEPOSIT_TIP_LOW_AMOUNT: 'Minimum 1.000,000',
	DEPOSIT_POST_TIP: 'Processing....',
	DEPOSIT_TIP_TITLE: 'Helpful Tip',
	DEPOSIT_UPLOAD_TITLE: 'Upload Image',
	DEPOSIT_TIP_TEXT: ['Deposit hours: Weekdays 09:00–23:00, weekends 13:00–23:00.',
		'Thank you for choosing us! To ensure the security of your funds, please confirm that the account address you are transferring to is correct. Each time you make a deposit, please inform our service team. Accounts are displayed in real-time on our platform, and any losses resulting from your deposits are your responsibility.'
	],

	CONTRACT_DESC_CONTENT: [
		`Contract Deposit: (Purchase Number*Nominal Value)/Multiple, nominal value 1000.`,
		`Number of vacancies: Balance sheet numbers, margins, margin fees.`,
		`Handling Fee: Margin * Currency Handling Rate (0.05%)*Multiple.`,
		`User Rights: User Balance + Total Margin + Position Gain/Loss.`,
		`Risk Ratio: User Privilege/Total Margin 100, generally less than 20% for liquidation.`
	],


	// 个人中心页面
	ACCOUNT_CHANGE_PWD: 'Change Sign In Password',
	ACCOUNT_TRADE_LOG: 'Capital flow',
	ACCOUNT_SERVICE: 'Service',
	ACCOUNT_AMOUNT_TOTAL: 'Total asset',
	ACCOUNT_AMOUNT_AVAILABLE: 'Available funds',
	ACCOUNT_MORE_FEATURES: 'More Features',

	// 交易记录页面
	TRADE_LOG_BTNS: ['Details', 'Deposit', 'Withdraw'],
	TRADE_LOG_TIP_MODAL_TITLE: 'Are you sure you want to cancel the withdrawal request?',
	TRADE_LOG_WITHDRAW_STATUS: ['Under review', 'Withdraw successfully',
		'Withdrawal failed, please contact customer service', 'Reject'
	],
	LOG_TRADE_AMOUNT_BEFORE: 'Balance before trade',
	LOG_TRADE_AMOUNT_AFTER: 'Balance after trade',
	LOG_TRADE_DW: 'Trade Amount',
	LOG_TRADE_CREATE_TIME: 'Time',
	LOG_TRADE_DESC: 'Detail',
	LOG_TRADE_ORDER_SN: 'Order Sn',
	LOG_TRADE_DW_DESC: 'Trade desc',
	LOG_WITHDRAW_AMOUNT: 'Withdrawal amount',
	LOG_STATUS: 'Status',


	// 交易页面
	TRADE_TITLE: 'Investment results',
	TRADE_TABS: ['Hold record', 'Sell record'],
	TRADE_TOTAL_BUY_AMOUNT: 'Total purchase',
	TRADE_VALUATION_GAIN_LOSS: 'Profit and loss',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: 'Evaluation amount',
	TRADE_RATE_RESPONSE: 'Response rate',
	TRADE_TOTAL_GAIN: 'Total profit',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['name', 'gains', 'QTY Hold', 'Eval', 'Price', 'Price'],
	TRADE_MOADL_TITLE: 'Order',
	// 订单的label组
	TRADE_MODAL_LABELS: ['name', 'Buy time', 'Sales time', 'Profit', 'Lever', 'Total profit', 'Price', 'QTY', 'Fee',
		'Total amount', 'Code'
	],
	// 卖出的二次确认
	SELL_TIP: 'Confirm sale?',


	// IPO 交易
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['Products', 'Record', 'Success'],
	TRADE_IPO_MODAL_TITLE: 'Public offering stock subscription application',
	TRADE_IPO_MODAL_CONTENT: 'If you want to apply for a subscription, please click Confirm',
	TADE_IPO_SUB_PRICE: 'Subscription',
	TRADE_IPO_PE_RATE: 'P/E ratio',
	TRADE_IPO_SUB_CT: 'Subscription time',
	TRADE_IPO_POST_QTY: 'Circulation',
	TRADE_IPO_RAISE_MONEY: 'Fund raising',
	TRADE_IPO_LOG_LABELS: ['Subscription price', 'P/E ratio', 'Subscription time', 'cycle'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO Subscription success record',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: 'Subscription QTY',
	TRADE_IPO_SUCCESS_AMOUNT: 'Winning',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: 'amount',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order sn',
	TRADE_IPO_SUCCESS_CT: 'Date time',


	// 单股详情页面
	PAGE_TITLE_STOCK_OVERVIEW: 'Stock details',
	// 股票最新数值
	STOCK_INFO_TITLES: ['market price', 'Closing price', 'high price', 'low price', 'Trading volume',
		'Trading amount'
	],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['Minute Charts', 'Daily Charts', 'Monthly Charts'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: 'quantity',
	STOCK_BUY_TIP_QUANTITY: 'Enter quantity',
	STOCK_BUY_AMOUNT: 'Payment amount',
	STOCK_BUY_FEE: 'Fee',
	STOCK_BUY_CONFIRM: 'Purchase',

	LEVER: 'Lever',
	STOCK_ALL: 'Stock List',
	STOCK_FOLLOW: 'Follow List',
	// 首页股票列表表头
	STOCK_THEAD: ['Name', 'Price', 'Rate'],
	PAGE_TITLE_NOTIFICATION: 'Notify',
	PAGE_TITLE_SEARCH: 'Search',
	TIP_SEARCH: 'Enter keywords',
	SEARCH_HISTORY: 'Search History',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: 'trade-in',
	TIP_POST_SUCCESS: 'Success',
	ABOUT_US: 'About Us',
	CURRENCY_UNIT: '',
	QUANTITY_UNIT: '',
	UNIT_BILION: 'Bilion',
	UNIT_POS: 'Position',
	UNIT_DAY: 'Day',
	MORE: 'More',
	BRIEF: 'Brief',
	EMPTY_NOTIFIY: 'Empty Notifiy',
	EMPTY_DATA: 'Empty Data',
	BTN_CONFIRM: 'Confirm',
	BTN_CANCEL: 'Cancel',
	BTN_SEND_SERVICE: 'Contact Customer Service',
	BTN_DETAIL: 'Details',
	BTN_BUY: 'Buy',
	BTN_SELL: 'Sell',
	STATUS_LOADING: "loading",
	STATUS_SUBMIT: 'Submitting',
	STATUS_REQUEST: 'Get new data',
	STATUS_HTTP_ERROR: 'Request exception, retrying',
	STATUS_UPLOAD: "Uploading",

	// =============================
	// 网络检查及网络状态
	TIP_NETWORK_TYPE_NONE: 'There is no network or the network status is poor.',

	// API 相关提示
	API_TOKEN_EXPIRES: 'Your login status has expired, please log in again',
	API_HTTP_ERROR: 'The request is abnormal. Please check your network.',
	REQUEST_DATA: 'Request Data',
	API_EMPTY_DATA: 'Empty Data',
	API_EMPTY_CONTENT: 'Empty Content',
	API_SIGN_IN_NOW: 'Logging in',
	API_SIGN_UP_NOW: 'Registering',
	API_DATA_SUBMIT: 'Submitting',
	API_POST_SUCCESS: 'Success',
	API_GET_ACCOUNT_INFO: 'Get account information',
	ABOUT_US_TITLE: 'About US',


	// 复制成功
	TIP_COPY_SUCCESS: 'Copy Success',


	COIN_LIST_TITLE: 'Coin List', // Coin 列表 标题

	TRADE_RECORD_TITLE: 'Record', // 交易记录

	MARKET_TAB_COIN: 'Coin', // 市场 coin
	MARKET_TAB_TRACK: 'Track', // 市场 收藏

	// Coin OverView 币 详情页面 [分 日 月]
	COIN_VIEW_TAB_MINUTE: 'Minute',
	COIN_VIEW_TAB_DAILY: 'Daily',
	COIN_VIEW_TAB_MONTHLY: 'Monthly',
	// COIN_VIEW_BTN_BUY: 'Buy',
	// COIN_VIEW_BTN_SELL: 'Sell',
	// Coin Buy and  Sell
	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',
	COIN_MODAL_WANT_TO: `Want to`,

	COIN_BAY_SELECT_PRICE_TYPE: 'Select Price Mode',
	COIN_BAY_ENTER_AMOUNT: 'Please Enter Amount',

	// Wealth 交易
	TRADE_WEALTH_TITLE: 'Wealth',
	TRADE_WEALTH_RECORD_TITLE: 'Wealth Record',
	TRADE_WEALTH_HOLD_RECORD: 'Hold Record',
	TRADE_WEALTH_HISTORY: 'History',
	TRADE_WEALTH_NEW_USERS: 'New Users',
	TRADE_WEALTH_BUY_DETAIL: 'Buy Detail',
	TRADE_WEALTH_RATE: 'Rate',
	TRADE_WEALTH_CYCLE: 'Cycle',
	TRADE_WEALTH_CYCLE_UNIT: 'Day',
	TEADE_WEALTH_MIN_PRICE: 'Min Price',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: 'Please Enter Amount',
	TRADE_WEALTH_BUY_AMOUNT_TIP: 'Amount Must Bigger Min Price',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: 'Rate',
	TRADE_WEALTH_HOLD_CYCLE: 'Cycle',
	TRADE_WEALTH_HOLD_PRICE: 'Price',

	TRADE_WEALTH_HOLD_NUM: 'Num',
	TRADE_WEALTH_HOLD_PROFIT: 'Profit',

	TRADE_WEALTH_HOLD_PAY_PRICE: 'Pay Price',
	// TRADE_WEALTH_HOLD_PROFIT: 'Profit',
	TRADE_WEALTH_HOLD_SN: 'SN',
	TRADE_WEALTH_HOLD_CRETIME: 'Create Time',
	TRADE_WEALTH_HOLD_ENDTIME: 'End Time',


	// 汇款
	ACCOUNT_LIST_REMITTANCE: 'Remittance',
	// 汇款页面
	REMITTANCE_TITLE: 'Remittance',


	// 等级 团队页面
	ACCOUNT_LEVEL_TITLE: 'Level',
	LEVEL_CURRENT_LEVEL: 'Current Level',
	LEVEL_CURRENT_TEAM: 'Current Team',
	LEVEL_DESC_TITLE: 'Level Description',
	LEVEL_NEXT_LEVEL: 'Next Level',
	LEVEL_SELF_HOLD_MONEY: 'Self Hold Money',
	LEVEL_L1_TEAM_USERS: 'L1 Team Users',
	LEVEL_L1_TEAM_MONEY: 'L1 Team Money',
	LEVEL_L2_TEAM_USERS: 'L2 Team Users',
	LEVEL_L2_TEAM_MONEY: 'L2 Team Money',
	LEVEL_TEAM_LIST_HEAD_MOBILE: 'Mobile',
	LEVEL_TEAM_LIST_HEAD_AMOUNT: 'Weathl Amount',
	LEVEL_L1_TEAM: 'L1 Team',
	LEVEL_L2_TEAM: 'L2 Team',


	// Trade  持仓页面 持有卖出的总页面

	// Trade Detail 持仓，单条数据详情
	TRADE_HOLD_DETAIL_TITLE: 'Trade Hold Detail',

	//理财
	LICAI_LICAI: 'Smart trading',
	LICAI_REN: 'Person',
	LICAI_YUGUSHOUYILV: 'Estimated yield',
	LICAI_ZHOUQI: 'cycle',
	LICAI_ZUIDIMAIRU: 'Minimum buy',
	LICAI_MINGCHENG: 'Name',
	LICAI_LEIXING: 'Type',
	LICAI_FAFANGRIQI: 'Release Date',
	LICAI_QINGSHURUMEIRUJINE: 'Please enter the purchase amount',
	LICAI_CHICANG: 'Position',
	LICAI_YISHUHUI: 'Redeemed',
	LICAI_KEFU: 'Contact Customer Service',

	// trade copy  跟单交易
	TRADE_COPY_TITLE: 'Copy Trading',
	TRADE_COPY_SEARCH_TIP: 'Enter keyword',
	TRADE_COPY_FOLLOWERS: 'Followers',
	TRADE_COPY_RATE: 'Total Rate',
	TRADE_COPY_WIN: '30 Day Win',
	TRADE_COPY_TOTAL: 'Total',
	TRADE_COPY_TOTAL_AMOUNT: 'Total Amount',
	TRADE_COPY_BTN_COPY: 'Join Now',

	COPY_DETAIL_TITLE: 'Detail',
	COPY_DETAIL_30DAY_PROFIT: '30 Day Profit',

	COPY_DETAIL_CHARTS: 'Charts', // 图表
	COPY_DETAIL_DATA: 'Data', // 数据
	COPY_DETAIL_SCORE: 'Score', // 评分
	COPY_DETAIL_INVESTORS: 'Investors', // 跟投
	COPY_DETAIL_ORDERS: 'Orders', // 订单
	COPY_DETAIL_TOTAL_RETURNS: 'Total Returns',
	COPY_DETAIL_TOTAL_RETURNS_TIP: 'Include Position Gains',
	COPY_DETAIL_TR_TABS: ['7-day', '30-day', '90-day', '180-day', 'All'],

	COPY_DETAIL_CLOSE_PROFIT: 'Close Profit', // 平仓盈亏
	COPY_DETAIL_TRADE_COUNT: 'Trade Count', // 交易笔数
	COPY_DETAIL_AVERAGE_PROFIT: 'Average Profit', // 平均盈利
	COPY_DETAIL_AVERAGE_DT: 'Average Date', // 平均持仓时间
	COPY_DETAIL_WIN_RATE: 'Win Rate', // 胜率

	// 月度表现
	COPY_DETAIL_MONTH_PL: 'Month Profit And Loss',

	// 周 盈亏
	COPY_DETAIL_WEEK_PL: 'Week Profit And Loss',

	// 交易量
	COPY_DETAIL_TRADE_VOLUME: 'Trading Volume',
	COPY_DETAIL_TV_TABS: ['24H', '7-day', '3-week', '1-month', '6-month'],

	// Data 分栏
	COPY_DETAIL_DATA_SPECIES: 'Species Preferences',
	COPY_DETAIL_DATA_THEAD_SPECIES: 'Species',
	COPY_DETAIL_DATA_THEAD_PROFIT: 'Profit(USD)',
	COPY_DETAIL_DATA_THEAD_VOL: 'Volume(Lots)',

	COPY_DETAIL_DATA_TRADE_DATA: 'Transaction data',
	// 最大回撤
	COPY_DETAIL_DATA_MAX: 'Max retracement(USD)',
	// 持有盈亏
	COPY_DETAIL_DATA_HOLD_PROFIT: 'Holding Profit(USD)',
	// 交易笔数
	COPY_DETAIL_DATA_TRADE_COUNT: 'Trade Count',
	// 胜率
	COPY_DETAIL_DATA_WIN_RATE: 'Win Rate(%)',
	// 平均盈利(USD)
	COPY_DETAIL_DATA_AVERAGE_PROFIT: 'Average Profit(USD)',
	// 平均亏损(USD)
	COPY_DETAIL_DATA_AVERAGE_LOSS: 'Average Loss(USD)',
	// 交易周数
	COPY_DETAIL_DATA_TRADE_WEEK: 'Trade Week',
	// 最大衰落期(天)
	COPY_DETAIL_DATA_MAX_DECAY_PERIOD: 'Max Decay Period(D)',
	// 净值/余额(USD)
	COPY_DETAIL_DATA_NET_BALANCE: 'Net/Balance(USD)',
	// 存款(USD)
	COPY_DETAIL_DATA_DEPOSIT: 'Deposit(USD)',
	// 取款(USD)
	COPY_DETAIL_DATA_WITHDRAWAL: 'Withdrawal(USD)',
	// 账户时区
	COPY_DETAIL_DATA_TIME_ZONE: 'Time Zone',
	// 最近交易
	COPY_DETAIL_DATA_RECENT_TRADE: 'Recent Trades',

	// 评分
	COPY_DETAIL_SCORE_INFO: 'Score Detail',
	COPY_DETAIL_SCORE_CHART: 'Score Chart',
	COPY_DETAIL_SCORE_CURRENT: 'Current Score',
	COPY_DETAIL_SCORE_TIP: 'Total score of 10, with 6 items assessed',
	// 评分六项： 盈利能力 风控能力 稳健性 非侥幸获利 资金规模 出入场优势
	COPY_DETAIL_SCORE_SIX: ['profitability', 'Risk Control Capability',
		'robustness', 'Not Fluke', 'Funds Size', 'Entry/Exit'
	],

	// 跟投 分栏
	COPY_DETAIL_INVESTORS_NUM: 'Number of Follow-up', // 跟投数量
	// 跟投资金总金额(EUR)
	COPY_DETAIL_INVESTORS_AMOUNT: 'Total follow-on investment (EUR)',

	// 订单 分栏
	COPY_DETAIL_ORDERS_BUY: 'Buy',
	COPY_DETAIL_ORDERS_SELL: 'Sell',
	COPY_DETAIL_ORDERS_PROFIT: 'Profit',
	COPY_DETAIL_ORDERS_LOST: 'Lost',
	COPY_DETAIL_ORDERS_PIPS: 'Pips',

	// 跟单 弹层
	COPY_MODAL_NET_VALUE: 'Net Value (USD)',
	COPY_MODAL_FOLLOW_FEE: 'Follow-up Fee (USD)',
	COPY_MODAL_DAY: 'Day',
	COPY_MODAL_CHOOSE_ACCOUNT: 'Choose Account',
	COPY_MODAL_CHOOSE_MODE: 'Choose Mode',
	COPY_MODAL_MODE_TIP: 'By Fixation Method',
	COPU_MODA_MODE_TIP1: 'Open positions according to a set fixed criteria',
	COPY_MODAL_QTY: 'Enter Quantity',
	COPY_MODAL_BALANCE: 'Balance',
	COPY_MODAL_AMOUNT: 'Amount',

	// FOF 相关
	FOF_TITLE: 'The fund of fund',
	FOF_BTN_VIEW: 'View Now',
	FOF_RUN_DT: 'Runtime(Day)', // 运行时间
	// 当前跟投金额
	FOF_COPY_AMOUNT: 'Current Follow-up Amount',
	// 平均每日收益
	FOF_AVERAGE_PROFIT: 'Average Profit(D)',
	// 当前跟投人数
	FOF_COPY_FOLLOWS: 'Current Followers',
	FOF_GAIN: 'cumulative gain', // 累计收益
	FOF_MIN_DAY: 'Min Days', // 最小天数
	FOF_DAYS: 'Days',
	FOF_SUB_TIP: 'Minimum days already', // 已是最小天数
	// FOF基金成员构成
	FOF_LIST_TITLE: 'FOF fund membership',
	FOF_LIST_THEAD_INDEX: 'Index',
	FOF_LIST_THEAD_TRADER: 'Trader',
	FOF_LIST_THEAD_PER: 'Percentage',

	FOF_MODAL_TITLE: 'Operational Tips', // 提示
	// 准备购买
	FOF_MODAL_TIP: 'You are ready to buy a FOF fund',
	FOF_MODAL_TIP_AMOUNT: 'Enter Amount',
	FOF_MODAL_ENTER_AMOUNT: 'Please enter the amount to be invested (EUR)',
	FOF_MODAL_BTN_CONFIRM: 'Confirm',
	FOF_MODAL_CYCLE: 'Cyclical',

	// coin index  detail
	COIN_DETAIL_TABS_TIME: ['1H', '1D', '1W', '1M', '5M', 'Month'],
	COIN_PRICE_TYPE_MARKET: 'Market',
	COIN_PRICE_TYPE_LIMIT: 'Limit',

	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_VIEW_BTN_BUY: 'Buy',
	COIN_VIEW_BTN_SELL: 'Sell',
	COIN_VIEW_OPEN: 'Open',
	COIN_VIEW_CLOSE: 'Close',
	COIN_VIEW_HIGH: 'High',
	COIN_VIEW_LOW: 'Low',
	COIN_VIEW_AMOUNT: 'Trade Amount',

	COIN_VIEW_TAB_DEPTH: 'Depth',
	COIN_VIEW_TAB_TRADE: 'Latest Trade',

	COIN_VIEW_TRADE_TITLE_DATE: 'Date Time',
	COIN_VIEW_TRADE_TITLE_PRICE: 'Price',
	COIN_VIEW_TRADE_TITLE_AMOUNT: 'Quantity',

	COIN_VIEW_DEPTH_TITLE_PRICE: 'Price',
	COIN_VIEW_DEPTH_TITLE_BUY_QTY: 'Buy QTY',
	COIN_VIEW_DEPTH_TITLE_SELL_QTY: 'Sell QTY',

	COIN_BUY_TITLE_PRICE: 'Price',
	COIN_BUY_TITLE_QTY: 'Quantity',

	COIN_BUY_BALANCE: 'Balance',
	COIN_BUY_MAX_QTY: 'Max QTY',
	COIN_BUY_TOTAL_AMOUNT: 'Total',
	COIN_BUY_TIP_ENTER_QTY: 'Enter Quantity',
	COIN_BUY_TIP_ENTER_PRICE: 'Enter Amount',
	COIN_BUY_TIP_ENTER_POINT: 'Up to 4 decimal places',

	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',

	COIN_CUR_ORDER: 'Current Orders',
	COIN_TRADE_RECORD: 'Trade Record',

	COIN_RECORD_TITLE: 'Record',
	COIN_RECORD_CURRENT: 'Current',
	COIN_RECORD_HISTORY: 'History',
	COIN_RECORD_SUCCESS: 'Success',

	COIN_RECORD_TIP_CUR_COIN: 'Only show the current',

	COIN_CURRENT_PRICE: 'Price',
	COIN_CURRENT_QTY: 'Quantity',
	COIN_CURRENT_TOTAL: 'Total',
	COIN_CURRENT_BTN_CANCEL: 'Cancel',
	COIN_HISTORY_TRADE_FEE: 'Fee',
	COIN_HISTORY_TRADE_PRICE: 'Trade Price',
	COIN_HISTORY_TRADE_QTY: 'Trade Volume',

	COIN_HISTORY_TIP_CANCEL: 'Cancel',
	COIN_HISTORY_TIP_TRADE: 'Trade',

	// Contract 
	CONTRACT_DETAIL_BTN_BUY: 'Buy Long',
	CONTRACT_DETAIL_BTN_SELL: 'Sell Short',
	CONTRACT_PROFIT: 'Profit Amount',
	CONTRACT_LOSS: 'Loss Amount',
	CONTRACT_PROFIT_LOSS_SET: 'Take Profit And Stop Loss(Optional)',
	CONTRACT_LEVER: `Lever`,
	CONTRACT_FEE: 'Fee',
	CONTRACT_DESC_MODAL_TITLE: 'Description',
	CONTRACT_DESC_BTN: 'OK',
	CONTRACT_DESC_Q: `What is Full Position and Position-by-Position mode?`,
	CONTRACT_DESC_A: `Full Position Mode: Positions in all currencies share the margin in a fully leveraged account to avoid a position being liquidated. In the event of a liquidation, the trader may lose all the margin and the position. Position-by-position mode: Each currency pair is a separate margin account and the left and right coins of the same pair share margin. In the event of a liquidation, the trader may lose the margin and position in the burst pair, but it will not have any effect on the positions in other coins that are not burst.`,
	CONTRACT_RECORD_CURRENT: 'Current',
	CONTRACT_RECORD_HOLD: 'Holding',
	CONTRACT_RECORD_HISTORY: 'History',

	CONTRACT_RECORD_TIP_CUR_CONTRACT: 'Only show current',

	CONTRACT_HOLD_QUICK_CLOSE: 'All Close',

	CONTRACT_HOLD_BTN_PROFIT_LOSS: 'Take Profit And Stop Loss',
	CONTRACT_HOLD_BTN_CLOSE: 'Close',

	CONTRACT_HOLD_BUY_PRICE: 'Price', // 单价	
	CONTRACT_HOLD_BUY_QTY: 'Buy Quantity', // 购买数量
	CONTRACT_HOLD_BUY_TOTAL: 'Buy Total', // 购买总价

	CONTRACT_HOLD_CURRENT_PRICE: 'Current Price',
	CONTRACT_HOLD_BUY_FEE: 'Fee', // 手续费
	CONTRACT_HOLD_BUY_PL: `Profit or Loss`,

	CONTRACT_HOLD_TAKE_PROFIT: 'Take Profit',
	CONTRACT_HOLD_STOP_LOSS: 'Stop Loss',
	CONTRACT_HOLD_FLOAT_PL: `Float P & L`,

	CONTRACT_PROFIT_LOSS_MODAL_TITLE: 'Take Profit And Stop Loss',

	CONTRACT_TAKE_PROFIT_AMOUNT: 'Take Profit Amount',
	CONTRACT_STOP_LOSS_AMOUNT: 'Stop Loss Amount',
	CONTRACT_CLOSE_QTY: 'Enter Quantity',
	CONTRACT_ESTIMATED_PROFIT: 'Floating Point',
	CONTRACT_ESTIMATED_LOSS: 'Floating point',
	CONTRACT_TIP_ENTER_PROFIT_BUY: 'Profit must be greater than price',
	CONTRACT_TIP_ENTER_PROFIT_SELL: 'Profit must be less than price',
	CONTRACT_TIP_ENTER_LOSS_BUY: 'Loss must be less than price',
	CONTRACT_TIP_ENTER_LOSS_SELL: 'Loss must be greater than price',

	// others
	OTHERS_INDEX_PRICE: 'Price',
	OTHERS_INDEX_LEVER: 'Choose Lever',
	OTHERS_INDEX_QUANTITY: 'Quantity',


	// 输入值的小数位置最大不可超过设置值
	COMMON_TIP_ENTER_POINT_PREFIX: `Up to `,
	COMMON_TIP_ENTER_POINT_SUFFIX: ` decimal places`,
	COMMON_TOP_ENTER_NUMBER: 'Please enter a valid value',
	COMMON_SUCCESS: 'Success',

	SERVICE_CONTACT_MANAGER: `Please contact an account manager`,
	BIANJI_GERENZILIAO: 'Edit Profile',
	SHEZHI_WODETOUXIANG: 'Set my avatar',
	SHEZHI_WODENICHEN: 'Set my nickname',
	QINGSHU_RUNICHEN: 'Please enter a nickname',
	SHOUJI_HAO: 'Phone number',
	QINGSHU_RUSHOUJIHAO: 'Please enter phone number',
	YOUXIANG: 'Account',
	QINGSHU_RUYOUXIANGDIZHI: 'please input your email',
	QUEREN: 'Confirm',
	HUOBI: 'Currency',
	SHANGPIN: 'Commodity',
	WAIHUI: 'Forex',
	GUPIAO: 'Stocks',
	MINGCHEN: 'Name',
	ZUIXIN_JIA: 'Latest price',
	ZAHNGDIE_FU: 'Quote',
	GEREN_XINXI: 'Personal Data',
	FUZHI: 'Copy',
	CHANGYONG_SHEZHI: 'General Setting',
	GENGGAI_DENGLUMIMA: 'Change login password',
	GENGGAI_ZHIFUMIMA: 'Change payment password',
	GUANLI_TIXIANDIZHI: 'Manage bank card',
	GUANLI_CHONGZHIDIZHI: 'Manage deposit address',
	SHIMING_RENZHENG: 'Certification',
	QITA_FUWU: 'Other Services',
	YONGHU_XIEYI: 'User Agreement',
	YINSI_SHUOMING: 'Privacy Statement',
	QINGCHU_HUANCUN: 'Clear cache',
	TUICHU_DENGLU: 'Sign out',
	JIUMI_MA: 'Old Password',
	XINMI_MA: 'New Password',
	ZAICI_QUERENXINMIMA: 'Reconfirm new password',
	CHONGZHI: 'Recharge',
	CHONGZHI_DIZHI: 'Deposit address',
	CHONGZHI_SHULIANG: 'Recharge quantity',
	QINGSHU_RUJINE: 'Please enter amount',
	QINGSHANG_CHUANGZHIFUPINGZHENG: 'Please upload payment receipt',
	CHONGZHI_JILV: 'Recharge record',
	JIAOYI_JINE: 'Transaction amount',
	CHONGZHI_SHIJIAN: 'Recharge time',
	DINGDAN_HAO: 'Order number',
	XIANGQING: 'Details',
	ZJING_DEHUIYUAN: 'Dear members, notice about service functions',
	XIANGMU_HUIBAOLV: 'Proficiency in Returns Ranking',
	HUIBAO_LV: 'Stock Rankings',
	ZUIDA_HUICHE: 'Retracement',
	SHOUYI: 'Profit',
	GENTOU_RENSHU: 'Followers',
	GENSUI_RENSHU: 'Followers Ranking',
	JIAOYI: 'Transaction',
	GENDAN: 'Follow orders',
	FOF: 'FOF Bill',
	GENSUI_JINEPAIMING: 'Follow Amount Ranking',
	GONGGAO_LIEBIAO: 'Notice list',
	ZONGZI_CHAN: 'Assets',
	ZIJIN: 'Funds',
	ZUORI_SHOUYI: 'Yesterdays profit',
	ZHANGHU_XIANGQING: 'Account Details',
	JILV: 'Record',
	GENSUI: 'Follow',
	DANGQIAN_GUZHI: 'Current valuation',
	HUANYING_DENGLU: 'Please Login',
	HUANYING_ZHUCE: 'Welcome Register',
	QINGZAI_XIAFANGTIANRU: 'Please enter your account password below',
	ZAHNGHAO: 'Account',
	MIMA: 'Password',
	YOUXIANG_YANZHENGMA: 'E-mail verification code',
	QUEREN_MIMA: 'Confirm Password',
	YINGYE_BUDAIMA: 'Codice Di Invito',

	TOUZI_SHOUYI: 'Investment income',
	JIAOYI_ZHANGHU: 'Transaction account',
	JINRI_BIANDONG: 'Todays changes',
	BIANDONG_LV: 'Change rate',
	JINRI_YINGKUI: 'Profit or loss',
	JINRI_YINGKUILV: 'Cate of return',
	ZIJIN_ZHANGHU: 'Funding Account',
	ZICHAN_MINGXI: 'Asset Details',
	YUNXING_SHIJIAN: 'Running time',
	DANGQIAN_GENTOUJINE: 'Follow Amount',
	PINGJUN_MEIRISHOUYI: 'Daily income',
	DANGQIAN_GENTOURENSHU: 'Follower number',
	TOUZI_JINE: 'Investment amount',
	LEIJI_SHOUYI: 'Cumulative income',
	QISHI_SHIJIAN: 'Start time',
	JIEZHI_RIQI: 'Deadline',
	KEYONG: 'Available',
	TIXIAN: 'withdraw',
	HUAZHUAN: 'Transfer',
	GENTOU_DAOQI: 'When the order expires, the amount will be automatically settled to the fund account',
	DONGJIE_YUE: 'Freeze Balance',
	GENDAN_ZIJIN: 'Copy Funds',
	GENDAN_SHOUYI: 'Follow-up income',
	GENTOU_JIAGE: 'Copy price',
	DAOQI_RIQI: 'Date of Expiry',

	YINHANG_ZAHNGHU: 'Bank account transfer',
	LIANXI_KEFU: 'Please contact customer service manager',
	GBP_ACCOUNT: 'EUR Account',
	DAZONG_JIAOYI: 'OTC',
	IPO: 'IPO',
	KEFU: 'Service',

	SHENGOU_SHULIANG: 'Subscription quantity',
	ZHONGQAIN_SHULIANG: 'Winning quantity',
	DINGDAN_HAO: 'Order number',
	SHENGOU_JIA: 'Subscription price',
	ZHONGQIAN_JINE: 'Winning amount',
	SHENGOU_RIQI: 'Subscription date',
	DINGDAN_HAO: 'Order number',
	SHENGOU_JIA: 'Subscription price',
	RENJIAO_RIQI: 'Payment date',
	GONGBU_RIQI: 'Announcement date',
	SHANGSHI_RIQI: 'Listing date',

	SOUSUO: 'Search',
	LISHI_JILV: 'History',
	MAIRU_JIAGE: 'Purchase price',
	QINGSHU_RUSHU: 'Please enter the quantity',
	XUANZE_GANGGAN: 'Select leverage',
	MAIRU_ZONGE: 'Total purchase amount',
	KEYONG_YUE: 'Available balance',
	QUEREN: 'Confirm',
	GANGGAN: 'lever',
	ZHIFU_JINE: 'Payment amount',
	SHULIANG: 'Quantity',
	MAIRU_SHIJIAN: 'Purchase time',
	MAIRU: 'Buy',
	XINWEN: 'News',

	GUPIAO_JIOAYI: 'Stocks',
	HUOBI_KUANGJI: 'FOF',
	IEO: 'IEO',
	QIQUAN: 'Option',
	JIAOYI_SUO: 'Exchange',
	HEYUE: 'Contract',
	TRADE_IPO_TITLE: 'IEO',
	TRADE_IPO_RECORD_TITLE: 'IEO Record',
	TRADE_IPO_LIST_PRICE: 'Price',
	TRADE_IPO_LIST_TOTAL: 'Total',
	TRADE_IPO_LIST_RC: 'Reserve Capacity',
	TRADE_IPO_LIST_LOCK: 'Lock',
	TRADE_IPO_LIST_DAY: 'Day',
	TRADE_IPO_DETAIL_TITLE: 'Detail',
	TRADE_IPO_PRICE: 'Price',
	TRADE_IPO_CT: 'Date Time',
	TRADE_IPO_SN: 'Order SN',
	TRADE_IPO_RECORD_DESC: 'Desc',
	TRADE_IPO_DETAIL_URL: 'White Paper',
	TRADE_IPO_DETAIL_WEBSITE: 'Website',
	TRADE_IPO_DETAIL_COIN_DESC: 'Coin Desc',
	TRADE_IPO_RECORD_APPLY_AMOUNT: 'Apply Amount',
	TRADE_IPO_RECORD_APPLY: 'Apply',
	TRADE_IPO_RECORD_SUCCESS: 'Success',
	// IPO 交易 申购成功记录
	TRADE_IPO_SUCCESS_SUB: 'Subscription',
	TRADE_IPO_SUCCESS_PRICE: 'Price',
	TRADE_IPO_SUCCESS_QUANTITY: 'Quantity',
	TRADE_IPO_SUCCESS_AMOUNT: 'Success Amount',
	TRADE_IPO_SUCCESS_FREEZE: 'Freeze',
	TRADE_IPO_SUCCESS_CT: 'Date Time',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order SN',
	TRADE_IPO_SUCCESS_UNPAY_AMOUNT: 'Unpay Amount',
	MAIRU_XIANGQING: 'Buy Details',
	COMMON_BUY: 'Buy',
	TRADE_IPO_RECORD_CREATETIME: 'Ganhando tempo',

	TIKUAN: 'Withdrawal',
	CHONGZHI: 'Deposit',
	JIJIN: 'EA Trading',
	CHONGZHI_KEFU: 'To recharge, please click the customer service Manager below and complete the recharge',
	LIANXI_KEFU: 'Customer Service Center',
	REAL_NAME: 'Account holder name',
	TIP_REAL_NAME: 'Please type in your name',
	BANK_NAME: 'Bank name',
	TIP_BANK_NAME: 'Enter or select a bank',
	BANK_CARD: 'Bank card number',
	TIP_BANK_CARD: 'Enter bank card number',
	BTN_CHANGE_BANK_CARD: 'Account management',
	BTN_BANK_SELECTED: 'Choose',
	IFSC: 'IFSC Code',
	YONGHU_ZHIFU: 'user_pay',

	DIZHI: 'Select Address',
	BANGKA: 'Add Account',
	DANGZAHNG_JINE: 'Amount received',

	BIBI_JIAOYI: 'Currency',
	DAIKUAN: 'Loan',
	KUAISU_CHONGBI: 'Quick deposit',
	KUAISU_TIBI: 'Quick withdrawal',
	SHENHE_DAIKUAN: 'After review by the platform, you can apply for a loan from the platform!',
	JIEDAI_CHANPIN: 'Loan product',
	JIEDAI_JINE: 'Loan amount',
	QINGSHU_JIEDAIE: 'Please enter the loan amount',
	HUANKUAN_ZHOUQI: 'Repayment period',
	RILI_LV: 'Daily interest rate',
	LIXI: 'Interest',
	HUANKUAN_FANGSHI: 'Repayment method',
	FANGKUAN_JIGOU: 'Lending institution',
	DAOQI_YICI: 'Repay the principal and interest once upon maturity',
	JIEKUAN_JILV: 'Loan record',
	DAIKUAN_JINE: 'Loan amount',
	ZHUANGTAI: 'Status',
	SOUSUO_BIZHONG: 'Search currency',
	ZIXUAN: 'Self-selected',
	MIAOHE_YUE: 'Second contract',
	BENWEI_HEYUE: 'U-based contract',
	KEYONG: 'Available',
	ZHANYONG: 'Occupied',
	ZHEHE: 'Converted',
	ZHANGHU_YUE: 'Account balance',
	JIAOYI_JILU: 'Record',
	DAISHEN_HE: 'Pending review',
	TIAN: 'Days',
	TONGGUO: 'Passed',
	WEITONG_GUO: 'Failed',

	QINGSHU_RUZHANGHAO: 'Please enter account',
	RINEI_JIAOYI: 'Day Trading',
	QIANGGOU: 'VIP',
	SHANDUI: 'Exchange',
	LIANGHUA_JIAOYI: 'Quantify',

	TRADE_DAY_TITLE: 'Intraday trading',
	TRADE_DAY_TABS: ['Day trading', 'Application status', 'Approval details'],
	TRADE_DAY_BUY: 'Apply',
	TRADE_DAY_TIP: 'Tip',
	TRADE_DAY_TIP_TEXT: [
		`After submitting the funds request, please wait for approval.`,
		'Once approved, the Q4 automated trading program will make automatic purchases based on trading signals.',
		'Please do not disclose trading-related information in the Q4 automated trading program to third parties, in order to maintain business confidentiality.',
	],
	TRADE_DAY_TIP_INPUT_AMOUNT: 'Please enter the amount',
	DEPOSIT_TITLE: 'Deposit',
	TRADE_DAY_MODAL_CONTENT: 'Confirm whether to apply? ',
	CANCEL: `Cancel`,
	CONFIRM: `Confirm`,
	TRADE_DAY_ORDER_STATUS: 'Status',
	TRADE_DAY_BUY_AMOUNT: 'Application amount',
	TRADE_DAY_SUCCESS: 'Amount passed',
	TRADE_DAY_ORDER_SN: 'Order number',
	TRADE_DAY_CREATE_TIME: 'date time',
	TRADE_VIP_TABS: ['Product List', 'Application Details'],

	XUAN_ZE_DIZHI: 'Select withdrawal Wallet',










}