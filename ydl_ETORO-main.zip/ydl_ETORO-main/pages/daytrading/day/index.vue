<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.RINEI_JIAOYI}}
			</view>
			<view style="margin-left:auto;">
				<view style="display: flex;align-items: center;">
					<image mode="aspectFit" src="/static/tongzhi.png" :style="$util.setImageSize(40)"
						@click="$util.linkService()" style="margin-left: 10px;"></image>
				</view>
			</view>
		</header>

		<view class="trade_day">
			<view style="padding-top: 120px;">
				<view
					style="display: flex;align-items: center;justify-content: space-between;background-color: #fff;margin:0 24rpx;padding: 24rpx;border-radius: 20rpx;box-shadow:rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgb(51 214 105 / 11%) 0px 0px 0px 1px;">
					<block v-for="(v,k) in $lang.TRADE_DAY_TABS" :key='k'>
						<view style="font-size: 28rpx;text-align: center;"
							:style="{color:curTab==k?$theme.PRIMARY:`#959CA0`}" @click="changeTab(k)">
							<image :src="`/static/trade_${k}.png`" mode="aspectFit" :style="$theme.setImageSize(64)">
							</image>
							<view>{{v}}</view>
						</view>
					</block>
				</view>
			</view>


			<template v-if="curTab==0">
				<view style="padding:18px;padding-bottom: 200rpx;">
					<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
						:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
						<text
							style="background-color: #D9FFE6;padding:8rpx;border-radius: 10rpx;margin-right: 12rpx;color: #35353A;">
							{{$lang.COMMON_AMOUNT}}
						</text>
						<input v-model="amount" type="digit" :placeholder="$lang.TRADE_DAY_TIP_INPUT_AMOUNT"
							:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
						<view :style="{color:$theme.RGBConvertToRGBA(`#33D669`,70)}" @click="chooseCurrency()">
							<text
								:style="{borderBottom:`1px dashed ${$theme.RGBConvertToRGBA(`#33D669`,20)}`}">{{curCurrency}}</text>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx;"
						:style="{color:$theme.LOG_LABEL}">
						<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
						<view :style="{color:$theme.LOG_VALUE}">
							<template v-if="available && available>0">
								<view class="margin-top-10" style="text-align: right;font-size: 18px;"
									:style="{color:$theme.PRIMARY}">
									{{` € `+$util.formatMoney(`${available}`,3)}}
								</view>
								<view style="color:#AAA;text-align: right;">
									{{` $ `+$util.formatUSD(`${available*eurToUsd}`,3)}}
								</view>
							</template>
							<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#33D669`,70)}"
								@click="linkDeposit">
								{{$lang.DEPOSIT_TITLE}}
							</view>
						</view>
					</view>

					<view class="text-center padding-10 color-white"
						style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
						@click="handleBuy()">
						{{$lang.TRADE_DAY_BUY}}
					</view>

					<view style="margin-top:20px;line-height: 1.5;padding:10px 0;" :style="{color:$theme.LOG_VALUE}">
						<view style="padding-bottom: 6px;">{{$lang.TRADE_DAY_TIP}}</view>
						<block v-for="(item,index) in $lang.TRADE_DAY_TIP_TEXT" :key="index">
							<view style="padding-bottom: 6px;font-size: 12px;">{{item}}</view>
						</block>
					</view>
				</view>
			</template>

			<!-- 申请记录和审批记录 -->
			<template v-else>
				<view style="padding:0 18px; padding-bottom: 100rpx;">
					<template v-if="!setList || setList.length<=0">
						<EmptyData></EmptyData>
					</template>
					<template v-else>
						<block v-for="(item,index) in setList" :key="index">
							<view
								style="padding:30rpx 0;margin:30rpx 0;position: relative;border-bottom: 1rpx dashed #3AC2906A;">
								<view style="position: absolute;top:0;right: 0;">
									<image src="/static/position_hold_icon.png" mode="widthFix"
										:style="$theme.setImageSize(320)"></image>
								</view>

								<!-- <view
								style=" padding:20rpx 30rpx;border-radius: 8rpx;margin-top:24rpx;border: 1px #00a997 solid; border-radius: 10px;"> -->
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
									<view style="color:#666;font-size: 12px;">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
									<view :style="{color:colors[item.status]}">
										{{$lang.TRADE_DAY_STATUS_APPROVAL[item.status]}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
									<view style="color:#666;font-size:12px;">
										{{$lang.TRADE_DAY_BUY_AMOUNT}}
									</view>
									<template v-if="curTab==1">
										<view>
											<view style="color:#33d669;">{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
											</view>
											<view>{{`$ `+$util.formatUSD(`${item.money*eurToUsd}`,3)}}</view>
										</view>
									</template>
									<template v-if="curTab==2">
										<view>
											<template v-if="$util.isEur(item.project_type_id)">
												{{`€ `+$util.formatMoney(`${item.money*1}`,3)}}
											</template>
											<template v-else>
												{{`$ `+$util.formatUSD(`${item.money}`,3)}}
											</template>
										</view>
									</template>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
									<view style="color:#666;font-size: 12px;">
										{{$lang.TRADE_DAY_SUCCESS}}
									</view>
									<template v-if="curTab==1">
										<view>
											<view style="color:#33d669;">
												{{`€ `+$util.formatMoney(`${(item.success||0)*1}`,3)}}
											</view>
											<view>{{`$ `+$util.formatUSD(`${(item.success||0)*eurToUsd}`,3)}}</view>
										</view>
									</template>
									<template v-if="curTab==2">
										<view>
											<template v-if="$util.isEur(item.project_type_id)">
												{{`€ `+$util.formatMoney(`${(item.success||0)*1}`,3)}}
											</template>
											<template v-else>
												{{`$ `+$util.formatUSD(`${(item.success||0)*eurToUsd}`,3)}}
											</template>
										</view>
									</template>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
									<view style="color:#666;font-size: 12px;">
										{{$lang.TRADE_DAY_ORDER_SN}}
									</view>
									<view style="font-size: 28rpx;">
										{{item.ordersn}}
									</view>
								</view>

								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
									<view style="color:#666;font-size: 12px;">
										{{$lang.TRADE_DAY_CREATE_TIME}}
									</view>
									<view style="font-size: 28rpx;padding-left: 24rpx;">
										{{item.created_at}}
									</view>
								</view>
							</view>
						</block>
					</template>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				amount: '', // 输入金额
				available: '', // 可用余额
				orderList: [], // 申请列表
				successList: [], // 通过列表
				eurToUsd: 1, // 欧转美
				curCurrency: 'EUR', // 默认币种
			}
		},
		computed: {
			// 列表数据
			setList() {
				if (this.curTab == 0) return [];
				if (this.curTab > 0) {
					return this.curTab == 1 ? this.orderList : this.successList;
				}
			},
			colors() {
				return ['#FFB044', '#03B467', '#FF2D30'];
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				this.getConfig(); // 每次重新请求汇率
				if (this.curTab == 0) this.getAccountInfo(); // 账户信息
				if (this.curTab == 1) this.getOrderList();
				if (this.curTab == 2) this.getSuccessList();
			},
			// 选择充值币种
			chooseCurrency() {
				this.curCurrency = this.curCurrency == 'EUR' ? `USD` : `EUR`;
			},
			// 跳转到充值页面
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			// 购买
			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TRADE_DAY_TIP_INPUT_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				// 弹层
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},

			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
					// this.curCurrency

				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					this.changeTab(1);
				}, 1000);
			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(result);
				this.available = result.totalZichan || 0;
			},


			// 申请列表
			async getOrderList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				if (!result) return false;
				console.log(result);
				this.orderList = result.length <= 0 ? [] : result;
			},

			// 审批结果列表
			async getSuccessList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/order-list`);
				if (!result) return false;
				console.log(result);
				this.successList = result.length <= 0 ? [] : result;
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>