<!-- 登入 注册 -->
<template>
	<view style="background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;min-height: 100vh;" :style="isSignIn?'background-image: url(/static/bg2.png);':'background-image: url(/static/bg3.png);'">
		<view class="flex">
			<view style="margin-top: 20%;margin-left: 8%;">

				<view v-if="isSignIn" style="color: #33D669;font-size: 28px;margin-top: 10px;text-transform: capitalize;">
					{{$lang.HUANYING_DENGLU}}
				</view>
				<view v-if="!isSignIn" style="color: #33D669;font-size: 28px;margin-top: 10px;text-transform: capitalize;">
					{{$lang.HUANYING_ZHUCE}}
				</view>
				<view style="color: #8f8f90;font-size: 12px;margin-top: 10px;">{{$lang.QINGZAI_XIAFANGTIANRU}}</view>
			</view>
		</view>

		


		<view class="flex gap10 " style="padding: 0px 20px;">
			<!-- <view style="padding: 5px 15px;" :style="inv==1?'background-color: #112542;color:#1194f7;':'color:#868d9a'" @click="inv=1">账号</view> -->
			<!-- <view style="padding: 5px 15px;" :style="inv==2?'background-color: #112542;color:#1194f7;':'color:#868d9a'" @click="inv=2">邮箱</view>
			<view style="padding: 5px 15px;" :style="inv==3?'background-color: #112542;color:#1194f7;':'color:#868d9a'" @click="inv=3">手机</view> -->
		</view>

		<view  style="position: absolute;width: 80%;margin-left: 10%;" :style="isSignIn?'top: 30%;':'top: 22%;'">
		
			<view>
				<view style="color: #000;">{{$lang.ZAHNGHAO}}</view>
				<view class="">
					<!-- <image src="/static/account_name.png" mode="aspectFit" :style="$util.setImageSize(40)"></image> -->


					<view class="access_input_wrapper"
						style="padding:12rpx 16rpx;border: 1px #33D669 solid;">
						<view style="color:#666;">+39</view>
						<view style="padding:0 12rpx;color:#666;">|</view>
						<input v-model="user" type="text" :placeholder="$lang.QINGSHU_RUZHANGHAO"
							style="width: 80%;color: #000;"></input>
					</view>

					<!-- <u--input style="width: 100%;background-color: #27293B;padding: 10px;" v-model="user" type="text"
						:placeholder="$lang.QINGSHU_RUZHANGHAO" color="#fff" border="none"
						placeholderStyle="color:#666;" v-if="inv==1" clearable></u--input> -->


					<u--input style="padding: 10px;border: 1px #33D669 solid;" v-model="user" type="text"
						:placeholder="$lang.ENTER_USER_NAME" border="none" color="#000" placeholderStyle="color:#666"
						v-if="inv==2" clearable></u--input>

					<view v-if="inv==3" class="flex" style="background-color: #27293B;border-radius: 5px;">
						<VueCountryIntl schema="modal" v-model="phoneCountry" :visible.sync="show" @onChange="xuanze">
						</VueCountryIntl>

						<VueCountryFlag :value="phoneCountry" schema="popover" @click="show=true"
							style="margin-left: 15px;color: #fff;">
							<template v-slot="{country}">
								<span class="slot-span">+{{country.dialCode}}</span>
							</template>
						</VueCountryFlag>
						<u--input style="width: 100%;background-color: #27293B;padding: 10px;" v-model="user"
							type="text" placeholder="请输入手机号" border="none" placeholderStyle="color:#666" color="#fff"
							clearable>


						</u--input>
					</view>



				</view>
			</view>

			<!-- <view style="padding: 20px;" v-if="!isSignIn">
				<view style="color: #fff;">{{$lang.YOUXIANG_YANZHENGMA}}</view>
				<view class="flex" style="margin: 10px 0px 0 0;background-color: #27293B;border-radius: 5px;">
					<u--input style="width: 100%;padding: 10px;" v-model="email_code" type="text"
						:placeholder="$lang.INVITATION_CODE" border="none" placeholderStyle="color:#666" color="#fff"
						clearable></u--input>
					<view class="padding-5 radius10 color-white" style="background-color: #202328;margin-right: 10px;"
						@tap="getCode">{{tips}}</view>
					<u-code :seconds="seconds" @end="end" @start="start" ref="uCode" @change="codeChange"
						startText="Send" changeText="X" endText='Send'></u-code>
					</input>
				</view>
			</view> -->

			<view>
				<view>
					<view style="color: #000;">{{$lang.MIMA}}</view>
					<view class="flex"
						style=";padding: 10px 14px;border-radius: 5px;margin-top: 10px;border: 1px #33D669 solid;">
						<!-- <image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image> -->

						<template v-if="isShow">
							<input v-model="password" type="text" :placeholder="$lang.ENTER_PASSWORD"
								style="width: 80%;color: #000;"></input>
						</template>
						<template v-else>
							<input v-model="password" type="password" :placeholder="$lang.ENTER_PASSWORD"
								style="width: 80%;color: #000;"></input>
						</template>

						<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleShow" style="margin-left: auto;">
						</image>
					</view>
				</view>



				<template v-if="!isSignIn">

					<view class="margin-top-10">
						<view style="color: #000;">{{$lang.QUEREN_MIMA}}</view>
						<view class="flex"
							style=";padding: 10px 14px;border-radius: 5px;margin-top: 10px;border: 1px #33D669 solid;">
							<!-- <image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image> -->

							<template v-if="isShow">
								<input v-model="verifyPassword" type="text" :placeholder="$lang.VERIFY_PASSWORD"
									style="width: 80%;color: #000;"></input>
							</template>
							<template v-else>
								<input v-model="verifyPassword" type="password" :placeholder="$lang.VERIFY_PASSWORD"
									style="width: 80%;color: #000;"></input>
							</template>

							<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
								:style="$util.setImageSize(40)" @click="toggleShow" style="margin-left: auto;">
							</image>
						</view>



					</view>
					<view class="margin-top-10">
						<view style="color: #000;">{{$lang.YINGYE_BUDAIMA}}</view>
						<view class="flex"
							style=";padding: 10px 14px;border-radius: 5px;margin-top: 10px;border: 1px #33D669 solid;">
							<!-- <image src="/static/account_code.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image> -->
							<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
								style="width: 90%;color: #000;"></input>
						</view>
					</view>
				</template>

				<view
					style="display: flex;align-items: center;justify-content: center;margin-top: 10px;margin-bottom: 24rpx;"
					v-if="!isSignIn">
					<u-checkbox-group>
						<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_AGREE" v-model="isAgree"
							labelColor="#666666" labelSize="24rpx" @change="changeAgree"
							:checked="isAgree"></u-checkbox>
					</u-checkbox-group>
					<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
						{{$lang.TIP_PRVITE_PACT}}
					</view>
				</view>

				<view class="text-center" @click="handleConfirm()"
					style="background-color: #fff;padding: 10px 0;border-radius: 30px;color: #33D669;margin:20px;box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</view>

				<template v-if="isSignIn">
					<view
						style="padding:20px 20px 10px 20px;display: flex;align-items: center;justify-content: space-between;">

						<u-checkbox-group>
							<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
								v-model="isRemember" :labelColor="$theme.PRIMARY" labelSize="24rpx"
								@change="changeRemember" :checked="isRemember"></u-checkbox>
						</u-checkbox-group>

					<!-- 	<view style="font-size: 28rpx;margin-right: 4px;" :style="{color:$theme.LOG_VALUE}"
							@click="linkService()">
							{{isSignIn?$lang.FORGOT_PASSWORD:''}}
						</view> -->
					</view>
				</template>

				<!-- <template v-else>
				<view class="access_btn" @click="handleChange()" style="background-color: transparent;border-radius: 0;"
					:style="{color:$theme.PRIMARY}">
					{{$lang.SIGN_IN}}
				</view>
			</template> -->

			</view>
			<view class="flex flex-b" style="margin-top: 50px;">
				<view style="color: #33D669;" class="bold flex-1 text-center font-size-16"
					@click="handleChange()">{{$lang.GO_TO_SIGN_IN}}</view>
				<view style="color: #33D669;" class="bold flex-1 text-center font-size-16"
					@click="handleChange()">{{$lang.SIGN_UP}}</view>
			</view>
			<!-- <view class="access_wrapper">
			<view style="width: 100%;height: 100vh; border-radius: 30px 30px 0px 0px;padding-top: 20px;">
				<h3 style="font-size: 40rpx;text-align: center;padding-bottom:20px;" :style="{color:'#333333'}">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</h3>

				
			</view> -->

			<!-- <view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
				<image src='/static/top13.png' mode="aspectFit" :style="$theme.setImageSize(64)" @click="linkService()">
				</image>
			</view> -->
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="showLangList" :columns="[Object.values(langList)]" @change="changeLang"
			@cancel="showLangList=false" @confirm="confirmLang" :cancelText="$lang.COMMON_CANCEL"
			:confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"
			keyName="lang" visibleItemCount="9"></u-picker>

	</view>
</template>

<script>
	import localize from '@/common/localize.js';
	import CustomDivider from '@/components/CustomDivider.vue';

	import {
		getSmsCode
	} from '@/common/api.js';

	export default {
		components: {
			CustomDivider,
		},

		data() {
			return {
				isShow: false, // 密码显隐
				user: "",
				password: '',
				verifyPassword: '',
				code: '',
				isSignIn: true,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
				shareCode: '', // 分享链接携带的邀请码
				seconds: 60,
				tips: 'Send',
				email_code: "",
				inv: 1,
				phoneCountry: "93",
				show: false,
				phoneCountry_sel: 93,
				showLangList: false, // 是否显示语言选择器
			};
		},
		computed: {
			langList() {
				return localize
			}
		},
		onLoad(opt) {
			console.log(`opt:`, opt);
			if (opt.code && opt.code.length > 0) {
				this.isSignIn = false; // 设置到注册状态
				this.shareCode = opt.code || '';
			}
		},
		onShow() {
			// 读取缓存中的页面信息
			this.user = uni.getStorageSync('user');
			this.password = uni.getStorageSync('pwd');
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
		},
		mounted() {
			// 页面渲染完成，将邀请码复制到邀请码输入框
			this.code = this.shareCode;
		},
		methods: {
			linkService() {
				// this.$util.linkService();
				const url = 'https://wa.me/393409945485';
				if (window.android) {
					window.location.href=url;
					return false;
				}
				if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
					.nativeExt) {
					window.webkit.messageHandlers.nativeExt.postMessage({
						msg: 'open,' + url
					})
					return false;
				}
				let u = navigator.userAgent;
				let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
				if (isiOS) {
					window.location.href = url;
					return false;
				}
				window.open(url)
			},

			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				this.showLangList = false;
				uni.setStorageSync('lang', e.value[0].code);
				this.$util.setLang();
				this.$util.switchTabBar();
				uni.reLaunch({
					url: this.$paths.LAUNCH,
				})
			},

			xuanze(e) {
				console.log(2222, e, this.phoneCountry);
				console.log(this.phoneCountry);
				this.phoneCountry_sel = e.dialCode
			},
			codeChange(text) {
				this.tips = text;
			},
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				return !emailPattern.test(val)
			},
			async getCode() {
				if (this.checkEmail(this.user)) {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (!this.user || this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}

				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: 'Getting verification code'
					})

					const result = await this.$http.post(`api/app/sendSmsCode`, {
						mobile: this.user,
					})


					uni.hideLoading()
					console.log('result:', result);
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
				} else {
					uni.$u.toast('Send after the countdown ends');
				}
			},
			end() {
				// uni.$u.toast('倒计时结束');
			},
			start() {
				// uni.$u.toast('倒计时开始');
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PRVITE_PACT
				})
			},

			handleChange() {
				this.isSignIn = !this.isSignIn;
				if (this.isSignIn) {
					uni.setStorageSync('user', this.user);
					uni.setStorageSync('pwd', this.password);
				}
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.ENTER_PASSWORD);
					return false;
				}
				// if (!this.isSignIn && this.email_code == '') {
				// 	uni.$u.toast("Please fill in the email verification code");
				// 	return false;
				// }
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.$u.toast(this.$lang.ENTER_VERIFY_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && (!this.code || this.code.length <= 0)) {
					uni.$u.toast(this.$lang.ENTER_INVITATION_CODE);
					return false;
				}
				if (!this.isSignIn && this.isAgree != true) {
					uni.$u.toast(this.$lang.TIP_CHECK_AGREE);
					return false;
				}
				return true;
			},

			async signIn() {
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
					type: this.inv,
					phoneCountry: this.phoneCountry_sel
				})
				if (!result) return false;
				const token = result.token.access_token
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
				// this.setStorageData();
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: this.email_code,
					inv: this.inv,
					phoneCountry: this.phoneCountry_sel
				})
				if (!result) return false;
				uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
				this.signIn();
			},
		}
	}
</script>