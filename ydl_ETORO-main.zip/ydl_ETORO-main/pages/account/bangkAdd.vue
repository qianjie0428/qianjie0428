<!-- 绑定银行卡 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.GUANLI_TIXIANDIZHI}}
			</view>
		</view>

		<view class="common_block"
			style="box-shadow:rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgb(51 214 105 / 11%) 0px 0px 0px 1px;border: none;padding:24rpx;">
			<view :style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
				<view style="padding-top: 8px;">{{$lang.BANGKA_LEIXING}}</view>
				<view class="flex flex-b padding-10" @click="show=true">
					<view class="font-size-16" style="color: #AEAEAE;">{{huobi}}</view>
					<image src="/static/baisexia.png" mode="widthFix" style="width: 15px;"></image>
				</view>
			</view>

			<template v-if="type==2">
				<view style="padding-top: 8px;">{{$lang.ADDRESS_WALLET_ADDRESS}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="name_address" type="text" :placeholder="$lang.ADDRESS_TIP_ENTER_ADDRESS"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>
			</template>

			<template v-if="type==1">
				<view style="padding-top: 8px;">{{$lang.BANGKA_XINGMING}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="realname" type="text" :placeholder="$lang.BANGKA_SRXINGMING"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">{{$lang.BANK_NAME}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="bank_name" type="text" :placeholder="$lang.BANGKA_SRMINGCHENG"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">{{$lang.BANK_CARD}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="card_sn" type="text" :placeholder="$lang.BANGKA_SRKAHAO"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">{{$lang.BANGKA_SHOUKUAND}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="name_address" type="text" :placeholder="$lang.BANGKA_SRDIZHI"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">{{$lang.BANGKA_YINHANGDIHZI}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="bank_sub_name_address" type="text" :placeholder="$lang.BANGKA_SRYINGHAOD"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">SWIFT</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="ifcscode" type="text" placeholder="Enter SWIFT"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<view style="padding-top: 8px;">IBAN</view>
				<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
					:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
					<input v-model="iban" type="text" placeholder="Enter IBAN"
						:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				</view>

				<!-- <view style="padding: 10px 20px;">
					<view class="bold font-size-16">{{$lang.BANGKA_LEIXING}}</view>
					<input :placeholder="$lang.BANGKA_SRLEIXING" class="flex flex-b padding-10 margin-top-10 radius10"
						style="border: #31353a 1px solid;" v-model="type" />
				</view> -->
			</template>
		</view>

		<view class="text-center padding-10 color-white"
			style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
			@click="replaceBank()">
			{{$lang.COMMON_CONFIRM}}
		</view>
		<!-- <view class="text-center padding-10 color-white"
			style="margin:40rpx auto;width: 90%;color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;border: 1px solid #33D669;"
			@click="linkBank()">
			{{$lang.MY_BANK_CARD}}
		</view> -->

		<u-picker :show="show" :columns="[columns]" @confirm="confirm" @cancel="show=false" @close="show = false"
			closeOnClickOverlay :confirmText="$lang.COMMON_CONFIRM" :cancelText="$lang.COMMON_CANCEL"></u-picker>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				show: false,
				type: 1,
				huobi: "Card",
				columns: ['ERC20-USDT', 'TRC20-USDT', 'Card'],

				address: "",
				realname: "",
				bank_name: "",
				card_sn: "",
				name_address: "",
				bank_sub_name_address: "",
				ifcscode: "",
				iban: "",
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkBank() {
				uni.navigateTo({
					url: "/pages/account/bangk"
				})
			},
			confirm(e) {
				console.log('confirm', e)
				this.show = false
				this.huobi = e.value[0]
				if (e.indexs[0] == 2) {
					this.type = 1
				} else {
					this.type = 2
				}

			},
			home() {
				uni.switchTab({
					url: this.$paths.ACCOUNT_CENTER
				});
			},
			//跟换银行卡
			async replaceBank() {
				if (this.type == 2) {
					if (!this.name_address || this.name_address == '') {
						uni.showToast({
							title: this.$lang.ADDRESS_TIP_ENTER_ADDRESS,
							icon: 'none'
						});
						return false;
					}
				}
				if (this.type == 1) {
					if (!this.realname || this.realname == '') {
						uni.showToast({
							title: this.$lang.BANGKA_SRXINGMING,
							icon: 'none'
						});
						return false;
					}
					if (!this.bank_name || this.bank_name == '') {
						uni.showToast({
							title: this.$lang.BANGKA_SRMINGCHENG,
							icon: 'none'
						});
						return false;
					}
					if (!this.card_sn || this.card_sn == '') {
						uni.showToast({
							title: this.$lang.BANGKA_SRKAHAO,
							icon: 'none'
						});
						return false;
					}
					if (!this.name_address || this.name_address == '') {
						uni.showToast({
							title: this.$lang.BANGKA_SRDIZHI,
							icon: 'none'
						});
						return false;
					}
					if (!this.bank_sub_name_address || this.bank_sub_name_address == '') {
						uni.showToast({
							title: this.$lang.BANGKA_SRYINGHAOD,
							icon: 'none'
						});
						return false;
					}
					if (!this.ifcscode || this.ifcscode == '') {
						uni.showToast({
							title: `Enter SWIFT`,
							icon: 'none'
						});
						return false;
					}
					if (!this.ifcscode || this.ifcscode == '') {
						uni.showToast({
							title: `Enter SWIFT`,
							icon: 'none'
						});
						return false;
					}
					if (!this.iban || this.iban == '') {
						uni.showToast({
							title: `Enter IBAN`,
							icon: 'none'
						});
						return false;
					}
				}



				uni.showLoading({
					title: 'Submitting'
				});
				const result = await this.$http.post('api/user/bindBankCard', {
					huobi: this.huobi,
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
					name_address: this.name_address,
					bank_sub_name_address: this.bank_sub_name_address,
					ifcscode: this.ifcscode,
					IBAN: this.iban,
					address: this.address,
					type: this.type,
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: 'Successfly',
					icon: 'success'
				})
				setTimeout(() => {
					uni.navigateTo({
						url: "/pages/account/bangk"
					});
				}, 1000);
			},
		},
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		padding: 50px 0 0;
	}

	.header {
		height: 55px;
		background: #fff;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}
	}

	.bankInfo-box {
		padding: 16px;
		background: #fff;
	}

	.list {
		padding: 0 22px;
		margin-bottom: 16px;
		height: 48px;
		background: #f6f6f6;
		border-radius: 24px;
	}

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #1c4199;
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
		// background: #f5f5f5;

		.bank-name {
			padding: 0 22px;
			margin-bottom: 16px;
			height: 48px;
			background: #f6f6f6;
			border-radius: 24px;

			view {
				width: 22%;
			}

			input {
				margin-left: 60rpx;
				font-weight: 400;
				font-size: 28rpx;
			}
		}

		.xian {
			height: 2rpx;
			width: 100%;
			background: #fff;
		}
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #1c4199;
		margin: 100rpx 30rpx;
		border-radius: 24px;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		// font-weight: 600;
		font-size: 28rpx;
	}
</style>