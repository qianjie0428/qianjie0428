<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{isPay? $lang.GENGGAI_ZHIFUMIMA: $lang.GENGGAI_DENGLUMIMA}}
			</view>
		</view>

		<view style="background-color: #E8FFEF;border-radius: 10rpx;padding:40rpx;margin:24rpx;
		display: flex;align-items: center;justify-content: space-between;">
			<view>
				<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
			</view>
			<view style="flex: 1;padding-left: 48rpx;">
				<template v-if="userInfo">
					<view style="color: #333;font-size: 16px;">{{userInfo.real_name}}</view>
					<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{userInfo.mobile}}</view>
				</template>
			</view>

		</view>

		<view style="padding:24rpx;margin:24rpx;border-radius: 20rpx;
		box-shadow:rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgb(51 214 105 / 11%) 0px 0px 0px 1px;">
			<view>{{$lang.JIUMI_MA}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="value" :password="isShow" :placeholder="$lang.TIP_OLD_PWD"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
			</view>

			<view style="padding-top: 15px;">{{$lang.XINMI_MA}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="value2" :password="isShow" :placeholder="$lang.TIP_NEW_PWD"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				<view style="margin-left: auto;">
					<image :src="`/static/icon_${isShow?'show':'hide'}.png`" mode="aspectFit"
						:style="$util.setImageSize(40)" @click="toggleShow">
					</image>
				</view>
			</view>

			<view style="padding-top: 10px;">{{$lang.ZAICI_QUERENXINMIMA}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="value3" :password="isShow" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				<view style="margin-left: auto;">
					<image :src="`/static/icon_${isShow?'show':'hide'}.png`" mode="aspectFit"
						:style="$util.setImageSize(40)" @click="toggleShow">
					</image>
				</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="text-center padding-10 color-white"
				style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
				@click="changePassword()">
				{{$lang.QUEREN}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				value: "",
				value2: "",
				value3: "",
				userInfo: null,
				tag: '', // 当前页面角色 登录 or 支付
			};
		},
		computed: {
			isPay() {
				return this.tag == 'pay';
			}
		},
		onLoad(opt) {
			this.tag = opt.tag || this.tag;
		},
		onShow() {
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 获取账户信息
			async getAccount() {
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			},

			//修改密码
			async changePassword() {
				const url = this.isPay ? `updatePayPassword` : `updateLoginPassword`;
				const result = await this.$http.post(`api/user/${url}`, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (!result) return false;
				// this.actionEvent();
				uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
				});
				if (!result) return false;
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000);
			},
		},
	}
</script>