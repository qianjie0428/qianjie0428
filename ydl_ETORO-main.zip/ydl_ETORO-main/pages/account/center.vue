<template>
	<view class="bg_center">
		<view class="flex" style="padding:40rpx 24rpx 24rpx 24rpx;">
			<template v-if="userInfo">
				<!-- border: 1px solid #16c0c1; -->
				<view style="border-radius: 100%;border: 1px solid #264543;" :style="$theme.setImageSize(100)"
					@click="bianji()">
					<image :src="!userInfo||!userInfo.avatar? `/static/logo.png`:userInfo.avatar" mode="aspectFit"
						:style="$theme.setImageSize(100)" @click="bianji()"></image>
				</view>
				<view class="flex-1 margin-left-10">
					<view class="flex">
						<view class="font-size-16" style="color: #333;">
							{{ `HI `+userInfo.real_name}}
						</view>
						<image src="/static/jiahao.png" mode="widthFix" style="width: 12px;margin-left: 10px;"
							@click="bianji()"></image>
					</view>
					<view class="font-size-10" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
						{{!userInfo?'':userInfo.mobile}}
					</view>
				</view>
				<view style="margin-left: auto;">
					<image src="/static/service.png" style="padding-right: 24rpx;" mode="aspectFit"
						:style="$util.setImageSize(40)" @click="$util.linkCustomerService()"></image>
				</view>
				<view style="margin-left: auto;">
					<image src="/static/lang.svg" mode="aspectFit" :style="$util.setImageSize(40)"
						@click="showLangList=true"></image>
				</view>
			</template>
		</view>

		<view style="margin:0 24rpx;background-color: #FFFBEC;border-radius: 10rpx 10rpx 0 0;padding:12rpx 24rpx;">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<view>
					<image src='/static/center_total_icon.png' mode="aspectFit" :style="$theme.setImageSize(120)">
					</image>
				</view>
				<view style="margin-left: auto;font-size: 32rpx;color: #FED326;text-transform:Uppercase;">
					{{$lang.CENTER_TOTAL_ASSETS}}
				</view>
			</view>
			<view style="border-top: 1rpx dashed #3AC2906A;padding-top: 24rpx;">
				<!-- <view style="text-align: center;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
					{{$lang.POSITION_BALANCE}}
				</view>
				<view style="color: #33D669;font-size: 20px;text-align: center;">
					{{!userInfo?'':$util.formatNumber(userInfo.money*1)}}
				</view> -->
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;line-height: 1.6;">
					<!-- <view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{$lang.POSITION_TOTAL}}
						</view>
						<view style="color: #242424;font-size: 16px;">
							{{!userInfo?'':$util.formatNumber(userInfo.totalZichan*1,4)}}
						</view>
					</view> -->
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{$lang.POSITION_TOTAL_PL}}
						</view>
						<view style="color: #242424;font-size: 16px;text-align: right;">
							{{!userInfo?'':$util.formatNumber(userInfo.totalYingli*1)}}
						</view>
					</view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;line-height: 1.6;"
					v-if="assets">
					<view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{!assets?'':assets[0].name}}
						</view>
						<view style="color: #242424;font-size: 16px;">
							{{!assets?'':$util.formatNumber(assets[0].money*1,4)}}
						</view>
					</view>
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{!assets?'':assets[1].name}}
						</view>
						<view style="color: #242424;font-size: 16px;text-align: right;">
							{{!assets?'':$util.formatNumber(assets[1].money*1,4)}}
						</view>
					</view>
				</view>
			</view>

			<view>
				<image src="/static/home/laba.png" mode="widthFix" style="width: 90px;height: 90px;"></image>
				<view class="flex"
					style="padding: 5px;border: 1px #FED326 solid;margin: -70px 10px;border-radius: 10px;">
					<view style="margin-left: 40px;width: 100%;">
						<u-notice-bar :text="text1" icon="" direction="column" speed="40" bgColor="#fff" color="#a7a8ac"
							url="/pages/componentsB/tag/tag"></u-notice-bar>
					</view>
				</view>
			</view>
		</view>

		<view class="flex"
			style="padding: 10px;margin-top: 10px;align-items: flex-start;margin-top: 70px;justify-content: space-between;">
			<view style="background-color: #FFFCD6;padding:24rpx;width: 40%;border-radius: 10rpx;">
				<view style="display: flex;align-items: center;" @tap="linkDeposit()">
					<view>
						<image src="/static/recharge.png" mode="aspectFill" :style="$theme.setImageSize(64)"></image>
					</view>
					<view style="padding-left: 24rpx;color: #484848;font-size: 14px;text-transform:Uppercase;">
						{{$lang.CHONGZHI}}
					</view>
				</view>
			</view>
			<view style="background-color: #ECFFF2;padding:24rpx;width: 40%;border-radius: 10rpx;">
				<view style="display: flex;align-items: center;" @tap="linkWithdraw()">
					<view>
						<image src="/static/withdraw.png" mode="aspectFill" :style="$theme.setImageSize(64)"></image>
					</view>
					<view style="padding-left: 24rpx;color: #484848;font-size: 14px;text-transform:Uppercase;">
						{{$lang.TIKUAN}}
					</view>
				</view>
			</view>
		</view>

		<view style="padding:24rpx;">
			<view style="display: flex;align-items: center;padding-bottom: 16rpx;border-bottom: 1px solid #EEEEEE;"
				@click="linkAuth()">
				<view>
					<image src="/static/1.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.AUTH_TITLE}}</view>
				<view style="margin-left: auto;">
					<template v-if="!userInfo">
						<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
					</template>
					<template v-else>
						<view :style="setStyle()"> {{curAuth}} </view>
					</template>
				</view>
			</view>

			<view style="display: flex;align-items: center;padding: 16rpx 0;border-bottom: 1px solid #EEEEEE;"
				@click="linkBankCard()">
				<view>
					<image src="/static/2.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.GUANLI_TIXIANDIZHI}}</view>
				<view style="margin-left: auto;">
					<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view>

			<!-- <view class="center_banner"></view> -->

			<view style="display: flex;align-items: center;padding: 16rpx 0;border-bottom: 1px solid #EEEEEE;"
				@click="linkPwd()">
				<view>
					<image src="/static/3.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.GENGGAI_DENGLUMIMA}}</view>
				<view style="margin-left: auto;">
					<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view>

			<view style="display: flex;align-items: center;padding: 16rpx 0;border-bottom: 1px solid #EEEEEE;"
				@click="linkPayPwd()">
				<view>
					<image src="/static/4.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.GENGGAI_ZHIFUMIMA}}</view>
				<view style="margin-left: auto;">
					<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view>

			<view style="display: flex;align-items: center;padding: 16rpx 0;border-bottom: 1px solid #EEEEEE;"
				@click="linkTradRecord()">
				<view>
					<image src="/static/5.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.ACCOUNT_TRADE_LOG}}</view>
				<view style="margin-left: auto;">
					<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view>

			<!-- <view style="display: flex;align-items: center;padding: 16rpx 0;border-bottom: 1px solid #EEEEEE;"
				@click="linkAbout()">
				<view>
					<image src="/static/6.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
				</view>
				<view style="padding-left: 24rpx;text-transform:Uppercase;"
					:style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">{{$lang.ABOUT_US}}</view>
				<view style="margin-left: auto;">
					<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view> -->
		</view>

		<view class="flex flex justify-center" style="border-radius: 10px;padding: 10px;margin: 30px 20px;">
			<image src="/static/tuichu.png" mode="widthFix" style="width: 20px;"></image>
			<view class="margin-left-10" style="color: #02B975;" @click="handleSignOut()">{{$lang.TUICHU_DENGLU}}
			</view>
		</view>

		<!-- 语言选择器 -->
		<u-picker :show="showLangList" :columns="[Object.values(langList)]" @change="changeLang"
			@cancel="showLangList=false" @confirm="confirmLang" @close="showLangList = false" closeOnClickOverlay
			:cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL"
			:confirmColor="$theme.PRIMARY" keyName="lang" visibleItemCount="9"></u-picker>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import localize from '@/common/localize.js';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
		},
		data() {
			return {
				showLangList: false, // 是否显示语言选择器
				showAmount: false, // 显示金额
				yan_show: true,
				hideAmount: '****', // 隐藏金额
				userInfo: null, // 基本信息
				selectedContent: 1,
				log_list: "",
				goods: "",
				info: "",
				assets: "",
				curTab: 0, //
				orderlist: "",
				order: "",

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
				text1: ['Attention Investors! 📢 Stock X has hit a new all-time high, breaking a key resistance level! Get ready for a fresh wave of gains!',
					'Market Update! 📈 Hot stock Y is soaring today with heavy inflows! Don’t miss out on this great opportunity!',
					'Announcement Alert📢 – Big news! Leading Bank Z has reported quarterly earnings above expectations. Watch for potential price movements!',
					'Investment Opportunity! 📢 Pharma stocks are on a strong uptrend! Could be the start of a new rally—investors, keep an eye on the leading stocks in the sector!',
					'Quick Reminder 📢 – Company W just released a major announcement, and the stock price is swinging! Current holders, manage risks and monitor intraday movements closely!',
					'Hot Off the Press! 🔥 IT sector stocks are performing exceptionally well! Multiple companies announce new contracts, creating opportunities. Stay tuned!',
				],
			}
		},
		computed: {
			langList() {
				return localize
			},
			curAuth() {
				if (this.userInfo) {
					console.log(`?`, this.userInfo);
					// 实名验证：-1未提交 0未审核  1通过 2未通过
					return [
						this.$lang.PROFILE_AUTH_UNSUBMIT,
						this.$lang.PROFILE_AUTH_UNAPPLY,
						this.$lang.PROFILE_AUTH_VERIFIED,
						this.$lang.PROFILE_AUTH_UNVERIFIED
					][!this.userInfo.is_check ? 0 : this.userInfo.is_check + 1]
				}
			},
		},
		onLoad(opt) {
			this.selectedContent = opt.tag && opt.tag.length > 0 ? 4 : this.selectedContent;
		},

		onShow() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo()
		},

		//下拉刷新
		onPullDownRefresh() {
			this.showContent(this.selectedContent);
			this.getConfig();
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			changeLang(e) {
				console.log(`changeMode e:`, e);
			},
			// 選擇器確認事件
			confirmLang(e) {
				console.log(`confirmMode e:`, e);
				this.showLangList = false;
				uni.setStorageSync('lang', e.value[0].code);
				this.$util.setLang();
				this.$util.switchTabBar();
				uni.reLaunch({
					url: this.$paths.LAUNCH,
				})
			},
			setStyle() {
				const temp = this.userInfo && this.userInfo.is_check == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
					padding: `0 4px`,
				}
			},
			// gbp转 gbp_usd
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`config:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.curTab == 1) {
				// 	this.isHold = false;
				// } else {
				// 	this.isHold = true;
				// }
				// this.getList();
			},
			bianji() {
				uni.navigateTo({
					url: '/pages/Introduction/EditProfile'
				})
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw'
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			huazhuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},

			linkAbout() {
				uni.navigateTo({
					url: this.$paths.ABOUT_US
				})
			},

			linkService() {
				this.$util.linkCustomerService();
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			linkPwd() {
				uni.navigateTo({
					url: '/pages/account/pwd'
				})
			},
			linkPayPwd() {
				uni.navigateTo({
					// url: '/pages/Introduction/Paymentpwd'
					url: '/pages/account/pwd?tag=pay'
				})
			},
			linkBankCard() {
				uni.navigateTo({
					url: '/pages/account/bangkAdd'
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: '/pages/Introduction/auth'
				})
			},
			yonghu() {
				uni.navigateTo({
					url: '/pages/about'
				})
			},
			yinshi() {
				uni.navigateTo({
					url: '/pages/account/pact'
				})
			},
			linkPassword(val = '') {
				this.handleClose();
				const temp = val.length > 0 ? `?role=${val}` : '';
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PASSWORD + temp
				});
			},

			// 登出
			handleSignOut() {
				uni.removeStorageSync('token');
				try {
					let version = uni.getStorageSync('version')
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
				}, 500)
			},


			showContent(content) {
				this.selectedContent = content;
				this.getassets()

			},

			async getassets() {
				const result = await this.$http.get(`api/user/assets`, {
					type: 2
				});
				console.log('info result：', result);
				if (!result) return false;
				this.assets = result;

				// this.typelog();
			},

			// async typelog() {
			// 	const result = await this.$http.get(`api/user/typelog`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.log_list = result;
			// },

			// async getEafof() {
			// 	const result = await this.$http.get(`api/jijin/order`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.order = result;
			// },


			// async getGentouEa() {
			// 	const result = await this.$http.get(`api/Gentouea/orderlist`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.orderlist = result;
			// },

			// async getMoneychange() {
			// 	const result = await this.$http.get(`api/user/moneychange`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.info = result;
			// 	console.log(this.info.userlevel);
			// },


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>