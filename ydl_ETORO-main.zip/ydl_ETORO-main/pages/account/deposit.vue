<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.CHONGZHI}}
			</view>
		</view>

		<view style="margin:0 24rpx;background-color: #FFFBEC;border-radius: 10rpx 10rpx 0 0;padding:12rpx 24rpx;">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<view>
					<image src='/static/center_total_icon.png' mode="aspectFit" :style="$theme.setImageSize(120)">
					</image>
				</view>
				<view style="margin-left: auto;font-size: 32rpx;color: #FED326;text-transform:Uppercase;">
					{{$lang.CENTER_TOTAL_ASSETS}}
				</view>
			</view>
			<view style="border-top: 1rpx dashed #3AC2906A;padding-top: 24rpx;">
				<view style="text-align: center;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
					{{$lang.POSITION_BALANCE}}
				</view>
				<view style="color: #33D669;font-size: 20px;text-align: center;">
					{{!userInfo?'': $util.formatNumber(userInfo.money*1)}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;line-height: 1.6;">
					<view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> EUR </view>
						<view style="color: #242424;font-size: 16px;">
							{{!userInfo?'': $util.formatNumber(userInfo.qianbao[0].money*1,3)}}
						</view>
					</view>
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> USD
						</view>
						<view style="color: #242424;font-size: 16px;text-align: right;">
							{{!userInfo?'': $util.formatNumber(userInfo.qianbao[1].money*1,3)}}
						</view>
					</view>

					<!-- <view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{$lang.POSITION_TOTAL}}
						</view>
						<view style="color: #242424;font-size: 16px;">
							{{!userInfo?'': $util.formatNumber(userInfo.totalZichan*1,4)}}
						</view>
					</view>
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
							{{$lang.POSITION_TOTAL_PL}}
						</view>
						<view style="color: #242424;font-size: 16px;text-align: right;">
							{{!userInfo?'': $util.formatNumber(userInfo.totalYingli*1)}}
						</view>
					</view> -->
				</view>
			</view>
		</view>

		<view style="padding:40rpx;">
			<view style="padding-top: 8px;">{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="amount" type="number" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				<view :style="{color:$theme.RGBConvertToRGBA(`#33D669`,70)}" @click="chooseCurrency()">
					<text
						:style="{borderBottom:`1px dashed ${$theme.RGBConvertToRGBA(`#33D669`,20)}`}">{{curCurrency}}</text>
				</view>
			</view>
		</view>

		<view class="text-center padding-10 color-white"
			style="margin:40rpx auto;width: 86%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
			@click="to_recharge()">
			{{$lang.COMMON_CONFIRM}}
		</view>
		<view class="text-center padding-10"
			style="margin:40rpx auto;width: 86%;color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;border: 1px solid #33D669;"
			@click="$util.linkCustomerService()">
			{{$lang.KEFU}}
		</view>
	</view>
</template>

<script>
	// import {
	// 	pathToBase64
	// } from '@/common/js_sdk.js';
	// import md5 from 'js-md5';
	export default {
		components: {},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				// curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				// info: {}, // 基本信息
				// obverseUrl: '',
				// formData: {
				// 	obverseUrl: '',
				// },
				// type: "5",
				userInfo: null,
				// bank: {},
				// eurToUsd: 1, // 欧转美
				// usdToEur: 1, // 美转欧
				curCurrency: 'EUR', // 默认币种
			};
		},
		computed: {
			// amountList() {
			// 	// 充值预置额
			// 	return [100, 500, 1000, 10000];

			// }
		},
		onLoad(option) {},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
			// this.amount = this.amountList[0];
			// this.getconfig();
		},
		onHide() {
			this.isAnimat = false;
		},

		methods: {
			// 选择充值币种
			chooseCurrency() {
				this.curCurrency = this.curCurrency == 'EUR' ? `USD` : `EUR`;
			},

			// // 点击复制邀请链接
			// async copy(text) {
			// 	// 获取域名
			// 	const temp = text;

			// 	const result = await uni.setClipboardData({
			// 		data: temp, //要被复制的内容
			// 	});
			// 	if (result[1].confirm) {
			// 		uni.showToast({
			// 			title: this.$lang.TIP_COPY_SUCCESS,
			// 			duration: 2000,
			// 			icon: 'success'
			// 		})
			// 	}
			// },

			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				// console.log(this.userInfo.userlevel);
			},

			// chongzhi() {
			// 	uni.navigateBack({
			// 		delta: 1,
			// 	})
			// },
			// 总资产显隐控制
			// handleShowAmount() {
			// 	this.showAmount = !this.showAmount;
			// },

			// async getconfig() {
			// 	const result = await this.$http.get(`api/app/config`);
			// 	const temp = result.reduce((map, item) => {
			// 		map.set(item.key, item.value);
			// 		return map;
			// 	}, new Map());

			// 	console.log(7777, temp.get('BankName'));
			// this.bank.BankName = temp.get('BankName') || this.bank.BankName;
			// this.bank.BankNo = temp.get('BankNo') || this.bank.BankNo;
			// this.bank.BankUser = temp.get('BankUser') || this.bank.BankUser;
			// this.bank.erc20 = temp.get('erc20') || this.bank.erc20;
			// this.bank.trc20 = temp.get('trc20') || this.bank.trc20;

			// 	console.log(this.bank);

			// 	this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
			// 	this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			// 	this.$forceUpdate()
			// },
			// quantity(val, index) {
			// 	this.curPos = index;
			// 	this.amount = val;
			// },
			// // 点击上传
			// async selectImg() {
			// 	const result = await uni.chooseImage({
			// 		count: 1,
			// 		sizeType: ['compressed'],
			// 		sourceType: ['album'],
			// 	});
			// 	console.log('result:', result);
			// 	const imageFile = result[1].tempFiles[0];
			// 	console.log('imageFile:', imageFile);

			// 	this.upimg(imageFile.path)
			// },
			// 上传图片
			// async upimg(tempFilePath) {
			// 	uni.showLoading({
			// 		title: this.$lang.STATUS_UPLOAD,
			// 	})
			// 	let Request = "Qwd3N5yp"
			// 	let time = parseInt(new Date().getTime() / 1000)
			// 	let str_url = ("/api/app/upload").toLowerCase()

			// 	let mdd = md5("XPFXMedS" + Request + str_url + time);

			// 	const result = await uni.uploadFile({
			// 		url: this.$http.BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
			// 		filePath: tempFilePath,
			// 		name: 'file',
			// 	});

			// 	console.log('result:', result);
			// 	uni.hideLoading();
			// 	if (result[1].statusCode == 200) {
			// 		const temp = JSON.parse(result[1].data);
			// 		console.log('temp:', temp);
			// 		this.formData.obverseUrl = temp[0].url;
			// 	}
			// },
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				// if (!this.amount || this.amount <= 0) {
				// 	uni.showToast({
				// 		title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
				// 		icon: 'none'
				// 	});
				// 	return false;
				// }
				// uni.showToast({
				// 	title: this.$lang.API_DATA_SUBMIT,
				// 	icon: 'none'
				// });
				// const result = await this.$http.post(`api/app/recharge`, {
				// 	money: this.amount,
				// 	type: this.type,
				// 	image: this.formData.obverseUrl || '',
				// 	desc: '',
				// });
				// if (!result) return false;
				// console.log('result:', result);
				// uni.showToast({
				// 	// title:this.$lang.API_POST_SUCCESS,
				// 	icon: 'success'
				// });
				// uni.navigateTo({
				// 	url: this.$paths.ACCOUNT_TRADE_LOG
				// });
				setTimeout(() => {
					this.$util.linkCustomerService();
				}, 1000)
			},
			// async getAccountInfo() {
			// 	const result = await this.$http.get(`api/user/assets`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.userInfo = result;
			// },



			//用户信息
			// async getAccountInfo() {
			// 	const result = await this.$http.get(`api/user/info`);
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.info = {
			// 		total: result.totalZichan || 0,
			// 		money: result.money || 0,
			// 	};
			// }
		},
	}
</script>
<style>
	.example {
		width: 150px;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}
</style>