<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.ACCOUNT_TRADE_LOG}}
			</view>
		</view>

		<TabsPrimary :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab == 0">
			<LogTrade></LogTrade>
		</template>

		<template v-if="curTab == 1">
			<LogDeposit></LogDeposit>
		</template>

		<template v-if="curTab == 2">
			<LogWithdraw></LogWithdraw>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			fanhui() {
				uni.navigateBack({
					delta: 1,
				})
			},
		},
	}
</script>