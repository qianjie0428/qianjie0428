<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.PAGE_TITLE_DE}}
			</view>
		</view>

		<template v-if="!cardManagement || cardManagement.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding:20rpx 24rpx 200rpx 24rpx;">

				<block v-for="(item,index) in cardManagement" :key="index">
					<view style="border-bottom: 1rpx dashed #3AC2906A;">
						<view style="border-radius: 12rpx;padding:24rpx;">
							<view class="flex">
								<view class="flex-1" style="color: #666;"> {{$lang.BANGKA_LEIXING}}</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.huobi}}
								</view>
							</view>

							<view class="flex" v-if="item.type==1">
								<view class="flex-1" style="color: #666;">{{$lang.BANGKA_XINGMING}}</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.realname}}
								</view>
							</view>

							<view class="flex" v-if="item.type==1">
								<view class="flex-1" style="color: #666;"> {{$lang.BANK_NAME}}</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.bank_name}}
								</view>
							</view>

							<view class="flex" v-if="item.type==1">
								<view class="flex-1" style="color: #666;"> {{$lang.BANK_CARD}}</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.card_sn}}
								</view>
							</view>

							<view class="flex">
								<view class="flex-1" style="color: #666;"> {{$lang.BANGKA_SHOUKUAND}}</view>
								<view
									style="text-align: right;font-size: 32rpx;max-width: 70%;  white-space: normal;overflow-wrap: break-word;">
									{{item.name_address}}
								</view>
							</view>

							<view class="flex flex-b" v-if="item.type==1">
								<view style="color: #666;">{{$lang.BANGKA_YINHANGDIHZI}}</view>
								<view class="" style="text-align: right;font-size: 32rpx;">
									{{item.bank_sub_name_address}}
								</view>
							</view>

							<view class="flex" v-if="item.type==1">
								<view class="flex-1" style="color: #666;"> SWIFT</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.ifcscode}}
								</view>
							</view>

							<view class="flex" v-if="item.type==1">
								<view class="flex-1" style="color: #666;">IBAN</view>
								<view style="text-align: right;font-size: 32rpx;">
									{{item.iban}}
								</view>
							</view>
							<!-- <view class="margin-left-20">
						<view class="bold font-size-18 color-white">{{item.huobi}}</view>
					<view style="color: #999999;margin-top: 10px;">{{item.address}}</view>


				</view> -->
						</view>
					</view>
				</block>
			</view>
		</template>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="text-center padding-10 color-white"
				style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
				@click="renewal()">
				<!-- {{$lang.BTN_CONFIRM}} -->
				Add Account
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				cardManagement: [],
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$paths.HOME
				});
			},
			chongzhi() {
				uni.redirectTo({
					url: '/pages/Introduction/personaldata'
				})

			},
			renewal() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_BING_BANK_ADD
				});
			},
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				if (!result) return false;
				console.log(result);
				if (result.bank_card_info && result.bank_card_info.length > 0) {
					this.cardManagement = result.bank_card_info.filter(item => item.id > 0 && item.name_address !=
						'' && item.name_address != '');
					console.log(88888, this.cardManagement);

				}
			},
		},
		onLoad(option) {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		background: #f8f8f8;
		min-height: 100vh;
	}

	.top-pad {
		padding-top: 50px;
	}

	.header {
		height: 50px;
		background: #fff;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-center {
			font-size: 18px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}

		.header-left {
			width: 24px;
			height: 24px;
		}
	}

	.card {
		margin: 15px 15px 0 15px;
		padding: 15px;
		background: -webkit-linear-gradient(315deg, #1c4199, #40a2db);
		background: linear-gradient(135deg, #1c4199, #40a2db);
		border-radius: 6px;

		.card-top {
			color: #fff;
		}

		.card-num {
			font-size: 18px;
			font-weight: 700;
			color: #fff;
			margin-top: 15px;
		}
	}

	.pad {
		padding: 40px 15px;
	}

	.b-btn {
		width: 100%;
		height: 44px;
		line-height: 44px;
		background: #1c4199;
		border-radius: 22px;
		text-align: center;
		font-size: 16px;
		font-weight: 500;
		color: #FFFFFF;
		margin: 15px 0;
	}
</style>