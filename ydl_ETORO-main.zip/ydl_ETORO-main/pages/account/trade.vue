<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderPrimary :title="$lang.CONTRACT_POSITIONS" isSearch></HeaderPrimary>

		<view class="bg_position">
			<view style="padding: 240rpx 24rpx 0 24rpx;">
				<view style="border-radius: 10rpx;padding:30rpx;background-color: #fff;
					box-shadow:rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgb(51 214 105 / 11%) 0px 0px 0px 1px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<!-- <view>
							<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
								{{$lang.POSITION_BALANCE}}
							</view>
							<view style="color: #33D669;font-size: 20px;">
								{{!userInfo?'':  $util.formatNumber(userInfo.can_ti_money*1)}}
							</view>
						</view> -->
						<view>
							<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
								{{$lang.POSITION_FREEZE}}
							</view>
							<view style="color: #343434;font-size: 18px;">
								{{!userInfo?``: $util.formatNumber(userInfo.freeze*1)}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;">
						<view>
							<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> EUR </view>
							<view style="color: #242424;font-size: 16px;">
								{{!userInfo?'': $util.formatNumber(userInfo.qianbao[0].money*1,3)}}
							</view>
						</view>
						<view>
							<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> USD
							</view>
							<view style="color: #242424;font-size: 16px;text-align: right;">
								{{!userInfo?'': $util.formatNumber(userInfo.qianbao[1].money*1,3)}}
							</view>
						</view>
						<!-- <view>
							<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
								{{$lang.POSITION_TOTAL}}
							</view>
							<view style="color: #242424;font-size: 16px;">
								{{$util.formatNumber(userInfo.totalZichan*1,4)}}
							</view>
						</view>
						<view>
							<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
								{{$lang.POSITION_TOTAL_PL}}
							</view>
							<view style="color: #242424;font-size: 16px;text-align: right;">
								{{$util.formatNumber(userInfo.totalYingli*1)}}
							</view>
						</view> -->
					</view>
				</view>
			</view>

			<TabsFourth :tabs="$lang.TRADE_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curTab==0">
					<block v-for="(item,index) in list" :key="index">
						<view
							style="padding:30rpx;margin:30rpx 20rpx;position: relative;background-color: #fff;border-radius: 5px;"
							@tap.stop="handleSell(item.id)">
							<view style="position: absolute;top:0;right: 0;">
								<image src="/static/position_hold_icon.png" mode="widthFix"
									:style="$theme.setImageSize(320)"></image>
							</view>
							<view class="flex">
								<view
									style="background-color: #33D669;color:#fff;font-size: 16px;font-weight: bold;width: 20px;height: 20px;text-align: center;border-radius: 10rpx;">
									{{$util.isEur(item.goods_info.project_type_id)?`€ `: `$ `}}
								</view>
								<view class="flex-1" style="font-size: 36rpx;padding-left: 8px;">
									{{item.goods_info.name}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.price}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.price}`,3)}}
										</template>
									</view>
									<!-- <view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.price}`,3)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.price}`,3)}}
										</template>
									</view> -->
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
								<view style="font-size: 28rpx;">{{item.order_buy.num}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_PAY_PRICE}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay}`,3)}}
										</template>
									</view>
									<!-- <view style="color:#AAA;font-size: 24rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay}`,3)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay}`,3)}}
										</template>
									</view> -->
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.yingkui*1>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.yingkui}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.yingkui}`,3)}}11
										</template>
									</view>
									<!-- <view style="font-size: 24rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.yingkui*1>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`$ `+$util.formatUSD(`${item.order_buy.yingkui}`,3)}}
										</template>
										<template v-else>
											{{`€ `+$util.formatMoney(`${item.order_buy.yingkui}`,3)}}
										</template>
									</view> -->
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_RATE}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;"
										:style="$theme.setStockRiseFall(item.order_buy.rate>0)">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{ $util.formatUSD(`${item.order_buy.rate}`,2) }}%
										</template>
										<!-- <template v-else>
										  {{ $util.formatUSD(`${item.order_buy.rate}`,2) }}%
										</template> -->
										<template v-else>
										  {{ $util.formatUSD(`${item.order_buy.rate}`,2) }}%
										</template>
									</view>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
								<view style="font-size: 28rpx;text-align: right;">{{item.order_sn}}</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_CRETIME}}</view>
								<view style="font-size: 28rpx;text-align: right;">{{item.created_at}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center; justify-content: space-between;line-height: 1.6;border-top: 1rpx dashed #3AC2906A;padding-top: 16rpx;">
								<view
									style="color:#00AA98;padding:2px 8px;background-color: #00AA983A; border-radius: 6px;">
									{{item.order_buy.direct==1? $lang.POSIZIONE_LONG:$lang.POSIZIONE_SHORT}}
								</view>
								<view
									style="color:#33D669;padding:2px 6px; border-radius: 6px;font-size: 30rpx;border:1px solid #33D6696A;min-width: 40%;text-align: center">
									{{$lang.BTN_SELL}}
								</view>
							</view>
						</view>
					</block>
				</template>
				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view style="padding:30rpx;margin:30rpx 20rpx;position: relative;">
							<view style="position: absolute;top:0;right: 0;">
								<image src="/static/position_hold_icon.png" mode="widthFix"
									:style="$theme.setImageSize(320)"></image>
							</view>
							<view style="display: flex;align-items: center;">
								<view
									style="background-color: #33D669;font-size: 16px;font-weight: bold;width: 20px;height: 20px;text-align: center;border-radius: 10rpx;">
									{{$util.isEur(item.goods_info.project_type_id)?`€ `: `$ `}}
								</view>
								<view style="flex:0 0 auto;font-size: 36rpx;padding-left: 12rpx;">
									{{item.goods_info.name}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
								<view>
									<view style="font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.price}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.price}`,3)}}
										</template>
									</view>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_SELL_PRICE}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<view style="font-size: 28rpx;text-align: right;">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`€ `+$util.formatMoney(`${item.order_sell[0].price*1}`,3)}}
											</template>

											<template v-else>
												{{`$ `+$util.formatUSD(`${item.order_sell[0].price*1}`,3)}}
											</template>
										</view>
									</template>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
								<view style="font-size: 28rpx;">{{item.order_buy.num}}
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.ZHIFU_JINE}} </view>
								<view>
									<view style="font-size: 28rpx;text-align: right;">
										<template v-if="$util.isEur(item.goods_info.project_type_id)">
											{{`€ `+$util.formatMoney(`${item.order_buy.user_pay*1}`,3)}}
										</template>
										<template v-else>
											{{`$ `+$util.formatUSD(`${item.order_buy.user_pay*1}`,3)}}
										</template>
									</view>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<view style="font-size: 28rpx;text-align: right;"
											:style="$theme.setStockRiseFall(item.order_sell[0].yingkui*1>0)">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{`€ `+$util.formatMoney(`${item.order_sell[0].yingkui}`,3)}}
											</template>
											<template v-else>
												{{`$ `+$util.formatUSD(`${item.order_sell[0].yingkui}`,3)}}
											</template>
										</view>
									</template>
								</view>
							</view>

							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_RATE}}</view>
								<view>
									<template v-if="item.order_sell && item.order_sell[0]">
										<!-- float_yingkui/order_buy.price -->
										<!-- <view style="font-size: 28rpx;text-align: right;"
											:style="$theme.setStockRiseFall((item.order_sell[0].float_yingkui*1)/(item.order_buy.price*1)>0)">
											<template v-if="$util.isEur(item.goods_info.project_type_id)">
												{{ $util.formatMoney(`${(item.order_sell[0].float_yingkui*1)/item.order_buy.price}`,2) }}%
											</template>
											<template v-else>
												{{ $util.formatUSD(`${(item.order_sell[0].float_yingkui*1)/item.order_buy.price}`,2) }}%
											</template>
										</view> -->

										<!-- 做多（卖出-买入）/买入， -->
										<template v-if="item.order_sell[0].direct==1">
											<view style="font-size: 28rpx;text-align: right;"
												:style="$theme.setStockRiseFall((item.order_sell[0].price*1 - item.order_buy.price*1)/(item.order_buy.price*1)>0)">
				{{ $util.formatUSD(`${(item.order_sell[0].price*1 - item.order_buy.price*1)/item.order_buy.price*100}`,2) }}%
												
											</view>
										</template>
										<!-- 做空  （买入-平仓卖出价格）/买入 -->
										<template v-if="item.order_sell[0].direct==2">
											<view style="font-size: 28rpx;text-align: right;"
												:style="$theme.setStockRiseFall((item.order_buy.price*1-item.order_sell[0].price*1 )/(item.order_buy.price*1)>0)">
												{{ $util.formatUSD(`${(item.order_buy.price*1-item.order_sell[0].price*1 )/item.order_buy.price*100}`,2) }}%
											
											</view>
										</template>
									</template>
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
								<view style="font-size: 28rpx;text-align: right;">{{item.order_sn}}</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="color:#666;">{{$lang.SELL_TIME}}</view>
								<view style="font-size: 28rpx;text-align: right;">{{item.sell_time}}
								</view>
							</view>

							<view
								style="display: flex;align-items: center; justify-content: space-between;line-height: 1.6;border-bottom: 1rpx dashed #3AC2906A;padding-bottom: 16rpx;">
								<view
									style="color:#00AA98;padding:2px 8px;background-color: #00AA983A; border-radius: 6px;">
									{{item.order_sell[0].direct==1? $lang.POSIZIONE_LONG:$lang.POSIZIONE_SHORT}}
								</view>
							</view>
						</view>
					</block>
				</template>
			</template>
		</view>


		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
					<view class="popup_header">
						<text :style="{color:$theme.ACCESS_TEXT}"
							style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
						<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 10px;top:8px;"></image>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">{{info.goods_info.name}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.created_at}}
						</view>
					</view>
					<template v-if="!isHold">
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_sell.created_at}}
							</view>
						</view>
					</template>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}
						</view>
						<view style="flex: 30%;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}
						</view>
						<view style="flex: 20%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.order_buy.double}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
						<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="trade_modal_btn" style="background-color: #FF6700;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="trade_modal_btn" style="background-color:#00aa99;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import CustomTitle from '@/components/CustomTitle.vue';

	// import TradeHoldList from "@/components/trade/TradeHoldList.vue";
	// import TradeSellList from "@/components/trade/TradeSellList.vue";

	export default {
		components: {
			HeaderPrimary,
			TradeInfo,
			EmptyData,
			TabsFourth,
			CustomTitle,
			// TradeHoldList,
			// TradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: null, // 账户信息
				curTab: 0, // 

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
				timer: null,
				page: 1,
				assets: ""
			}
		},
		computed: {
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.page = 1;
			this.getconfig();
			// this.getassets()
			this.getAccount();
			// if (this.timer) this.clearTimer();
			if (this.curTab == 0) {
				this.getHolderList();
				// this.onSetTimeout();
			}
			if (this.curTab == 1) this.getHistoryList();
		},
		//下拉刷新
		onPullDownRefresh() {
			this.shuaxin();
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		onUnload() {
			// if (this.timer) this.clearTimer();
		},
		onHide() {
			this.isAnimat = false;
			// if (this.timer) this.clearTimer();
		},
		deactivated() {
			// console.log('deactivated', this.timer);
			// if (this.timer) this.clearTimer();
		},
		onReachBottom() {
			this.page = this.page + 1
			if (this.curTab == 0) this.getHolderList();
			if (this.curTab == 1) this.getHistoryList();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				this.page = 1; // 从第一页重新开始
				this.list = []; // 清空所有翻页后内中数据
				// if (this.timer) this.clearTimer();
				if (this.curTab == 0) {
					this.getHolderList();
					// this.onSetTimeout();
				}
				if (this.curTab == 1) this.getHistoryList();
			},

			shuaxin() {
				this.page = 1;
				this.list = []; // 清空所有翻页后内中数据
				if (this.curTab == 0) this.getHolderList();
				if (this.curTab == 1) this.getHistoryList();
			},
			// async getassets() {
			// 	const result = await this.$http.get(`api/user/assets`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.assets = result;

			// 	// this.typelog();
			// },

			// onSetTimeout() {
			// 	this.timer = setInterval(() => {
			// 		console.log("setInterval");
			// 		if (this.curTab == 0) this.getHolderList();
			// 	}, 3000);
			// },
			// clearTimer() {
			// 	if (this.timer) {
			// 		clearInterval(this.timer);
			// 		this.timer = null;
			// 		console.log('clearTimer', this.timer);
			// 	}
			// },
			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},

			// 平仓/卖出
			async handleSell(id) {
				console.log(`id:`, id);
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id: id,
				});
				if (!result) return false;
				uni.showToast({
					title: '',
					icon: 'success'
				})
				this.getAccount()
				setTimeout(() => {
					this.changeTab(this.curTab);
				}, 1000)

			},

			// 获取历史列表数据
			async getHistoryList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 2, // 1持仓，2历史
					gp_index: 0,
					page: this.page
				});
				console.log(`result:`, result);
				if (!result) return false;
				// check data
				const temp = result.data.filter(item => item.goods_info && item.order_buy && item.order_sell && item
					.order_sell.length > 0);
				this.list = this.list.concat(temp);

			},
			// 获取持有列表数据
			async getHolderList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 1, // 1持仓，2历史
					gp_index: 0,
					page: this.page
				});
				console.log(`result:`, result);

				if (!result) return false;
				// check data
				const temp = result.data.filter(item => item.goods_info && item.order_buy);
				// this.list = this.list.concat(temp);
				// 获取当前list中的所有id
				const ids = this.list.map(item => item.id);
				// 过滤 添加不重复的对象到新数组中
				const uniqueItems = temp.filter(item => !ids.includes(item.id));
				// // 获取 this.list 中不重复的对象
				// const uniqueItemsFromArray2 = this.list.filter(item => !temp.some(i => i.id === item.id));

				this.list = [...this.list, ...uniqueItems];
				console.log(this.list.length);
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},

			// handleShowModal(item) {
			// 	this.isShow = true;
			// 	this.info = item
			// },

			// // 平仓/卖出
			// handleSell(id) {
			// 	const _this = this;
			// 	uni.showModal({
			// 		title: this.$lang.SELL_TIP,
			// 		cancelText: this.$lang.BTN_CANCEL,
			// 		confirmText: this.$lang.BTN_CONFIRM,
			// 		success: function(res) {
			// 			this.isShow = false;
			// 			if (res.confirm) {
			// 				_this.confirmSell(id);
			// 			} else if (res.cancel) {}
			// 		}
			// 	})
			// },


			//用户信息
			async getAccount() {
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			},


			// 获取资产信息
			// async getAccountInfo() {
			// 	const result = await this.$http.get(`api/user/assets`, {
			// 		type: 2
			// 	});
			// 	console.log('info result：', result);
			// 	if (!result) return false;
			// 	this.userInfo = result;
			// },

			// // 平仓功能
			// async confirmSell(id) {
			// 	const result = await this.$http.post(`api/user/sell`, {
			// 		id
			// 	});
			// 	if (!result) return false;
			// 	this.getData();
			// },

			// handleStockDetail(code) {
			// 	uni.navigateTo({
			// 		url: `${this.$paths.COIN_OVERVIEW}?code=${code}`
			// 	});
			// },


		},
	}
</script>