<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.TIKUAN}}
			</view>
		</view>

		<view style="margin:0 24rpx;background-color: #FFFBEC;border-radius: 10rpx 10rpx 0 0;padding:12rpx 24rpx;">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<view>
					<image src='/static/center_total_icon.png' mode="aspectFit" :style="$theme.setImageSize(120)">
					</image>
				</view>
				<view style="margin-left: auto;font-size: 32rpx;color: #FED326;text-transform:Uppercase;">
					{{$lang.CENTER_TOTAL_ASSETS}}
				</view>
			</view>
			<view style="border-top: 1rpx dashed #3AC2906A;padding-top: 24rpx;">
				<view style="text-align: center;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}">
					{{$lang.POSITION_BALANCE}}
				</view>
				<view style="color: #33D669;font-size: 20px;text-align: center;">
					{{!userInfo?'': $util.formatNumber(userInfo.money*1)}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;line-height: 1.6;">
					<view>
						<view :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> EUR </view>
						<view style="color: #242424;font-size: 16px;">
							{{!userInfo?'': $util.formatNumber(userInfo.qianbao[0].money*1,3)}}
						</view>
					</view>
					<view>
						<view style="text-align: right;" :style="{color:$theme.RGBConvertToRGBA(`#343434`,70)}"> USD
						</view>
						<view style="color: #242424;font-size: 16px;text-align: right;">
							{{!userInfo?'': $util.formatNumber(userInfo.qianbao[1].money*1,3)}}
						</view>
					</view>
				</view>
			</view>
		</view>

		<view style="padding:20px;">
			<view :style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
				<view style="padding-top: 8px;">{{$lang.XUAN_ZE_DIZHI}}</view>
				<view class="flex flex-b padding-10" @click="show=true">
					<view class="font-size-16" style="color: #666;">{{!curMode?$lang.XUAN_ZE_DIZHI: curMode.name}}
					</view>
					<image src="/static/baisexia.png" mode="widthFix" style="width: 15px;"></image>
				</view>
			</view>

			<view :style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,5)}`}">
				<view style="padding-top: 8px;">{{$lang.CHOOSE_ADDRESS}}</view>
				<view class="flex flex-b padding-10" @click="showAddressList=true">
					<view
						style="flex: auto;width: 100%; max-width: 300px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;color: #AEAEAE;">
						{{!curAddress?$lang.CHOOSE_ADDRESS:curAddress}}
					</view>
					<image src="/static/baisexia.png" mode="widthFix" style="width: 15px;"></image>
				</view>
			</view>

			<view style="padding-top: 8px;">{{$lang.WITHDRAW_WITH_AMOUNT}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="amount" type="number" :placeholder="$lang.WITHDRAW_WITH_AMOUNT"
					:placeholder-style="$util.setPlaceholder()" autocomplete="off" style="flex:1;"></input>
				<view style="margin-left: auto;color:#3b3f44;" @click="handleAllAmount()">
					<text :style="{borderBottom:`1px dashed ${$theme.RGBConvertToRGBA(`#33D669`,50)}`}">
						{{$lang.COMMON_ALL}}
					</text>
				</view>
			</view>

			<view style="padding-top: 15px;">{{$lang.WITHDRAW_PAY_PWD}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="password" :password="isShow" :placeholder="$lang.TIP_WITHDRAW_PWD"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
				<view style="margin-left: auto;" @click="isShow=!isShow">
					<image :src="`/static/icon_${isShow?'show':'hide'}.png`" mode="aspectFit"
						:style="$util.setImageSize(40)">
					</image>
				</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="text-center padding-10 color-white"
				style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
				@click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>

		<!-- 弹窗选择器 -->
		<u-picker :show="show" :columns="[Object.values(modeOpts)]" @confirm="onConfirmMode" @cancel="show = false"
			@close="show = false" closeOnClickOverlay :cancelText="$lang.COMMON_CANCEL"
			:confirmText="$lang.COMMON_CONFIRM" keyName="name"></u-picker>

		<!-- Bank  選擇器 -->
		<template v-if="curMode">
			<u-picker :show="showAddressList" :columns="[curMode.address]" @change="changeBank"
				@cancel="showAddressList=false" @confirm="confirmBank" :cancelText="$lang.COMMON_CANCEL"
				:confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"
				keyName="name" visibleItemCount="9"></u-picker>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				show: false,
				password: '',
				isShow: false, // 是否掩码
				// 提现方式 多个银行卡以及多种钱包
				modeOpts: {
					// erc: {
					// 	key: `erc`,
					// 	name: `ERC20-USDT`,
					// 	address: [],
					// 	ids: [],
					// },
					// trc: {
					// 	key: `trc`,
					// 	name: `TRC20-USDT`,
					// 	address: [],
					// 	ids: [],
					// },
					card: {
						key: `card`,
						name: `Card`,
						address: [], // 放银行卡号数组
						ids: [],
					}
				},
				curMode: null, //  当前提现模式
				showAddressList: false,
				curAddress: null, // 当前选择提现地址，钱包地址or银行卡号
				bankList: [], // 钱包及银行卡数组

				userInfo: null,
				assets: "",

				eurToUsd: 1, // 欧转美
				usdToEur: 1, // 美转欧
			};
		},
		onShow() {
			this.isAnimat = true;
			this.getAccount();
			this.getconfig();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			handleAllAmount() {
				this.amount = this.userInfo.money;
			},

			changeBank() {},
			confirmBank(e) {
				this.curAddress = e.value[0];
				this.showAddressList = false;
				console.log(this.curAddress);
			},
			// 提现模式选择
			onConfirmMode(e) {
				this.curMode = e.value[0];
				this.show = false;
				this.curAddress = this.curMode.address[0];
			},
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				this.usdToEur = temp.get('usd_eur') || this.usdToEur;

				this.$forceUpdate()
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkRecord() {
				uni.navigateTo({
					url: '/pages/account/tradeLog'
				})
			},
			async handleWithdraw() {
				if (!this.curMode) {
					uni.showToast({
						title: this.$lang.XUAN_ZE_DIZHI,
						icon: 'none'
					});
					return false;
				}
				if (!this.curAddress) {
					uni.showToast({
						title: this.$lang.CHOOSE_ADDRESS,
						icon: 'none'
					});
					return false;
				}

				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.COMMON_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				if (!this.password || this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_WITHDRAW_PWD,
						icon: 'none'
					});
					return false;
				}

				let type = this.curMode.name == 'Card' ? 1 : 2;
				const temp = this.bankList.filter(item => item.name_address == this.curAddress || item.name_address ==
					this
					.curAddress);
				console.log('temp：', temp);
				const result = await this.$http.post(`api/app/withdraw`, {
					type: type,
					id: temp[0].id,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (!result) return false;
				setTimeout(() => {
					this.getAccount();
					this.linkRecord();
				}, 1000)

			},

			// 账户信息
			async getAccount() {
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('getAssets result：', result);
				if (!result) return false;
				this.userInfo = result;
				result.bank_card_info.forEach(item => {
					if (item.id > 0 && item.name_address != '' && item.name_address != '') {
						this.bankList.push({
							...item
						});
					}
					if (item.huobi == this.modeOpts.card.name) {
						if (item.name_address != null && item.name_address != '') {
							this.modeOpts.card.address.push(item.name_address);
						}
					}
					// if (item.huobi == this.modeOpts.erc.name) {
					// 	this.modeOpts.erc.address.push(item.name_address);
					// 	this.modeOpts.erc.ids.push(item.id);
					// }
					// if (item.huobi == this.modeOpts.trc.name) {
					// 	this.modeOpts.trc.address.push(item.name_address);
					// 	this.modeOpts.trc.ids.push(item.id);
					// }
				});
				console.log(`this.modeOpts`, this.modeOpts);
				if (!this.curMode) this.curMode = this.modeOpts.card;
				if (!this.curAddress) this.curAddress = this.curMode.address[0];
			}
		},
	}
</script>