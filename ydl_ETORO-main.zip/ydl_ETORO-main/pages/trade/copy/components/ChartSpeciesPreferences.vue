<template>
	<view>
		<view style="display: flex;align-items: center;padding:36rpx 36rpx 0 36rpx;">
			<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
			<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_DATA_SPECIES}}
			</view>
		</view>

		<!-- <view style="display: flex;align-items: center;padding:36rpx;padding-bottom: 0;">
			<block v-for="(item,index) in $lang.COPY_DETAIL_TV_TABS" :key="index">
				<view :style="setStyle(curTab==index)" @tap="changeTab(index)">{{item}}</view>
			</block>
		</view> -->

		<view style="display: flex;align-items: center;justify-content: center;">
			<canvas canvas-id="pie1" id="pie1" class="charts"></canvas>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import customUChart from '@/common/customUChart.js';
	// import {
	// 	ChartDataSpecies,
	// } from '../data.js';
	let uChartsInstance = {};
	export default {
		name: 'ChartSpeciesPreferences',
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				// curTab: 0, // 当前tab
				cWidth: 0,
				cHeight: 0,
			}
		},
		computed: {
			chartData() {
				if (this.info) {
					return {
						categories: this.info.bi,
						series: this.info.bi.map((item, index) => {
							return {
								name: item.toUpperCase(),
								data: this.info.shouyi[index] * 1
							}
						})
					}
				}
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			// changeTab(val) {
			// 	this.curTab = val;
			// 	this.genCharts();
			// },

			genCharts() {
				const ctx = uni.createCanvasContext("pie1", this);
				uChartsInstance["pie1"] = new uCharts(customUChart.pieChart(ctx,
					this.chartData,
					this.cWidth,
					this.cHeight))
			},

			// setStyle(val) {
			// 	return {
			// 		fontSize: `24rpx`,
			// 		textAlign: `center`,
			// 		borderRadius: `32rpx`,
			// 		padding: `4rpx 8rpx`,
			// 		color: val ? this.$theme.WHITE : '#8E8D92',
			// 		border: `1px solid ${val ? '#3B3B3D' : this.$theme.TRANSPARENT}`,
			// 		backgroundColor: this.$theme.TRANSPARENT,
			// 		minWidth: `120rpx`,
			// 	}
			// }
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>