<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex padding-15 margin-top-15">
			<view class="" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-1 text-center font-size-18" style="color: #33D669;">{{$lang.DAZONG_JIAOYI}}</view>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$util.setImageSize(40)"></image>
			</view>
		</view>

		<view class="trade_block">
			<view style="padding-top: 130px;"></view>

			<template v-if="!list|| list.length<=0">
				<EmptyData />
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="flex"
						style="padding: 20px;border-radius: 10px;margin:10px 16px;box-shadow:rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgb(51 214 105 / 11%) 0px 0px 0px 1px;">
						<view
							style="font-size: 14px; width: 120px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
							{{item.name}}
						</view>
						<view class="flex-1" style="color: #f65d43;text-align: center;">
							<template v-if="$util.isEur(item.project_type_id)">
								{{`€ `+$util.formatMoney(`${(item.price||0)*1}`,3)}}
							</template>
							<template v-else>
								{{`$ `+$util.formatUSD(`${(item.price||0)}`,3)}}
							</template>
						</view>
						<view style="background-color: #33D669;padding: 5px 20px;border-radius: 10rpx;color: #fff;"
							@click="handleDetail(item)">{{$lang.MAIRU}}</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;background-color: #FFF;">
				<view class="popup_header" style="background-color: #FFF;color: #202328;" :style="$theme.LG_PRIMARY">
					{{info.name}}
					<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
						@click="handleClose()">
					</image>
				</view>
				<view style="padding: 30rpx;">
					<view
						style="display: flex;flex-wrap: nowrap;align-items: center;justify-content:space-between;margin-top: 10px;">
						<text style="color:#666;">{{$lang.MAIRU_JIAGE}}</text>
						<view>
							<template v-if="$util.isEur(info.project_type_id)">
								{{`€ `+$util.formatMoney(`${(info.price||0)*1}`,3)}}
							</template>
							<template v-else>
								{{`$ `+$util.formatUSD(`${(info.price||0)}`,3)}}
							</template>
						</view>
					</view>

					<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
						:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
						<text
							style="background-color: #D9FFE6;padding:8rpx;border-radius: 10rpx;margin-right: 12rpx;color: #35353A;">
							{{$lang.COMMON_AMOUNT}}
						</text>
						<input v-model="amount" type="number" :placeholder="$lang.QINGSHU_RUSHU"
							:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
						<view :style="{color:$theme.RGBConvertToRGBA(`#33D669`,70)}">
							<text :style="{borderBottom:`1px dashed ${$theme.RGBConvertToRGBA(`#33D669`,20)}`}">
								{{$util.isEur(info.project_type_id)?`EUR`:`USD`}}
							</text>
						</view>
					</view>

					<!-- <view class=""
						style="padding-left: 20px;margin:30rpx 40rpx;background-color: #202328;padding: 15px;border: 1px #00aa98 solid ;border-radius: 10px;">
						<input v-model="amount" :placeholder="$lang.QINGSHU_RUSHU" type="number"
							style="width: 80%;color: #fff;"></input>
						<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
					</view> -->

					<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
					<!-- <template v-if="leverList.length>1">
					<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;">
						{{$lang.GANGGAN}}
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
						<block v-for="(item,index) in leverList" :key="index">
							<view
								style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
								:style="setStyle(curLever==item)" @click="chgangeLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template> -->

					<view
						style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:20rpx 0;">
						<view style="color:#666;">{{$lang.MAIRU_ZONGE}}</view>
						<view>
							<template v-if="$util.isEur(info.project_type_id)">
								{{`€ `+$util.formatMoney(`${(buyAmount||0)*1}`,3)}}
							</template>
							<template v-else>
								{{`$ `+$util.formatUSD(`${(buyAmount||0)}`,3)}}
							</template>
						</view>
					</view>

					<!-- <view class="common_input_wrapper" style="margin:30rpx 40rpx;padding-left: 20px;">
					<input v-model="password" :placeholder="$lang.TRADE_LARGE_TIP_BUY_PWD" type="password"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view> -->

					<!-- <view style="display: flex;align-items: center;justify-content: flex-end;padding:20rpx 50rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view style="padding-right: 10px;">{{$lang.KEYONG_YUE}}:</view>
					<view>{{available}}</view>
				</view> -->

					<view class="text-center" @tap.stop="handleConfirm()"
						style="margin:60rpx auto;width: 80%;background-color: #03b874;padding: 10px;border-radius: 10px;color: #fff;font-size: 18px;">
						{{$lang.QUEREN}}
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderThird,
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 是否显示购买弹层
				list: [], // 产品列表
				eurToUsd: 1, // 欧转美
				info: null, //
				amount: "", // 金额
				password: '', // 支付密码
				curLever: 1, // 当前杠杆值
			}
		},
		computed: {
			// 金额计算
			buyAmount() {
				return this.info.price * this.amount / this.curLever;
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getConfig(); // 每次重新请求汇率
			this.getList(); // 产品列表
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: '/pages/trade/large/record'
				})
			},
			handleDetail(val) {
				this.isShow = true;
				this.info = val;
			},
			// 关闭弹层
			handleClose() {
				this.isShow = false;
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async handleConfirm() {
				if (!this.checkForm()) return false;
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.info.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever,
				});
				if (!result) return false;
				this.handleClose();
				uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
				});
				setTimeout(() => {
					this.linkRecord();
				}, 1000)
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						project_type_id:item.goods.project_type_id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				});
			},
			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		},
	}
</script>