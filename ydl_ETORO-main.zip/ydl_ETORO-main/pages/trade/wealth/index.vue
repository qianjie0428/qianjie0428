<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx;">
			<view class="custom_header_left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<text class="custom_header_center" style="color:#33D669">{{$lang.LIANGHUA_JIAOYI}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$util.setImageSize(40)"></image>
			</view>
		</view>

		<view style="margin:0 10px;padding:10rpx;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;margin:30rpx 0;border-radius:24rpx;border: 1px #00AA98 solid;"
						@click="handleInfo(item)">
						<view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;font-size: 30rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666;font-size: 12px;">{{$lang.LICAI_YUGUSHOUYILV}}</view>
							<view style="font-size: 28rpx;">{{item.syl}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666;font-size: 12px;">{{$lang.LICAI_ZHOUQI}}</view>
							<view style="font-size: 28rpx;">{{item.zhouqi}} Giorni
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color:#666;font-size: 12px;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
							<view>
								<!-- <template v-if="$util.isEur(item.project_type_id)"> -->
									{{`€ `+$util.formatMoney(`${(item.min_price||0)*1}`,3)}}
								<!-- </template>
								<template v-else>
									{{`$ `+$util.formatUSD(`${(item.min_price||0)*eurToUsd}`,3)}}
								</template> -->
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto;background-color:#FFF;">
				<view class="popup_header" style="background-color:#FFF ;color: #202328;">
					{{$lang.TRADE_WEALTH_BUY_DETAIL}}
					<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
						@click="handleClose()">
					</image>
				</view>
				<view style="font-size: 16px;margin-left: 30rpx;color: #202328;padding:20rpx 0;">{{info.name}}</view>
				<template v-if="info.is_new==1">
					<view class="flex" style="justify-content: space-between;padding: 10rpx 20px;">
						<view style="color:#666;">{{$lang.LICAI_LEIXING}}</view>
						<view class="flex">
							<view
								style="background-color: #B2E8CD;font-size: 10px;padding: 5px;width: 80px;text-align: center;border-radius: 5px;color: #00B45A;">
								{{$lang.TRADE_WEALTH_NEW_USERS}}
							</view>
						</view>
					</view>
				</template>

				<view class="flex" style="justify-content: space-between;padding: 10rpx 20px;">
					<view style="color:#666;">{{$lang.LICAI_YUGUSHOUYILV}}</view>
					<view class="flex">
						<view>{{info.syl}}</view>
					</view>
				</view>

				<view class="flex" style="justify-content: space-between;padding: 10rpx 20px;">
					<view style="color:#666;">{{$lang.LICAI_ZHOUQI}}</view>
					<view class="flex">
						<view>{{info.zhouqi+$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
					</view>
				</view>

				<view class="flex" style="justify-content: space-between;padding: 10rpx 20px;">
					<view style="color:#666;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
					<view>
						<!-- <template v-if="$util.isEur(info.project_type_id)"> -->
							{{`€ `+$util.formatMoney(`${(info.min_price||0)*1}`,3)}}
						<!-- </template>
						<template v-else>
							{{`$ `+$util.formatUSD(`${(info.min_price||0)*eurToUsd}`,3)}}
						</template> -->
					</view>
				</view>
				<view style="padding:0 20px;">
					<template v-if="info.is_new!=1">
						<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
							:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
							<text
								style="background-color: #D9FFE6;padding:8rpx;border-radius: 10rpx;margin-right: 12rpx;color: #35353A;">
								{{$lang.COMMON_AMOUNT}}
							</text>
							<input v-model="amount" type="number" :placeholder="$lang.TRADE_WEALTH_BUY_AMOUNT"
								:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
							<view :style="{color:$theme.RGBConvertToRGBA(`#33D669`,70)}">
								<text :style="{borderBottom:`1px dashed ${$theme.RGBConvertToRGBA(`#33D669`,20)}`}">
									EUR
								</text>
							</view>
						</view>
						<view class="text-center padding-10 color-white"
							style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
							@click="handleBuy()">
							{{$lang.BTN_BUY}}
						</view>
					</template>
					<template v-if="info.is_new!=0">
						<view class="text-center padding-10 color-white"
							style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
							@click="home()">
							{{$lang.LICAI_KEFU}}
						</view>
					</template>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				isShow: false,
				info: null, // 选中一条数据
				eurToUsd: 1, // 欧转美
				amount: "", // 数量
			};
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
			this.getConfig(); // 每次重新请求汇率
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose() {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.info = item;
				this.isShow = true;
			},

			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT);
					return false;
				}
				if (this.amount < this.info.min_price) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT_TIP);
					return false;
				}
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.info.name} Payment Amount ${this.$util.formatMoney(this.amount)}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.info.id,
					ganggan: 1,
					price: this.amount,
				});
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				setTimeout(() => {
					this.isShow = false;
					this.getList();
				}, 1000);
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.eurToUsd = temp.get('eur_usd') || this.eurToUsd;
				// this.usdToEur = temp.get('usd_eur') || this.usdToEur;
			},
		}
	}
</script>

<style>
</style>