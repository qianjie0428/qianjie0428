<template>
	<view style="min-height: 100vh;">
		<!-- <HeaderSecond :title="$lang.PAGE_TITLE_SEARCH"></HeaderSecond> -->
		<view class="flex padding-20">
			<view @click="fanhui()">
				<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="flex-1 text-center" style="color: #fff;font-size: 18px;">{{$lang.SOUSUO}}</view>
		</view>
		<view style="margin:20px;">
			<u-search shape="round" :placeholder="$lang.TIP_SEARCH" v-model="keyword" :showAction="false" height="40px"
				:searchIconColor="$theme.PRIMARY" searchIconSize="30" bgColor="#ccc" @clear="keyword=''"
				:actionText="$lang.PAGE_TITLE_SEARCH" @search="searchButton" @custom="searchButton"></u-search>
		</view>

		<CustomTitle :title="$lang.SEARCH_HISTORY">
			<image mode="aspectFit" src="/static/delete.png" :style="$util.setImageSize(44)" style="margin-left: auto;"
				@click="clearKeywords()"></image>
		</CustomTitle>

		<view style="display: flex;align-items: center;margin:0 10px;padding:10px;flex-wrap: wrap;">
			<template v-if="keywords.length>0">
				<block v-for="(item,index) in keywords" :key="index">
					<view
						style="padding:4px 10px;margin:4px;border-radius: 16px;background-color: #34393e;color:#fff;"
						@click="selectedItem(item)">{{item}}</view>
				</block>
			</template>
		</view>

		<view style="">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="display: flex;align-items: center;padding:10px;background-color:#34393e ;" @click="linkInfo(item)">
					<!-- 	<template v-if="item.logo">
							<view style="width: 80rpx;margin:auto 0;">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
						</template> -->
						<view style="flex: 0 0 40%;padding-left: 6px;font-size: 36rpx;color:#666;" @tap="linkDetail(item)">
							<view>{{item.name}}</view>
							<view style="font-size: 24rpx;color:#666;">{{item.code}}</view>
						</view>
						<view style="margin-left: auto;text-align: right;" @tap="linkDetail(item)">
							<view :style="$util.setStockRiseFall(item.rate*1>0)">
								<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="aspectFit"
									:style="$util.setImageSize(24)"></image>
								{{item.rate}}%
							</view>
							<view style="font-weight: 800;font-size: 32rpx;color: #fff;">
								{{$util.formatCoin(item.price)}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>
<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
			CustomTitle,
			CustomLogo,
		},
		data() {
			return {
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,
			};
		},
		onReachBottom() {
			// 只要最大条数20，条件永不成立。
			if (this.list.length > this.limit) {
				this.curPage++;
				this.searchButton();
			}
		},
		onLoad() {
			this.keywords = uni.getStorageSync("keywords") || [];
		},
		methods: {
			// 点击查看股票详情
			linkInfo(val) {
				uni.navigateTo({
					url: this.$paths.COIN_OVERVIEW + `?code=${val.code}`
				});
			},
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.TRADE_COPY_DETAIL + `?id=${val}`
				});
			},
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?gid=${val.gid}`
				})
			},
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.searchButton()
			},

			//搜索
			async searchButton() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.$u.toast(this.$lang.TIP_SEARCH);
					return false;
				}
				const result = await this.$http.get(`api/product/list`, {
					key: this.keyword,
					page: this.curPage, 
					limit: this.limit,
					gp_index: 0
				});
				console.log('search result:', result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.name,
						code: item.code,
						price: item.current_price,
						rate: item.rate,
					}
				});
				console.log('list:', this.list);
				if (this.keywords.indexOf(this.keyword) < 0) {
					this.keywords.push(this.keyword);
					uni.setStorageSync("keywords", this.keywords)
				}
			},
			// 取关
			async handleUnFollow(gid) {
				const result = await updateFollow({
					gid: gid,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.getList()
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>