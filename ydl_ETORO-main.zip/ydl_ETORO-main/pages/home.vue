<template>
	<view>
		<!-- <image src="/static/home_banner.png" mode="widthFix" style="width: 100%;"></image> -->
		<view class="">
			<HeaderPrimary :title="$lang.TABBAR_HOME" isSearch></HeaderPrimary>
		</view>

		<view>
			<image src="/static/home_banner.jpg" mode="widthFix" style="width: 100%;"></image>
		</view>
		<view style="margin-top: -50px;padding:20px;">
			<view class="flex" style="background-color: #34393e;border-radius: 10px;">
				<block v-for="(item,index) in listinfo" :key="index" v-if="index==0||index==15||index==7">
					<view class="" style="padding: 15px;border-radius: 10px;">
						<view class="font-size-15 color-white">{{item.name}}</view>
						<view style="color: #02B975;" :style="$util.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
						<view style="color: #02B975;font-size: 18px;" :style="$util.setStockRiseFall(item.rate>0)">
							{{item.current_price}}
						</view>
					</view>
				</block>
			</view>

		</view>


		<view class="flex" style=" justify-content: space-between;padding: 10px;">
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradejiaoyi()">
				<image src="/static/top3.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.GUPIAO}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradegendan()">
				<image src="/static/top2.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.WAIHUI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTrabibi()">
				<image src="/static/top9.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.BIBI_JIAOYI}}</view>
			</view> -->
			<!-- <view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradaikuan()">
				<image src="/static/top10.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.DAIKUAN}}</view>
			</view> -->

		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;">
			<view style="flex:0 0 25%;" @tap="linkrinei()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/account.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">
						{{$lang.RINEI_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeipo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/ipo.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">{{$lang.IPO}}
					</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekeieo()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/etf.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">
						{{$lang.LIANGHUA_JIAOYI}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradeotc()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/commer.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">
						{{$lang.DAZONG_JIAOYI}}</view>
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: flex-start;justify-content: space-between;margin: 10px;margin-top: 0;">
			<view style="flex:0 0 25%;" @tap="linkqianggou()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/Finanza.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">{{$lang.QIANGGOU}}
					</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/veronome.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;">
						{{$lang.AUTH_TITLE}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @click="$u.route({url:'/pages/transfer/index'});">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/posizione.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;width: 60px;">
						{{$lang.TRANSFER_TITLE}}</view>
				</view>
			</view>
			<view style="flex:0 0 25%;" @tap="linkTradekefu()">
				<view style="display: flex;align-items: center;justify-content: center;flex-direction: column;">
					<image src="/static/home/assistenza.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="color: #343434;margin-top: 5px;text-align: center;font-size: 13px;width: 60px;">
						{{$lang.KEFU}}
					</view>
				</view>
			</view>
		</view>

		<view>
			<template>
				<image src="/static/home/laba.png" mode="widthFix" style="width: 90px;height: 90px;"></image>

				<view class="flex"
					style="padding: 5px;border: 1px #FED326 solid;margin: -70px 10px;border-radius: 10px;">
					<view style="margin-left: 40px;width: 100%;">
						<!-- <div class="marquee-container">
						  <div class="marquee">
						    <span>{{text1[0]}}</span>
						  </div>
						</div> -->
						<u-notice-bar :text="text1" icon="" direction="column" speed="40" bgColor="#fff" color="#a7a8ac"
							url="/pages/componentsB/tag/tag"></u-notice-bar>
					</view>


				</view>
			</template>
		</view>

		<view style="display: flex;align-items: center;padding:8px 16px;margin-top: 80px;" @click="linkTradejiaoyi()">

			<view style="font-size: 18px;color: #000;font-weight: 700;" class="flex justify-center">
				<image src="/static/biaoti.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 10px;">
				</image>
				Indice di mercato
			</view>

		</view>
		<view class="flex gap5" style="padding:10px;">
			<view style="background-size: contain;background-size: 100% 100%;background-repeat: no-repeat"
				class="flex-1 text-center" v-for="(item,index) in listinfo" v-if="index<=169"
				:style="item.rate>0?'background-image: url(/static/zhang.png);':'background-image: url(/static/die.png);'">
				<view class="margin-top-10">{{item.name}}</view>
				<view class="font-size-18 bold margin-top-5" :style="$util.setStockRiseFall(item.rate>0)">
					{{item.current_price}}</view>

				<view class="bold margin-top-5 flex gap5 text-center justify-center" style="width: 100%;"
					:style="$util.setStockRiseFall(item.rate>0)">
					<view class="font-size-12" style="border-radius: 5px;padding:2px 5px;"
						:style="item.rate>0?'background-color: #C2F7D3;':'background-color: #ffcaca;'">{{item.rate_num}}
					</view>
					<view class="font-size-12" style="border-radius: 5px;padding:2px 5px;"
						:style="item.rate>0?'background-color: #C2F7D3;':'background-color: #ffcaca;'">{{item.rate}}%
					</view>
				</view>
				<view style="margin-top:60px;"></view>
			</view>
		</view>

		<view style="display: flex;align-items: center;padding:8px 16px;margin-top: 10px;" @click="linkTradejiaoyi()">

			<view style="font-size: 16px;color: #000;" class="flex justify-center">
				<image src="/static/biaoti.png" mode="widthFix" style="width: 25px;height: 25px;margin-right: 5px;">
				</image>
				{{$lang.XIANGMU_HUIBAOLV}}
			</view>
			<!-- <view style="margin-left: auto;">
				<image src="/static/baijiantou.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
			</view> -->
		</view>

		<!-- <view class="flex padding-10 gap10">
			<view class="flex-1">
				<image src="/static/home/tu3.png" mode="widthFix" style="width: 100%;"></image>
			</view>
			<view class="flex-1">
				<image src="/static/home/tu1.png" mode="widthFix" style="width: 100%;"></image>
				<image src="/static/home/tu2.png" mode="widthFix" style="width: 100%;"></image>
			</view>
		</view> -->

		<!-- <u-modal :show="show" title="Non approvato" :content='content' :showCancelButton='true' :confirmText="$lang.AUTH_TITLE" :cancelText="$lang.COMMON_CANCEL" @cancel='show=false' @close='show=false' @confirm="$u.route({url:'/pages/Introduction/auth'});"></u-modal> -->

		<view style="padding:0rpx 5rpx;">

			<view>
				<!-- <view class="padding-10">
					<image src="/static/home/xinwen.png" mode="widthFix" style="width: 100%;"></image>
				</view> -->
				<scroll-view class=" " scroll-x="false" @scroll="scroll()" @click="home()">
					<view>
						<block v-for="(item, index) in levelinfo" :key="index">
							<view @click="open(item.url)"
								style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;padding: 10px;border-bottom: 1px #ccc solid;">
								<template v-if="curTab==0">
									<view style="flex:60%;padding-right: 30px;padding-top: 10px;color: #000;">
										<view>{{item.title}}</view>
										<view style="margin-top: 16px;color: #666666;"><text>{{item.created_at}}</text>
										</view>
									</view>
									<image :src="item.pic" :style="$theme.setImageSize(220,150)" mode="scaleToFill"
										style="border-radius: 10px;"></image>
								</template>
								<template v-else>
									<view style="flex:100%">
										<view style="color: #000;">{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;text-align: right;color: #000;">
											{{item.updated_at}}
										</view>
									</view>
								</template>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import index from 'uview-ui';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'MarketNews',
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			TabsFifth,
			CustomTitle,
			EmptyData,

		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				info: {}, // 基本信息
				scrollTop: 0,
				selectedContent: 0,
				message: [],
				listinfo: [],
				isShow: false,

				listinfo2: [],
				list: [],
				curTab: 0,
				levelinfo: [],
				AccountInfo: [],
				old: {
					scrollTop: 0
				},
				show: false,
				text1: ['Attention Investors! 📢 Stock X has hit a new all-time high, breaking a key resistance level! Get ready for a fresh wave of gains!',
					'Market Update! 📈 Hot stock Y is soaring today with heavy inflows! Don’t miss out on this great opportunity!',
					'Announcement Alert📢 – Big news! Leading Bank Z has reported quarterly earnings above expectations. Watch for potential price movements!',
					'Investment Opportunity! 📢 Pharma stocks are on a strong uptrend! Could be the start of a new rally—investors, keep an eye on the leading stocks in the sector!',
					'Quick Reminder 📢 – Company W just released a major announcement, and the stock price is swinging! Current holders, manage risks and monitor intraday movements closely!',
					'Hot Off the Press! 🔥 IT sector stocks are performing exceptionally well! Multiple companies announce new contracts, creating opportunities. Stay tuned!',
				],
			}
		},

		onShow() {
			this.getLevelInfo();
			this.getList()
			// this.getList2()


		},
		onLoad() {
			// this.getAccountInfo();
		},

		onHide() {
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},
		created() {
			this.ipoSuccess();
		},

		methods: {
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.show = result.is_check == 2 ? true : false;
			},
			open(url) {
				window.open(url)
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/account/withdraw',
				})
			},


			// 跳转到交易的股票分栏
			linkTradejiaoyi() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=0`,

				})
			},
			linkAuth() {
				uni.navigateTo({
					url: `/pages/Introduction/auth`
				})
			},
			linkTradegendan() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=1`,

				})
			},
			linkTragensui() {
				uni.navigateTo({
					url: '/pages/trade/copy/index',

				})
			},

			linkTradekeieo() {
				uni.navigateTo({
					url: '/pages/trade/wealth/index'
				})
			},
			linkrinei() {
				uni.navigateTo({
					url: '/pages/daytrading/day/index'
				})
			},
			linkTradaikuan() {
				uni.navigateTo({
					url: '/pages/remittance/index'
				})
			},
			// 弹层关闭
			handleClose() {
				this.isShow = false;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO + `?type=2`,
				})
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get(`api/app/renjiaoStatus`);
				console.log(22222, result);
				if (!result) return false;
				// if (result.code == 0) {
				if (result.status == 1) {
					this.msg = result.msg
					this.isShow = true;
				}
				// } else {
				// 	uni.$u.toast(result.data.message);
				// }
			},
			linkTradekefu() {
				// uni.navigateTo({
				// 	url: '/pages/service'
				// })
				this.$util.linkService()
			},
			// linkTradeheyue() {
			// 	uni.navigateTo({
			// 		url: '/pages/transfer/index'
			// 	})
			// },
			linkTradeipo() {
				uni.navigateTo({
					url: '/pages/trade/ipo/index'
				})
			},
			linkTradeotc() {
				uni.navigateTo({
					url: '/pages/trade/large/index'
				})
			},


			licai() {
				uni.switchTab({
					url: "/pages/trade/wealth/index"
				})
			},
			tongzhi() {
				uni.navigateTo({
					url: "/pages/tongzhi"
				})
			},
			linkqianggou() {
				uni.navigateTo({
					url: '/pages/daytrading/vip/index'
				})
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			// 跳转到市场
			linkMarket() {
				uni.switchTab({
					url: this.$paths.MARKET,
				})
			},

			home() {
				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},

			closeAll() {
				if (this.$refs.goods) this.$refs.goods.disconnect();
			},
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				uni.showToast({
					icon: "none",
					title: "纵向滚动 scrollTop 值已被修改为 0"
				})
			},
			// 
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?gid=${val.gid}`
				})
			},

			async getList() {
				const result = await this.$http.post(`api/goods/zhishu`, {});
				console.log(result);
				if (!result) return false;
				this.listinfo = result;
				console.log(this.listinfo);
				this.connect1()
			},

			async getList2() {
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: 8
				});
				console.log(result);
				if (!result) return false;
				this.listinfo2 = result;
				console.log(this.listinfo2);
			},


			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0 && data.type == 'ticker') {
						console.log(data);
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].rate_num = data.rate_num || 0;
					}

				});
			},
			connect1() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.listinfo[data.pid] && data.pid && data.last > 0) {
						// console.log(data);
						this.listinfo[data.pid].current_price = data.last;
						this.listinfo[data.pid].rate = data.pcp || 0;
						this.listinfo[data.pid].rate_num = data.pc || 0;
						// this.list[data.market].vol = data.vol || 0;
					}

				});
			},

			async getLevelInfo() {
				const result = await this.$http.get(`api/article/list`, {
					type: 11
				});
				if (!result) return false;
				this.levelinfo = result;
			},
		},

	}
</script>

<style>
	.marquee-container {
		width: 100%;
		/* 可以根据需要设置宽度 */
		overflow: hidden;
		/* 隐藏超出部分 */
		white-space: nowrap;
		/* 禁止换行 */
		padding: 10px 0;
		box-sizing: border-box;
	}

	.marquee {
		display: inline-block;
		white-space: nowrap;
		animation: marquee 10s linear infinite;
		/* 10s 是滚动时间，越大滚动越慢 */
	}

	.marquee span {
		display: inline-block;
		padding-left: 100%;
		/* 确保内容从右侧开始滚动 */
	}

	@keyframes marquee {
		0% {
			transform: translateX(100%);
			/* 从右侧开始 */
		}

		100% {
			transform: translateX(-100%);
			/* 向左滚动，直到完全隐藏 */
		}
	}

	.scroll-Y {
		height: 300rpx;
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		/* background-image: url(/static/dialog_bg_ipo_success.png); */
		background-color: #fff;
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 38vh;
		width: 80vw;
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		align-items: center;
		border-radius: 20px;
		padding: 20px 0;
	}

	.scroll-view-item_H {
		display: inline-block;
		border-radius: 10px;
		width: 80%;
		/* height: 300rpx; */
		/* line-height: 60rpx; */
		/* text-align: center; */
		font-size: 36rpx;
	}
</style>