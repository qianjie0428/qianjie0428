<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="bold font-size-18 flex-1 text-center" style="color: #33D669;text-transform:Uppercase;">
				{{$lang.BIANJI_GERENZILIAO}}
			</view>
		</view>

		<view style="padding: 0px 20px;display: flex;align-items: center;justify-content: space-between;">
			<view style="font-size: 32rpx;">{{$lang.SHEZHI_WODETOUXIANG}}</view>
			<view style="border-radius: 100%;margin-bottom: 10px;background-color: #264543;"
				:style="$theme.setImageSize(120)">
				<image :src="!avatar? `/static/avatar.png`:avatar" mode="aspectFit" :style="$theme.setImageSize(120)"
					@click="selectImg()"></image>
			</view>
		</view>

		<view style="padding:20px;">
			<view style="font-size: 32rpx;">{{$lang.SHEZHI_WODENICHEN}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="nick_name" type="text" :placeholder="$lang.QINGSHU_RUNICHEN"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
			</view>
		</view>

		<view style="padding:5px 20px;">
			<view style="font-size: 32rpx;">{{$lang.YOUXIANG}}</view>
			<view class="common_input_wrapper" style="margin-bottom: 16rpx;border-radius: 0;"
				:style="{borderBottom:`1px solid ${$theme.RGBConvertToRGBA(`#2E2E2E`,20)}`}">
				<input v-model="email" type="text" :placeholder="$lang.YOUXIANG"
					:placeholder-style="$util.setPlaceholder()" style="flex: 1;"></input>
			</view>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="text-center padding-10 color-white"
				style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
				@click="xiugai()">
				{{$lang.QUEREN}}
			</view>
		</view>
	</view>
</template>

<script>
	import md5 from 'js-md5';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {

		data() {
			return {
				isAnimat: false, // 页面动画
				userInfo: null,
				nick_name: '',
				email: '',
				avatar: '',
			}
		},
		onShow() {
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 	//用户信息
			async getAccount() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				this.nick_name = this.userInfo.nick_name;
				this.email = this.userInfo.email;
				this.avatar = this.userInfo.avatar;
			},
			async xiugai() {
				if (!this.nick_name || this.nick_name == '') {
					uni.showToast({
						title: this.$lang.SHEZHI_WODENICHEN,
						icon: 'none'
					});
					return false;
				}
				if (!this.email || this.email == '') {
					uni.showToast({
						title: this.$lang.YOUXIANG,
						icon: 'none'
					});
					return false;
				}

				const result = await this.$http.post(`api/user/updateAvatar`, {
					avatar: this.avatar,
					nick_name: this.nick_name,
					email: this.email,
				});
				console.log('info result：', result);
				if (!result) return false;

				uni.$u.toast('success');
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000);
			},
			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				this.upimg(imageFile.path)
			},
			// 上传图片
			async upimg(tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					this.avatar = temp[0].url;
				}
			},
		},

	}
</script>