<!-- 股票详情 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="flex padding-20">
			<view @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 20px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center" style="color: #33D669;">{{$lang.MAIRU_XIANGQING}}</view>
		</view>
		<view style="padding-bottom: 20px;">
			<template v-if="info">
				<StockInfo :info="info"></StockInfo>
				<view style="padding:10px;">
					<view :style="{display:curTab==0?'block':'none' }">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
							<block v-for="(item,index) in tabs" :key="index">
								<view style="text-align: center;font-size: 32rpx;border-radius: 10px;"
									:style="{color:curKLine==index? '#121212':'#666666'}"
									@click="handleShowKLine(index)">
									{{item}}
								</view>
							</block>
						</view>
						<view class="chart" id="kline-stock" style="width: 100%;height: 1000rpx;">
						</view>
					</view>
				</view>
			</template>
		</view>

		<!-- 8和9是指标 指标是不能购买 -->
		<template v-if="info && info.project_type_id<8">
			<view style="position: fixed;bottom: 0;left: 0;right: 0;z-index: 9999;">
				<view class="text-center padding-10 color-white"
					style="margin:40rpx auto;width: 90%;background-color:#33D669;border-radius: 10rpx;line-height: 1.8;text-transform:Uppercase;"
					@click="purchase()">
					{{$lang.BTN_BUY}}
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import StockInfo from './components/StockInfo.vue';

	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea,
		klineCandle
	} from '@/common/klineConfig.js';

	import localize from '@/common/localize.js';

	export default {
		components: {
			HeaderSecond,
			StockInfo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				gid: "",
				info: null, // 单股信息，
				klineChart: null, // Kline实例化
				curKLine: 4, // 当前显示的Kline数据图标
				timer: null,
				curType: 0, // 当前弹层模式[0买|1卖]
				indicator: null, // 技术指标
				socket: null, // ws
				isConnected: false, // 是否已链接ws
			};
		},
		computed: {
			// header title
			setTitle() {
				if (this.info) {
					return this.info.name || 'XAU';
				}
			},
			// 时间
			tabs() {
				return ['1m', "5m", "15m", "30m", "1D", "1W", "1M"]
			}
		},

		onLoad(option) {
			this.gid = option.gid || '';
		},
		onShow() {
			this.isAnimat = true;
			if (this.socket) this.disconnect();
			console.log('stock onShow:', this.curTab)
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			if (this.socket) this.disconnect();
		},
		methods: {
			handleShowKLine(val) {
				if (this.socket) this.disconnect();
				this.curKLine = val;
				this.getData();
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},

			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Dandu_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);

					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
						uni.sendSocketMessage({
							data: this.info.pid,
						});
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.info.pid == data.pid && data.last > 0) {
							console.log(`pid:`, this.info, data);
							this.info.current_price = data.last;
							this.info.rate = data.pcp || 0;
							this.info.rate_num = data.pcp || 0;
							this.info.high = data.high || 0;
							this.info.low = data.low || 0;

							// 获取图标上的数据
							const dataList = this.klineChart.getDataList();
							// 数据数组的最后一个元素
							const lastData = dataList[dataList.length - 1];
							// 建新数据
							const newData = {
								...lastData
							}
							console.log(`newData:`, newData);
							newData.close = data.last * 1;
							newData.high = data.high * 1;
							newData.low = data.low * 1;
							newData.open = data.last_numeric * 1;
							// newData.volume = data.vol * 1;							
							// newData.rate = data.pcp * 1;
							// newData.rate_num = data.pcp * 1;
							// 当前ws时间戳 - 最后一个元素时间戳，>指定秒数，追加一根蜡烛
							if (data.time - newData.timestamp > 60000)
								newData.timestamp = data.time;
							this.klineChart.updateData(newData);
						}
					});
				}
			},

			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			// 买入
			purchase(val) {
				console.log(`val:`, val);
				this.curType = val;
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?gid=${this.gid}&type=${this.info.project_type_id}`
				});
			},

			// 产品详情
			async getData() {
				console.log("getData", this.gid);
				const result = await this.$http.get(`api/product/info`, {
					gid: this.gid,
					time_index: this.curKLine
				});
				console.log(result);
				if (!result) return false;
				this.info = result[0];

				console.log(`info:`, this.info);
				console.log(this.info.project_type_id);

				if (!this.socket) this.connect();
				// 延时,等DOM渲染
				setTimeout(() => {
					this.genKLineData(); // 获取并生成KLine数据	
				}, 50);
			},
			clearData() {
				if (this.indicator) {
					this.klineChart.removeIndicator(this.indicator);
					this.indicator = null;
				}
				if (this.klineChart) this.klineChart.clearData();
			},

			// 获取并生成KLine数据
			async genKLineData() {
				console.log(`localize:`, localize);

				if (!this.klineChart) {
					this.klineChart = init(`kline-stock`);
					const temp = uni.getStorageSync('lang');
					const tz = localize[temp];
					this.klineChart.setTimezone(tz.timeZone);
				}

				const result = await this.$http.get(`api/product/lishi`, {
					code: this.info.code,
					ac_time: this.curKLine,
					project_type_id: this.info.project_type_id,
				})
				console.log('k data:', result);
				if (!result) return false;
				this.clearData();
				this.klineList = result;
				this.klineChart.setStyles({
					grid: klineGird,
					// 第一个用面积图 后面用蜡烛图
					// candle: this.active == 0 ? klineArea : klineCandle,
					candle: klineCandle,
				});
				// this.klineChart.setPriceVolumePrecision(this.info.shudian, 0)
				this.klineChart.applyNewData(this.klineList)
				// 显示技术指标
				if (!this.indicator) {
					this.indicator = this.klineChart.createIndicator('MA', false);
				}
			},
		},
	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #489ce5;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #489ce5;
			}
		}

		.list1 {
			background-color: #0332783b;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}
</style>