<template>
	<view style="background-color: #000;height: 120vh;">
		<view class="flex" style="padding: 20px;">
			<view>
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;" @click="home()"></image>
			</view>
			<view class="flex-1 text-center" style="color: #fff;">推广中心</view>
		</view>
		<view style=" border-top:1px solid #222224;">.</view>

		<view class="flex" style="padding:0px 10px;">
			<view style="border-left: #fff 2px solid;height: 15px;">.</view>
			<view style="color: #fff;">当前等级</view>
		</view>

		<view style="padding: 10px 0px;position: relative;" @click="Promotion()">
			<image src="/static/tuiguang.png" mode="widthFix" style="width: 95%;margin-left: 10px;"></image>
			<image src="/static/xing.png" mode="widthFix"
				style="width: 58%;position: absolute;bottom: 75%;left: 30px; "></image>
			<image src="/static/zuanshi.png" mode="widthFix"
				style="width: 15px;position: absolute;bottom: 82%;left:100px; "></image>

			<view class="flex" style="position: absolute;bottom: 65%;left: 30px; width: 85%;">
				<view class="flex" @click="show = true">
					<view style="color: #a5b3b4;">二层奖励/直推奖励</view>
					<image src="/static/wenhao.png" mode="widthFix" style="width: 15px;margin-left: 5px;" ></image>
				</view>
				<view style="color: #fff;margin-left: auto;">18%/50%</view>
			</view>
		   
		   <view>
				<u-popup :show="show" @close="close" @open="open">
					<view style="background-color: #000;color: #fff;">
				<view class="bold text-center" style="font-size: 18px;margin-top: 10px;">说明</view>
			<view class="flex" style=" justify-content: space-between;padding: 10px;margin-top: 30px;">
						<view >星级</view>
						<view >二层奖励</view>
						<view >直推奖励</view>
					</view>   
			<view class="flex" style=" justify-content: space-between;width: 95%;padding: 10px;">
				<view class="flex-1">
						<image src="/static/zuanshi.png" mode="widthFix" style="width: 15px;margin-left: 5px;"></image>
						</view>
						<view class="flex-1">5%</view>
						<view>30%</view>
					</view>   
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 10px;">
					<view class="flex-1">
						<image src="/static/zuanshi.png" v-for="item in 2" mode="widthFix" style="width: 15px;margin-left: 5px;"></image>
					</view>
							<view class="flex-1">10%</view>
							<view>35%</view>
						</view>  
					<view class="flex" style=" justify-content: space-between;width: 95%;padding: 10px;">
							<view class="flex-1">
								<image src="/static/zuanshi.png" v-for="item in 3" mode="widthFix" style="width: 15px;margin-left: 5px;"></image>
							</view>
								<view class="flex-1">12%</view>
								<view>40%</view>
							</view>  
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 10px;">
							<view class="flex-1">
								<image src="/static/zuanshi.png" v-for="item in 4" mode="widthFix" style="width: 15px;margin-left: 5px;"></image>
							</view>
							<view class="flex-1">15%</view>
							<view>45%</view>
						</view>  
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 10px;">
							<view class="flex-1">
								<image src="/static/zuanshi.png" v-for="item in 5" mode="widthFix" style="width: 15px;margin-left: 5px;"></image>
							</view>
							<view class="flex-1">18%</view>
							<view>50%</view>
						</view> 
					<view style="width: 95%;padding: 15px;">规则:每推荐两个用户购买FOF基金,您的个人等级将会提升一个星际,推荐10人即可升到五星,获取最高奖励。</view>
					<view class="text-center" style="background-color: #16e2e2;color: #fff;border-radius: 30px;padding: 10px;width: 85%;margin-left: 20px;">确定</view>
					<view style="margin-top: 20px;color: #000;">.</view>
					</view>
				</u-popup>
				
			</view>
				
		
			<view class="flex" style="position: absolute;bottom: 55%;left: 30px; width: 85%;">
				<view class="flex-1" style="color: #a5b3b4;">邀请码</view>
				<view class="flex">
					<view style="color: #fff;">3KF9nXowQ4asSG</view>
					<view style="color: #a5b3b4;margin-left: 10px;">复制</view>
				</view>
			</view>

			<view class="flex" style="position: absolute;bottom: 45%;left: 30px; width: 85%;">
				<view class="flex-1" style="color: #a5b3b4;">邀请链接</view>
				<view class="flex">
					<view
						style="color: #fff;width: 180px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
						best-trader.vip/#/pages/ot</view>
					<view style="color: #a5b3b4;margin-left: 10px;">复制</view>
				</view>
			</view>

			<view style="position: absolute;bottom: 25%;left: 30px; width: 85%;">
				<view class="text-center"
					style="color: #a5b3b4;background-color: #16e2e2;color: #fff;border-radius: 30px;padding: 10px;">立即邀请
				</view>
			</view>

			<view
				style="color: #fff;position: absolute;bottom: 6%;left: 13px; background-color: #16516B;width: 88%;padding: 10px;border-radius: 20px;">
				<view style="font-size: 10px;">距离下一等级还需要邀请4人</view>
			</view>
		</view>

		<view class="flex" style="padding: 10px;">
			<view style="border-left: #fff 2px solid;height: 15px;">.</view>
			<view style="color: #fff;">当前等级</view>
		</view>

		<view class="flex text-center"
			style="justify-content: space-between;color: #a5b3b4;margin-top: 5px;width: 100%;margin-left: -25px;">
			<view class="flex-1">序号</view>
			<view class="flex-1">用户昵称</view>
			<view class="flex-1">邀请人数</view>
			<view>返利金额</view>
		</view>

		<view class="flex text-center"
			style="justify-content: space-between;color: #a5b3b4;margin-top: 5px;width: 105%;margin-left: -30px;">
			<view class="flex-1">3</view>
			<view class="flex-1">ym3****.com</view>
			<view class="flex-1">85</view>
			<view>84523.98 U</view>
		</view>

		<view class="flex text-center"
			style="justify-content: space-between;color: #a5b3b4;margin-top: 5px;width: 105%;margin-left: -30px;">
			<view class="flex-1">2</view>
			<view class="flex-1">ym3****.com</view>
			<view class="flex-1">855</view>
			<view>84523.98 U</view>
		</view>

		<view class="flex text-center"
			style="justify-content: space-between;color: #a5b3b4;margin-top: 5px;width: 105%;margin-left: -30px;">
			<view class="flex-1">3</view>
			<view class="flex-1">ym3****.com</view>
			<view class="flex-1">5585</view>
			<view>84523.98 U</view>
		</view>

	</view>


	</view>
</template>

<script>
	export default {
		data() {
			return {
		      show: false
				

			}
		},
		onLoad() {

		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1,
				});
			},
			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			}

		},
	}
</script>

<style>
</style>