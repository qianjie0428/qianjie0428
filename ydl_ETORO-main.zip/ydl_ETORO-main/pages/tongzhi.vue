<template>
	<view>
		<view>
			<view class="flex " style="padding: 20px;">
				<view>
					<image src="/static/zuofanhui.png" mode="widthFix" style="width: 20px;" @click="home()"></image>
				</view>
				<view class="flex-1 text-center" style="color: #fff;font-size: 18px;">{{$lang.GONGGAO_LIEBIAO}}</view>
				
			</view>
			<view style=" border-top:1px solid #222224;">.</view>
		</view>
		<block v-for="(item,index) in list" :key="index">
		<view style="padding: 0px 20px;">
			<view style="color: #fff;">{{item.biaoti}}</view>
			<view style="color: #636266;">{{item.updated_at}}</view>
		</view>
		<view style=" border-top:2px solid #222224;margin-top: 10px;width: 90%;margin-left: 20px;">.</view>
		<!-- <view style="padding: 0px 20px;">
			<view style="color: #fff;">尊敬的会员，于服务功能的通知</view>
			<view style="color: #636266;">2024-07-26 15:32</view>
		</view>
		<view style=" border-top:2px solid #222224;margin-top: 10px;width: 90%;margin-left: 20px;">.</view>
		<view style="padding: 0px 20px;">
			<view style="color: #fff;">尊敬的会员，于服务功能的通知</view>
			<view style="color: #636266;">2024-07-26 15:32</view>
		</view>
		<view style=" border-top:2px solid #222224;margin-top: 10px;width: 90%;margin-left: 20px;">.</view> -->
		</block>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [],	
			}
		},
	onLoad() {
		this.getList();
	},
	methods: {
		home() {
			uni.navigateBack({
				delta: 1, 
			});
		},
		async getList() {
			const result = await this.$http.get(`api/app/gginfo`);
			console.log(result,1111)
			if (!result) return false;
			this.list = result;
			console.log(this.list,22222)
		},
		},
	}
	
		
</script>

<style>
</style>