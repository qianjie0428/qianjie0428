<template>
	<view class="launch" style="background-image: url(/static/bg.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat">
		<view>
			<image src='/static/logo.png' :style="$util.setImageSize(360)" style="margin-bottom: 50px;" mode="widthFix">
			</image>
		</view>
		
		<!-- <view style="color: #fff;font-size: 18px;margin-top: -20px;">TFG Asset Managemen</view> -->
		
		<view class="launch_progress">
			<!-- <u-line-progress :percentage="percentage" height="15" activeColor="linear-gradient(90deg, #BCFFD2, #9DEBB7, #66ED93)"
				:showText="false">
			</u-line-progress> -->
			<div class="progress-bar-container">
			    <div class="progress-bar" :style="{ width: percentage + '%' }"></div>
				<image mode="widthFix" style="width: 30px;height: 30px;" class="coin" src="/static/jinbi.png" :style="{ left: percentage + '%' }" alt="Coin"  />
			</div>
			  
			
		</view>

		<view class="launch_tip">
			{{`${$lang.STATUS_LOADING} `}}
			(<u-count-to :startVal="1" :endVal="percentage" :duration="1500" :useEasing="true" fontSize="16"
				:color="$theme.PRIMARY"></u-count-to> {{` % `}})
		</view>

		
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 1, // 进度条初始值
				
			}
		},
		onLoad() {
			uni.$u.sleep(1800).then(() => {
				this.percentage = 100;
				//跳转到首页 缓一秒，否则看不到进度条加满效果
				uni.$u.sleep(1500).then(() => {
					uni.switchTab({
						url: HOME,
					})
				})
			})
		},
	}
</script>
<style scoped>
.progress-bar-container {
  width: 100%;
  height: 20px;
  background-color: #e1e5e3;
  border-radius: 5px;
  position: relative;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, #bcffd2, #9debb7, #66ed93);
  transition: width 1s ease;
}


.coin {
  position: absolute;
  top: -8px; /* 调整此值，使金币在进度条上方 */
  transform: translateX(-50%);
  transition: left 1s ease;
  z-index: 10; /* 确保金币在进度条上方 */
}
</style>