<template>
	<view>
		<template v-if="Object.values(list).length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in Object.values(list)" :key="index">
				<view class="common_block" style="padding:10px;background-color: #FFFFFF;margin:20rpx;"
					@click="linkInfo(item.code)">
					<view style="display: flex;align-items: center;">
						<template v-if="item.logo">
							<view style="width: 80rpx;margin:auto 0;">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
						</template>
						<view style="flex:1 0 40%;padding-left: 40rpx;">
							<view :style="{color:$theme.SECOND}" style="font-size: 32rpx;line-height: 1.6;">
								{{item.name}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">24H:
								{{$util.formatNumber(item.vol,0)}}
							</view>
						</view>
						<view style="margin-left: auto;">
							<view style="font-size: 32rpx;font-weight: 700;text-align: right;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{$util.formatCoin(item.current_price)}}
							</view>
							<view style="font-size: 28rpx;text-align: right;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{item.rate}}%
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketCoin',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: {},
				socket: null, // websocket
			}
		},
		created() {
			this.getList();
		},
		deactivated() {
			this.disconnect();
		},
		methods: {
			// 跳转到详情
			linkInfo(val) {
				uni.navigateTo({
					url: this.$paths.COIN_OVERVIEW + `?code=${val}`
				});
			},

			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0) {
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].vol = data.vol || 0;
					}
				});
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`);
				console.log(result);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
				// 启动 websocket链接
				this.connect();
			}
		}
	}
</script>

<style>
</style>