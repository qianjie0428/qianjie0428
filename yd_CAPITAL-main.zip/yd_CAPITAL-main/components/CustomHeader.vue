<!-- 包含返回和标题的自定义Header -->
<template>
	<view class="common_header" style="background-image: url(/static/diwen.png);background-size: contain;background-size: 40% 100%;background-repeat: no-repeat;background-color: #27285e;height: 40px;">
		<view class="custom_header_left" @click="$util.goBack()">
			<image src="/static/fanhui.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
		</view>
		<text class="custom_header_center" style="color: #fff;">{{title}}</text>
		<view class="custom_header_right"></view>
	</view>
</template>

<script>
	export default {
		name: "CustomHeader",
		props: ["title"],
		data() {
			return {};
		},
		methods: {
			// actionEvent() {
			// 	this.$emit('action', '');
			// }
		}
	}
</script>