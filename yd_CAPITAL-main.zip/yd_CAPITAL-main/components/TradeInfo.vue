<!-- 个人交易 交易信息 -->
<template>
	<view
		style="background-image: url(/static/order/beijing.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;padding: 10px;margin: 0 10px;border-radius: 10px;">
		<view class="flex flex-b">
			<view class="flex gap5">
				<image src="/static/order/zongzichan.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view>Total assets</view>
				<image :src="`/static/${!isMask?`show`:`hide`}_dark.png`" mode="aspectFit"
					style="width: 20px;height: 20px;padding-left: 12rpx;" @click="isMask=!isMask">
				</image>
			</view>
			<view class="flex gap5">
				<image src="/static/order/zongzichan.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
				<view>Available assets</view>
			</view>
		</view>
		<view class="flex flex-b margin-left-20 ">
			<view class="flex gap5">
				<view class="font-size-20">₹{{isMask?maskCode: $util.formatNumber(info.totalZichan)}}</view>
			</view>
			<view class="flex gap5">
				<view class="font-size-20">₹{{isMask?maskCode:$util.formatNumber(info.money)}}</view>
			</view>
		</view>
		<view class="flex flex-b margin-top-15 margin-bottom-15">
			<view class="text-center">
				<view>{{$lang.TOTAL_BUY_AMOUNT}}</view>
				<view>{{isMask?maskCode:$util.formatNumber(info.frozen)}}</view>
			</view>
			<view class="text-center">
				<view>Position P&L</view>
				<view>{{isMask?maskCode:$util.formatNumber(info.holdYingli)}}</view>
			</view>
			<view class="text-center">
				<view>{{$lang.TOTAL_GAIN}}</view>
				<view>{{isMask?maskCode:$util.formatNumber(info.totalYingli)}}</view>
			</view>

		</view>

	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		props: ['info'],
		data() {
			return {
				isMask: false,
				maskCode: `*****`,
			};
		},
		mounted() {},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
		}
	}
</script>