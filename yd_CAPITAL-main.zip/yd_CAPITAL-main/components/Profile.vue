<!-- 用户基本信息 -->
<template>
	<view style="padding: 30px 10px;">
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:0%;text-align: center;">
				<image src="/static/logo.png" mode="widthFix"
					style="width: 70px;height: 70px;background-color: #fff;border-radius: 50px;"></image>
				<!-- <image style="border-radius: 100px;" mode="aspectFit"
					:src="info.avatar?info.avatar:'/static/avatar.png'" :style="$util.calcImageSize(60)"></image> -->
			</view>
			<view style="flex:56%;padding-left: 10px;">
				<view class="flex flex-b">
					<view style="font-size: 20px;text-align: left;font-weight: 700;color: #fff;">
						{{info.real_name}}
					</view>
					<image src="/static/wd_kf.png" mode="widthFix" style="width: 25px;height: 25px;"
						@click="$util.linkCustomerService()"></image>
				</view>

				<view style="font-size: 14px;text-align: left;padding: 5px 0px;" :style="{color:$util.THEME.TIP}">
					EN:{{info.mobile}}
				</view>
				<!-- <view class="flex margin-top-5">
					<view style="font-size: 14px;">Credit Score :</view>
					<view style="font-size: 14px;text-align: left;">
						{{info.xinyong}}
					</view>
				</view> -->

			</view>
			<!-- <view style="flex:4%;">
				<image mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(36)" @click="handleSignOut()" style="padding-left: 6px;"></image>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true
			};
		},
		methods: {
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
		}
	}
</script>

<style>

</style>