<template>
	<view class="common_block" style="margin-top: 20px;">
		<TabsSecond :tabs="$util.tabsMarketNew" @action="handleChangeTab"></TabsSecond>
		<view style="padding: 10px;">
			<block v-for="(item,index) in list" :key="index">
				<view @click="open(item.url)" style="margin-bottom: 16px;display: flex;align-items: center;">
					<template v-if="current==0">
						<view style="flex:30%; height: 80px; margin-right: 10px; border-radius: 5px;">
							<image :src="item.pic" style="border-radius: 6px;width: 100%;height: 100%;"></image>
						</view>
					</template>
					<view style="flex:70%;display: flex;flex-direction: column;justify-content: space-between;">
						<view :style="{color:$util.THEME.TEXT}">{{item.title}}</view>
						<view style="text-align: right;padding-right: 16px;margin-top: 10px;"
							:style="{color:$util.THEME.TIP}">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
			<view style="text-align: center;color: #999;">For popular items, only the top 100 rankings are provided.. </view>
		</view>
	</view>
</template>

<script>
	import TabsSecond from '@/components/TabsSecond.vue';
	export default {
		name: 'TabFour',
		components: {
			TabsSecond
		},
		data() {
			return {
				list: [],
				current: 0,
			}
		},
		mounted() {
			this.getList();
		},
		methods: {
			handleChangeTab(val) {
				this.current = val;
				this.getList();
			},
			open(url) {
				window.open(url)
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.GOODS_NEWS, {
					current: this.current
				});
				this.list = result.data.data;
				uni.hideLoading();
			},
		},
	}
</script>