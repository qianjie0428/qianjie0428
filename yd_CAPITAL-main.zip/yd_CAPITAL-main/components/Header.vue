<template>
	<header class="app_header" >
		<view style="padding: 30px 20px;background-image: url(/static/home_banner.png);height: 240px;background-size: contain;background-size: 100% 100%;background-repeat: no-repeat">
			<view class="flex flex-b" >
				<view>
					<view style="background-color: #fff;width: 35px;height: 35px;border-radius: 50%;" class="flex justify-center">
						<image src="/static/logo.png" mode="widthFix" style="width: 30px;text-align: center;"></image>
					</view>
				</view>
				<view class="text-center color-white font-size-16" style="z-index: 999;">
					ABCIC
				</view>
				<view class="flex gap10">
					<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;" @click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
					<image src="/static/service.png" mode="widthFix" style="width: 20px;height: 20px;" @click="$util.linkCustomerService()"></image>
				</view>
			</view>
			
		</view>
		
	</header>

	<!-- <view class="common_header">
		<view class="primary_header_left" style="margin-left: 10%;line-height: 2.4;"
			@click="$u.route({url:$util.PAGE_URL.SEARCH});">
			<image mode="aspectFit" src="/static/search.png" :style="$util.calcImageSize(24)"></image>
		</view>
		<view class="primary_header_right"> -->
	<!-- <image mode="aspectFit" src="/static/notification.png" :style="$util.calcImageSize(20)"
				@click="$u.route({url:$util.PAGE_URL.NOTIFICATION});" style="padding-left: 6px;"></image> -->
	<!-- <image mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)"
				@click="kefu()" style="padding-left: 6px;"></image> -->
	<!-- <image mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(20)" @click="handleSignOut()" style="padding-left: 6px;"></image> -->
	<!-- 		</view>
	</view> -->

</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
		}
	}
</script>
