<template>
	<view class="btns">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(25)"></image>
				<text style="padding-top: 6px;text-align: center;color: #35353A;font-size: 12px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns', 'col'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				// 如果是客服
				if (url.includes('service')) {
					// uni.showToast({
					// 	title: `Hello, please contact offline customer service.`,
					// 	icon: 'none'
					// });
					this.$util.linkCustomerService();
					return false;
				}
				if (url.includes(`download`)) {
					const temp = `https://down.capitalapp.top/`;
					if (window.android) {
						window.open(temp)
						return false;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + temp
						})
						return false;
					}
					let u = navigator.userAgent;
					let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = temp;
						return false;
					}
					window.open(temp)
					return false;
				}

				// 如果点击大宗交易
				if (url == `/pages/trade/large`) {
					console.log('btn:', url);
					this.$emit('action', url);
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>