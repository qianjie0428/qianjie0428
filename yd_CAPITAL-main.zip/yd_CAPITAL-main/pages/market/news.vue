<template>
	<view>
		<!-- <u-tabs :list="list1" style="margin: 0px 10px;"
			activeStyle="color:#fe3f7c;font-weight: 700;" lineColor="#fe3f7c" @change="change" :current="current">

		</u-tabs> -->

		<view style="background-color: #27285e;width: 100%;">
			<image src="/static/diwen.png" mode="heightFix" style="height: 70px;"></image>
			<view class="padding-20" style="position: absolute;top: 18px;width: 90%;">
				<view class="flex flex-b">
					<view class="color-white font-size-16">NEWS</view>
					<view class="flex">
						<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
							@click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
						<image src="/static/service.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 20px;"
							@click="$util.linkCustomerService()"></image>
					</view>
				</view>
			</view>
		</view>

		<view class="padding-10">
			<image src="/static/news_banner.png" mode="widthFix" style="width: 100%;"></image>
		</view>


		<view>
			<view class="list">


				<view class="list">
					<view class="item flex flex-b" v-for="(item,index) in list" @click="open(item.id)">
						<view class="img">
							<image :src="item.pic"></image>
						</view>

						<view class="flex-2">
							<view class="t el">{{item.title}}</view>
							<view class="t1">{{item.created_at}}
							</view>
						</view>
					</view>

				</view>
			</view>
			<view style="text-align: center;color: #999999;" class="content-end-text">Featured items are ranked up to 100 in
				total.<br>We only provide rankings.</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				show: false,
				list1: [{
						name: 'News',
					},
					// {
					// 	name: 'Market',
					// }, 
					// {
					// 	name: 'Company'
					// }, 
					// {
					// 	name: 'Politics'
					// }, 
					// {
					// 	name: 'Cricket'
					// }, 
					// {
					// 	name: 'Personal Finance'
					// }, {
					// 	name: 'Technology'
					// }, {
					// 	name: 'World'
					// },
				],

				list: [],
				current: 0,

			}
		},

		methods: {
			open(val) {
				uni.navigateTo({
					url: `/pages/market/newsDetail?id=${val}`
				});
			},
			// open(url){
			// 	window.open(url, '_blank')
			// },

			async lists() {
				uni.showLoading({})
				let list = await this.$http.post('api/goods/get_news', {
					current: this.current
				})
				this.list = list.data.data
				uni.hideLoading()
			},

			change(index) {
				console.log(index)
				this.current = index.index;
				this.lists()
			},

		},

		mounted() {

			this.lists()
		},

		onLoad() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	.list {
		padding: 10px;

		.item {
			margin-bottom: 16px;

			.img {
				width: 120px;
				height: 80px;
				margin-right: 10px;
				border-radius: 5px;

				image {
					width: 100%;
					height: 100%;
					border-radius: 5px;
				}
			}

			.t {
				color: #333;
			}

			.t1 {
				color: #999;
				margin-top: 10px;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #014b8d;

			span {
				background: #014b8d;
			}
		}
	}
</style>