<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="News Detail" @action="handleBack()"></CustomHeader>
		</view>
		<template v-if="!detail || !detail.id">
			<view style="text-align: center;padding-top: 10vh;">
				<image src="/static/icon_sigin.png" mode="heightFix" style="height: 280px;width: auto;"></image>
			</view>
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view class="common_block" style="padding:20px;">
				<view style="font-size: 18px;font-weight: 800;">{{detail.title}}</view>
				<view style="text-align: right;padding:16px 0;">{{detail.created_at}}</view>
				<view v-html="detail.content"></view>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				id: '',
				detail: null,
			}
		},
		onLoad(opt) {
			this.id = opt.id || this.id;
		},
		onShow() {
			if (this.id > 0) this.getDetail();
		},
		onPullDownRefresh() {
			if (this.id > 0) this.getDetail();
			uni.stopPullDownRefresh();
		},
		methods: {
			handleBack() {
				uni.navigateTo({
					url: '/pages/market/news'
				});
			},
			async getDetail() {
				uni.showLoading({})
				const result = await this.$http.post('api/goods/get_news_detail', {
					id: this.id
				})
				console.log(result);
				const temp = result.data.data;
				this.detail = temp;
				uni.hideLoading()
			},
		}
	}
</script>

<style>
</style>