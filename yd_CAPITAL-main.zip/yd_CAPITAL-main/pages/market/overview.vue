<template>
	<view>
		<view style="background-color: #27285e;width: 100%;">
			<image src="/static/diwen.png" mode="heightFix" style="height: 70px;"></image>

			<view class="padding-20" style="position: absolute;top: 15px;width: 100%;">
				<view class="flex flex-b">
					<view>
						<view style="color: #F9D130;font-size: 18px;">Market</view>
						<view style="width: 100%;height: 5px;background-color: #F9D130;border-radius: 5px 0 5px 0;">
						</view>
					</view>
					<view class="flex">
						<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
							@click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
						<image src="/static/service.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 20px;"
							@click="$util.linkCustomerService()"></image>
					</view>
				</view>

			</view>

		</view>

		<!-- 	
		<view style="margin-top: 10px;margin-left: 10px;">
			<block v-for="(item,index) in $util.MARKET_TAB" :key="index">
				<view @click="handleChange(index)"
					style="display: inline-block; width:max-content;height: 20px;padding:8px 10px;text-align: center;font-size: 16px;"
					:style="$util.calcStyleTabActive(current === index)">
					{{item}}
				</view>
			</block>
		</view> -->
		<view>
			<!-- <TabOne v-if="current==0"></TabOne> -->
			<view style="background-color: #f8f8f8;">
				<view style="background-color: #fff;">
					<template v-if="zhishu && zhishu.length>0">
						<view class="flex gap5 padding-10">
							<image src="/static/home/zhishu.png" mode="widthFix" style="width: 20px;height: 20px;">
							</image>
							<view style="color: #27285E;" class="bold">Market Index</view>
						</view>
						<view class="flex flex-b gap10 padding-10">
							<block v-for="(item,index) in zhishu" :key="index">
								<view :class="item.PERCCHANGE>0?'green':'red'"
									style="padding:15px 4px 40px 4px;flex:33.33%;border-radius: 6px;text-align: center;background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;"
									:style="item.PERCCHANGE>0?'background-image: url(/static/home/zhang.png);':'background-image: url(/static/home/die.png);'">
									<!-- <view class="name" style="font-size: 11px;">{{item.indxnm}}</view> -->
									<view style="color: #000;">{{item.name}}</view>
									<view class="price bold margin-top-10">{{item.pricecurrent}}</view>

									<view style="margin-top: 10px;">{{(item.pricechange*1).toFixed(2)}}
										{{item.PERCCHANGE}}%
									</view>
								</view>
							</block>
						</view>
					</template>
					<!-- <view class="flex flex-b padding-20 text-center">
						<view @click="$u.route({url:'/pages/trade/ipo'});">
							<view><image src="/static/market/xingushengou.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
							<view class="text-center">IPO</view>
						</view>
						<view @click="$u.route({url:'/pages/trade/large'});">
							<view><image src="/static/market/dazongjiaoyi.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
							<view class="text-center">BlockTrading</view>
						</view>
						<view @click="$u.route({url:'/pages/account/deposit'});">
							<view><image src="/static/market/rinrijiaoyi.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
							<view class="text-center">Deposit</view>
						</view>
						<view @click="$u.route({url:'/pages/account/withdraw'});">
							<view><image src="/static/market/cunkuan.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
							<view class="text-center">Withdrawal</view>
						</view> -->

					<!-- </view> -->
					<view class="padding-10">
						<image src="/static/market/tu.png" mode="widthFix" style="width: 100%;"></image>
					</view>
				</view>


				<view style="margin-top: 10px;background-color: #fff;">
					<view class="list">
						<view class="tt">
							<view class="flex flex-b">
								<view class="t">Top Gainers</view>
								<view class="t1">Update {{today}}</view>
							</view>
							<!-- <view class="cot">
								<view class="flex tab">
									<view class="tab-item" :class="current2==0?'active':''" @click='qiehuan2(0)'>NSE</view>
									<view class="tab-item" :class="current2==1?'active':''" @click='qiehuan2(1)'>BSE</view>
								</view>
							</view> -->
						</view>
						<view>
							<view class="flex">
								<view class="flex-2">Name</view>
								<view class="flex-1 text-center">Price</view>
								<view class="flex-1 text-center">Rate</view>
								<view class="flex-1 text-center">Rise & Fall</view>
							</view>
							<view v-for="(item,index) in top2"
								@click="$u.route('/pages/stock/overview',{code:item.code,type:2});">
								<view class="flex">

									<view class="flex-2 ">
										<view class="name">{{item.LONG_NAME}}</view>
										<view style="color: #858585;">{{item.code}}</view>
									</view>
									<span style="font-weight: 700;font-size: 13px;" class="flex-1 text-center"
										:style="item.change_percent*1>0?'color:#0e8103':'color:#ef4d4b'">{{$util.formatNumber(item.ltradert)}}
									</span>

									<span style="font-size: 13px;" class="flex-1 text-center"
										:style="item.change_percent*1>0?'color:#0e8103':'color:#ef4d4b'">
										{{(item.change_val*1).toFixed(2)}}</span>

									<view class="flex-1 text-center">
										<span style="font-size: 13px;padding: 5px 10px;color:#fff;border-radius: 5px;"
											:style="item.change_percent*1>0?'background:#0e8103':'background:#ef4d4b'">
											{{(item.change_percent*1).toFixed(2)}}%</span>
									</view>

								</view>
								<view style="height: 0.5px;background: #d1d1d1;width: 100%;margin: 10px 0;"></view>
								<!-- <view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
									<u-image src="/static/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
									<u-image src="/static/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
								</view> -->
							</view>
						</view>
						<!-- <view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">View more featured items<view class="icon jtr">
							</view>
						</view> -->
					</view>
				</view>
				<view style="background-color: #fff;">
					<view class="list">
						<view class="tt">
							<view class="flex flex-b">
								<view class="t">Top Losers</view>
								<view class="t1">Update {{today}}</view>
							</view>
							<view class="cot">
								<view class="flex tab">
									<view class="tab-item" :class="current33==0?'active':''" @click='qiehuan3(0)'>NSE
									</view>
									<view class="tab-item" :class="current33==1?'active':''" @click='qiehuan3(1)'>BSE
									</view>
								</view>
							</view>
						</view>
						<view class="lists">
							<view class="item flex flex-b" v-for="(item,index) in top3"
								@click="$u.route('/pages/marketQuotations/productDetails',{code:item.co_code,type:current2*1+1});">
								<view class="flex flex-3">
									<view class="t">{{index+1}}</view>

									<view style="margin-left: 20px;">
										<view class="name">{{item.co_name}}</view>
										<span style="font-weight: 700;font-size: 13px;"
											:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">{{$util.formatNumber(item.current_price)}}
										</span>
										<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
											:style="item.per_chg*1>0?'color:#0e8103':'color:#ef4d4b'">
											{{(item.per_chg*1).toFixed(2)}}%</span>
									</view>
								</view>
								<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
									<!-- <u-icon name="photo" ></u-icon> -->
									<u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image>
									<u-image src="/static/icon/qxsc.png" width="18" height="18"
										v-if="item.sc"></u-image>
								</view>
							</view>
						</view>
						<!-- <view class="flex flex-c more" @click="$u.route({type:'reLaunch',url:'/pages/marketQuotations/marketQuotations?type=1'});">View more featured items<view class="icon jtr">
							</view>
						</view> -->
					</view>
				</view>

			</view>



			<!-- <TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
			<TabFour v-if="current==3"></TabFour> -->
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	// import Tbas from '@/components/Tbas.vue';
	// import TabOne from '@/components/market/TabOne.vue'
	// import TabTwo from '@/components/market/TabTwo.vue'
	// import TabThree from '@/components/market/TabThree.vue'
	// import TabFour from '@/components/market/TabFour.vue';

	import {
		area
	} from '../../consts/area.js'

	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'

	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		components: {
			Header,
			// Tbas,
			// TabOne,
			// TabTwo,
			// TabThree,
			// TabFour
		},
		data() {
			return {
				// current: 0,
				tablist: [{
					name: 'Sensex'
				}, {
					name: 'Nifty'
				}, {
					name: 'Nifty Bank'
				}],
				current: 0,
				top1: [],
				top11: [],
				top12: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: [],
				chartData: {},
				opts: "",
				today: "",
				zhishu: ""
			}
		},
		onLoad(op) {
			if (op.type) {
				this.current = Number(op.type);
			}
			// this.opts = area
			// this.top_one()
			// this.top_one1()
			// this.top_one2()
			// this.startTimer()
		},
		onShow() {
			this.getzhishu()
			this.top_two()

			var date = new Date(),
				year = date.getFullYear(), //年
				month = date.getMonth() + 1, //月
				day = date.getDate(); //日
			this.today = day + "-" + month + "-" + year
			this.top_three()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},

		methods: {
			handleChange(val) {
				this.current = val;
			},
			open(url) {
				window.open(url)
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
					this.top_three()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			qiehuan33(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan3(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan2(current) {
				this.current2 = current;
				this.top_two()
			},
			qiehuan(current1) {
				console.log(2222, current1);

				this.current1 = current1.index;
				this.top_one()
			},
			async top_one() {

				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1

				})

				this.top1 = list.data.data.top1

				console.log(list.data.data);

				let res = {
					categories: list.data.data.time,
					series: [{
						name: "",
						data: list.data.data.kline
					}]
				};
				this.chartData = JSON.parse(JSON.stringify(res));

				this.$forceUpdate()
			},
			async top_one1() {

				let list = await this.$http.post('api/goods/top1', {
					current1: 1

				})

				this.top11 = list.data.data.top1

				console.log(list.data.data);

				// let res = {
				// 	categories: list.data.data.time,
				// 	series: [
				// 	  {
				// 		name: "",
				// 		data: list.data.data.kline
				// 	  }
				// 	]
				//   };
				// this.chartData = JSON.parse(JSON.stringify(res));

				this.$forceUpdate()
			},
			async top_one2() {

				let list = await this.$http.post('api/goods/top1', {
					current1: 2

				})

				this.top12 = list.data.data.top1

				console.log(list.data.data);

				// let res = {
				// 	categories: list.data.data.time,
				// 	series: [
				// 	  {
				// 		name: "",
				// 		data: list.data.data.kline
				// 	  }
				// 	]
				//   };
				// this.chartData = JSON.parse(JSON.stringify(res));

				this.$forceUpdate()
			},
			async top_two() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			async top_three() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top3', {
					current: this.current33
				})
				this.top3 = list.data.data
				// uni.hideLoading()
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.top_one()
					this.top_two()
					this.top_three()
					// this.dataUpdate()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);


			},
			async getzhishu() {
				const result = await this.$http.post('api/goods/zhishu', {})
				if (result.data.code == 0) {
					this.zhishu = result.data.data && result.data.data.length > 3 ? result.data.data.slice(0, 3) :
						result
						.data.data;
					// console.log(this.list);
				}
			},
		},
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}

	.charts-box {
		width: 100%;
		height: 200px;
	}


	.header {
		padding: 0 15px;
		width: 100vw;
		height: 50px;
		line-height: 50px;
		background: #014b8d;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.title {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
		}
	}



	.flex.flex-b {
		-webkit-box-pack: justify;
		-webkit-justify-content: space-between;
		justify-content: space-between;
	}

	.flex {
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
	}

	.line-box {
		padding: 0 5px;

		.top {
			padding: 16px 10px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}
		}
	}

	.pdd {
		padding: 0 5px;
	}

	.nav-boxs {
		height: 32px;
		line-height: 32px;

		.nav-items {
			font-size: 17px;
			font-weight: 700;
			color: #999;
			background: #f1f2f4;
			border-radius: 5px;
			padding: 0 10px;
			margin-right: 10px;
		}

		.active {
			color: #014b8d;
			background: #e0e3eb;
		}

	}

	.line-box .nums {
		background: #f0f3fa;
		border-radius: 10px;
		padding: 5px;
		text-align: center;
		margin: 16px 0;

		.nums-item {
			width: 48%;
			background: #fff;
			border-radius: 8px;
			padding: 16px 0;

			.name {
				color: #0e8103;

			}

			.icon {
				margin: 5px auto;
			}

			.t {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}

			.t.die {
				color: #0e8103;
			}

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}

			.t1.die {
				color: #0e8103;
			}

		}
	}

	.line-box .last {
		padding: 10px;

		view {
			font-size: 12px;
			color: #333;
		}

		span {
			font-size: 12px;
			color: red;
			margin-left: 5px;
		}
	}

	.list {
		padding: 16px 0;
		// border-top: 5px solid #f5f5f5;
		border-bottom: 5px solid #f5f5f5;
		margin-top: 10px;

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

		}

		.pdd {
			padding: 0 10px 16px;
			border-bottom: 1px solid #ccc;

			.item {
				width: 49%;

				uni-image {
					width: 100%;
					height: 117px;
					border-radius: 5px;
					margin-bottom: 10px;
				}
			}

		}

		.items {
			padding: 16px 10px;
			border-bottom: 1px solid #ccc;
		}

		.tt {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			padding: 0 10px 16px;

			.t {
				font-size: 19px;
				font-weight: 700;
				color: #333;
			}

			.t1 {
				font-size: 12px;
				color: #999;
			}

			.cot .tab {
				padding: 16px 0 0;

				.tab-item {
					background: #f1f2f4;
					border-radius: 5px;
					color: #999;
					height: 32px;
					line-height: 32px;
					text-align: center;
					min-width: 20%;
					margin-right: 10px;
				}

				.tab-item.active {
					background: #e7f1f9;
					color: #014b8d;
				}
			}
		}
	}

	.show {
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
		font-weight: 500;
	}

	.more {
		padding: 16px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}

	.flex.flex-c {
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
	}

	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}

	.tb {
		height: 32px;
		background: #f1f2f4;
		border-radius: 5px;
		padding: 0 5px;
		margin-top: 16px;

		.it {
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;
			text-align: center;
			height: 26px;
			border-radius: 3px;
			color: #014b8d;
			line-height: 26px;
		}

		.it.active {
			background: #fff;
		}
	}

	.top1 {
		border-bottom: 1px solid #ccc;
		padding: 16px 10px;

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			margin-top: 16px;
		}
	}

	.list {
		padding: 16px 10px;

		.item {

			margin-bottom: 16px;

			.red {
				font-weight: 600;
				color: #ff3636;
			}

			.red.die {
				color: #014b8d;
			}
		}
	}

	.ct {
		width: 149px;

		.bg {
			background: #e7f1f9;
			border-radius: 5px;
			overflow: hidden;

			.b-bg {
				height: 21px;
				background: #014b8d;
			}

			.r-bg {
				height: 21px;
				background: red;
			}
		}
	}
</style>