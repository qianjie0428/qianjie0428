<!-- 银转证 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Deposit Information" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view :style="{color:$util.THEME.TIP}">Available Funds</view>
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.TEXT_DARK}">
				₹{{$util.formatNumber(userInfo.money*1)}}
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>


		<view style="padding: 48rpx;color: #999;">
			Based on SEBI regulations, institutional trading funds must comply with the required audits and apply for
			the appropriate regulatory accounts. Before making a deposit, please click on the customer service window in
			the app or contact your dedicated assistant to schedule an online appointment for the deposit.
		</view>
		<view class="common_btn btn_primary" @click="$util.linkCustomerService()" style="z-index: 9999;width: 60%;margin: auto;">
			Customer Service</view>

		<!-- <view style="padding:0 16px;display: flex;align-items: center;justify-content: space-between;">
			<view style="padding-right: 40rpx;flex:1;">
				<u-input placeholder="Request password from customer service" type="password" v-model="value3"
					:placeholder-style="$util.setStylePlaceholder()"></u-input>
			</view>
			<view style="margin-left: auto;">
				<view style="color:#FFF; font-weight: 900; background-color: #27285e;border-radius: 5px;
				padding: 4px 6px;" @click="testVerify()">
					Verify</view>
			</view>
		</view> -->

		<!-- <view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">Bank Name:</view>
				<view class="">{{bankName}}</view>
				<view class="duplicate" @click="copy(bankName)">Copy</view>
			</view>
		</view>

		<view class="collections">
			<view class="call">
				<view class="beneficiaryName">Branch:</view>
				<view class="">{{branch}}</view>
				<view class="duplicate" @click="copy(branch)">Copy</view>
			</view>
		</view>

		<view class="collections">
			<view class="call">
				<view class="beneficiaryName">Account Name:</view>
				<view class="">{{bankNum}}</view>
				<view class="duplicate" @click="copy(bankNum)">Copy</view>
			</view>
		</view>

		<view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">Bank Account Number:</view>
				<view class="">{{accountName}}</view>
				<view class="duplicate" @click="copy(accountName)">Copy</view>
			</view>
		</view>

		<view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">IFSC:</view>
				<view class="">{{ifscCode}}</view>
				<view class="duplicate" @click="copy(ifscCode)">Copy</view>
			</view>
		</view> -->

		<!-- <view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">Account Type : Current</view>
				<view class="">{{IFSC}}</view>
				<view class="duplicate" @click="copy(IFSC)">Copy</view>
			</view>
		</view> -->

		<!-- 		<view class="inv-h-w">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="Inv=index">{{item}}</view>
			</block>
		</view> -->

		<!-- <view v-show="Inv == 0">
			<view class="collections">
				<view class="call">
					<view class="beneficiaryName">Receiver's Name</view>
					<view class="">{{BankUser}}</view>
					<view class="duplicate" @click="copy(BankUser)">Copy</view>
					<view class="duplicate" @tap="customer()">客服</view>
				</view>
			</view>
			<view class="xian"></view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Receiving bank</view>
					<view class="">{{BankName}}</view>
					<view class="duplicate" @click="copy(BankName)">Copy</view>
				</view>
			</view>
			<view class="xian"></view>

			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Accounts receivable</view>
					<view class="">{{BankNo}}</view>
					<view class="duplicate" @click="copy(BankNo)">Copy</view>
				</view>
			</view>
			<view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">IFSC code</view>
					<view class="">{{IFSC}}</view>
					<view class="duplicate" @click="copy(IFSC)">Copy</view>
				</view>
			</view> -->

		<!-- </view> -->
		<!-- <view v-show="Inv == 1"> -->



		<!-- <view class="xian"></view> -->
		<!-- 密码 -->
		<!-- 	 <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">输入密码</view>
					<view class="beneficiaryinput">
						<u-input placeholder="输入密码,可查看银行信息" type="password" v-model="value4"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify_2()">验证</view>
				</view>
			</view> 
		 </view> -->


		<!-- 查看 -->
		<!-- <view class="make-collections">
			<view class="call">
				<view class="beneficiaryName">Charging record</view>
				<view class=""></view>
				<view class="duplicate" @tap="capitalDetails()">Check</view>
			</view>
		</view>
		<!- 充值金额 -->

		<!-- <view class="recharge">
			<view class="title">Charge Amount</view>
			<view class="minimum" style="font-size: 16px;">The minimum recharge amount is <text>10000 INR</text> </view>
			<input placeholder="Please enter the recharge amount" type="number" v-model="value1"></input>
			<view class="select">
				<view class="" :style="{ 'background':shadow,'color':character}" @click="quantity('10000')">10,000
				</view>
				<view class="" :style="{ 'background':shadow1, 'color':character1}" @click="quantity('1000000')">
					1,000,000
				</view>
				<view class="" :style="{ 'background':shadow2, 'color':character2}" @click="quantity('10000000')">
					10,000,000
				</view>
				<view class="" :style="{ 'background':shadow3, 'color':character3}" @click="quantity('100000000')">
					100,000,000
				</view>
			</view>
		</view> -->

		<!-- <view class="uploadVoucher">Upload Receipt</view>
		<view class="success">
			<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1"
				width="" height="200" style="z-index: 10;">
				<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">Click to
					upload proof of successful transfer.</view>

				<image src="/static/22.png" mode="heightFix" style="margin: 0 auto;"></image>


			</u-upload>
		</view> -->

		<!-- <view class="recharge">
			<input placeholder="Please fill in transaction UTR  code" type="text" v-model="utr"></input>
		</view> -->


		<!-- <view class="common_btn btn_primary" @click="to_recharge()" style="z-index: 9999;width: 60%;margin: auto;">
			Recharge now</view> -->



		<!-- <view class="point-out">
			<view class="">Guidelines</view>
			<view>1.Deposit time: Weekdays 09:00~18:00, closed on public holidays.</view>
			<view>1.Thank you for choosing us. To ensure the safety of your funds,
				Please make sure that the account you wish to transfer is one that is displayed in real time on the
				platform.</view>
			<view> 2.Please check with our accounts staff each time you transfer.</view>
			<view> 3.You are responsible for any losses incurred by depositing funds from a bank account other than the
				account displayed in real time on the Platform.</view>
		</view> -->
		<view style="height: 30rpx;"></view>



	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				// value1: '',
				// shadow: '',
				// shadow1: '',
				// shadow2: '',
				// shadow3: '',
				// character: '',
				// character1: '',
				// character2: '',
				// character3: '',
				// utr: "",
				// fileList6: [],
				userInfo: {},
				// queryFunction: '',
				// value3: '',
				// value4: "",
				// // lookOver: "",
				// bankName: '',
				// ifscCode: '',
				// branch: '',
				// accountName: '',
				// bankNum: '',
				// current: 0,
				// list1: [{
				// 		name: 'Channel 1'
				// 	},
				// 	{
				// 		name: 'Channel 2'
				// 	},
				// ],
				// Inv: 0,
				// items: ['Channel 1', 'Channel 2']
			};
		},

		onLoad(option) {},
		onShow() {
			this.gaint_info()
		},
		methods: {
			
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInfo = list.data.data
			},
			// //选项卡
			// strike(item) {
			// 	// console.log(item);
			// 	this.current = item.index;
			// },
			// //选项卡
			// changeTab(Inv) {
			// 	that.navIdx = Inv;

			// },

			// //充值记录
			// capitalDetails() {
			// 	uni.navigateTo({
			// 		//保留当前页面，跳转到应用内的某个页面
			// 		url: this.$util.PAGE_URL.ACCOUNT_TRADE_LOG
			// 	});
			// },

			// copy(value) {
			// 	//提示模板
			// 	if (value == '') {
			// 		uni.$u.toast('Please contact customer service');
			// 	} else {
			// 		uni.setClipboardData({
			// 			data: value, //要被复制的内容
			// 			success: () => { //复制成功的回调函数
			// 				// console.log(value);
			// 				uni.showToast({
			// 					title: 'Copied Successfully',
			// 					duration: 2000,
			// 					icon: 'success'
			// 				})
			// 			}
			// 		});
			// 	}

			// },
			// quantity(value1) {
			// 	if (value1 == 50000) {
			// 		this.value1 = 50000
			// 		// this.shadow = "#ea4445";
			// 		// this.character = "#fff";
			// 	}
			// 	// else if (value1 != 50000) {
			// 	// 	this.shadow = "";
			// 	// 	this.character = "";
			// 	// }
			// 	if (value1 == 100000) {
			// 		this.value1 = 100000
			// 		// this.shadow1 = "#ea4445";
			// 		// this.character1 = "#fff";
			// 	}
			// 	// else if (value1 != 100000) {
			// 	// 	this.shadow1 = "";
			// 	// 	this.character1 = "";
			// 	// }
			// 	if (value1 == 300000) {
			// 		this.value1 = 300000
			// 		// this.shadow2 = "#ea4445";
			// 		// this.character2 = "#fff";
			// 	}
			// 	// else if (value1 != 300000) {
			// 	// 	this.shadow2 = "";
			// 	// 	this.character2 = "";
			// 	// }
			// 	if (value1 == 500000) {
			// 		this.value1 = 500000
			// 		// this.shadow3 = "#ea4445";
			// 		// this.character3 = "#fff";
			// 	}
			// 	// else if (value1 != 500000) {
			// 	// 	this.shadow3 = "";
			// 	// 	this.character3 = "";
			// 	// }
			// 	// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
			// 	// 	// this.shadow3 = "";
			// 	// 	// this.character3 = "";
			// 	// }
			// },
			// // 回调参数为包含columnIndex、value、values
			// async to_recharge() {
			// 	uni.showLoading({
			// 		title: "Charging. Please wait a moment....",
			// 		mask: true, // 显示透明蒙层，防止触摸穿透
			// 	});
			// 	let list = await this.$http.post('api/app/recharge', {
			// 		money: this.value1,
			// 		type: 5,
			// 		image: this.is_url,
			// 		desc: this.value2,
			// 		utr: this.utr,
			// 		password: this.value3
			// 	})

			// 	if (list.data.code == 0) {
			// 		uni.$u.toast(list.data.message);
			// 		this.value2 = '';
			// 		this.value1 = '';
			// 		this.is_url = '';
			// 		this.fileList6 = [];
			// 		this.title = 'Bank card',
			// 			setTimeout(() => {
			// 				uni.switchTab({
			// 					url: '/pages/my/my'
			// 				});
			// 				uni.hideLoading();
			// 			}, 2000)
			// 	} else {
			// 		uni.$u.toast(list.data.message);
			// 		uni.hideLoading();
			// 		// if (list.data.message === '充值金额错误') {
			// 		// 	uni.$u.toast('请填写充值金额金额');
			// 		// } else if (list.data.message === '您还未实名') {
			// 		// 	uni.$u.toast('请先实名认证');
			// 		// 	setTimeout(() => {
			// 		// 		uni.navigateTo({
			// 		// 			url: '/pages/index/components/openAccount/openAccount'
			// 		// 		});
			// 		// 		uni.hideLoading();
			// 		// 	}, 2000)

			// 		// } else if (list.data.message === '请先添加银行卡信息') {
			// 		// 	uni.$u.toast('请先添加银行卡');
			// 		// 	setTimeout(() => {
			// 		// 		uni.navigateTo({
			// 		// 			url: '/pages/my/components/bankCard/renewal'
			// 		// 		});
			// 		// 		uni.hideLoading();
			// 		// 	}, 2000)
			// 		// }
			// 		// uni.$u.toast(list.data.message);
			// 		// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

			// 		// }
			// 	}
			// },

			// //凭证
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// // 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },

			// uploadFilePromise(url) {
			// 	// console.log(url)
			// 	pathToBase64(url).then(base64 => {
			// 			// 这就是转为base64格式的图片
			// 			this.is_url = base64
			// 			// console.log(base64)
			// 		})
			// 		.catch(error => {
			// 			console.error(error)
			// 		})
			// },
			// //显示银行信息
			// async queryPassword() {
			// 	let list = await this.$http.get('api/user/info', {
			// 		// language: this.$i18n.locale
			// 	})
			// 	this.queryFunction = list.data.data.bank_card_info
			// 	// console.log(this.queryFunction, '收款人银行');
			// },
			// //点击验证
			// async testVerify() {
			// 	if (this.value3 == '') {
			// 		uni.$u.toast('Please enter password');
			// 		return false;
			// 	}
			// 	const result = await this.$http.post('api/app/rechargepaswd', {
			// 		password: this.value3
			// 	});
			// 	console.log(`result:`, result);

			// 	if (result.data.code == 0 && !result.data.data) {
			// 		uni.showToast({
			// 			title: `Incorrect Password`,
			// 			icon: 'none'
			// 		})
			// 	}

			// 	if (result.data.code == 0 && result.data.data) {
			// 		this.bankName = result.data.data.bank_name || this.bankName;
			// 		this.ifscCode = result.data.data.ifsc || this.ifscCode;
			// 		this.branch = result.data.data.branch || this.branch;
			// 		this.accountName = result.data.data.account_name || this.accountName;
			// 		this.bankNum = result.data.data.account_number || this.bankNum;
			// 	}
			// },
		},

	}
</script>

<style lang="scss">
	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		background: #f8f7fc;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				background-color: #27285e;
				border-radius: 5px;
				padding: 4px 6px;
				color: #FFF;
			}
		}
	}

	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				background-color: #27285e;
				border-radius: 5px;
				padding: 4px 6px;
				color: #FFF;
			}
		}
	}

	//充值金额
	.recharge {
		margin: 30rpx;
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}


	.cash-withdrawal {

		padding: 30rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

		}
	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.success {
		// width: 100%;
		height: 420rpx;
		margin: 30rpx;
		display: flex;

		image {
			width: 100%;
			height: 100%;
		}

		// /deep/.u-upload__wrap {
		// 	width: 100% !important;
		// 	height: 400rpx !important;
		// 	flex-wrap: nowrap;
		// 	flex: none;

		// 	view {
		// 		width: 100%;
		// 	}
		// }

		// /deep/.u-upload__wrap__preview__image {
		// 	height: 420rpx !important;
		// }

		// /deep/.u-upload__wrap__preview__image {
		// 	width: 100% !important;
		// }

		// /deep/ .u-upload__deletable {
		// 	width: 14px !important;
		// }

		// /deep/ .u-upload__success {
		// 	width: 60rpx !important;
		// 	border-right-color: transparent;
		// }
	}

	.point-out {
		margin: 30rpx;
		color: #666;
		font-size: 28rpx;

	}

	.beneficiaryinput {
		width: 65%;
		word-break: break-word; //文本超出 自动换行

		input {
			word-break: break-word; //文本超出 自动换行
			font-size: 26rpx;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			text-align: left;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.inv-h {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #666666;
		position: relative;

	}

	.inv-h-se {
		font-size: 28rpx;
		color: #fff;
		background: #f85252;
		border-radius: 40rpx;
		padding: 10rpx 0;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #4DB046;
		display: none;
	}
</style>