<template>
	<view style="background-color: #f8f8f8;">
		<view class="">
			<!-- <CustomHeader :title="$lang.TRADE_LOG" @action="handleBack()"></CustomHeader> -->
			<view class="common_header flex" style="background-image: url(/static/diwen.png);background-size: contain;background-size: 40% 100%;background-repeat: no-repeat;background-color: #27285e;height: 40px;">
				<image src="../../static/fanhui.png" mode="widthFix" style="width: 20px;height: 20px;" @click="handleBack()"></image>
				<view class="bold color-white flex-1 text-center font-size-18">{{$lang.TRADE_LOG}}</view>
			</view>
		</view>
		<view style="margin-top: 10px;margin-left: 10px;">
			<Tbas :btns="$util.BTNS_TRADE_LOG" :tabIndex="current" @action="handleChangeTab"></Tbas>
		</view>
		<view style="margin: 10px;">
			<template v-if="current == 0">
				<LogTrade></LogTrade>
			</template>
			
			<template v-if="current == 1">
				<LogDeposit></LogDeposit>
			</template>
			
			<template v-if="current == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import LogTrade from '@/components/LogTrade.vue';
	import LogDeposit from '@/components/LogDeposit.vue';
	import LogWithdraw from '@/components/LogWithdraw.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				current: 0,
				// btns: [this.$lang.LOG_TRADE, this.$lang.LOG_DEPOSIT, this.$lang.LOG_WITHDRAW],
			};
		},
		onLoad(item) {
			console.log(item,33333);
			this.current = Number(item.type) || 0;
		},
		methods: {
			handleBack() {
				uni.reLaunch({
					url:'/pages/account/center'
				});
			},
			handleChangeTab(val) {
				clearInterval(this.timer);
				this.current = val;
			},
		},
	}
</script>