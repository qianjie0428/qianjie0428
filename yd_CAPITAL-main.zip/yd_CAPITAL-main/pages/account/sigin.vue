<!-- 登入 注册 -->
<template>
	<view class="signIn_bg">
		<view class="signIn_icon"> </view>

		<view style="padding:24rpx;margin-top: -80rpx;">
			<view
				style="border:1px solid #f94635;border-radius: 12rpx;background-color: rgba(255, 255, 255, 0.7);padding: 24rpx;">
				<view class="flex gap10">
					<image src="/static/shoujihao.png" mode="widthFix" style="width: 15px;"></image>
					Mobile Number
				</view>

				<view class="common_input_wrapper">
					<input v-model="user" type="text" placeholder="Enter your mobile number"></input>
				</view>

				<view class="flex gap10 margin-top-10">
					<image src="/static/querenmima.png" mode="widthFix" style="width: 15px;"></image>
					Password
				</view>

				<view class="common_input_wrapper">

					<input v-model="password" type="password" :placeholder="$lang.PASSWORD"></input>
				</view>


				<view class="flex gap10 margin-top-10" v-if="!isSignIn">
					<image src="/static/querenmima.png" mode="widthFix" style="width: 15px;"></image>
					Repeat password
				</view>


				<view v-if="!isSignIn" class="common_input_wrapper">

					<input v-model="password2" type="password" :placeholder="$lang.PASSWORD_CONFIRM"></input>
				</view>


				<view class="flex gap10 margin-top-10" v-if="!isSignIn">
					<image src="/static/yanzhengma.png" mode="widthFix" style="width: 15px;"></image>
					Invitation Code
				</view>

				<view v-if="!isSignIn" class="common_input_wrapper">

					<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE"></input>
				</view>

				<view style="position: relative;height: 24px;line-height: 24px;margin-top: 10px;">
					<!-- <u-checkbox-group v-if="isSignIn">
						<u-checkbox :activeColor="$util.THEME.PRIMARY" :label="$lang.TIP_REMEMBER_PWD" v-model="checked"
							:labelColor="$util.THEME.TIP"></u-checkbox>
					</u-checkbox-group> -->
					<template v-if="isSignIn">
						<u-checkbox-group>
							<u-checkbox shape="" :activeColor="$util.THEME.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
								v-model="isRemember" :labelColor="$util.THEME.PRIMARY" labelSize="24rpx"
								@change="changeRemember" :checked="isRemember"></u-checkbox>
						</u-checkbox-group>
					</template>
					<view style="display: flex;align-items: center;position: absolute;right: 0;top: 0;"
						@click="handleChange()">
						<text style="font-size: 14px;margin-right: 4px;"
							:style="{color:$util.THEME.TIP}">{{isSignIn?$lang.SIGN_out55:$lang.SIGN_IN}}</text>
						<view class="arrow rotate_45" :style="$util.calcImageSize(5)"></view>
					</view>
				</view>
				<view class="common_btn btn_primary" style="margin-top: 20px;border-radius: 5px;"
					@click="handleConfirm()">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_out55}}
				</view>

				<view class="flex margin-left-20"
					style="width: 86%;position: relative;height: 24px;line-height: 24px;margin-top: 20px;">

					<u-checkbox-group>
						<u-checkbox shape="" :activeColor="$util.THEME.PRIMARY" v-model="isAgree" labelColor="#CBCBCF"
							labelSize="24rpx" @change="changeAgree" :checked="isAgree"></u-checkbox>
					</u-checkbox-group>

					<!-- <u-checkbox-group>
						<u-checkbox :activeColor="$util.THEME.PRIMARY" v-model="pri_checked"></u-checkbox>
					</u-checkbox-group> -->


					<view class="flex" @tap="tiaokuan()">
						<view class="flex" style="color: #109E58;">
							Agree to
						</view>
						<view class="flex margin-left-5">
							the terms and conditions
						</view>
					</view>
				</view>

				<view style="font-size: 11px;text-align: center;margin-top: 48rpx; "> SEBI
					Registration No.NSE/BSE/MCX/NCDEX: INZ000172636 </view>

			</view>

			<!-- <view style="padding: 280px 30px;"> -->




			<!-- <template v-if="!isSignIn">
				<view class="common_input_wrapper">
					<image mode="aspectFit" src="/static/code.png" :style="$util.calcImageSize(20)">
					</image>
					<input v-model="email_code" type="text" placeholder="Email verification Code"></input>
					<u-code ref="uCode" @change="codeChange" seconds="20" :changeText="$t('index.60mhcxhq')"></u-code>
					<view style="width: 80px;background-color: aquamarine;text-align: center;" @click="getCode">Get Code
					</view>
				</view>
			</template>
			 -->





			<!-- </view> -->
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				password: '',
				password2: '',
				code: "",
				// email_code: '',
				isSignIn: true,
				isRemember: false, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		onShow() {
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
			this.isRemember = uni.getStorageSync('remember') || false;
			this.isAgree = uni.getStorageSync('agree') || false;
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
			// 用于app退至后台回到前台 /by 2024.06.10
			this.password2 = uni.getStorageSync('password2') || '';
			this.code = uni.getStorageSync('code') || '';
		},
		onHide() {
			// 用于app退至后台 /by 2024.06.10
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
			uni.setStorageSync('password2', this.password2);
			uni.setStorageSync('code', this.code);
		},
		methods: {
			// 勾选记住密码
			changeRemember(e) {
				console.log(e);
				this.isRemember = e;
				uni.setStorageSync('remember', this.isRemember);
				// // 如果取消勾选记住密码，移除账密缓存
				// if (!this.isRemember) {
				// 	uni.removeStorageSync('user');
				// 	uni.removeStorageSync('pwd');
				// }
			},
			// 勾选用户隐私协议
			changeAgree(e) {
				console.log(e);
				this.isAgree = e;
				uni.setStorageSync('agree', this.isAgree);
			},

			handleChange() {
				this.isSignIn = !this.isSignIn;
				// 无论是否勾选记住密码，都在切换时存储以下信息 /by 2024.06.10
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('password2', this.password2);
				uni.setStorageSync('code', this.code);
			},
			handleConfirm() {
				console.log(this.checkForm(), this.isSignIn)
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			tiaokuan() {
				// 无论是否勾选记住密码，都在切换时存储以下信息 /by 2024.06.10
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('password2', this.password2);
				uni.setStorageSync('code', this.code);
				// // 只有在勾选了记住密码，才存储一下信息
				// if (this.isRemember) {
				// 	uni.setStorageSync('user', this.user);
				// 	uni.setStorageSync('pwd', this.password);
				// 	uni.setStorageSync('remember', this.isRemember);
				// }
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/tiaokuan'
				});
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.USER_NAME);
					return false;
				}
				if (!this.isSignIn && this.user.length < 10) {
					uni.$u.toast(`Minimum input is 10 characters`);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.password2 == '') {
					uni.$u.toast(this.$lang.PASSWORD_CONFIRM);
					return false;
				}
				if (!this.isSignIn && this.password2 != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.INVITATION_CODE);
					return false;
				}
				if (this.isAgree != true) {
					uni.$u.toast("Please agree to the privacy agreement");
					return false;
				}

				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNIN_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_IN, {
					username: this.user,
					password: this.password,
				})
				uni.hideLoading();
				if (result.data.code == 0) {
					const token = result.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					uni.setStorageSync('user', this.user);
					uni.setStorageSync('pwd', this.password);
					uni.$u.sleep(500).then(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME,
						});
					});
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async register() {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				// let invalidEmail = !emailPattern.test(this.user);
				// if (invalidEmail) {
				// 	return uni.$u.toast('Please enter your vaild email');
				// }
				uni.showLoading({
					title: this.$lang.TIP_SIGNUP_ING,
				})
				const result = await this.$http.post("api/app/register", {
					mobile: this.user,
					password: this.password,
					confirmpass: this.password,
					invite: this.code,
					// code: this.email_code,
				})
				uni.hideLoading();
				if (result.data.code == 0) {
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			async getCode() {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				// let invalidEmail = !emailPattern.test(this.user);
				// if (invalidEmail) {
				// 	return uni.$u.toast('Please enter your vaild email');
				// }
				if (!this.user) {
					uni.$u.toast('Please enter your vaild email');
					return
				}
				if (this.$refs.uCode.canGetCode) {
					// 模拟向后端请求验证码
					uni.showLoading({
						title: "Getting"
					})
					let list = await this.$http.post('api/app/sendSmsCode', {
						mobile: this.user,
					})
					uni.hideLoading();
					// 这里此提示会被this.start()方法中的提示覆盖
					uni.$u.toast("Verification code sent");
					// 通知验证码组件内部开始倒计时
					this.$refs.uCode.start();
				} else {
					// uni.$u.toast('倒计时结束后再发送');
				}
			},
		}
	}
</script>