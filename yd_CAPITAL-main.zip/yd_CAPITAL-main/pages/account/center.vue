<template>
	<view style="">
		<view class="account_center_bg" style="background-color: #ffffff;">
			<!-- <Header></Header> -->


			<Profile :info="userInfo"></Profile>



			<view style="padding: 10px;">
				<view class="flex"
					style="background-color: #fcf0d0;border-radius: 10px 10px 0px 0px;padding: 10px;border: 1px #e2ad50 solid ;">
					<image src="/static/anquan.png" mode="widthFix" style="width: 25px; height: 25px;"></image>
					<view class="flex-1 bold" style="color: #d2a557;margin-left: 10px;">Account Funds</view>
					<view class="bold" style="color: #d2a557;" v-if="is_check !==1">KYC Not Certified</view>
					<view class="bold" style="color: #d2a557;" v-if="is_check ==1">KYC Certified</view>
				</view>
				<view class="flex flex-b"
					style="background-color: #fff;padding: 15px 35px;border-radius: 0px 0px 10px 10px;border: 1px #e2ad50 solid">
					<view class="text-center" @click="xinwen()">
						<image src="/static/xinwen.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1">News</view>
					</view>
					<view class="text-center" @click="shichang()">
						<image src="/static/jinrong.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1">Market</view>
					</view>
					<view class="text-center" @click="jiaoyi()">
						<image src="/static/jiaoyi.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1">Trade</view>
					</view>

					<view class="text-center" @click="shiming()">
						<image src="/static/KYC.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1">KYC</view>
					</view>
				</view>
			</view>

			<view>
				<template>
					<view class="flex" style="background-color: #f7f7fb;padding: 5px;">
						<image src="../../static/lunbo.png" mode="widthFix"
							style="width: 25px;height: 25px;margin-left: 10px;"></image>
						<u-notice-bar :text="text1" icon="" direction="column" speed="60" bgColor="#f7f7fb"
							color="#a7a8ac" url="/pages/componentsB/tag/tag"></u-notice-bar>
					</view>
				</template>
			</view>

			<view class="padding-15">
				<view
					style="background-image: url(/static/yue_bg.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;padding: 10px;">
					<view class="flex">
						<image src="/static/jine.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
						<view class="bold hui1 margin-left-10">Total Assets</view>
					</view>
					<view style="font-size: 20px;font-weight: 500;padding: 10px 30px;"
						:style="{color:$util.THEME.TEXT_DARK}">
						{{$util.formatNumber(userInfo.totalZichan)}}
					</view>
					<view class="flex flex-b" style="padding: 0px 30px;">
						<view>
							<view class="bold hui1">Available Balance</view>
							<view style="font-size: 20px;font-weight: 500;margin-top: 10px;"
								:style="{color:$util.THEME.TEXT_DARK}">
								{{$util.formatNumber(userInfo.money)}}
							</view>
						</view>
						<view>
							<view class="bold hui1">Freeze Funds</view>
							<view style="font-size: 20px;font-weight: 500;margin-top: 10px;"
								:style="{color:$util.THEME.TEXT_DARK}">
								{{$util.formatNumber(userInfo.totalZichan-userInfo.money)}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<view class="flex flex-b" style="padding: 0px 20px;">
				<view
					style="padding: 15px 55px;background-image: url(/static/cunkuan.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;"
					@click="handleDeposit()">Deposit</view>
				<view
					style="padding: 15px 50px;background-image: url(/static/tikuan.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;"
					@click="handleWithDraw()">Withdrawal</view>
			</view>

			<view>
				<view class="flex " style="padding: 20px 0px;">
					<view class="text-center" style="flex: 30%;" @click="yuejl()">
						<image src="/static/yue.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Balance Record</view>
					</view>
					<view class="text-center" style="flex: 30%;" @click="cunkuanjl()">
						<image src="/static/cunkuan2.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Deposit Records</view>
					</view>
					<view class="text-center" style="flex: 30%;" @click="qukuanjl()">
						<image src="/static/qukuan.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Withdrawal Record</view>
					</view>

				</view>
				<view class="flex" style="padding: 10px 0px;">
					<view class="text-center" style="flex: 30%;" @click="xiugai()">
						<image src="/static/mima.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Change Login Password</view>
					</view>
					<view class="text-center" style="flex: 30%;" @click="zhifu()">
						<image src="/static/shiming.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Reset Payment Password</view>
					</view>
					<view class="text-center" style="flex: 30%;" @click="yinhangka()">
						<image src="/static/yinhangka.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
						<view class="bold font-size-12 hui1 margin-top-5">Bank Details</view>
					</view>
				</view>
			</view>

			<view class="padding-15">
				<image src="/static/wo_bgtu.png" mode="widthFix" style="width: 100%;"></image>
			</view>

			<view class="flex flex-b" style="padding: 5px 20px;">
				<view class="flex"
					style="background-color: #f5f5f5;padding: 10px 40px;border-radius: 20px 20px 20px 0px;">
					<image src="/static/lianluo.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					<view class="margin-left-10">Contact Us</view>
				</view>
				<view class="flex"
					style="background-color: #f5f5f5;padding: 10px 40px;border-radius: 20px 20px 20px 0px;"
					@click="handleSignOut()">
					<image src="/static/tuichu.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					<view class="margin-left-10">Log Out</view>
				</view>
			</view>
			<view class="padding-15">
				<view
					style="padding: 15px;background-image: url(/static/ty_bg.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;background-color: #f7f7f7;border-radius: 10px;">
					<!-- <view style="border-bottom: 1px #ccc solid;">
						<view class="flex" @click="$util.linkCustomerService()">
							<image src="/static/women.png" mode="widthFix" style="width: 15px;height: 15px;"></image>
							<view class="margin-left-10">Our Services</view>
						</view>
						<view style="padding: 5px 25px;font-size: 10px;color: #777;">About the Service Agreement</view>
					</view> -->
					<!-- <view style="border-bottom: 1px #ccc solid;padding: 10px 0px;">
				<view class="flex">
					<image src="/static/zhanghu.png" mode="widthFix" style="width: 15px;height: 15px;"></image>
					<view class="margin-left-10">账户安全</view>
				</view>
				<view style="padding: 5px 25px;font-size: 10px;color: #777;">保护账户与资金</view>
			</view> -->
					<view style="border-bottom: 1px #ccc solid;padding: 10px 0px;" @click="privacyAgreement()">
						<view class="flex">
							<image src="/static/tiaokuan.png" mode="widthFix" style="width: 15px;height: 15px;"></image>
							<view class="margin-left-10">Terms</view>
						</view>
						<view style="padding: 5px 25px;font-size: 10px;color: #777;">Protecting privacy and information
						</view>
					</view>
				</view>
			</view>
		</view>



		<!-- <NavList :list="$util.funcListConfig()" @action="handleClick"> </NavList> -->



		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header">{{curConfig.title}}</view>
					<template v-if="current==2">
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/user.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value1" :placeholder="curConfig.input1ph" type="text"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/bank.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value2" :placeholder="curConfig.input2ph" type="text"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/card1.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value3" :placeholder="curConfig.input3ph" type="text"></input>
						</view>
					</template>

					<template v-else>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
							</image>
							<input v-model="value1" :placeholder="curConfig.input1ph" type="password"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
							</image>
							<input v-model="value2" :placeholder="curConfig.input2ph" type="password"></input>
						</view>
					</template>

					<view style="display: flex;justify-content: space-evenly;margin-top: 60px;">
						<view class="common_btn btn_primary" style="flex:30%;margin:0px 30px;" @click="handleConfirm">
							{{$lang.CONFIRM}}
						</view>
						<view class="common_btn btn_secondary" style="flex:30%;margin:0px 30px;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	export default {
		components: {
			Header,
			Profile,
			NavList,
		},
		data() {
			return {
				userInfo: {}, // 基本信息
				isShow: false, // 显示弹层
				value1: '', // 第一个输入框
				value2: '', // 第二个输入框
				value3: '', // 第三个输入框，绑卡所需
				current: -1, // 当前显示的弹层
				curConfig: {}, // 弹层中的配置
				is_check: '',
				text1: ['Attention Investors! 📢 Stock X has hit a new all-time high, breaking a key resistance level! Get ready for a fresh wave of gains!',
					'Market Update! 📈 Hot stock Y is soaring today with heavy inflows! Don’t miss out on this great opportunity!',
					'Announcement Alert📢 – Big news! Leading Bank Z has reported quarterly earnings above expectations. Watch for potential price movements!',
					'Investment Opportunity! 📢 Pharma stocks are on a strong uptrend! Could be the start of a new rally—investors, keep an eye on the leading stocks in the sector!',
					'Quick Reminder 📢 – Company W just released a major announcement, and the stock price is swinging! Current holders, manage risks and monitor intraday movements closely!',
					'Hot Off the Press! 🔥 IT sector stocks are performing exceptionally well! Multiple companies announce new contracts, creating opportunities. Stay tuned!',
				],
				cardInfo: {}, // 银行卡信息，显示绑卡信息，或变更绑卡信息
			}
		},
		onShow() {
			this.gaint_info()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Loading',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
			// 储值
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				})
			},
			// 贷款
			handleScore() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_CREDIT_SCORE
				})
			},
			// 功能列表，点击事件
			// handleClick(val) {
			// 	console.log('val:', val);
			// 	this.current = this.$util.MODE_DIALOG.findIndex(item => item.url == val.url);
			// 	console.log('index:', this.current);
			// 	this.curConfig = {
			// 		title: val.name,
			// 		input1ph: this.current == 2 ? this.$lang.REAL_NAME : this.$lang.NEW_PWD,
			// 		input2ph: this.current == 2 ? this.$lang.BANK_NAME : this.$lang.NEW_PWD2,
			// 		input3ph: this.$lang.BANK_CARD,
			// 		type: this.current == 2 ? 'text' : 'password',
			// 	};
			// 	this.isShow = true;

			// 	// 如果是绑卡弹层，请求已绑卡信息
			// 	if (this.current == 2 && this.cardInfo) {
			// 		this.value1 = this.cardInfo.realname;
			// 		this.value2 = this.cardInfo.bank_name;
			// 		this.value3 = this.cardInfo.card_sn;
			// 	}
			// },
			handleCancel() {
				this.isShow = false;
				this.value1 = "";
				this.value2 = "";
				this.value3 = "";
			},
			async handleConfirm() {
				// 根据当前显示弹出，分别处理。其中，变更账户密码与支付密码逻辑相同
				const urls = [this.$http.API_URL.SIGNIN_PASSWORD,
					this.$http.API_URL.PAY_PASSWORD,
					this.$http.API_URL.BIND_BANK_CARD,
				];
				let tempData = {};
				if (this.current == 2) {
					tempData = {
						realname: this.value1,
						bank_name: this.value2,
						card_sn: this.value3,
					}
				} else {
					tempData = {
						newpass: this.value1,
						confirmpass: this.value2,
					};
				}
				let result = await this.$http.post(urls[this.current], tempData);
				if (result.data.code == 0) {
					uni.$u.toast(this.current == 2 ? 'Your bank card information has been successfully submitted.' :
						'It is changed.');
					this.isShow = false;
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			actionEvent() {
				console.log("Clicked item:", item); // 检查 item 是否包含 mode: 'sign_out'

				if (item.mode === 'sign_out') {
					this.handleSignOut();
					return false;
				}

				if (item.mode) {
					uni.navigateTo({
						url: item.url,
					});
				} else {
					this.$emit('action', item);
				}
			},

			// manages() {
			// 	if (this.cardManagement) {
			// 		uni.navigateTo({
			// 			url: this.$util.PAGE_URL.ACCOUNT_BANK_CARD
			// 		});
			// 	} else {
			// 		uni.navigateTo({
			// 			//保留当前页面，跳转到应用内的某个页面
			// 			url: '/pages/my/components/bankCard/renewal'
			// 		});
			// 	}
			// },
			// //版本更新
			// Update() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/versionUpdate'
			// 	});
			// },
			//用户协议
			// userAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/userAgreement'
			// 	});
			// },

			//存款记录
			cunkuanjl() {
				uni.reLaunch({
					url: '/pages/account/tradeLog?type=1'
				});
			},
			//取款记录
			qukuanjl() {
				uni.reLaunch({
					url: '/pages/account/tradeLog?type=2'
				});
			},
			//余额记录
			yuejl() {
				uni.reLaunch({
					url: '/pages/account/tradeLog?type=0'
				});
			},
			//市场
			shichang() {
				uni.reLaunch({
					url: '/pages/market/overview'
				});
			},
			//交易
			jiaoyi() {
				uni.reLaunch({
					url: '/pages/account/trade'
				});
			},
			//新闻
			xinwen() {
				uni.reLaunch({
					url: '/pages/market/news'
				});
			},
			//实名
			shiming() {
				uni.navigateTo({
					url: '/pages/account/auth'
				});
			},
			//修改登录密码
			xiugai() {
				uni.navigateTo({
					url: '/pages/account/pwd'
				});
			},
			//修改支付密码
			zhifu() {
				uni.navigateTo({
					url: '/pages/account/pwdPay'
				});
			},
			//银行卡
			yinhangka() {
				uni.navigateTo({
					url: '/pages/account/cardList'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					url: '/pages/about'
				});
			},

			//关于我们
			aboutUs() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ABOUT
				});
			},
			//实名认证
			notCertified() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_AUTH
				});
			},


			//用户信息
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				this.is_check = result.data.data.is_check;
				// this.cardManagement = result.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('completed successfully');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		},


	}
</script>