<template>
	<view>
		<view style="background-color: #27285e;width: 100%;">
			<image src="/static/diwen.png" mode="heightFix" style="height: 70px;"></image>

			<view class="padding-20" style="position: absolute;top: 18px;width: 90%;">
				<view class="flex flex-b">
					<view class="color-white font-size-16">Transaction</view>
					<view class="flex">
						<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
							@click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
						<image src="/static/service.png" mode="widthFix" style="width: 20px;height: 20px;margin-left: 20px;"
							@click="$util.linkCustomerService()"></image>
					</view>
				</view>

			</view>

		</view>
		<view style="padding: 0 10px;">
			<view class="padding-10">
				<image src="/static/order/banner.png" mode="widthFix" style="width: 100%;"></image>
			</view>
			<view class="flex flex-b text-center" style="padding: 10px 60px;">
				<view @click="$u.route({url:'/pages/trade/ipo'});">
					<view>
						<image src="/static/market/xingushengou.png" mode="widthFix" style="width: 45px;height: 45px;">
						</image>
					</view>
					<view class="text-center">IPO</view>
				</view>
				<view @click="$u.route({url:'/pages/trade/large'});">
					<view>
						<image src="/static/market/dazongjiaoyi.png" mode="widthFix" style="width: 45px;height: 45px;">
						</image>
					</view>
					<view class="text-center">OTC Trade</view>
				</view>

				<!-- <view @click="$u.route({url:'/pages/account/auth'});">
					<view><image src="/static/market/shiming.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
					<view class="text-center">Real</view>
				</view>
				<view @click="$u.route({url:'/pages/account/withdraw'});">
					<view><image src="/static/market/cunkuan.png" mode="widthFix" style="width: 45px;height: 45px;"></image></view>
					<view class="text-center">Withdrawal</view>
				</view> -->

			</view>

			<view style="margin-top: 10px;">
				<TradeInfo :info="userInfo"></TradeInfo>
			</view>
			<view style="background-color: #f8f8f8;padding: 5px 40px;" class="flex flex-b margin-top-10">
				<!-- <view class="font-size-18 text-center" :style="inv==0?'background-color: #F0EEFF;border-radius: 20px 20px 20px 0;':'color:#35353A'" style="padding: 10px 20px;" @click="inv=0;list=''">Delegation</view> -->
				<view class="font-size-18 text-center"
					:style="curTab==0?'background-color: #F0EEFF;border-radius: 20px 20px 20px 0;':'color:#35353A'"
					style="padding: 10px 20px;" @click="curTab=0;changeTab(0)">{{$lang.STOCK_HOLD_STATUS}}</view>
				<view class="font-size-18 text-center"
					:style="curTab==1?'background-color: #F0EEFF;border-radius: 20px 20px 20px 0;':'color:#35353A'"
					style="padding: 10px 20px;" @click="curTab=1;changeTab(1)">{{$lang.STOCK_SALES_HISTORY}}
				</view>
			</view>
			<view>
				<template v-if="list && list.length>0">
					<view class="margin-top-10 gap5" style="">
						<block v-for="(item,index) in list" :key="index">
							<view style="padding:10px;">
								<view>
									{{item.name}}
									<span style="margin-left: 5px;">({{item.curcode}}) </span>
								</view>
								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.BUY_NUM}}</view>
										<view>{{$util.formatNumber(item.buyNum)}}</view>
									</view>
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.BUY_PRICE}}</view>
										<view>{{$util.formatNumber(item.buyPrice,2)}}</view>
									</view>
								</view>
								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.FEE_BUY_SELL}}</view>
										<view>{{$util.formatNumber(item.buyFee,2)}}</view>
									</view>
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.BUY_TOTAL_AMOUNT}}</view>
										<view>{{$util.formatNumber(item.buyAmount,2)}}</view>
									</view>
								</view>
								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.CURRENT_PROFIT_LOSS}}</view>
										<view :style="$util.calcStyleRiseFall(item.buyFloatPL>0)" v-if="isHold">
											{{$util.formatNumber(item.buyFloatPL,2)}}
										</view>
										<view :style="$util.calcStyleRiseFall(item.sellFloatPL>0)" v-else>
											{{$util.formatNumber(item.sellFloatPL,2)}}
										</view>
									</view>
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">Price Change</view>
										<view :style="$util.calcStyleRiseFall(item.buyPLRate>0)" v-if="isHold">
											{{$util.formatNumber(item.buyPLRate,2)}}%
										</view>
										<view :style="$util.calcStyleRiseFall(item.sellPLRate>0)" v-else>
											{{$util.formatNumber(item.sellPLRate,2)}}%
										</view>
									</view>
								</view>

								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">Market Cap</view>
										<view v-if="isHold"> {{$util.formatNumber(item.buyTotal,2)}} </view>
										<view v-else> {{$util.formatNumber(item.sellTotal,2)}} </view>
									</view>

									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.LEVER}}</view>
										<view>{{item.double}}</view>
									</view>
								</view>

								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.TOTAL_PROFIT_LOSS_AMOUNT}}</view>
										<view>
											{{$util.formatNumber(item.plAmount)}}
										</view>
									</view>

									<view class="flex flex-b margin-top-10 flex-1" v-if="!isHold">
										<view style="color: #35353A;"> Close Price</view>
										<view>{{$util.formatNumber(item.sellPrice,2)}}</view>
									</view>

									<view class="flex flex-b margin-top-10 flex-1" v-else>
										<view style="color: #35353A;">Current Price</view>
										<view style="color: crimson;">
											{{$util.formatNumber(item.curPrice,2)}}
										</view>
									</view>
								</view>

								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">{{$lang.BUY_DATETIME}}</view>
										<view>{{item.buyDT}}</view>
									</view>
									<view class="flex flex-b margin-top-10 flex-1" v-if="!isHold">
										<view style="color: #35353A;">{{$lang.SELL_DATETIME}}</view>
										<view>{{item.sellDT}}</view>
									</view>
								</view>

								<view class="flex flex-b gap10">
									<view class="flex flex-b margin-top-10 flex-1">
										<view style="color: #35353A;">Order ID</view>
										<view>{{item.sn}}</view>
									</view>
								</view>

								<view class="flex  margin-top-10 gap10">
									<view class="common_btn btn_primary flex-1"
										@tap="handleStockDetail(item.numCode,item.typeId)">
										{{$lang.STOCK_DETAIL}}
									</view>
									<view class="common_btn btn_secondary flex-1" @tap="handleSell(item.id)"
										v-if="isHold">
										{{$lang.STOCK_SELL}}
									</view>
								</view>
							</view>
							<view style="height: 15px;background-color: #f8f8f8;margin: 10px 0;"></view>
						</block>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	export default {
		components: {
			Header,
			TradeInfo,
		},
		data() {
			return {
				isHold: true, // 是否是持股状态，否则为销售历史
				list: [],
				isSelf: true, // 国内，false:海外
				info: {},
				isShow: false, // 买卖弹出
				userInfo: {}, // 顶部基本信息
				curTab: 0,
				curPage: 1, //
				// maxPage: 1, // 最大页码
				// flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh()
		},
		onShow() {
			this.getUserInfo();
			this.changeTab(this.curTab);
		},

		onUnload() {
			console.log('Position closed');
			clearInterval(this.timerId);
		},
		onHide() {
			console.log('Position closed');
			clearInterval(this.timerId);
		},
		onReachBottom() {
			this.curPage = this.curPage + 1;
			this.getList();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.isHold = val == 0;
				this.curPage = 1;
				// this.flag = true;
				this.getList();
				this.list = [];
			},

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.STOCK_SELL_TIP,
					cancelText: this.$lang.CANCEL,
					confirmText: this.$lang.CONFIRM,
				});
				if (result[1].confirm) {
					uni.hideLoading();
					this.confirmSell(id);
				}
				if (result[1].cancel) {
					console.log('User clicks Cancel.');
				}
			},

			// 平仓功能
			async confirmSell(id) {
				uni.showLoading({
					title: this.$lang.TIP_SELLING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.USER_SELL, {
					id
				})
				if (result.data.code == 0) {
					this.changeTab(this.curTab);
					this.getUserInfo()
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading();
				}
			},

			handleStockDetail(code, type) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&type=${type}`,
				})
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_ORDER, {
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					page: this.curPage,
				});
				if (result.data.code == 0) {
					const temp = result.data.data;
					let tempList = [];
					const ids = this.list.map(item => item.id);

					if (this.isHold) {
						tempList = !temp || temp.length <= 0 ? [] : temp.filter(item => item.goods_info && item
							.order_buy && item.order_buy.id > 0);
					} else {
						tempList = !temp || temp.length <= 0 ? [] : temp.filter(item => item.goods_info && item
							.order_buy && item.order_buy.id > 0 &&
							item.order_sell && item.order_sell.id > 0);
					}
					const filterList = tempList.length <= 0 ? [] : tempList.filter(item => !ids.includes(item.id));
					// 格式化所需数据
					const fmtList = filterList.map(item => {
						const typeId = item.goods_info.project_type_id;
						const curcode = typeId == 1 ? item.goods_info.ncode : item.goods_info.bcode;
						const buyPrice = item.order_buy.price * 1 || 0;
						const buyPL = item.order_buy.yingkui * 1 || 0;
						const sellPrice = item.status == 1 ? 0 : (item.order_sell.price * 1 || 0);
						const sellPL = item.status == 1 ? 0 : (item.order_sell.yingkui * 1 || 0);
						const curPrice = item.goods_info.current_price * 1 || 0;
						const buyNum = item.order_buy.num * 1 || 0;
						return {
							id: item.id,
							status: item.status,
							name: item.goods_info.name || '',
							curcode,
							numCode: item.goods_info.number_code || '',
							typeId: typeId,
							buyNum: item.order_buy.num * 1 || 0,
							buyPrice,
							curPrice,
							sellPrice,
							buyFee: item.order_buy.buy_fee * 1 || 0,
							buyAmount: item.order_buy.amount * 1 || 0,
							buyFloatPL: item.order_buy.float_yingkui * 1 || 0,
							sellFloatPL: item.status == 1 ? 0 : (item.order_sell.float_yingkui * 1 || 0),
							buyPLRate: (curPrice - buyPrice) / buyPrice * 100,
							sellPLRate: item.status == 1 ? '' : (sellPrice - buyPrice) / buyPrice * 100,
							buyTotal: curPrice * buyNum,
							sellTotal: sellPrice * buyNum,
							double: item.order_buy.double || 1,
							// 1买 2卖
							plAmount: item.status == 1 ? buyPL : sellPL,
							buyDT: item.order_buy.created_at || '',
							sellDT: item.status == 1 ? '' : (item.order_sell.created_at || ''),
							sn: item.order_sn || '',
						}
					});
					if (!this.list || this.list.length <= 0) this.list = fmtList;
					else this.list.push(...fmtList);

					console.log(this.list);
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
				console.log(this.list);
			},

			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>