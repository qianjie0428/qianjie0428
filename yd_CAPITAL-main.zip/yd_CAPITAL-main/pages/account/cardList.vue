<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Add Banking Details"></CustomHeader>
		</view>
		<view style="margin:20px;">
			<view style="display: flex;align-items: center;justify-content: center;">
				<view style="background-image: url(/static/card_bg.png);background-repeat: no-repeat;background-position: center;
				background-size: 100% 100%;width: 100%;height: 280rpx;">
					<template v-if="cardInfo">
						<view style="padding:30px;color: #121212;">
							<view>{{cardInfo.bank_name}}</view>
							<view>{{ cardInfo.card_sn.slice(0, -5) + '*****' }}</view>
							<view>{{cardInfo.bank_sub_name}}</view>
						</view>
					</template>
				</view>
			</view>

			
		</view>
		<view class="common_btn btn_primary" style="position: absolute;bottom: 50px;width: 90%;margin-left: 5%;" @click="linkTo()">
			{{!cardInfo?'Add':'Modify' }} Bank Account
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				cardInfo: null,
			};
		},
		onShow() {
			this.gaint_info()
		},
		methods: {
			linkTo() {
				uni.navigateTo({
					url: `/pages/account/bankCard`
				})
			},

			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				console.log(result);
				if (result.data.code == 0) {
					if (!result.data.data.real_name) {
						uni.navigateTo({
							url: this.$util.PAGE_URL.ACCOUNT_AUTH,
						})
					}
					this.cardInfo = result.data.data.bank_card_info;
				}
			},
		},
	}
</script>

<style>
</style>