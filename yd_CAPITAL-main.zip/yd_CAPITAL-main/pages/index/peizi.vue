<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Loan" @action="handleBack()"></CustomHeader>
		</view>

		<view>
			<block v-for="(item,index) in btns" :key="index">
				<view @click="handleChangeTab(index)"
					style="display: inline-block; width:max-content;height: 20px;padding:8px 20px;text-align: center;font-size: 16px;"
					:style="$util.calcStyleTabActive(current === index)">
					{{item}}
				</view>
			</block>
			
		</view>

		<template v-if="current==0">
			<view class="college-content" style="margin-top: 15px;">
				<view class="hui2">
					Lending Institution
				</view>
				<view class="cipher" @click="show=true">
					<input maxlength="11" placeholder="Please select a lending institution" 
						v-model="dk_name"></input>
				</view>
				<view class="hui2">
					Loan minimum amount
				</view>
				<view class="cipher">
					<input maxlength="12" placeholder="Please enter the minimum loan amount" type="text"
						v-model="x_amount"></input>
				</view>

				<view class="hui2">
					Maximum loan amount
				</view>
				<view class="cipher">
					<input maxlength="12" placeholder="Please enter the maximum loan amount" type="text"
						v-model="d_amount"></input>
				</view>
			</view>

			<view class="purchase" @click="submit">
				Confirm
			</view>
		</template>

		<template v-else-if="current==1">
			<view style="display: flex;align-items: center;padding:10px;" :style="{color:$util.THEME.TITLE}">
				<view style="flex: 40%;">Lending Institution</view>
				<view style="flex: 30%;">Loan amount</view>
				<view style="flex: 30%;">Status</view>
			</view>
			<view>
				<EmptyData v-if="list && list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="margin:0 10px 20px 10px;padding:10px;">
						{{item}}
						<!-- <view style="flex: 40%;">{{$util.formatNumber(item.money)}}</view>
						<view style="flex: 30%;font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">
							{{$util.formatNumber(item.success)}}
						</view>
						<view style="flex: 30%;font-size: 13px;">{{item.zt}}</view> -->
					</view>
				</block>
			</view>
		</template>
		<u-picker :show="show" :columns="columns" confirmText="Confirm" cancelText="Cancel" @confirm="jigou_click"
			@cancel="show=false"></u-picker>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0, // 当前tab
				btns: ['Loan', 'Loan log'], // tabs数组
				score:"", // 信用分
				show: false,
				columns: [
					['Citibank']
				],
				money: "",
				top_index: 0,
				list: [],
				bid: "",
				dk_name: "",
				x_amount: "",
				d_amount: ""
			}
		},
		onShow() {},
		onLoad() {},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getLoanLog();
				} 
			},

			jigou_click(item) {
				console.log(item);
				console.log(item.indexs[0]);

				this.bid = item.indexs[0] * 1 + 1
				this.dk_name = item.value[0]
				this.show = false
			},
			
			async getUserInfo(){
				const result = await this.$http.get(`/api/user/info`,{});
				console.log(result);
				this.score = result.data.data.xinyong || 0;
			},

			async getLoanLog(){
				 const result = await this.$http.get(`/api/daikuan/log/`,{});
				 console.log(result);
				 if(result.data.code==0){
					 this.list =result.data.data;
					 this.handleChangeTab(1);
				 }
			},			

			async submit() {
				if (!this.bid) {
					return uni.$u.toast('Please select a lending institution');
				}
				if (!this.x_amount) {
					return uni.$u.toast('Please enter the minimum loan amount');
				}
				if (!this.d_amount) {
					return uni.$u.toast('Please enter the maximum loan amount');
				}
				let list = await this.$http.post('api/daikuan/shenqing', {
					bid: this.bid,
					x_amount: this.x_amount,
					d_amount: this.d_amount,
				})
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
					return uni.$u.toast(list.data.data);
				}
			},
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	// /deep/.uni-input-placeholder {
	// 	color: #C0C4CC;
	// 	font-size: 28rpx;
	// }

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #f6e77f;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #000;
		font-weight: 600;
	}
</style>