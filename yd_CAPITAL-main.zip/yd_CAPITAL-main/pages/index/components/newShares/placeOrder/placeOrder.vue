<!-- 下单 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/fanhui.png" mode="widthFix" style="width: 20px;height: 20px;" @click="fanhui()"></image>
			<view class="college-text ">
				{{objData.goods.name}}
				<view class="" style="font-size: 24rpx;">{{objData.goods.current_price}}</view>
			</view>
			<view class=""></view>
		</view>
		<view class="quantity-content" style="margin-top: 50rpx;">
			
			<view class="quantity">
				<!-- <image src="../../../../../static/purchase/shangshen.png" mode=""></image> -->
				<view class="">quantity</view>
			</view>
			<view class="quantity-input">
				<input class="" placeholder="Please enter" type="number" v-model="quantity"></input>
				<view class="">Quantity</view>
			</view>
		</view>

		<!-- <view class="hand">1 lot = 100 shares</view> -->
		<view class="quantity-content">
			<view class="quantity">
				<!-- <image src="../../../../../static/purchase/biaoqian.png" mode=""></image> -->
				<view class="">Available Credits</view>
			</view>
			<view class="">
				{{list.money}}
			</view>
		</view>

		<!-- 二选一 -->
		<!-- 	<view class="radio">
			<view :class="[flag===0?rise:fall]" @click="chooseEmer(0)">买涨</view>
			<view :class="[flag===1?rise:fall]" @click="chooseEmer(1)">买跌</view>
		</view> -->
		<!-- 杠杆倍数 -->
		<!-- <view class="quantity-content"> -->
		<!-- 		<view class="quantity">
				<image src="../../static/purchase/ganggan.png" mode=""></image>
				<view class="">选择杠杆倍数</view>
			</view> -->

		<!-- <view class="select" @click="show = true">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- 下拉菜单上面这个 -->
		<!-- 	<view class="select">
				<view class="times">{{title}}</view>
				<image src="../../static/purchase/xiabiao.png" mode=""></image>
			</view> -->
		<!-- </view> -->
		<!-- 下拉菜单 -->
		<u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm"></u-picker>

		<view class="quantity-content">
			<view class="quantity">
				<!-- <image src="../../../../../static/purchase/baozheng.png" mode=""></image> -->
				<view class="">Payment Amount</view>
			</view>

			<view class="">
				{{objData.goods.current_price*this.quantity/this.title|addZero}}
			</view>

		</view>

		<view v-if="list.is_check!=1" @tap="authentication()" class="purchase">
			Please check your real name first
		</view>
		<view v-if="list.is_check==1" class="purchase" @click="placeOrder()">
			Buy
		</view>


	</view>
</template>

<script>
	export default {
		data() {
			return {
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '',
				detailedData: "",
				objData: ''
			};
		},
		methods: {
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.objData.ganggan
				// console.log(this.title, '99999');
			},
			fanhui(){
				uni.navigateTo({
					url:'/pages/trade/vip'
				})
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//实名认证
			authentication() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			//购买
			async placeOrder(objData) {
				let list = await this.$http.post('api/product/buy_scramble', {
					num: this.quantity,
					id: this.objData.id,
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "I 'm purchasing it, so please wait...",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_TRADE,
						});
						uni.hideLoading();
					}, 2000)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.list = list.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			const item = JSON.parse(decodeURIComponent(option.item));
			this.objData = item;
			// console.log(this.objData, '========接着');
			this.columns = [item.ganggan]

			// console.log(item.ganggan, '111');
			// const productDetails = JSON.parse(decodeURIComponent(option.productDetails));
			// this.detailedData = productDetails
			// this.columns = [productDetails.ganggan]

		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 20rpx 30rpx 0;
		height: 120rpx;
		background-image: linear-gradient(to right, #1a73e8, #01B4D5);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.quantity-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 30rpx;
		font-size: 28rpx;

		//数量
		.quantity {
			display: flex;
			justify-content: space-between;
			align-items: center;
			font-size: 28rpx;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-right: 20rpx;
			}
		}

		// /deep/.input-placeholder {
		// 	font-size: 28rpx;
		// }

		.quantity-input {
			background-color: #f5f5f5;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;
			padding: 10rpx 20rpx;
			display: flex;
			font-size: 28rpx;
		}

		//杠杆倍数
		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx;
			background-color: #f5f5f5;
			width: 50%;
			border: 2rpx solid #e0e0e0;
			border-radius: 10rpx;



			.times {}

			image {
				height: 20rpx;
				width: 20rpx;

			}
		}

	}

	// 二选一
	.hand {
		text-align: right;
		margin: 10rpx 30rpx;
		font-size: 26rpx;
		color: #999;
	}

	.radio {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 10rpx 30rpx;


		view {
			width: 48%;
			height: 80rpx;
			line-height: 80rpx;
			text-align: center;
			border-radius: 10rpx;
			border: 2rpx solid #e0e0e0;
		}

		.rise {
			background-image: linear-gradient(to right, #1a73e8, #01B4D5);
			color: #fff;
		}

		.fall {
			color: #000;
		}
	}

	//买入
	.purchase {
		background-image: linear-gradient(to right, #1a73e8, #01B4D5);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 28rpx;
	}
</style>