<!-- 우승기록 -->
<template>
	<view style="background-color: #FFF;">
		<view class="header_wrapper_10">
			<CustomHeader title="Subscription allocation details" @action="$util.goBack()"></CustomHeader>
		</view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="border-bottom: 1px solid #ccc;margin: 4px 20px;background-color: #FFF;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
					<view>{{item.goods.name}}</view>
					<view
						style="font-size: 16px;color:seagreen;border-bottom: 2px solid seagreen;background-color: #2e8b573C;padding: 8rpx 12rpx;border-radius: 6rpx;">
						<view v-if="item.status==2" class="" @click="handlePay(item)">Subscribe</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Public Offering Price</view>
					<view>{{$util.formatNumber(item.price)}}</view>
				</view>

				<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" :style="{color:$util.THEME.TIP}">
					<view>Allocation Quantity</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.success_num_amount)}}</view>
				</view> -->
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Subscription amount</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{item.apply_num_amount}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Winning Amount</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{item.success_num_amount}}</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Allocation Quantity</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{item.success}}</view>
				</view>

				<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" :style="{color:$util.THEME.TIP}">
					<view>Amount of back payment</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{(item.success_num_amount-item.freeze)>0?(item.success_num_amount-item.freeze):0}}</view>
				</view> -->

				<template v-if="item.status>1 && item.freeze>0">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TIP}">
						<view>Remaining Amount</view>
						<!-- price*success-freeze -->
						<view :style="{color:$util.THEME.PRIMARY}">{{item.success*item.price-(item.freeze*1)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$util.THEME.TIP}">
						<view>Amount Subscribed</view>
						<view :style="{color:$util.THEME.PRIMARY}">{{item.freeze}}</view>
					</view>
				</template>

				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Transaction date</view>
					<view>{{item.created_at}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Transaction code</view>
					<view>{{item.order_sn}}</view>
				</view>
			</view>
		</block>


		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" style="color:#FFF">Subscription application details</view>
					<view style="padding:10px 20px;">
						<u--input v-model="amount" placeholder="Please enter the subscription amount" type="number"></u--input>
					</view>
					<view style="display: flex;justify-content: space-evenly;margin:20px 10px;gap: 10px;">
						<view class="common_btn btn_primary flex-1" @click="handleConfirm"> {{$lang.BUY}}
						</view>
						<view class="common_btn btn_secondary flex-1" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: '',
				amount: '',
				isShow: false,
			};
		},
		onShow() {
			this.shengou()
			// this.gaint_info()
		},
		// mounted() {
		// 	// uni.showLoading({
		// 	// 	title: '加载中'
		// 	// });

		// },
		methods: {
			// 우승기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

			// 认缴
			handlePay(val) {
				this.isShow = true;
				this.curInfo = val;
			},

			async handleConfirm() {
				const result = await this.$http.post(`api/user/renjiao`, {
					id: this.curInfo.id,
					money: this.amount
				});
				console.log(`pay:`, result);
				this.handleCancel();
				if (result && result.data && result.data.code == 0) {
					uni.$u.toast(result.data.data);
					setTimeout(() => {
						this.shengou();
					}, 1000);
				} else {
					uni.$u.toast(result.data.data.message);
				}
			},

			handleCancel() {
				this.isShow = false;
			},

			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							uni.navigateTo({
								url: this.$util.PAGE_URL.SERVICE
							});
						}, 500)
					} else {
						uni.redirectTo({
							url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
						});
						this.$router.go(0)

					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},

		},

	}
</script>