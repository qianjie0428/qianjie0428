<!-- 主页 -->
<template>
	<view style="background-color: #fffffe;">

		<!-- <Header></Header> -->
		<view style="background-color: #27285e;width: 100%;">
			<image src="/static/diwen.png" mode="heightFix" style="height: 70px;"></image>

			<view class="padding-20" style="position: absolute;top: 0px;width: 100%;">
				<view class="flex flex-b">
					<view>
						<image src="/static/logo.png" mode="widthFix" style="width: 50px;text-align: center;"></image>
					</view>
					<view class="flex">
						<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
							@click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
						<image src="/static/service.png" mode="widthFix"
							style="width: 20px;height: 20px;margin-left: 20px;" @click="$util.linkCustomerService()">
						</image>
					</view>
				</view>
			</view>
		</view>
		
		<template>
		  <u-swiper :list="list1"  circular></u-swiper>
		</template>



		<view style="margin-top: 0px;">
			<view class="common_block" style="background-color: #fafafa;padding: 10px;">
				<ButtonGroup :btns="$util.BTNS_CONFIG_HOME" @action="linkLarge" @deposit="linkDeposit">
				</ButtonGroup>
			</view>

			<view>
				<template>
					<view class="flex" style="background-color: #f7f7fb;padding: 5px;">
						<image src="/static/lunbo.png" mode="widthFix"
							style="width: 25px;height: 25px;margin-left: 10px;"></image>
						<u-notice-bar :text="text1" icon="" direction="column" speed="60" bgColor="#f7f7fb"
							color="#a7a8ac" url="/pages/componentsB/tag/tag"></u-notice-bar>
					</view>
				</template>
			</view>

			<view class="flex gap10 padding-10">

				<view class="flex-1"
					style="background-image: url(/static/home/EasyGains.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;height:80px;padding-left: 10px;">
					<view style="margin-top: 30px;">Secure Growth</view>
					<view style="color: #666666;margin-top: 10px;">Make Wealth Steadier</view>
				</view>

				<view class="flex-1"
					style="background-image: url(/static/home/SecureGrowth.png);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;height:80px;padding-left: 10px;">
					<view style="margin-top: 30px;">Easy Gains</view>
					<view style="color: #666666;margin-top: 10px;">Make Wealth Steadier</view>
				</view>

			</view>
			<!-- 指数 -->
			<template v-if="list && list.length>0">
				<view class="flex gap5 padding-10">
					<image src="/static/home/zhishu.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					<view style="color: #27285E;" class="bold font-size-16">Market Index</view>
				</view>
				<view class="flex flex-b gap10 padding-10">
					<block v-for="(item,index) in list" :key="index">
						<view :class="item.PERCCHANGE>0?'green':'red'"
							style="padding:15px 4px 40px 4px;flex:33.33%;border-radius: 6px;text-align: center;background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;"
							:style="item.PERCCHANGE>0?'background-image: url(/static/home/zhang.png);':'background-image: url(/static/home/die.png);'">
							<!-- <view class="name" style="font-size: 11px;">{{item.indxnm}}</view> -->
							<view style="color: #000;">{{item.name}}</view>
							<view class="price font-size-16 bold margin-top-10">
								{{$util.formatNumber( item.pricecurrent)}}
							</view>

							<view style="margin-top: 10px;">{{$util.formatNumber( item.pricechange*1)}}
								{{item.PERCCHANGE}}%
							</view>
						</view>
					</block>
				</view>
			</template>
			<view class="padding-10">
				<image src="/static/home/SimpleWealth.png" mode="widthFix" style="width: 100%;"></image>

				<view class="flex flex-b gap5 margin-top-10">
					<image src="/static/home/StockTrends.png" mode="widthFix" style="width: 100%;" @click="zuishenc()">
					</image>
					<image src="/static/home/KeyStocks.png" mode="widthFix" style="width: 100%;" @click="pioanuhd()">
					</image>
					<image src="/static/home/PopularWealth.png" mode="widthFix" style="width: 100%;"
						@click="yangtcjsw()"></image>
				</view>
			</view>


			<!-- <template v-if="news.length>0">
				<view class="flex gap5 padding-10">
					<image src="/static/home/hot.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					<view style="color: #27285E;" class="bold font-size-16">Hot News</view>
				</view>
				<view class="list">
					<view class="list">
						<view class="item flex flex-b" v-for="(item,index) in news" @click="open(item.url)">
							<view class="img">
								<image :src="item.pic"></image>
							</view>

							<view class="flex-2">
								<view class="t el">{{item.title}}</view>
								<view class="t1">{{item.sum_title}}
								</view>
							</view>
						</view>

					</view>
				</view>
			</template> -->

			<!-- <GoodsList ref="goods"></GoodsList> -->
		</view>

		<!-- <template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" style="color:#FFFFFF">Please Enter Password</view>

					<view style="display: flex;align-items: center;justify-content: center;">
						<view class="common_input_wrapper">
							<input v-model="password" placeholder="Please Enter Password" type="password"
								:placeholder-style="$util.setStylePlaceholder()"></input>
						</view>
					</view>

					<view style="text-align: right;padding-right: 60rpx;font-size: 24rpx;"
						:style="{color:$util.THEME.TIP}">
						Request password from customer service
					</view>

					<view style="display: flex;justify-content: space-evenly;margin:20px 0;">
						<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm"> Submit
						</view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}000
						</view>
					</view>
				</view>
			</view>
		</template> -->

		<!-- IPO申购成功弹层 -->
		<template v-if="isShowIPO">
			<view class="overlay" style="background-color: rgba(0, 0, 0, 0.35);" @click="handleCloseIPO()"></view>

			<view class="modal_wallet_center ipo_bg" style="width:96vw;">
				<view style="min-height: 30vh;padding:12px 12px 24px 12px;border-radius: 24rpx;">
					<view style="border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;">
						<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
							{{ipoInfo.name}}
						</view>
						<view style="font-size: 28rpx;font-weight: 700;color: #121212;padding:4px 40px;">
							{{ipoInfo.code}}
						</view>

						<view style="font-size: 32rpx;padding:2px;line-height: 1.6;">
							Congratulations on winning the allotment of <text
								style="font-weight: 700;color:#109E58;font-size: 48rpx;">
								{{$util.formatNumber(ipoInfo.success)}}</text> shares.
						</view>
						<view style="font-size: 32rpx;padding:2px;line-height: 1.6;">
							The amount payable is <text
								style="font-weight: 700;color:#109E58;font-size: 48rpx;">{{$util.formatNumber(ipoInfo.total)}}</text>.
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-around;margin-top: 40rpx;">
							<view class="common_btn btn_primary"
								style="color:#FFF;padding:0 48rpx;border:1px solid #109E58;" @click="handleCloseIPO()">
								Cancel</view>

							<view class="common_btn btn_secondary" style="color:#109E58;padding:0 48rpx;"
								@click="linkIPOSuccessLog()">Details</view>
						</view>
					</view>
				</view>
			</view>

			<!-- <view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
				<view class="bg_ad" style="">

				</view>
			</view> -->
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				list: [],
				listTitles: ['BANKEX', 'S&P BSE 100', 'Next 50'],
				// isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.11
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
				isShowIPO: false, //
				ipoInfo: {},
				news: {},
				text1: ['Trade Smart, Trade Secure with ABMLIC!',
					'Your Gateway to Seamless Trading!',
					'Empowering Traders with Real-Time Insights!',
					'Unlock Your Trading Potential with ABMLIC!',
					'Navigate the Market with Confidence!',
					'Stay Ahead with Custom Alerts and Insights!',
					'Join a Community of Expert Traders Today!',
				],
				list1: [
				          "/static/news_banner.png",
				          "/static/wo_bgtu.png",
				          "/static/dazong.png",
				        ],
			}
		},

		onLoad() {},

		onShow() {
			this.ipoSuccess();
			this.getDataList();
			this.get_news()
			this.startTimer();
			if (this.$refs.goods) {
				// this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			open(url) {
				window.open(url, '_blank')

			},
			async get_news() {

				let list = await this.$http.post('api/goods/get_news', {
					current: 0
				})
				this.news = list.data.data
			},
			// 弹层关闭
			handleCloseIPO() {
				this.isShowIPO = false;

			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
				// if (this.info.type == 1) {
				// 	uni.navigateTo({
				// 		url: this.$paths.TRADE_IPO + `?type=2`,
				// 	})
				// } else {
				// 	uni.navigateTo({
				// 		url: '/pages/trade/large/record',
				// 	})
				// }
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get(`api/goods-shengou/tanchuang`);
				console.log(result);
				if (result.data.code == 0 && result.data.data) {
					const temp = Array.isArray(result.data.data) ? result.data.data[0] : result.data.data;
					this.ipoInfo = {
						code: temp.goods.code,
						name: temp.goods.name,
						success: temp.success,
						total: temp.success_num_amount,
					};
					this.isShowIPO = true;
				}
			},

			// 按钮组，点击大宗交易
			linkLarge(val) {
				// console.log('linkLarge:', val);
				// this.largePath = val;
				// this.isShow = true;

				uni.navigateTo({
					url: "/pages/trade/large"
				});
				return
			},

			// // 弹层取消按钮事件
			// handleCancel() {
			// 	this.isShow = false;
			// },
			// 弹层确认按钮事件
			async handleConfirm() {

				// 判断输入密码不为空。后端对比密码，返回结果
				if (this.isShow && this.password == '') {
					uni.showToast({
						title: 'Please Enter Password',
						icon: 'none'
					});
					return false;
				}

				// 获取后台设置的大宗查看密码
				const result = await this.$http.get(`api/app/config`);
				console.log(result.data);
				if (result && result.data.code == 0) {
					const temp = Object.values(result.data.data).reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());

					console.log(temp.get('big_pwd'));
					// 根据返回结果，处理是否跳转到大宗交易
					if (this.isShow && this.password == temp.get('big_pwd')) {
						this.isShow = false;
						uni.navigateTo({
							url: this.largePath
						});
						return false;
					}
					uni.showToast({
						title: 'The password you entered is incorrect',
						icon: 'none'
					});
				} else {
					uni.showToast({
						title: result.data.message,
						icon: 'none'
					});
				}
			},
			yhingj() {
				uni.navigateTo({
					url: '/pages/market/overview'
				})
			},
			huasheng() {
				uni.navigateTo({
					url: '/pages/market/news'
				})
			},
			zuishenc() {
				uni.navigateTo({
					url: '/pages/search'
				})
			},
			pioanuhd() {
				uni.navigateTo({
					url: '/pages/trade/large'
				})
			},
			yangtcjsw() {
				uni.navigateTo({
					url: '/pages/trade/ipo'
				})
			},

			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.getDataList();
					// this.$refs.goods.getList();
				}, 10000);
			},
			// 指数数据
			async getDataList() {
				const result = await this.$http.post('api/goods/zhishu', {})
				if (result.data.code == 0) {
					this.list = result.data.data && result.data.data.length > 3 ? result.data.data.slice(0, 3) : result
						.data.data;
					// console.log(this.list);
				}
			},
			// 银转证
			async silver() {
				this.kefu()
			},
			async kefu() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				let url = list.data.data[8].value

				// window.open(this.list, '_blank');
				if (window.android) {
					window.android.callAndroid("open," + url)
					return;
				}
				if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
					.nativeExt) {
					window.webkit.messageHandlers.nativeExt.postMessage({
						msg: 'open,' + url
					})
					return;
				}

				var u = navigator.userAgent;
				var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
				if (isiOS) {
					window.location.href = url;
					return;
				}
				window.open(url)

			},
		},
	}
</script>

<style lang="scss" scoped>
	view,
	text {
		box-sizing: border-box;
	}

	// .mask {
	// 	background-color: rgba(0, 0, 0, 0.35);
	// 	position: fixed;
	// 	top: 0;
	// 	left: 0;
	// 	width: 100vw;
	// 	height: 100vh;
	// 	z-index: 999;
	// }

	// .bg_ad {
	// 	background-image: url(/static/bg_ipo.png);
	// 	background-size: cover;
	// 	background-position: center;
	// 	background-repeat: no-repeat;
	// 	min-height: 800rpx;
	// 	width: 80vw;
	// 	display: flex;
	// 	flex-direction: column;
	// 	align-items: center;
	// 	justify-content: center;
	// 	border-radius: 20px;
	// 	padding: 20px 0;
	// }

	.green {
		color: #3AC290;
	}

	.red {
		color: #EA393F;
	}

	.list {
		padding: 10px;

		.item {
			margin-bottom: 16px;

			.img {
				width: 120px;
				height: 80px;
				margin-right: 10px;
				border-radius: 5px;

				image {
					width: 100%;
					height: 100%;
					border-radius: 5px;
				}
			}

			.t {
				color: #333;
			}

			.t1 {
				color: #999;
				margin-top: 10px;
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 2;
				overflow: hidden;
				text-overflow: ellipsis;
				white-space: normal;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #014b8d;

			span {
				background: #014b8d;
			}
		}
	}
</style>