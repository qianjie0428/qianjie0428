<template>
	<view>
		<view class="common_header"
			style="gap: 12px; background-image: url(/static/diwen.png); background-size: 40% 100%; background-repeat: no-repeat; background-color: #27285e; height: 40px;">
			<view class="custom_header_left" @click="handleBack()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 20px; height: 20px;"></image>
			</view>
			<text class="custom_header_center" style="color: #fff;">NEWS</text>
		</view>
		<view class="container">
			<!-- 使用 currentUrl 作为 web-view 的 src -->
			<web-view :src="currentUrl"></web-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				currentUrl: '' // 用于存储从路由参数传入的 URL
			}
		},
		onLoad(options) {
			// 检查是否有传入 url 参数，并解码后存入 currentUrl
			if (options.url) {
				this.currentUrl = decodeURIComponent(options.url);
			} 
		},
		methods: {
			handleBack() {
				uni.navigateTo({
					url: '/pages/stock/news'
				});
			}
		}
	}
</script>

<style>
	.container {
		width: 100%;
		height: calc(100% - 40px);
		/* 根据 header 高度调整 */
	}
</style>