<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader :title="$lang.SEARCH" @action="$u.route({type:'navigateBack'});" style="height: 70px;"></CustomHeader>
		</view>
		<view style="margin:20px; background-color:rgba(255, 255, 255, 0.75);">
			<u-search shape="square" placeholder="Item code search" v-model="keyword" :showAction="false" height="40px"
				:searchIconColor="$util.THEME.PRIMARY" searchIconSize="30" bgColor="" @clear="keyword=''"
				:actionText="$lang.SEARCH" @search="searchButton" @custom="searchButton"
				@change="searchButton"></u-search>
		</view>

		<view class="common_block" style="margin:10px;">
			<view class="flex padding-top-10 padding-bottom-10">
				<view class="margin-left-10" :style="{color:$util.THEME.TIP}">Search History</view>
			</view>

			<view class="box" style="border-radius: 10px; " v-if="searchList">
				<view class="top flex flex-b padding-10">
					<view class="font-size-16" style="flex:50%;">Stock </view>
					<!-- <view class="flex-1 t-r"></view> -->
					<view class="font-size-16" style="flex:45%;text-align: center;">price</view>
					<view class="font-size-16" style="margin-left: 10px;flex:5%;">recent</view>
				</view>

				<u-gap height="2" bgColor="#bbb" marginTop="10px" marginBottom="10px"></u-gap>

				<view class=" box-item flex flex-b" v-for="(item,index) in searchList"
					style="padding:2px;margin: 10px 0;"
					@click="$u.route($util.PAGE_URL.STOCK_OVERVIEW,{code:item.number_code,id:item.id,type:item.project_type_id});">
					<view class="list-name flex-2 font-size-16">
						<view class="list-name-txt ">
							<span style="padding: 3px;margin-right: 2px;color:#3779CD;">{{item.locate}}</span>
							<!-- <span style="background-color: #489ce5;color: #fff;padding: 3px;margin-right: 2px;">{{item.number_code}}</span> -->
							{{item.name}}
						</view>
					</view>
					<view class="flex-1 t-c num-font" :class="item.rate>0?'red':'green'">
						{{$util.formatNumber(item.current_price,2)}}
					</view>
					<view class="per t-r color-white" :class="item.rate>0?'bg-red':'bg-green'" style="width:80px;">
						{{item.rate>0?'+':''}}{{item.rate}}%
					</view>
					<view class="flex justify-end" style="margin-left: 10px;" :class="item.rate>0?'red':'green'">
						<view class="icon yzx " @click="handleClickDelProduct(item.gid)"></view>
					</view>
				</view>
			</view>
			<view style="width: 60%;margin-left: 20%;margin-top: 30%; margin-bottom: 20%;" v-if="!searchList">
				<u-image src="/static/search_result.png" width="100%" mode="widthFix"></u-image>
				<view class="font-size-20 text-center padding-bottom-30" :style="{color:$util.THEME.LABEL}">no record
				</view>
			</view>
		</view>
	</view>
</template>
<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				searchList: '',
				pager: {
					page: 1,
					limit: 20
				},
				keyword: "",
				keywords: [],
				gp_select: [{
					name: "domestic",
				}, {
					name: "Overseas",
				}],
				gp_index: 0,
			};
		},
		onReachBottom() {
			this.status = 'loading';
			this.pager.page++;
			this.searchButton()
		},
		onLoad() {
			let keywords = uni.getStorageSync("keywords")
			if (keywords) {
				this.keywords = keywords
			}
			console.log(this.keywords)
		},
		methods: {
			gp_select_click(e) {
				this.storehouse = ""
				this.gp_index = e.index
			},
			dianji(keyword) {
				this.keyword = keyword;
				this.searchButton()
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},

			//搜索
			async searchButton() {
				if (this.keyword == '') {
					uni.$u.toast('Search term cannot be empty. Please search again');
					return false;
				}
				uni.showLoading({
					title: "loading...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/product/list', {
					key: this.keyword,
					page: 1,
					limit: 9999999,
					gp_index: this.gp_index
				})
				this.searchList = list.data.data
				console.log(8888, list.data.data)
				uni.hideLoading();
				if (list.data.data.length > 0) {
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
		}
	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		min-height: 100vh;
		background-color: #F3F4F8;
	}

	.home {
		background-image: url(/static/chuanggai/home-top.png);
		/* 背景图片覆盖整个容器，可能会裁剪 */
		background-size: cover;
		/* 让背景图片始终位于容器的中心 */
		background-position: center;
		/* 不重复背景图片 */
		background-repeat: no-repeat;
		height: 600rpx;
		margin-left: -10px;
	}
</style>