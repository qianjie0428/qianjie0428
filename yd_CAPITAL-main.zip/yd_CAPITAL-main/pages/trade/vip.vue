<template>
	<!-- vip -->
	<view>
		<view class="common_header" style="background-image: url(/static/diwen.png);background-size: contain;background-size: 40% 100%;background-repeat: no-repeat;background-color: #27285e;height: 40px;">
			<view class="custom_header_left" @click="fanhui()">
				<image src="/static/fanhui.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
			</view>
			<text class="custom_header_center" style="color: #fff;">Institutional Stock</text>
		</view>
		<view class="science" v-for="(item,index) in funding" :key="index">
			<view class="display" style="margin: 20rpx 0;">
				<view style="flex: 30%;">
					<view class="corporation">{{item.goods.name}}</view>
					<!-- <view class="area" v-if="item.goods.locate=='깊은'">
						<view class="deep">{{item.goods.locate}}</view>
						<view class="deep-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='북쪽'">
						<view class="north">{{item.goods.locate}}</view>
						<view class="north-number">{{item.goods.code}}</view>
					</view>
					<view class="area" v-if="item.goods.locate=='상하이'">
						<view class="shanghai">{{item.goods.locate}}</view>
						<view class="shanghai-number">{{item.goods.code}}</view>
					</view> -->
				</view>
				<view class="price" style="flex: 20%;text-align: center;">
					{{item.goods.current_price}}
				</view>
				<!-- <view class="price" style="flex: 10%;">
					{{item.goods.rate}}%

				</view> -->
				<view class="detailed" @tap="goBuy(item)">
					Buy
				</view>
			</view>
		</view>



	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				funding: ''
			}
		},
		methods: {
			//去到购买
			goBuy(item) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/placeOrder/placeOrder' +
						`?item=${encodeURIComponent(JSON.stringify(item))}`

				});
				// console.log(item, '=========抛出去');
			},
			fanhui(){
				uni.switchTab({
					url:'/pages/home'
				})
			},
			//列表
			async scramble(item) {
				let list = await this.$http.get('api/goods/goodsvipscramble', {
					page: 1,
					limit: 500,
				})
				this.funding = list.data.data
			},
		},
		mounted() {
			this.scramble()
		},
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: center;
			align-items: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;

			.up-down {
				width: 40%;
				display: flex;
				justify-content: space-between;
				align-items: center;
			}

			.name {
				width: 30%;
			}

			.price {
				width: 100%;
			}

			.downRange {
				width: 100%;
			}

		}

	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #333;

		}

		.price {
			color: #f85252;
			font-size: 26rpx;
		}

		.detailed {
			background-image: linear-gradient(to right, #1a73e8, #01B4D5);
			color: #fff;
			border-radius: 40rpx;
			padding: 6rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}
	}
</style>