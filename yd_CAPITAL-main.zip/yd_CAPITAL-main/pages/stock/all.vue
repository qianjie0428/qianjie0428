<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader :title="$lang.STOCK_OVERVIEW" @action="handleBack()"></CustomHeader>
		</view>

		<GoodsList ref="goodsAll"></GoodsList>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onLoad(option) {
			console.log(option);
			// this.current = Number(option.index) || 0;
		},
		onShow() {
			this.startTimer();
			if (this.$refs.goodsAll) {
				this.$refs.goodsAll.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					this.$refs.goodsAll.getList();
				}, 3000);
			},
		},
	}
</script>