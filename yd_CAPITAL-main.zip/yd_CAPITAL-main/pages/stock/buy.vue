<!-- 下单 -->
<template>
	<view>
		<!-- <view class="header_wrapper_10">
			<CustomHeader :title="!productDetails?'':productDetails.name" @action="handleBack()"></CustomHeader>
		</view>
		
		 -->
		<view style="background-color: #27285e;width: 100%;">
			<image src="/static/diwen.png" mode="heightFix" style="height: 70px;"></image>
			
			<view class="padding-20" style="position: absolute;top: 10px;width: 90%;">
				<view class="flex flex-b">
					<view @click="$util.goBack()">
						<image src="/static/fanhui.png" mode="widthFix" style="width: 20px;height: 20px;"></image>
					</view>
					<view class="color-white font-size-16" >{{!productDetails?'':productDetails.name}}</view>
					<view class="flex gap10">
						<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;" @click="$u.route({url:$util.PAGE_URL.SEARCH});"></image>
						<image src="/static/service.png" mode="widthFix" style="width: 20px;height: 20px;" @click="kefu()"></image>
					</view>
				</view>
				
			</view>
			
		</view>
		
		
		<view style="background-image: url(/static/stock_bg.png),linear-gradient(to right, #fff, #FFF4EC);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;padding: 20px;height: 140px;">
			<template v-if="productDetails">
				<view class="flex flex-b" >
					<view class="flex align-center">
						<!-- <image :src="getlogo()" mode="aspectFit" :style="$util.calcImageSize(50)" style="border-radius: 100px;"></image> -->
						<view>
							<view class="text-center bold" style="font-size: 16px;">{{productDetails.name}}</view>
							<view class="hui1"> {{productDetails.project_type_id==1?"NSE":"BSE"}}
								{{productDetails.number_code}}
							</view>
						</view>
					</view>
				
					<image :src="`/static/${productDetails.is_collected==1?'star1':'star'}.png`"
						:style="$util.calcImageSize(16)" @click="handleClickDelProduct(productDetails.gid)"></image>
				</view>
				<view
					:style="$util.calcStyleRiseFall(productDetails.rate>0)">
					<view style="font-size: 26px; font-weight: 700;margin-top: 10px;">
						{{$util.formatNumber(productDetails.current_price,2)}}
					</view>
					<view class="flex">
						<view style="font-size: 16px;">
							{{$util.formatNumber(productDetails.rate_num,2)}}
						</view>
						<view style="font-size: 16px;margin-left: 30px;" :style="{color:$util.calcStyleRiseFall(productDetails.rate>0)}">
							{{$util.formatNumber(productDetails.rate,2)}}%
						</view>
					</view>
					
				</view>
				
				<view class="flex flex-b gap10 margin-top-10">
					<view class="flex flex-b flex-1">
						<view style="color: #909092;">OPEN</view>
						<view>{{productDetails.data.open}}</view>
					</view>
					<view class="flex flex-b flex-1">
						<view style="color: #909092;">Previous Close</view>
						<view>{{productDetails.data.close}}</view>
					</view>
				</view>	
				<view class="flex flex-b gap10 margin-top-10">
					<view class="flex flex-b flex-1">
						<view style="color: #909092;">HIGH</view>
						<view>{{productDetails.data.high}}</view>
					</view>
					<view class="flex flex-b flex-1">
						<view style="color: #909092;">LOW</view>
						<view>{{productDetails.data.low}}</view>
					</view>
				</view>	
				
			</template>
		</view>
		

		<template v-if="productDetails">
			<view class="common_block" style="padding:10px;">
				
				<view class="margin-top-20" :style="{color:$util.THEME.TIP}">Quantity</view>

				<view class="btns">
					<block v-for="(item,index) in quantityList" :key="index">
						<view class="item" style="flex:30%;margin:4px;" :class="curQuantity==item?'actity':'noactity'"
							@click="handleSelected(item)">{{item}}</view>
					</block>
				</view>

				<view style="margin-bottom: 10px;">
					<u--input v-model="quantity" type="number" placeholder="Please Enter Quantity" @input="handleInput"></u--input>
				</view>

				<!-- 若后台开启杠杆，此处条件成立，页面会显示杠杠选择 -->
				<!-- <template v-if="userInfo.ganggan">
				<view class="margin-top-20" :style="{color:$util.THEME.TIP}">
					Choose your leverage
				</view>
				<view class="margin-top-10 text-center">
					<u-grid :border="false" col="3">
						<u-grid-item v-for="(item,index) in userInfo.ganggan">
							<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
								{{item}}
							</view>
						</u-grid-item>
					</u-grid>
				</view>
			</template> -->




				<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
					<view class="flex-1">Credit</view>
					<view class="flex-1 text-right">₹{{$util.formatNumber(userInfo.money)}}
					</view>
				</view>

				<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
					<view class="flex-1">Amount of payment</view>
					<view class="flex-1 text-right"><text
			v-if="productDetails.project_type_id==2"></text>{{productDetails.current_price*this.quantity|addZero}}
					</view>
				</view>
				<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
					<view class="flex-1">Charge</view>
					<view class="flex-2 text-right"><text
		v-if="productDetails.project_type_id==2"></text>{{productDetails.current_price*this.quantity*fee|addZero}}
					</view>
				</view>
			</view>

			<view style="background-color: #16a139;text-align: center;padding: 10px;color: #fff;border-radius: 5px;margin: 15px;" @click="placeOrder()">
				Order
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				quantityList: [100, 150, 200, 300, 400, 500], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				show: false,
				quantity: 100,
				productDetails: null,
				// ganggan: 1,
				userInfo: null,
				fee: 0.01,
				code: '',
				type:1
			};
		},

		onLoad(option) {
			this.code = option.code || this.code;
			this.type = option.type
		},
		onShow() {
			this.getUserInfo();
			this.product();
			this.getconfig();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleSelected(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},

			// 获取配置
			async getconfig() {
				const result = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				console.log(result);
				console.log(result.data.data);

				if (result.data.code == 0) {
					const temp = result.data.data;
					let map = new Map();
					for (let obj in temp) {
						if (temp.hasOwnProperty(obj)) {
							map.set(temp[obj].key, temp[obj].value);
						}
					}
					this.fee = map.get('TransRate') || this.fee || 0.01;

					// const temp = result.data.data.reduce((map, item) => {
					// 	map.set(item.key, item.value);
					// 	return map;
					// }, new Map());
					// this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async product() {
				const result = await this.$http.get('api/product/info', {
					code: this.code,
					type: this.type
				})
				console.log(`result111:`, result);
				if (result.data.code == 0) {
					this.productDetails = result.data.data[0]
				}
			},
			//购买
			placeOrder() {
				// if (this.quantity < 100) {
				// 	uni.$u.toast('Minimum value 100');
				// 	return false;
				// }

				const _this = this;
				let money = this.$util.formatNumber(this.productDetails.current_price * this.quantity * 1);
				uni.showModal({
					title: "Do you want to Executed Orders ? ",
					// content: this.productDetails.name + ' ' + this.quantity.toString().replace(
					// 	/\B(?=(\d{3})+(?!\d))/g, ",") + "Weekly payment amount " + money + "one",
					cancelText: "Cancel", // 取消按钮的文字
					confirmText: "Execute", // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#39B54A',
					cancelColor: '#f55850',
					success: (res) => {
						if (res.confirm) {
							console.log('comfirm') //点击确定之后执行的代码
							_this.buy()
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})


			},
			async buy() {
				uni.showLoading({
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity || 0,
					gid: this.productDetails.gid,
					price: this.productDetails.current_price,
					// ganggan: this.ganggan,
				});
				uni.hideLoading();

				if (result.data.code == 0) {
					uni.$u.toast(result.data.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//实名认证
			async getUserInfo() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				console.log('result:', result);
				this.userInfo = result.data.data;
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #27285e;
		color: #fff;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>