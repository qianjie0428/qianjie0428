# in_fdl
fork yindu5

![LOGO](https://github.com/github1413/in_fdl/raw/main/static/logo.png)

nse用ncode   bse用bcode
或者就是project_type_id=1用ncode   2就是bcode

```TODO
前端需要改的内容如下
大宗可以输入金额提交，而不是一键提交
新股在申购中签记录里，可以认缴金额

api/user/renjiao  印度CAP 新股手动认缴接口
```

[](https://mobile.capitalapp.top/chatlink.html?agentid=c475ccdb331545b6e15a849f9c175edf&language=en)
