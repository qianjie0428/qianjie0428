<template>
	<view class="tooltip">
		<slot></slot>
		<view class="tooltip-popup" :style="{display:status?`block`:`none` }">
			<slot name="content">
				{{content}}
			</slot>
		</view>
	</view>
</template>

<script>
	/**
	 * 提示文字
	 * @description 常用于展示鼠标 hover click 时的提示信息。
	 * @property {String} content   弹出层显示的内容
	 * @property {String}  placement出现位置, 
	 */
	export default {
		name: "Tooltip",
		props: {
			content: {
				type: [String, Number],
				default: ''
			},

			placement: {
				type: String,
				default: 'top'
			},
			status: {
				type: Boolean,
				default: false,
			}
		},
		data() {
			return {};
		},
		beforeMount() {
			// console.log(this.status);
		},
		methods: {}
	}
</script>

<style>
	.tooltip {
		position: relative;
		cursor: pointer;
	}

	.tooltip-popup {
		z-index: 1;
		display: none;
		position: absolute;
		top: -54px;
		bottom: 36px;
		left: -14px;
		right: -16px;
		background-color: #3bcec6;
		border-radius: 4px;
		color: #000;
		font-size: 28px;
		text-align: center;
		line-height: 46px;
		padding: 0;
		font-weight: 500 !important;
	}


	.tooltip:hover .tooltip-popup {
		display: block;
	}
</style>