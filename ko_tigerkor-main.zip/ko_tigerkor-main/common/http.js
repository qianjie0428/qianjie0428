import Vue from 'vue';
import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import md5 from '@/common/md5.min.js';
import * as fmt from '@/intl/index.js';
import {
	Msg,
} from '@/localize/index.js';

// import * as mock from '@/common/mock.js';

// export const HOST = `api.capitalgrou.top`.trim();
// export const HOST = `api.lgpstock.top`.trim();
export const HOST = `api.tigerkor.top`.trim();

export const BASE_URL = `https://${HOST}`.trim();
export const WS_OTHER_URL = `wss://${HOST}/zonghe`.trim(); // 币

const CODE = "Qwd3N5yp";

// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;
		return true;
	} catch (err) {
		throw err
	}
}

export async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();
	if (!result) {
		return {
			message: Msg.API_NETWORKNO
		};
	} else {
		// console.log('url:', url, 'params:', params);
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": fmt.getLgre(),
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();
		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);
		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}?sign=${mdd}&t=${time}`;
		try {
			const response = await uni.request({
				url: `${fmtAPIURL}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});
			uni.hideLoading();
			const [err, res] = response;
			// console.log('err:', err, 'res:', res);

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					uni.removeStorageSync('token'); // 只移除token的缓存
					uni.showToast({
						title: Msg.API_TOKEN_EXPIRES,
						icon: 'none'
					})
					setTimeout(() => {
						linkTo.signin();
					}, 1000);
					return null;
				}
				// console.log('res:', res);
				// console.log('res.data:', res.data);
				if (res.data) {
					// console.log('res.data:', res.data);
					if (res.data.code == 0) {
						// console.log('res.data.data:', res.data.data);
						return res.data.data || null;

					} else {
						uni.showToast({
							title: !res.data.message ? res.message : res.data.message,
							icon: 'none'
						})
						return null;
					}
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: err.errMsg || Msg.API_HTTP_ERROR,
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
export const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

export const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}


// 图片上传
export async function uploadImage(val) {
	// console.log(val)
	uni.showLoading({
		title: Msg.API_UPLOAD,
	})
	let Request = "Qwd3N5yp"
	let time = parseInt(new Date().getTime() / 1000)
	let str_url = ("/api/app/upload").toLowerCase()
	let mdd = md5("XPFXMedS" + Request + str_url + time);

	const result = await uni.uploadFile({
		url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
		filePath: val,
		name: 'file',
	});
	// console.log('result:', result);
	uni.hideLoading();
	if (result[1].statusCode == 200) {
		const temp = JSON.parse(result[1].data);
		// console.log('temp:', temp);
		// this.obverseUrl = temp[0].url;
		return temp[0].url;
	} else {
		return null;
	}
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('addInterceptor', requestConfig);
	}
});

// 获取客服链接
export const getServiceURL = async () => {
	// 默认客服链接。用于无token时。（开发完成向客户索取）
	let url = ``;
	linkTo.isAuth();
	const result = await get(`api/app/config`);
	if (!result) return url;
	const temp = result.reduce((map, v) => {
		map.set(v.key, v.value);
		return map;
	}, new Map());
	return !temp.get('CustomerLink') ? url : temp.get('CustomerLink');
}

// 完整账户信息
export const getAccount = async () => {
	const result = await get(`api/user/info`);
	if (!result) return false;
	return result;
}

// 精简账户信息
export const getFastInfo = async () => {
	const result = await get(`api/user/fastInfo`);
	if (!result) return false;
	return result;
}

// 获取配置
export const getConfig = async () => {
	const result = await get(`api/app/config`);
	console.log(`config result:`, result);
	const temp = result.reduce((map, v) => {
		map.set(v.key, v.value);
		return map;
	}, new Map());
	return temp;
}

export const getIPOAlert = async () => {
	const result = await get(`api/goods-shengou/tanchuang`);
	if (!result) return null;
	console.log(result);
	if (result.length <= 0) return null;
	return {
		code: result[0].goods.code,
		name: result[0].goods.name,
		success: result[0].success,
		price: result[0].price,
		total: result[0].success_num_amount,
	}
}

export const getStocks = async (val = 0) => {
	const result = await get(`api/goods/list`, {
		// current: 0,
		gp_index: val,
	});
	if (!result) return null;
	const temp = result.filter(v => v.stock_id > 0 || v.gid > 0);
	const objData = {};
	!temp || temp.length <= 0 ? null : temp.forEach(v => {
		const isKR = val == 1;
		const lgre = isKR ? fmt.code.KEY_KR : fmt.code.KEY_US;
		objData[`${isKR ? v.stock_id : v.gid}`] = {
			pid: v.pid || 0,
			gid: isKR ? v.stock_id : v.gid,
			name: isKR ? v.ko_name : v.name,
			code: v.code,
			logo: v.logo,
			price: isKR ? (v.close * 1 || 0) : (v.current_price * 1 || 0),
			rate: isKR ? v.returns : v.rate,
			rateNum: v.rate_num * 1 || 0,
			industry: v.industry || '',
			lgre: lgre,
			track: v.sc,
		};
	});
	return objData;
};

export const getIndicators = async (val = 0) => {
	const result = await get(`api/goods/zhibiao`, {
		current: val
	});
	if (!result) return null;
	const temp = Object.values(result).filter(v => v.stock_id > 0);
	const objData = {};
	!temp || temp.length <= 0 ? null : temp.forEach(v => {
		const lgre = val == 0 || val == 1 ? fmt.code.KEY_KR : fmt.code.KEY_US;
		objData[`${v.stock_id}`] = {
			// pid: v.pid || 0,
			gid: v.stock_id,
			name: v.ko_name,
			code: v.code.toUpperCase(),
			logo: v.logo,
			open: fmt.numer(v.open * 1, Vue.prototype.$decimal) || 0,
			close: fmt.numer(v.close * 1, Vue.prototype.$decimal) || 0,
			high: fmt.numer(v.high * 1, Vue.prototype.$decimal) || 0,
			low: fmt.numer(v.low * 1, Vue.prototype.$decimal) || 0,
			// rate: v.rate * 1 || 0,
			rateNum: v.returns * 1 || 0,
			lgre: lgre,
			track: v.is_collected == 1,
		};
	});
	return objData;
}

export const getRanking = async (val = 0) => {
	const result = await get(`api/goods/paihang`, {
		current: val
	});
	console.log(result);
	if (!result) return null;
	const temp = result.filter(v => v.gid > 0);
	const objData = {};
	!temp || temp.length <= 0 ? null : temp.forEach(v => {
		// const type = v.project_type_id;
		objData[`${v.gid}`] = {
			// pid: v.pid,
			gid: v.gid,
			name: v.ko_name,
			code: v.code.toUpperCase(),
			logo: v.logo,
			close: v.close * 1 || 0,
			rateNum: v.returns * 1 || 0,
			industry: v.industry || '',
			lgre: fmt.code.KEY_KR,
			track: v.sc,
		};
	});
	return objData;
}

export const getTrack = async (val = 0) => {
	uni.showLoading({
		title: Msg.API_REQUEST_DATA,
	})
	const result = await get(`api/user/collect_list`, {
		current: val
	});
	if (!result || !result.list || result.list.length <= 0) return false;
	console.log(result);
	const temp = result.list.filter(v => v.gid > 0);
	const objData = {};
	!temp || temp.length <= 0 ? null : temp.forEach(v => {
		const type = v.goods.project_type_id;
		const lgre = type == 1 ? fmt.code.KEY_KR : fmt.code.KEY_US;
		objData[`${v.goods.gid}`] = {
			// pid: v.goods.pid,
			gid: v.goods.gid,
			name: v.goods.name,
			code: v.goods.code,
			rate: v.goods.rate * 1 || 0,
			price: v.goods.current_price * 1 || 0,
			rateNum: v.goods.rate_num * 1 || 0,
			type: type,
			lgre: lgre,
			track: v.goods.is_collected == 1 || true
		};
	});
	return objData;
}

export const postTrack = async (val = '') => {
	uni.showLoading({
		title: Msg.API_SUBMITING,
	});
	const result = await post(`api/user/collect_edit`, {
		gid: val,
	});
	if (!result) return false;
	return result;
}

export const getTop = async (val = '', id = "") => {
	const temp = !id || id == '' || id <= 0 ? [141, 144, 16709][val] : id;

	const result = await get(`api/goods/top1`, {
		current1: val, // 0  1  2
		stockid: temp, // stockId: 141, 144 , 16709
	});
	console.log(`getTop:`, result);
	if (!result) return null;
	const tempTop1 = Object.values(result.top1).filter(v => v.stock_id > 0);
	const objTop1 = {};
	const top1Name = {
		17470: "코스피 200",
		255: "코스피",
		141: "코스닥",
		157: "다우",
		155: "S&P500",
		144: "나스닥",
		16709: "비트코인",
		16710: "이더리움",
		16714: "리플",
	};
	!tempTop1 || tempTop1.length <= 0 ? null : tempTop1.forEach(v => {
		const type = v.project_type_id;
		objTop1[`${v.stock_id}`] = {
			// pid: v.pid,
			gid: v.stock_id,
			name: top1Name[v.stock_id],
			code: v.code.toUpperCase(),
			rate: v.rate * 1 || 0,
			price: v.close,
			// rateNum: v.rate_num * 1 || 0,
			// line: true,
			// type: type,
			// track: v.is_collected == 1 || true,
			// lgre: tmpLgre[type]
		}
	});
	const tempArticle = result.article.map(v => {
		return {
			title: v.title,
			titleSub: v.sum_title,
			url: v.url,
			pic: v.pic,
			dt: v.created_at
		}
	});
	return {
		tops: objTop1,
		article: tempArticle,
		industry: result.bottom,
		chart: result.kline,
	}
}

export const getTop2 = async (val = '') => {
	const result = await get('api/goods/top2', {
		current: val
	})
	if (!result) return false;
	console.log(result);
	const temp = result.filter(v => v.gid > 0);
	const objData = {};
	!temp || temp.length <= 0 ? null : temp.forEach(v => {
		const lgre = v.project_type_id == 1 ? fmt.code.KEY_KR : fmt.code.KEY_US;
		objData[`${v.gid}`] = {
			// pid: v.pid,
			gid: v.gid,
			stockId: v.stock_id,
			name: v.ko_name,
			code: v.code.toUpperCase(),
			logo: v.logo,
			price: v.close * 1 || 0,
			rate: v.returns * 1 || 0,
			// rateNum: v.net_vol_valued_foreigner_returns * 1 || 0,
			industry: v.industry || '',
			// type: type,
			lgre: fmt.code.KEY_KR,
			track: v.sc,
		};
	});
	console.log(objData);
	return objData;
}

export const getTop3 = async () => {
	const result = await get('api/goods/top3', {
		current: 0,
		current33: 0
	})
	if (!result) return false;
	console.log(result);
}

// export const getEAGoods = async () => {
// 	uni.showLoading({
// 		title: Msg.API_REQUEST_DATA,
// 	})
// 	const result = await get(`api/jijin/list`);
// 	if (!result) return false;
// 	console.log(result);
// 	const temp = !result || result.jj_list.filter(v => v.id && v.id > 0);
// 	return !temp || temp.length <= 0 ? [] : temp.map(v => {
// 		return {
// 			id: v.id,
// 			name: v.name,
// 			minAmount: v.min_price * 1 || 0,
// 			fudu: v.fudu * 1 || 0,
// 			syl: v.syl * 1 || 0,
// 			days: v.zhouqi * 1 || 0,
// 		}
// 	});
// }

// export const getEARecord = async () => {
// 	uni.showLoading({
// 		title: Msg.API_REQUEST_DATA,
// 	})
// 	const result = await get(`api/jijin/list`);
// 	if (!result) return null;
// 	console.log(result);
// 	const temp = !result || result.order.filter(v => v.id && v.id > 0);
// 	return !temp || temp.length <= 0 ? [] : temp.map(v => {
// 		return {
// 			id: v.id,
// 			name: v.goodname,
// 			price: v.price * 1 || 0,
// 			fudu: v.fudu * 1 || 0,
// 			syl: v.syl * 1 || 0,
// 			days: v.zhouqi * 1 || 0,
// 			sdt: v.time || '',
// 			edt: v.endtime || '',
// 			fee: v.shouxu_fee || 0,
// 		}
// 	});
// }