import * as http from '@/common/http.js';

// 页面URL 以及跳转函数
export const PAGES = `/pages/`; // pages 部分
export const LAUNCH = `launch/index`; // 启动页

export const checkToken = () => {
	return uni.getStorageSync('token') &&
		uni.getStorageSync('token').length > 0
}

/**
 * @function 鉴权跳转
 * @description 用于设置需要检查token的跳转，如onShow，linkTo
 */
export const isAuth = () => {
	if (!checkToken()) {
		signin();
		// return false;
	} else {
		return true;
	}
};

// 根据当前平台，执行回退方式
export const goBack = () => {
	/*#ifdef APP-PLUS*/
	uni.navigateBack({
		delta: 1
	});
	/*#endif*/

	/*#ifdef H5*/
	history.back();
	/*#endif*/
};

/*
跳转到客服：
	上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	正常模式：`line`(跳轉到外鏈頁面)，`第三方`(跳轉内頁)
*/
export const SERVICE = `service`; // 内联客服所需
export const service = async () => {
	// 上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	// uni.showToast({
	// 	title: ``,
	// 	icon: 'none'
	// });

	// 正常模式：`第三方`(跳轉内頁)
	// uni.navigateTo({
	// 	url: SERVICE
	// });

	// 正常模式：`line`(跳轉到外鏈頁面)
	const url = await http.getServiceURL(); // 获取客服链接
	console.log(url);
	if (!url) return false;
	if (window.android) {
		window.open(url)
		// window.android.callAndroid("open," + url)
		return false;
	}
	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
		.nativeExt) {
		window.webkit.messageHandlers.nativeExt.postMessage({
			msg: 'open,' + url
		})
		return false;
	}
	let u = navigator.userAgent;
	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if (isiOS) {
		window.location.href = url;
		return false;
	}
	window.open(url)

}

export const HOME = `home/index`; // 主页
export const home = () => {
	if (!isAuth()) return false;
	uni.reLaunch({
		url: PAGES + HOME,
	})
};

export const SIGN_IN = `signin/index`; // 登入
export const signin = () => {
	uni.reLaunch({
		url: PAGES + SIGN_IN
	})
};

export const SIGN_UP = `signup/index`; // 登入
export const signup = () => {
	uni.reLaunch({
		url: PAGES + SIGN_UP
	})
};

export const TERMS = `settings/terms`; // 用户隐私协议
export const terms = () => {
	uni.navigateTo({
		url: PAGES + TERMS,
	})
}

export const SETTINGS = `settings/index`; // 个人中心
export const settings = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SETTINGS,
	})
}

export const ABOUT = `settings/about`;
export const about = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + ABOUT,
	})
}

export const AUTH = `settings/auth`; // 实名认证
export const auth = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + AUTH,
	})
}

export const BANK = `settings/bank`; // 银行卡
export const bank = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + BANK,
	})
}

export const PASSWORD = `settings/password`; // 密码管理
export const pwd = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PASSWORD,
	})
}
export const pwdPay = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PASSWORD + `?tag=pay`,
	})
}

export const DEPOSIT = `settings/deposit`;
export const deposit = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + DEPOSIT,
	})
}

export const WITHDRAW = `settings/withdraw`;
export const withdraw = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + WITHDRAW,
	})
}

export const CONVERT = `settings/convert`;
export const convert = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + CONVERT,
	})
}

export const LOANS = `settings/loans`;
export const loans = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + LOANS,
	})
}

export const FUNDS = `settings/funds`;
export const funds = (val = '') => {
	console.log(val);
	if (!isAuth()) return false;
	val = val == '' ? 'record' : val;
	console.log(val)
	uni.navigateTo({
		url: PAGES + FUNDS + `?tag=${val}`,
	})
}

export const PROFILE = `settings/profile`;
export const profile = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PROFILE,
	})
}

export const NOTIFY = `settings/notify`;
export const notify = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + NOTIFY,
	})
}



export const OTC = `trade/otc/index`;
export const otc = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + OTC,
	})
}

export const IPO = `trade/ipo/index`;
export const ipo = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + IPO,
	})
}

export const SCR = `trade/scr/index`;
export const scr = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SCR,
	})
}

export const AI = `trade/ai/index`;
export const ai = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + AI,
	})
}

export const EA = `trade/ea/index`;
export const ea = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + EA,
	})
}

export const SEARCH = `markets/search`;
export const search = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SEARCH,
	})
}

export const MARKET = `markets/index`;
export const markets = (val = '') => {
	if (!isAuth()) return false;
	val = val != '' ? `?tag=${val}` : '';
	uni.navigateTo({
		url: PAGES + MARKET + val,
	})
}

export const NEWS = `markets/news`;
export const news = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + NEWS,
	})
}

export const STOCK_INDEX = `stock/index`;
export const stockDetail = (symbol, gid, tag = '') => {
	if (!isAuth()) return false;
	tag = tag != '' ? `&tag=${tag}` : '';
	uni.navigateTo({
		url: PAGES + STOCK_INDEX + `?symbol=${symbol}&gid=${gid}${tag}`,
	})
}

export const POSITION = `position/index`; // 持仓
export const position = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + POSITION,
	})
}

export const openNews = (val) => {
	window.open(val)
}