export const TRANSPARENT = `transparent`;
export const PRIMARY = `primary`;
export const SECOND = `second`;
export const PRIMARY_TXT = `primary_txt`;
export const SUCCESS = `success`;
export const ERROR = `error`;
export const WARN = `warn`;
export const INFO = `info`;
export const PRIMARY_RGBA = `primary-rgba`;
export const SUCCESS_RGBA = `success-rgba`;
export const ERROR_RGBA = `error-rgba`;
export const WARN_RGBA = `warn-rgba`;
export const INFO_RGBA = `info-rgba`;
export const FALL = `fall`;
export const FLAT = `flat`;
export const RISE = `rise`;
export const WHITE = `white`;
export const CANCEL = `cancel`;
// export const BLACK_10 = `black-10`;
// export const BLACK_30 = `black-30`;
// export const BLACK_70 = `black-70`;
// export const WHITE_30 = `white-30`;
// export const WHITE_70 = `white-70`;

export const fundsStatus = [PRIMARY_RGBA, SUCCESS_RGBA, ERROR_RGBA, ERROR_RGBA];
export const fundsStatusLabel = [PRIMARY, SUCCESS, ERROR, ERROR];

export const getColor = (val) => {
	const temp = Object.create(null);
	temp[TRANSPARENT] = `var(--${TRANSPARENT})`;
	temp[PRIMARY] = `var(--${PRIMARY})`;
	temp[SECOND] = `var(--${SECOND})`;
	temp[PRIMARY_TXT] = `var(--${PRIMARY_TXT})`;
	temp[SUCCESS] = `var(--${SUCCESS})`;
	temp[ERROR] = `var(--${ERROR})`;
	temp[WARN] = `var(--${WARN})`;
	temp[INFO] = `var(--${INFO})`;
	temp[PRIMARY_RGBA] = `var(--${PRIMARY_RGBA})`;
	temp[SUCCESS_RGBA] = `var(--${SUCCESS_RGBA})`;
	temp[ERROR_RGBA] = `var(--${ERROR_RGBA})`;
	temp[WARN_RGBA] = `var(--${WARN_RGBA})`;
	temp[INFO_RGBA] = `var(--${INFO_RGBA})`;
	temp[FALL] = `var(--${PRIMARY})`;
	temp[FLAT] = `var(--${INFO})`;
	temp[RISE] = `var(--${ERROR})`;
	temp[WHITE] = `var(--${WHITE})`;
	temp[CANCEL] = `var(--${INFO})`;

	// temp[BLACK_10] = `var(--${BLACK_10})`;
	// temp[BLACK_30] = `var(--${BLACK_30})`;
	// temp[BLACK_70] = `var(--${BLACK_70})`;
	// temp[WHITE_30] = `var(--${WHITE_30})`;
	// temp[WHITE_70] = `var(--${WHITE_70})`;
	// console.log(temp);
	return temp[val];
}

export const statusBG = [PRIMARY_RGBA, SUCCESS_RGBA, ERROR_RGBA, ERROR_RGBA];
export const statusLabel = [PRIMARY, SUCCESS, ERROR, ERROR];

export const statusStyle = (val = 0) => {
	return {
		backgroundColor: getColor(statusBG[val]),
		color: getColor(statusLabel[val]),
	}
}


/**
 * @function 涨跌值样式设置
 * @param {number} num 数值
 * @param {string} isbg 是否需要背景
 * @description 所有涨幅通用。[-1跌,0平,1涨]
 * @example
 */
export const setRiseFall = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const temp = [FALL, FLAT, RISE];
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	// console.log(temp[index + 1]);
	return getColor(temp[index + 1])
};

export const setRiseFallRGBA = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const temp = [PRIMARY_RGBA, TRANSPARENT, ERROR_RGBA];
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	// console.log(temp[index + 1]);
	return getColor(temp[index + 1])
};

// 渐变设置
export const linerGradient = (deg, from, to) => {
	return `linear-gradient(${deg}deg, ${from} ,${to})`
};

// export const TXT_UNACT = `#838B9C`;
// // checkbox 边框及勾选
// export const CHECKBOX_COLOR_ACTIVE = PRIMARY;
// export const CHECKBOX_LABEL_COLOR = '#1f212d'; // checkbox 文字
// export const TRANSPARENT = 'transparent'; // 使用父级元素颜色
// export const BASIC_LIGHT = `#F8F8F8`;
// export const BASIC_DARK = `#121212`;
// export const INPUT_BG = 'transparent'; // input背景
// export const INPUT_BORDER = '#6D41FF3A'; // input边框
// export const BTN_UNLOCK = `#FFFFFF`;
// export const BTN_LOCK = `#CCC`;

// 按钮或card元素的边框。
// export const BASIC_BORDER = `#EAECEF`;


// 设置按钮状态，避免重复点击
export const btnStatus = (val, bg) => {
	return {
		cursor: val ? 'not-allowed' : 'pointer',
		// Disabled color
		color: val ? BTN_LOCK : BTN_UNLOCK,
		backgroundColor: val ? convertRGBA(bg, 70) : bg
	};
}

// 设置图片尺寸（自定义size）
export const setImageSize = (w = 24, h = 0) => {
	const _h = h > 0 ? h : w;
	return {
		width: `${w}px`,
		// 若为设置h值，则视为高=宽
		height: `${_h}px`,
	};
};


// // 定义颜色数组
// export const colors = [
// 	PRIMARY,
// 	'#0ECB81',
// 	'#FF5722',
// 	'#3F51B5',
// 	'#9C27B0',
// 	'#FFC107',
// 	'#4CAF50',
// 	'#E91E63',
// 	'#FF9600',
// 	'#935EBD',
// 	'#2196F3',
// 	'#E11D74',
// 	'#01C5C4',
// ];

// // 随机一个颜色值作为无LOGO时的背景底色
// export const randomBGColor = () => {
// 	// 随机选择一个颜色
// 	const randomIndex = Math.floor(Math.random() * colors.length);
// 	return convertRGBA(colors[randomIndex], 80)
// }

// // 状态的颜色值
// export const colorStatus = [
// 	`#FF9000`,
// 	`#42BF86`,
// 	`#42BF86`,
// 	`#F20105`,
// ];

// export const flowStatus = [
// 	`#FF9000`,
// 	`#42BF86`,
// 	`#F20105`,
// 	`#F20105`,
// ]

// export const ipoStatus = [
// 	`#FF9000`,
// 	`#42BF86`,
// 	`#F20105`,
// ]