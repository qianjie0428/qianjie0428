import Vue from 'vue';
import * as keys from '@/intl/keys.js';
import * as fmt from '@/intl/index.js';

import enUS from './en-US.json';
import koKR from './ko-KR.json';

console.log(fmt);

export const messages = {
	[keys.KEY_US]: enUS,
	[keys.KEY_KR]: koKR,
}

export const Msg = Object.create(null);
// console.log(Msg);

/**
 * @function set current locale
 */
export const setLocale = (locale = Vue.prototype.$DEF_LGRE) => {
	locale = !locale ? fmt.getLgre() : locale;
	Object.keys(messages[locale]).forEach(function(k) {
		Msg[k] = messages[locale][k];
	});
	Vue.prototype.$msg = Msg;
	console.log(`setLocale msg:`, Vue.prototype.$msg);
}