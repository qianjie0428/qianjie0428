<template>
	<view>
		<template v-if="!list || list.length <= 0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_primary">
					<view class="flex_row_between" style="gap: 12px;width: 100%;padding-bottom: 4px; ">
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}
						</view>
						<text style="font-size: 13px;font-weight: 300;">({{v.code}})</text>
						<template v-if="curKey===$C.KEY_BUY">
							<view style="margin-left: auto;">
								<text class="btn_buy" @tap="buy(v)">{{$msg.OTC_BUY}}</text>
							</view>
						</template>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_PRICE}}</view>
						<view>{{$fmt.amount(v.price,v.lgre)}}</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_PRICE_LATEST}}</view>
						<view>{{$fmt.amount(v.current_price,v.lgre)}}</view>
					</view>

					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_RATE}}</view>
						<view :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.percent(v.rate)}}
						</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_RATE_NUM}}</view>
						<view :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.amount(v.rate_num,v.lgre)}}
						</view>
					</view>

					<template v-if="curKey===$C.KEY_BUY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_MIN}}</view>
							<view>{{$fmt.decimal(v.min_num)}}</view>
						</view>
					</template>

					<template v-if="curKey===$C.KEY_APPLY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_QTY}}</view>
							<view>{{$fmt.decimal(v.num)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_AMOUNT}}</view>
							<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.amount,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_PL}}</view>
							<view :style="{color:$theme.setRiseFall(v.pl)}">
								{{$fmt.amount(v.pl,v.lgre)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_PL_FLOAT}}</view>
							<view :style="{color:$theme.setRiseFall(v.floatPL)}">
								{{$fmt.amount(v.floatPL,v.lgre)}}
							</view>
						</view>

						<!-- 	<view class="flex_row_between table_primary_tr">
					<view>{{$msg.OTC_A_LEVER}}</view>
					<view>{{$fmt.quantity(v.lever)}}</view>
				</view> -->
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_A_FEE}}</view>
							<view>{{$fmt.amount(v.fee,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.OTC_DT}}</view>
							<view>{{v.dt}}</view>
						</view>

						<template v-if="v.desc!=''">
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.OTC_DESC}}</view>
							</view>
							<view class="flex_row_between table_primary_tr">
								<view></view>
								<view style="text-align: right;" :style="{color:$theme.getColor($theme.INFO)}">{{v.desc}} </view>
							</view>
						</template>
					</template>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Record",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>