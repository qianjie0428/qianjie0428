<template>
	<view :class="isAnimat ? 'fade_in' : 'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{ $msg.MENU_OTC }}</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<view class="flex_row_between common_tabs" style="padding:12px 18px;">
			<block v-for="(v, k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item" :class="curKey === k ? `item_act` : ``">
					{{ v }}
				</view>
			</block>
		</view>

		<view :class="curIndex % 2 == 0 ? `left_in` : `right_in`" style="padding:20px 18px 60px 18px;">
			<CommonList :list="list" :curKey="curKey" @buy="openBuyDialog" />
		</view>

		<template v-if="showBuy">
			<CommonBuy :title="$msg.OTC_MODAL_TITLE" @close="modalClose">
				<view style="padding:12px 12px 40px 12px;">
					<view class="flex_row_between" style="gap: 12px;width: 100%;padding-bottom: 4px; ">
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{detail.name}}
						</view>
						<text style="font-size: 13px;font-weight: 300;">({{detail.code}})</text>
					</view>

					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.OTC_PRICE}}</view>
						<view>{{$fmt.amount(detail.price,detail.lgre)}}</view>
					</view>

					<view class="flex_row_between table_primary_tr" style="padding-bottom: 16px;">
						<view>{{$msg.OTC_MIN}}</view>
						<view>{{$fmt.decimal(detail.min_num)}}</view>
					</view>
					<view class="line_h"></view>
					<view class="form_label" style="padding-top: 16px;"> {{ $msg.OTC_MODAL_QTY }} </view>
					<view class="form_input">
						<input v-model="qty" type="number" :placeholder="$msg.OTC_MODAL_QTY_TIP"
							placeholder-class="placeholder"></input>
						<template v-if="qty && qty.length > 0">
							<image src="/static/del.svg" mode="aspectFit" @tap="qty = ''"></image>
						</template>
					</view>
					<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
					<!-- <template v-if="levers.length>1">
							<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
								:style="{color:$theme.LOG_LABEL}">
								{{$lang.LEVER}}
							</view>

							<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
								<block v-for="(item,index) in levers" :key="index">
									<view
										style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
										:style="setStyle(curLever==item)" @tap="chgangeLever(item)">
										{{item}}
									</view>
								</block>
							</view>
						</template> -->
					<Balance :balance="!user ? '' : $fmt.amount(user.money,detail.lgre)" deposit />
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;">
						<view>{{ $msg.STOCK_TOTAL }} </view>
						<view style="padding:0 0 0 12px;">
							{{ $fmt.amount(total,detail.lgre) }}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content:  space-between;padding-top: 12px;">
						<view>{{ $msg.STOCK_FREEZE }} </view>
						<view style="padding:0 0 0 12px;"> {{ $fmt.amount(feeRate,detail.lgre) }} </view>
					</view>
					<view style="padding:24px 0 10px 0;">
						<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
							{{ $msg.COMMON_SUBMIT }}
						</BtnLock>
					</view>
				</view>
			</CommonBuy>
		</template>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.OTC_PWD_TITLE" @cancel="cancel" @confirm="confirm">
				<view class="form_input">
					<image src="/static/pwd_old.svg" mode="aspectFit"></image>
					<input v-model="password" :password="isMask" :placeholder="$msg.P_OTC_PWD"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask ? `hide` : `show`}.svg`" mode="aspectFit" @tap="toggleMask()">
					</image>
				</view>
				<view style="padding-top:8px;text-align: right;font-size: 11px;color: #999;" @tap="$util.linkCustomerService()">
					<text style="border-bottom: 0.1px solid #999;cursor: pointer;">
						{{ $msg.OTC_PWD_TIP }}</text>
				</view>
			</CommonConfirm>
		</template>
	</view>
</template>

<script>
	import CommonList from './components/CommonList.vue';
	export default {
		components: {
			CommonList
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_BUY]: this.$msg.OTC_TAB_BUY,
					[this.$C.KEY_APPLY]: this.$msg.OTC_TAB_APPLY,
					// [this.$C.KEY_RECORD]: this.$msg.OTC_TAB_RECORD,
				},
				list: null,
				detail: null,
				user: null,
				qty: '',
				levers: [],
				curLever: 1,
				showBuy: false,
				fee: 1,
				islock: false,
				password: '',
				showConfirm: false,
				isMask: null,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			},
			total() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price / this.curLever, this.$decimal);
			},
			feeRate() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price * this.fee, this.$decimal)
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.$C.KEY_BUY;
			this.changeTab(this.curKey);
			this.isMask = uni.getStorageSync('masking');
		},
		onHide() {
			this.isAnimat = false;
			this.cancel();
			this.modalClose();
		},
		onPullDownRefresh() {
			this.cancel();
			this.modalClose();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_BUY) this.getGoods();
				if (this.curKey === this.$C.KEY_APPLY) this.getRecord();
			},
			async openBuyDialog(val) {
				console.log(val);
				this.detail = val;
				// this.showConfirm = true;
				this.showBuy = true;
				this.user = await this.$http.getAccount();
				this.levers = this.$util.leverList(this.user.ganggan);
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') || this.fee;
			},

			cancel() {
				this.showConfirm = false;
				this.detail = null;
				this.password = '';
			},
			async confirm() {
				// 匹配密码，成功则显示购买弹层
				if (this.password == this.detail.password) {
					this.showConfirm = false;
					this.password = '';
					this.showBuy = true;
					this.user = await this.$http.getAccount();
					this.levers = this.$util.leverList(this.user.ganggan);
					const result = await this.$http.getConfig();
					this.fee = result.get('TransRate') || this.fee;
				} else {
					uni.showToast({
						title: this.$msg.OTC_PWD_TITLE,
						icon: 'none'
					});
				}
			},
			modalClose() {
				this.showBuy = false;
				this.qty = '';
			},
			async handleSubmit() {
				if (!this.$util.checkField(this.qty, this.$msg.P_OTC_QTY)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.detail.id,
					num: this.qty,
					// pay_pass: this.password,
					ganggan: this.curLever,
				});
				this.islock = false;
				if (!result) return false;
				this.modalClose();
				this.changeTab(this.curKey);
			},

			async getGoods() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/goods-bigbill/list`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(v => v.gid && v.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					const type = v.goods.project_type_id || 1;
					return {
						logo: v.goods.logo,
						name: v.goods.name,
						code: v.goods.code,
						current_price: v.goods.current_price * 1 || 0,
						id: v.id,
						price: v.price * 1 || 0,
						rate_num: v.goods.rate_num * 1 || 0,
						rate: v.goods.rate * 1 || 0,
						min_num: v.min_num * 1 || 0,
						max_num: v.max_num * 1 || 0,
						type: type,
						lgre: type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US,
						password: v.password || '',
					}
				});
			},
			async getRecord() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(v => v.gid && v.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					const type = v.goods.project_type_id || 1;
					return {
						name: v.goods.name,
						code: v.goods.code,
						num: v.num * 1 || 0,
						price: v.price || 0,
						current_price: v.goods.current_price || 0,
						amount: v.amount || 0,
						rate_num: v.goods.rate_num || 0,
						rate: v.goods.rate * 1 || 0,
						pl: v.yingkui || 0,
						floatPL: v.float_yingkui || 0,
						fee: v.buy_fee || 0,
						lever: v.double * 1 || 1,
						dt: v.created_at,
						desc: v.desc,
						type: type,
						lgre: type == 1 ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US,
						status: v.status,
					}
				});
			}
		}
	}
</script>

<style></style>