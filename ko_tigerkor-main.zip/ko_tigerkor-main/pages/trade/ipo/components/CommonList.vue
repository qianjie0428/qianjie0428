<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_primary">
					<template v-if="curKey===$C.KEY_APPLY || curKey===$C.KEY_RECORD">
						<template v-if="v.msg &&v.msg.length>0">
							<view style="margin-top:8px;text-align: right;color: #9F8137;">
								{{v.msg}}
							</view>
						</template>
					</template>

					<view class="flex_row_between" style="align-items: stretch; gap: 12px;width: 100%;padding-bottom: 4px;">
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}
						</view>
						<text style="font-size: 13px;font-weight: 300;">({{v.code}})</text>
						<template v-if="curKey===$C.KEY_BUY">
							<view style="margin-left: auto;">
								<template v-if="v.status==0 || v.status==2">
									<text class="common_status" :style="$theme.statusStyle(v.status)">
										{{$msg.IPO_STATUS[v.status]}}
									</text>
								</template>
								<template v-if="v.status==1">
									<text class="btn_buy" @tap="buy(v)">{{$msg.IPO_BUY}}</text>
								</template>
							</view>
						</template>
					</view>

					<!-- <view class="flex_row_between table_primary_tr">
						<view>{{$msg.IPO_PRICE}}</view>
						<view>{{$fmt.amount(v.price,v.lgre)}}</view>
					</view> -->

					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.IPO_PRICE}}</view>
						<view>{{$fmt.amount(v.price,v.lgre)}}</view>
					</view>
					<template v-if="v.status==5">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_PRICE_LATEST}}</view>
							<view>{{$fmt.amount(v.latestPrice,v.lgre)}}</view>
						</view>
					</template>
					<template v-if="v.status==5">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_RATE}}</view>
							<view :style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_RATE_NUM}}</view>
							<view :style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.decimal(v.rate_num,v.lgre)}}
							</view>
						</view>
					</template>
					<template v-if="curKey===$C.KEY_BUY">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_SHARES_ISSUED}}</view>
							<view :style="{color:$theme.getColor($theme.PRIMARY)}">
								{{$fmt.amount(v.issuedAmount,v.lgre)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_SUB_QTY}}</view>
							<view :style="{color:$theme.getColor($theme.PRIMARY)}">{{$fmt.decimal(v.subQTY,$fmt.NEVER)}}
							</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_SUB_DT}}</view>
							<view>{{v.subDT}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_OLINE_DT}}</view>
							<view>{{v.onlieDT}}</view>
						</view>
					</template>

					<template v-if="curKey===$C.KEY_APPLY || curKey===$C.KEY_RECORD">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_APPLY_QTY}}</view>
							<view> {{$fmt.decimal(v.applyQTY,$fmt.NEVER)}} </view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_APPLY_AMOUNT}}</view>
							<view>
								{{$fmt.amount(v.applyAmount,v.lgre)}}
							</view>
						</view>
						<template v-if="curKey===$C.KEY_RECORD">
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.IPO_WIN_AMOUNT}}</view>
								<view :style="{color:$theme.getColor($theme.PRIMARY)}">
									{{$fmt.amount(v.winning,v.lgre)}}
								</view>
							</view>
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.IPO_WIN_QTY}}</view>
								<view :style="{color:$theme.getColor($theme.PRIMARY)}">
									{{$fmt.decimal(v.success,$fmt.NEVER)}}
								</view>
							</view>
							<view class="flex_row_between table_primary_tr">
								<view>{{$msg.IPO_FREEZE}}</view>
								<view> {{$fmt.amount(v.freeze,v.lgre)}} </view>
							</view>
							<template v-if="v.unPayAmount>0">
								<view class="flex_row_between table_primary_tr">
									<view>{{$msg.IPO_UNPAY_AMOUNT}}</view>
									<view :style="{color:$theme.getColor($theme.PRIMARY)}">
										{{$fmt.amount(v.unPayAmount,v.lgre)}}
									</view>
								</view>
							</template>
						</template>

						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_DT}}</view>
							<view>{{v.dt}}</view>
						</view>
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.IPO_SN}}</view>
							<view>{{v.sn}}</view>
						</view>
					</template>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CommonList",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>