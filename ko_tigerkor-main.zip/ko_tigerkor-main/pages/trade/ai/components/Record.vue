<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_primary">
					<view class="flex_row_between table_primary_tr" style="padding-bottom: 6px;">
						<view style="margin-left: auto;">
							<text class="common_status" :style="$theme.statusStyle(v.status)">{{v.statusTxt}}</text>
						</view>
					</view>
					<template v-if="curKey===$C.KEY_RECORD">
						<view class="flex_row_between table_primary_tr">
							<view>{{$msg.AI_PRICE}}</view>
							<view>{{$fmt.amount(v.price)}}</view>
						</view>
					</template>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.AI_AMOUNT}}</view>
						<view :style="{color:$theme.getColor($theme.PRIMARY)}">
							{{$fmt.amount(v.money)}}
						</view>
					</view>
					<template v-if="curKey===$C.KEY_RECORD">
						<view class="flex_row_between flex_row_between table_primary_tr">
							<view>{{$msg.AI_AMOUNT_SUCCESS}}</view>
							<view :style="{color:$theme.getColor($theme.PRIMARY)}">
								{{$fmt.amount(v.success)}}
							</view>
						</view>
					</template>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.AI_DT}}</view>
						<view :style="{color:$theme.getColor($theme.SECOND)}">{{v.dt}}</view>
					</view>
					<view class="flex_row_between table_primary_tr">
						<view>{{$msg.AI_SN}}</view>
						<view :style="{color:$theme.getColor($theme.SECOND)}">{{v.sn}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Record",
		props: {
			list: {
				type: Array,
				default: []
			},
			curKey: {
				type: String,
				default: ''
			}
		},
	}
</script>

<style>
</style>