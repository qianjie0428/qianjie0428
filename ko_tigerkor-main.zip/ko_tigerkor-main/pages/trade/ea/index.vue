<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="page_header">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.EA_TITLE)" />

		<view style="margin:20px 8px 10px 8px;">
			<view class="tabs" style="background-color: #FFF;border-radius: 14px;">
				<block v-for="(v,k) in tabs" :key="k">
					<view :class="v.key===curKey?`tab_act`:``" @tap="changeTab(v.key)"
						style="text-align: center;font-size: 12px;font-weight: bold;flex: 1;cursor: pointer;">
						{{v.name}}
					</view>
				</block>
			</view>
		</view>

		<view :class="$theme.random(curIndex)+`_in`" style="padding:0 8px 60px 8px;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curKey===$C.KEY_GOODS">
					<Goods :list="list" @buy="showBuy" />
				</template>
				<template v-if="curKey===$C.KEY_APPLY">
					<Record :list="list" />
				</template>
			</template>
		</view>

		<template v-if="showBuyModal">
			<view class="overlay" @tap="modalClose()"></view>
			<view class="modal_wrapper_bottom bottom_in" style="background-color: rgba(0,0,0,0.9);">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #F0D6A3;background-color: #F4E0B5;border-radius: 6px 6px 0 0;line-height: 2.4;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							{{detail.name}}
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit"
							style="margin-left: auto;padding-right: 6px;cursor: pointer;" :style="$theme.setImageSize(20)"
							@tap.top="modalClose()"></image>
					</view>
					<view class="position" style="padding:12px 12px 0 12px;color: #FFF;">
						<view class="item">
							<view style="color:#FFF;">{{$t($msg.EA_CYCLE)}}</view>
							<view>{{detail.days}}</view>
						</view>
						<view class="item">
							<view style="color:#FFF;">{{$t($msg.EA_GROWTH)}}</view>
							<view>{{$fmt.percent(detail.fudu)}}</view>
						</view>
					</view>
					<view style="padding:12px 12px 40px 12px;">
						<view style="font: 14px;font-weight: 700;margin-bottom: 8px;color: #FFF;">
							{{$t($msg.COMMON_BUY + ` ` +$msg.COMMON_AMOUNT)}}
						</view>
						<view class="input_wrapper" style="border-radius: 12px;">
							<input v-model="amount" type="text"
								:placeholder="$t($msg.EA_MIN_AMOUNT+`: `+$fmt.amount(detail.minAmount))"
								:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
							<template v-if="amount && amount.length > 0">
								<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;"
									:style="$theme.setImageSize(16)" @tap="amount=''"></image>
							</template>
						</view>

						<Balance :balance="!user?'': $fmt.amount(user.money,$util.isUS())" deposit />

						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;color: #CCC;padding-top: 6px;">
							<view>{{$t($msg.STOCK_TOTAL)+`:`}} </view>
							<view style="padding:0 0 0 12px;" :style="{color:$theme.PRIMARY}">
								{{$fmt.amount(totoal)}}
							</view>
						</view> -->
						<!-- <view
							style="display: flex;align-items: center;justify-content:  space-between;color: #CCC;padding-top: 6px;">
							<view>{{$t($msg.STOCK_FREEZE)+`:`}} </view>
							<view style="padding:0 0 0 12px;"> {{$fmt.amount(feeRate)}} </view>
						</view> -->
						<view class="btn_second" style="margin-top:20px;" @tap="handleBuy()">
							{{$t($msg.COMMON_BUY)}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import * as ext from './ext.js';
	import Goods from './components/Goods.vue';
	import Record from './components/Record.vue';
	export default {
		components: {
			Goods,
			Record
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curKey: null,
				tabs: ext.tabs(),
				list: null,
				detail: null,
				user: null,
				amount: '',
				showBuyModal: false,
			}
		},
		computed: {
			curIndex() {
				const tem = this.tabs.findIndex(v => v.key === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.$C.KEY_GOODS;
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_GOODS) {
					this.getGoods();
					this.getAccount();
				}
				if (this.curKey === this.$C.KEY_APPLY) this.getRecord();
			},

			modalClose() {
				this.showBuyModal = false;
				this.amount = '';
			},

			async showBuy(val) {
				this.detail = null;
				this.detail = val;
				this.getAccount();
				this.showBuyModal = true;
			},

			async handleBuy() {
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				if (!this.$fmt.isNumer(this.amount)) {
					uni.showToast({
						title: this.$t(this.$msg.TIP_VALID),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.detail.id,
					ganggan: 1,
					price: this.amount,
				});
				if (!result) return false;
				this.showBuyModal = false;
				this.amount = '';
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				this.changeTab(this.$C.KEY_APPLY);
			},

			// async showSell(val) {
			// 	const result = await uni.showModal({
			// 		title: '',
			// 		content: this.$t(this.$msg.EA_MODAL_CONTENT),
			// 		cancelText: this.$t(this.$msg.COMMON_CANCEL),
			// 		confirmText: this.$t(this.$msg.COMMON_CONFIRM),
			// 		confirmColor: this.$theme.PRIMARY,
			// 		cancelColor: '#999999',
			// 	});
			// 	if (result[1].confirm) {
			// 		this.handleSell(val.id);
			// 	}
			// },
			// async handleSell(id) {
			// 	uni.showLoading({
			// 		title: this.$t(this.$msg.API_SUBMITING),
			// 	});
			// 	const result = await this.$http.post(`api/jijin/buy`, {
			// 		id
			// 	});
			// 	if (!result) return false;
			// 	uni.showToast({
			// 		title: result,
			// 		icon: 'none'
			// 	});
			// 	this.changeTab(this.curKey);
			// },
			async getGoods() {
				this.list = await this.$http.getEAGoods();
			},
			async getRecord() {
				this.list = await this.$http.getEARecord();
			},
			async getAccount() {
				this.user = await this.$http.getAccount();
			},
		}
	}
</script>

<style>
</style>