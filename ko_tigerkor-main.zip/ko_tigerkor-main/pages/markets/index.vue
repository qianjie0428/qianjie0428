<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<view class="flex_row_between common_tabs" style="flex:1;">
				<block v-for="(v,k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item" :class="curKey===k?`item_act`:``">
						{{v}}
					</view>
				</block>
			</view>
			<image src="/static/search.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.search()">
			</image>
		</header>

		<view :class="curIndex%2==0?`left_in`:`right_in`" style="padding:0 18px 60px 18px;">
			<!-- <template v-if="curKey===$C.KEY_STOCK">
				<view class="flex_row_between common_tabs" style="padding:10px 4px;border-radius: 6px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
					<block v-for="(v,k) in tabsStock" :key="k">
						<view @tap="changeTabStock(k)" class="item_sec" :class="curStock===k?`item_sec_act`:``">
							<text>{{v}}</text>
						</view>
					</block>
				</view>
			</template> -->

			<template v-if="curKey===$C.KEY_INDI">
				<view class="flex_row_between common_tabs" style="padding:10px 4px;border-radius: 6px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
					<block v-for="(v,k) in $msg.INDI_TABS" :key="k">
						<view @tap="changeTabIndi(k)" class="item_sec" :class="curIndi===k?`item_sec_act`:``">
							<text>{{v}}</text>
						</view>
					</block>
				</view>
			</template>
			<template v-if="curKey===$C.KEY_RANK">
				<view style="padding:10px 4px;border-radius: 6px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
					<scroll-view :scroll-x="true" style="white-space: nowrap;width: 99%;" @touchmove.stop>
						<view class="flex_row_between common_tabs" style="gap:12px;">
							<block v-for="(v,k) in $msg.RANK_TABS" :key='k'>
								<view @tap="changeTabRank(k)" class="item_sec" :class="curRank===k?`item_sec_act`:``">
									<text>{{v}}</text>
								</view>
							</block>
						</view>
					</scroll-view>
				</view>
			</template>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="curKey==$C.KEY_INDI">
					<ListIndicator :list="list" @action="linkTo" />
				</template>
				<template v-if="curKey===$C.KEY_RANK">
					<ListRank :list="list" @action="linkTo" @track="handleTrack" />
				</template>
				<template v-if="curKey===$C.KEY_TRACK">
					<ListTrack :list="list" @action="linkTo" @track="handleTrack" />
				</template>
				<template v-if="curKey===$C.KEY_STOCK">
					<view>
						<block v-for="(v,k) in list" :key="k">
							<view @tap="$linkTo.stockDetail(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
								<view class="flex_row_between" style="gap: 12px;width: 100%;">
									<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
									<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
										{{v.name}} <text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
									</view>
								</view>
								<view class="flex_row_between" style="gap: 12px;">
									<view style="width: 48%;">{{v.industry}}</view>
									<view style="font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
										{{$fmt.amount(v.price,v.lgre)}}
									</view>
									<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
										{{ $fmt.percent(v.rate)}}
									</text>
								</view>
							</view>
						</block>
					</view>
				</template>
			</template>
		</view>

		<FooterSmall :actKey="$C.KEY_MARKET"></FooterSmall>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_STOCK]: this.$msg.MARKET_TAB_STOCK,
					[this.$C.KEY_INDI]: this.$msg.MARKET_TAB_INDI,
					[this.$C.KEY_RANK]: this.$msg.MARKET_TAB_RANK,
					[this.$C.KEY_TRACK]: this.$msg.MARKET_TAB_TRACK,
				},
				curIndi: 0,
				curRank: 0,
				list: null,
				curStock: null,
				tabsStock: {
					[this.$fmt.code.KEY_KR]: this.$msg.STOCK_TABS_KR,
					// [this.$fmt.code.KEY_US]: this.$msg.STOCK_TABS_US,
				},
				timer: null,
			}
		},
		computed: {
			curIndex() {
				const tem = Object.keys(this.tabs).findIndex(k => k === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			},
			curGpIndex() {
				return this.$C.GPINDEX[this.curStock] || Object.keys(this.tabsStock)[0];
			}
		},
		onLoad(opt) {
			this.curKey = opt.tag || this.curKey;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.curStock = this.curStock || Object.keys(this.tabsStock)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
			this.wsClient = null;
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.clearTimer();
				this.curKey = val;
				this.list = null;
				this.curStock = this.curStock || Object.keys(this.tabsStock)[0];
				this.curIndi = 0;
				this.curRank = 0;
				if (this.curKey === this.$C.KEY_STOCK)
					this.changeTabStock(this.curStock);
				if (this.curKey === this.$C.KEY_INDI)
					this.changeTabIndi(this.curIndi);
				if (this.curKey === this.$C.KEY_RANK)
					this.changeTabRank(this.curRank);
				if (this.curKey === this.$C.KEY_TRACK)
					this.list = await this.$http.getTrack();
			},
			async changeTabStock(val) {
				this.clearTimer();
				this.list = null;
				this.curStock = val;
				this.getStocks();
				if (this.curStock === this.$fmt.code.KEY_KR)
					if (!this.timer) this.onSetTimeout();
			},
			async changeTabIndi(val) {
				this.list = null;
				this.curIndi = val;
				this.list = await this.$http.getIndicators(this.curIndi);
			},
			async changeTabRank(val) {
				this.list = null;
				this.curRank = val;
				this.list = await this.$http.getRanking(this.curRank);
			},

			async handleTrack(val) {
				const result = await this.$http.postTrack(val);
				console.log(result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTabRank(this.curRank);
				}, 1000);
			},

			async getStocks() {
				this.list = await this.$http.getStocks(this.curGpIndex);
			},

			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val) {
				if (this.curKey == this.$C.KEY_INDI) return false;

				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val);
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					// this.getTop();
					if (this.curStock === this.$fmt.code.KEY_KR) this.getStocks();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>