<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<view class="flex_row_between common_tabs" style="flex:1;">
				<block v-for="(v,k) in tabs" :key="k">
					<view @tap="changeTab(k)" class="item" :class="curKey===k?`item_act`:``">
						{{v}}
					</view>
				</block>
			</view>
			<image src="/static/search.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.search()">
			</image>
		</header>

		<template v-if="curKey===$C.KEY_NEW">
			<view style="padding:10px 12px;border-radius: 6px;"
				:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
				<scroll-view :scroll-x="true" style="white-space: nowrap;width: 99%;" @touchmove.stop>
					<view class="flex_row_between common_tabs" style="gap:12px;">
						<block v-for="(v,k) in $msg.RANK_TABS" :key='k'>
							<view @tap="changeTabNew(k)" class="item_sec" :class="curNew===k?`item_sec_act`:``">
								<text>{{v}}</text>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>

			<view class="right_in" style="padding:0 0 60px 0;">
				<template v-if="!news || news.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<newsList :list="news.slice(0,100)" />
				</template>
			</view>
		</template>

		<template v-if="curKey===$C.KEY_MARKET">
			<view class="flex_row_between common_tabs" style="padding:10px 4px;border-radius: 6px;"
				:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
				<block v-for="(v,k) in $msg.PLACE_TAB_BEST" :key="k">
					<view @tap="changeTabBest(k)" class="item_sec" :class="curBest===k?`item_sec_act`:``">
						<text>{{v}}</text>
					</view>
				</block>
			</view>
			<template v-if="bests && Object.values(bests).length>0">
				<view class="card_row" style="padding-top: 12px;">
					<block v-for="(v,k) in bests" :key="k">
						<CardItem :detail="v" @action="linkTo" />
					</block>
				</view>
			</template>
		</template>

		<!-- kline -->
		<view class="common_card" style="background-color: #FFF;padding:8px;margin:8px;">
			<view id="kline-stock" style="width: 100%;height:240px;"> </view>
		</view>

		<template v-if="article && article.length>0">
			<CommonTitle :title="$msg.MENU_NEWS"> </CommonTitle>
			<newsList :list="article" />
		</template>
		<template v-if="curKey===$C.KEY_MARKET">
			<view style="text-align: center;">
				<image src="/static/banner1.png" mode="heightFix" style=" width: auto;height: 100px;cursor: pointer;"
					@tap="changeTab($C.KEY_NEW)"></image>
			</view>
			<view style="margin-top: -20px;"></view>

			<CommonTitle :title="$msg.MARKET_TAB_RANK">
				<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
					@tap="$linkTo.markets($C.KEY_RANK)">
					{{$msg.NEWS_ALL}}
				</view>
			</CommonTitle>
			<view style="padding:10px 12px;border-radius: 6px;"
				:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
				<scroll-view :scroll-x="true" style="white-space: nowrap;width: 99%;" @touchmove.stop>
					<view class="flex_row_between common_tabs" style="gap:12px;">
						<block v-for="(v,k) in $msg.PLACE_TAB_RANK" :key='k'>
							<view @tap="changeTabRank(k)" class="item_sec" :class="curRank===k?`item_sec_act`:``">
								<text>{{v}}</text>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>

			<view style="background-color: #FFF;padding:0 16px 10px 16px;">
				<block v-for="(v,k) in ranks" :key="k">
					<view @tap="linkTo(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
						<view class="flex_row_between" style="gap: 12px;width: 100%;">
							<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
							<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
								{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
							</view>
							<view style="margin-left: auto;">
								<image :src="`/static/star_dark${v.track?``:`_un`}.svg`" mode="aspectFit"
									:style="$theme.setImageSize(16)" @click.stop="track(v.gid)"></image>
							</view>
						</view>
						<view class="flex_row_between" style="gap: 12px;">
							<view style="flex:2;">{{v.industry}}</view>
							<view style="flex:1;font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.amount(v.price,v.lgre)}}
							</view>
							<!-- <text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rateNum)}">
								{{ $fmt.amount(v.rateNum,v.lgre)}}
							</text> -->
							<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
								{{ $fmt.percent(v.rate)}}
							</text>
						</view>
					</view>
				</block>
			</view>

			<template v-if="industry && industry.length>0">
				<CommonTitle :title="$msg.PLACE_INDUSTRY">
					<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
						@tap="$linkTo.markets($C.KEY_INDI)">
						{{$msg.NEWS_ALL}}
					</view>
				</CommonTitle>
			</template>
			<view>
				<block v-for="(v,k) in industry" :key="k">
					<view class="news_item" style="display: flex;align-items: center;justify-content: space-between;gap: 10px;">
						<view :style="{color:$theme.setRiseFall(v.avg_returns)}">{{$fmt.percent(v.avg_returns)}}</view>
						<view>{{v.name}}</view>
						<view style="flex:0 0 auto;font-size: 11px;text-align: right;"
							:style="{color:$theme.getColor($theme.INFO)}">{{$fmt.setYMDHMS(v.dt)}}</view>
					</view>
				</block>
			</view>
		</template>

		<FooterSmall :actKey="$C.KEY_NEW"></FooterSmall>
	</view>
</template>

<script>
	import {
		init,
		dispose,
		utils,
	} from '@/common/klinecharts.min.js';
	import newsList from './components/newsList.vue';
	export default {
		components: {
			newsList
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_MARKET]: this.$msg.MENU_PLACE,
					[this.$C.KEY_NEW]: this.$msg.MENU_NEWS,
				},
				news: null,
				curNew: 0,
				bests: null,
				article: null,
				industry: null,
				curId: 141,
				curBest: 0,
				chart: null,
				chartData: [],
				timer: null,
				ranks: null,
				curRank: 0,
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
			await this.$http.getTop3();
		},

		onHide() {
			this.isAnimat = false;
			dispose("kline-stock");
			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		deactivated() {
			dispose("kline-stock");
			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		onUnload() {
			dispose("kline-stock");
			this.chart = null;
			this.chartData = null;
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			this.clearTimer();
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.curKey = val;
				this.clearTimer();
				dispose("kline-stock");
				this.chart = null;
				this.chartData = null;
				if (this.curKey === this.$C.KEY_NEW) this.changeTabNew(this.curNew);
				if (this.curKey === this.$C.KEY_MARKET) {
					this.changeTabBest(this.curBest);
					this.changeTabRank(this.curRank);
				}
			},
			async changeTabNew(val) {
				this.curNew = val;
				this.getList();
			},
			async changeTabRank(val) {
				this.curRank = val;
				this.ranks = await this.$http.getTop2(this.curRank);
			},

			async changeTabBest(val) {
				this.curBest = val;
				this.clearTimer();
				this.getTop();
				this.onSetTimeout();
			},

			async linkTo(val) {
				this.curId = val.gid;
				this.getTop()
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getTop();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			async getTop() {
				const result = await this.$http.getTop(this.curBest, this.curId);
				if (!result) return false;
				this.bests = result.tops;
				this.chartData = result.chart;
				console.log(this.chartData)
				if (!this.chart) {
					this.chart = init('kline-stock')
					console.log(this.chart)
					this.chart.setStyles({
						candle: {
							type: "area",
							tooltip: {
								showRule: "none",
							}
						},
					});
				}
				this.chart.applyNewData(this.chartData);
				this.$forceUpdate();

				setTimeout(() => {
					this.article = result.article;
					this.industry = result.industry;
				}, 300);

			},

			async getList() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/get_news`, {
					current: this.curNew
				});
				if (!result) return null;
				this.news = result.length <= 0 ? [] : result.map(v => {
					return {
						title: v.title,
						url: v.url,
						dt: v.created_at,
						pic: v.pic,
					}
				});
			}
		}
	}
</script>

<style>
</style>