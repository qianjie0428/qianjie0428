<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="setTitle" />
		<view class="right_in" style="padding:0 0 60px 0;">
			<CommonList :list="list" @action="linkTo" />
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: ext.tabsCommon(),
				list: null,
			}
		},
		computed: {
			setTitle() {
				return this.tabs[this.curKey].name;
			},
			curAPI() {
				return this.tabs[this.curKey].api;
			},
		},
		onLoad(opt) {
			this.curKey = opt.tag || this.curKey;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.changeTab(this.curKey);
			console.log(this.tabs);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				console.log(`curKey`, this.curKey);
				this.curKey = val;
				this.list = await this.$http.getMarketCommons(this.curAPI);
			},
			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val) {
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val);
			}
		}
	}
</script>

<style>
</style>