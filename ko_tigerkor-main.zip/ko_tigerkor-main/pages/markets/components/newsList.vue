<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="news_item" @tap="$linkTo.openNews(v.url)">
				<image :src="v.pic" mode="scaleToFill" :style="$theme.setImageSize(60)" style="border-radius: 6px;">
				</image>
				<view style="flex:1;padding-left: 12px;display: flex;flex-direction: column;justify-content: space-between;">
					<view><text>{{v.title}}</text> </view>
					<view style="flex:0 0 auto;font-size: 11px;text-align: right;" :style="{color:$theme.getColor($theme.INFO)}">
						{{v.dt}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "newsList",
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style>
</style>