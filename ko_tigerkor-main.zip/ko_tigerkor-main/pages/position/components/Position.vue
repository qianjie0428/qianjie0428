<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="table_primary">
				<view style="font-size: 14px;font-weight: 500;">
					{{v.name}} <text style="padding-left: 12px;font-size: 11px;font-weight: 300;"
						:style="{color:$theme.FLAT}">({{v.curcode}})</text>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_BUY_PRICE}}</view>
					<view>{{$fmt.amount(v.buyPrice,v.lgre)}} </view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>
						{{v.status==1?$msg.POSITION_CUR_PRICE:$msg.POSITION_SELL_PRICE}}
					</view>
					<template v-if="v.status==1">
						<view> {{$fmt.amount(v.curPrice,v.lgre)}} </view>
					</template>
					<template v-if="v.status==2">
						<view> {{$fmt.amount(v.sellPrice,v.lgre)}} </view>
					</template>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_BUY_QTY}}</view>
					<view>{{$fmt.numer(v.buyNum)}} </view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{ v.status==1? $msg.POSITION_BUY_FEE:$msg.POSITION_SELL_FEE}}</view>
					<template v-if="v.status==1">
						<view>{{$fmt.amount(v.buyFee,v.lgre)}} </view>
					</template>
					<template v-else>
						<view>{{$fmt.amount(v.sellFee,v.lgre)}} </view>
					</template>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_BUY_AMOUNT}}</view>
					<view>{{$fmt.amount(v.buyAmount,v.lgre)}} </view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view> {{$msg.POSITION_PL_RATE}} </view>
					<template v-if="v.status==1">
						<view :style="{color:$theme.setRiseFall(v.buyPLRate)}">
							{{$fmt.percent(v.buyPLRate)}}
						</view>
					</template>
					<template v-if="v.status==2">
						<view :style="{color:$theme.setRiseFall(v.sellPLRate)}">
							{{$fmt.percent(v.sellPLRate)}}
						</view>
					</template>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view> {{$msg.POSITION_TOTAL}} </view>
					<template v-if="v.status==1">
						<view> {{$fmt.amount(v.buyTotal,v.lgre)}} </view>
					</template>
					<template v-if="v.status==2">
						<view> {{$fmt.amount(v.sellTotal,v.lgre)}} </view>
					</template>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_PL}}</view>
					<view :style="{color:$theme.setRiseFall(v.plAmount)}">
						{{$fmt.amount(v.plAmount,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}}
					</view>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_FLOAT_PL}}</view>
					<template v-if="v.status==1">
						<view :style="{color:$theme.setRiseFall(v.buyFloatPL)}">
							{{$fmt.amount(v.buyFloatPL,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}}
						</view>
					</template>
					<template v-if="v.status==2">
						<view :style="{color:$theme.setRiseFall(v.sellFloatPL)}">
							{{$fmt.amount(v.sellFloatPL,v.lgre,v.lgre,$fmt.EXCEPT_ZERO)}}
						</view>
					</template>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.POSITION_LEVER}}</view>
					<view>{{$fmt.numer(v.double)}} </view>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view> {{$msg.POSITION_DT}} </view>
					<view> {{v.status==1? v.buyDT:v.sellDT}} </view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view> {{$msg.POSITION_SN}} </view>
					<view> {{v.sn}} </view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;margin-top: 10px;">
					<view class="btn_buy" style="flex:1;padding:8px 0;"
						:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA),color:$theme.getColor($theme.PRIMARY)}"
						@tap="$linkTo.stockDetail(v.curcode)">
						{{$msg.STOCK_DETAIL}}
					</view>
					<template v-if="v.status==1">
						<view class="btn_buy" style="flex:1;padding:8px 0;"
							:style="{backgroundColor:$theme.getColor($theme.ERROR_RGBA),color:$theme.getColor($theme.ERROR)}"
							@tap="sell(v)">
							{{$msg.POSITION_SELL}}
						</view>
					</template>
					<template v-if="v.status==2">
						<view class="btn_buy" style="flex:1;padding:8px 0;"
							:style="{backgroundColor:$theme.getColor($theme.SUCCESS_RGBA),color:$theme.getColor($theme.SUCCESS)}"
							@tap="buy(v.curcode)">
							{{$msg.POSITTON_BUY}}
						</view>
					</template>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "PositionBak",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			sell(val) {
				this.$emit('sell', val);
			},
			buy(val) {
				this.$linkTo.stockDetail(val, 'buy');
			}
		}
	}
</script>

<style>
</style>