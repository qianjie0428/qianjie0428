<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<view style="font-size: 20px;font-weight: 600;">{{$msg.MENU_ACCOUNT}}</view>
			<image src="/static/service.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.service()">
			</image>
		</header>

		<view class="left_in">
			<view style="display: flex;align-items: center;padding:12px 18px;" @tap="$linkTo.profile()">
				<image :src='!user||!user.avatar?`/static/avatar.png`:$util.setLogo(user.avatar)' mode="scaleToFill"
					:style="$theme.setImageSize(72)" style="border-radius: 100%;"></image>
				<view style="flex:1;color: #FFF;">
					<view style="padding-left: 12px;font-size: 16px;font-weight: 700;text-transform:uppercase;color: #333333;">
						{{!user?'': user.nick_name}}
					</view>
					<view style="padding-left: 12px;padding-top: 12px;color: #999999;">{{!user?'':user.mobile}}</view>
				</view>
				<image src="/static/arrow_right_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)"
					style="cursor: pointer;margin-left: auto;">
			</view>

			<template v-if="assets">
				<AssetsCard :info="assets" />
			</template>

			<view class="set_btns">
				<view class="item flex_row_center" style="cursor: pointer;"
					:style="{backgroundColor:$theme.getColor($theme.WARN_RGBA)}" @tap="$linkTo.withdraw()">
					<image src="/static/mine_1.png" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
					<text style="padding-left: 12px;font-weight: 600;"
						:style="{color:$theme.getColor($theme.SECOND)}">{{$msg.MENU_WITHDRAW}}</text>
				</view>
				<view @tap="$linkTo.deposit()" class="item flex_row_center" style="cursor: pointer;"
					:style="{backgroundColor:$theme.getColor($theme.SUCCESS_RGBA)}">
					<image src="/static/mine_0.png" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
					<text style="padding-left: 12px;" :style="{color:$theme.getColor($theme.SECOND)}">{{$msg.MENU_DEPOSIT}}</text>
				</view>
				<!-- 				<view @tap="$linkTo.service()" class="item flex_row_center"
					:style="{backgroundColor:$theme.getColor($theme.WARN_RGBA)}">
					<image src="/static/home/btn_7.png" mode="aspectFit" :style="$theme.setImageSize(48)"></image>
					<text style="padding-left: 12px;" :style="{color:$theme.getColor($theme.SECOND)}">{{$msg.MENU_SERVICE}}</text>
				</view> -->
			</view>

			<view style="padding:20px;background-color: #FFFFFF;border-radius: 20px 20px 0 0;min-height: 60vh;">
				<!-- <view @tap="openLgre()"
					style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 2.4;">
					<view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view>
					<view style="padding-left: 12px;color: #6D6D6D;flex:1;">{{$t($msg.LGRE_TITLE)}}</view>
					<view style="font-size: 14px;font-weight: 500;" :style="{color:$theme.PRIMARY}">
						{{curLang}}
					</view>
				</view> -->

				<block v-for="(v,k) in features" :key="k">
					<view @tap="v.action"
						style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 3.2;font-size: 13px;"
						:style="{borderBottom:`${k<features.length-1?`0.5`:`0`} solid #C0C0C03A`}">
						<!-- <view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view> -->
						<image mode="aspectFit" :src="`/static/set_${v.icon}.svg`" :style="$theme.setImageSize(20)">
						</image>
						<view style="padding-left: 12px;flex:1;">{{v.name}}</view>
						<template v-if="v.key ===$C.KEY_AUTH">
							<view style="font-size: 12px;padding-right: 12px;"
								:style="{color:$theme.getColor([$theme.ERROR, $theme.SUCCESS][!user?-1: user.is_check])}">
								{{setAuth(!user?-1: user.is_check)}}
							</view>
						</template>
						<image src="/static/arrow_right_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
						</image>
					</view>
				</block>
				<view
					style="border-radius: 22px;text-align: center;line-height: 3;width: 90%;margin: 20px auto;font-weight: 500;font-size: 16px;"
					:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}" @tap="$util.signOut()">
					{{$msg.SIGN_OUT}}
				</view>
			</view>
		</view>

		<FooterSmall :actKey="$C.KEY_ACCOUNT"></FooterSmall>

		<!-- <u-picker :show="showLang" :columns="[lgres]" @change="chooseLgre" @cancel="showLang=false"
			@confirm="confirmLgre" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="lang"
			visibleItemCount="9"></u-picker> -->
	</view>
</template>

<script>
	import * as ext from './ext.js';
	// import {
	// 	lgre,
	// 	getLang,
	// 	setLgre
	// } from '@/localize/index.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				user: null,
				features: ext.features(),
				userAssets: null,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
			// curLang() {
			// 	console.log(getLang());
			// 	return getLang();
			// },
			// lgres() {
			// 	return Object.values(lgre)
			// },
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
			// console.log(lgre)
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			setAuth(val) {
				const temp = val == 1 ? 0 : -1;
				return this.$msg.AUTH_STATUS[temp + 1];
			},
			// async getAccount() {
			// 	const result = await this.$http.getAccount();
			// 	this.user = {
			// 		avatar: result.avatar || null,
			// 		mobile: result.mobile || '',
			// 		name: result.nick_name || '',
			// 		isCheck: result.is_check || -1,
			// 	}
			// 	this.userAssets = {
			// 		totalZichan: result.totalZichan,
			// 		money: result.money,
			// 		floatPL: result.holdYingli,
			// 	}
			// },
			// openLgre() {
			// 	this.showLang = true;
			// },
			// chooseLgre(e) {
			// 	console.log(`changeMode e:`, e);
			// },
			// confirmLgre(e) {
			// 	console.log(`confirmMode e:`, e);
			// 	this.showLang = false;
			// 	setLgre(e.value[0].code);
			// 	this.$forceUpdate();
			// 	window.location.reload();
			// },
		}
	}
</script>

<style>
</style>