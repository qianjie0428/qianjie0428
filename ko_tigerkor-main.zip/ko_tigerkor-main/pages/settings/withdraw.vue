<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_WITHDRAW}}</view>
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)" style="cursor: pointer;"
				@tap="$linkTo.funds($C.KEY_WITHDRAW)"></image>
		</header>

		<view class="right_in" style="padding:20px 0 60px 0;">

			<template v-if="assets">
				<AssetsCard :info="assets" />
			</template>

			<view class="common_card" style="margin: 16px 18px;padding: 14px 20px;">
				<view class="form_label"> {{$msg.WITHDRAW_ANOUNT}} </view>
				<view class="form_input">
					<input v-model="amount" type="digit" :placeholder="$msg.P_WITHDRAW_ANOUNT"
						placeholder-class="placeholder"></input>
					<template v-if="amount && amount.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="amount=''"></image>
					</template>
				</view>
				<view style="padding-top: 4px;font-size: 11px;margin-bottom: 16px;text-align: right;">
					{{$msg.WITHDRAW_TIP_AMOUNT}}
					<text style="padding:4px 0 8px 4px;">{{$fmt.amount(10000)}}</text>
				</view>

				<view class="form_label"> {{$msg.WITHDRAW_PWD}} </view>
				<view class="form_input">
					<input v-model="password" :password="isMask" :placeholder="$msg.P_WITHDRAW_PWD"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
				<view :style="{color:$theme.BLACK_70}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$msg.WITHDRAW_RULE_TITLE}}
					</view>
					<block v-for="(v,k) in $msg.WITHDRAW_RULES" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・`+ v}}</view>
					</block>
				</view>
			</view>

			<view style="padding:10px 18px 25px 18px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
					{{$msg.WITHDRAW_BTN}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				user: null,
				amount: '',
				password: '',
				isMask: null,
				islock: false,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = await this.$http.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.P_WITHDRAW_ANOUNT)) return false;
				if (!this.$util.checkField(this.password, this.$msg.P_WITHDRAW_PWD)) return false;
				this.islock = true;
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount.trim(),
					pay_pass: this.password.trim(),
					remakes: "",
				});

				this.islock = false;
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.funds($C.KEY_WITHDRAW)
				}, 1000)
			},
		}
	}
</script>

<style>
</style>