<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="table_primary">
				<view class="flex_row_between table_primary_tr">
					<view style="flex:1;"></view>
					<view class="common_status" :style="$theme.statusStyle(v.status)">
						{{v.statusLabel}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_MONEY}}</view>
					<view style="font-size: 14px;">
						{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_DT}}</view>
					<view>{{v.dt}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_SN}}</view>
					<view>{{v.sn}}</view>
				</view>

				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_W_REASON}}</view>
					<view :style="{color:$theme.getColor($theme.INFO)}">{{v.reason}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view></view>
					<template v-if="v.status==0">
						<view style="margin-left: auto;">
							<view class="btn_buy" @tap="cancel(v)">
								{{$msg.FUNDS_W_CANCEL}}
							</view>
						</view>
					</template>
					<template v-if="v.status==2">
						<view style="margin-left: auto;">
							<view class="common_status" :style="$theme.statusStyle(v.status)" @tap="$linkTo.service()">
								{{v.statusLabel}}
							</view>
						</view>
					</template>
				</view>
			</view>

		</block>
	</view>
</template>

<script>
	export default {
		name: 'FundsWithdraw',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			cancel(val) {
				this.$emit('cancel', val);
			}
		}
	}
</script>

<style>
</style>