<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="table_primary">
				<view class="flex_row_between table_primary_tr" style="padding-bottom: 6px;">
					<view style="margin-left: auto;">
						<text class="common_status" :style="$theme.statusStyle(v.status)">{{v.desc}}</text>
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_D_MONEY}}</view>
					<view style="font-size: 14px;" >
						{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_D_DT}}</view>
					<view :style="{color:$theme.getColor($theme.SECOND)}">{{v.dt}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_D_SN}}</view>
					<view :style="{color:$theme.getColor($theme.SECOND)}">{{v.sn}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "FundsDeposit",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>