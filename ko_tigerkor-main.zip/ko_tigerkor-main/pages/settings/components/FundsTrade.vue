<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="table_primary">
				<view class="flex_row_between table_primary_tr" :style="{paddingTop: k==0?``:`6px`}">
					<view>{{$msg.FUNDS_TRADE_AFTER}}</view>
					<view>{{$fmt.amount(v.after,$fmt.setLgre(v.lgre))}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_TRADE_BEFORE}}</view>
					<view>{{$fmt.amount(v.before,$fmt.setLgre(v.lgre))}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_MONEY}}</view>
					<view style="font-size: 14px;" >
						{{$fmt.amount(v.money,$fmt.setLgre(v.lgre))}}
					</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_TRADE_DT}}</view>
					<view>{{v.dt}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view>{{$msg.FUNDS_TRADE_DESC}}</view>
				</view>
				<view class="flex_row_between table_primary_tr">
					<view></view>
					<view style="text-align: right;color: #888;">{{v.desc}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'FundsTrade',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>