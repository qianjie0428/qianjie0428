import * as linkTo from '@/common/linkTo.js';
import * as constants from '@/common/constants.js';
import {
	Msg,
} from '@/localize/index.js';

export const features = () => {
	return [{
			key: constants.KEY_AUTH,
			name: Msg.MENU_AUTH,
			icon: `auth`,
			action: linkTo.auth,
		}, {
			name: Msg.MENU_BANK_CARD,
			icon: `bank`,
			action: linkTo.bank,
		},
		// {
		// 	name: Msg.MENU_CONVERT,
		// 	icon: `convert`,
		// 	action: linkTo.convert,
		// }, {
		// 	name: Msg.MENU_LOANS,
		// 	icon: `convert`,
		// 	action: linkTo.loans,
		// }, 
		{
			name: Msg.MENU_FUNDS,
			icon: `funds`,
			action: () => {
				linkTo.funds()
			},
		}, {
			name: Msg.MENU_PWD_ACCOUNT,
			icon: `pwd`,
			action: linkTo.pwd,
		}, {
			name: Msg.MENU_PWD_PAY,
			icon: `pay`,
			action: linkTo.pwdPay,
		}, {
			name: Msg.MENU_TERMS,
			icon: `terms`,
			action: linkTo.terms,
		}, {
			name: Msg.MENU_ABOUT,
			icon: `about`,
			action: linkTo.about,
		}
	]
}