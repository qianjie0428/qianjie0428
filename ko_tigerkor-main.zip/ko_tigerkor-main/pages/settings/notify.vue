<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGCover(`sign_bg`)">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.NOTIFY_TITLE)" dir="slide_in_right" :msg="false" />

		<!-- <view class="notify" style="margin-top: 20px;">
			<image src="/static/search_fff.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="hur"></image>
			<input v-model="keywords" type="text" :placeholder="$t($msg.COMMON_ENTER+$msg.COMMON_KEYWORDS)"
				:placeholder-style="$theme.setPlaceholder(`#CCC`)"
				style="flex:auto;padding-left: 12px;color: #FFFFFF;font-weight: 100;"></input>

			<template v-if="keywords && keywords.length > 0">
				<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)" @tap="keywords=''"></image>
			</template>
		</view> -->

		<view class="right_in">
			<!-- <template v-if="!list || list.length<=0"> -->
			<EmptyData></EmptyData>
			<!-- </template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<view style="border-radius: 10px;padding:10px;margin-top:7px;"
						:style="{backgroundColor:k%2==0?`#F1F9FF`:$theme.TRANSPARENT}" @tap="linkDetail(v.url)">
						<view class="ellipsis" style="font-size: 14px;font-weight: 500;color: #515151;">
							{{v.title}}
						</view>
						<view style="color: #9A9A9A;font-size: 9px;">{{v.dt}}</view>
					</view>
				</block>
			</template> -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				keywords: '',
				list: null,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await get(`api/app/gglist`);
				if (!result) return false;
				this.list = result;
			},

			async getDetail(val) {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				});
				const result = await post(`api/app/gginfo`, {
					id: val
				});
				if (!result) return false;
				return result;
			}
		}
	}
</script>

<style>
</style>