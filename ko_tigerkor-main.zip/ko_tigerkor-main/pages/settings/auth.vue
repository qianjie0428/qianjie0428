<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_AUTH}}</view>
		</header>
		<view class="right_in" style="padding:20px 18px 60px 18px;">
			<view class="common_card" style="margin: 0 0 16px 0;padding: 14px 20px;">
				<view class="form_label"> {{$msg.AUTH_REAL_NAME}} </view>
				<view class="form_input">
					<input v-model="realName" type="text" :placeholder="$msg.P_AUTH_REAL_NAME"
						placeholder-class="placeholder"></input>
					<template v-if="realName && realName.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="realName=''"></image>
					</template>
				</view>
				<view class="form_label" style="margin-top: 20px;">
					{{$msg.AUTH_ID}}
				</view>
				<view class="form_input">
					<input v-model="cardID" :password="isMask" :placeholder="$msg.P_AUTH_ID"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
			</view>

			<view class="common_card" style="margin: 0 0 16px 0;padding: 14px 20px;">
				<view class="form_label" style="margin-top: 16px;"> {{$msg.AUTH_ID_FRONT}} </view>

				<view @tap="selectImg('front')" class="flex_row_center auth_card">
					<template v-if="!frontURL">
						<view class="auth_card_icon">
							<image src="/static/carmera.svg" mode="aspectFit" :style="$theme.setImageSize(96)">
							</image>
							<view class="auth_card_tip">{{$msg.TIP_AUTH_ID_FRONT}}</view>
						</view>
					</template>
					<template v-else>
						<image :src="frontURL" style="margin:10px;width:200px;height:160px;">
						</image>
					</template>
				</view>

				<view class="form_label" style="margin-top: 16px;"> {{$msg.AUTH_ID_BACK}} </view>

				<view @tap="selectImg('back')" class="flex_row_center auth_card">
					<template v-if="!backURL">
						<view class="auth_card_icon">
							<image src="/static/carmera.svg" mode="aspectFit" :style="$theme.setImageSize(96)">
							</image>
							<view class="auth_card_tip">{{$msg.TIP_AUTH_ID_BACK}}</view>
						</view>
					</template>
					<template v-else>
						<image :src="backURL" style="margin:10px;width:200px;height:160px;">
						</image>
					</template>
				</view>

				<view class="form_label" style="margin-top: 16px;">
					{{$msg.AUTH_RULE_TITLE}}
				</view>
				<block v-for="(v,k) in $msg.AUTH_RULES" :key="k">
					<view style="color:#6D6D6D;font-size: 12px;padding-bottom: 4px;">{{`・`+ v}}</view>
				</block>
			</view>
			<view style="padding:10px 0 25px 0;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
					{{$msg.AUTH_BTN}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				realName: '',
				cardID: '',
				frontURL: null,
				backURL: null,
				islock: false,
			}
		},
		computed: {},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 缓存表单，否则输入框值会消失
			setStorage() {
				uni.setStorageSync('real', this.realName);
				uni.setStorageSync('card', this.cardID);
				uni.setStorageSync('front', this.frontURL);
				uni.setStorageSync('back', this.backURL);
			},
			getStorage() {
				this.realName = uni.getStorageSync('real');
				this.cardID = uni.getStorageSync('card');
				this.frontURL = uni.getStorageSync('front') || this.frontURL;
				this.backURL = uni.getStorageSync('back') || this.backURL;
			},

			async getAccount() {
				const result = await this.$http.getAccount();
				this.realName = result.real_name || '';
				this.cardID = result.idno || '';
				this.frontURL = result.front_image || '';
				this.backURL = result.back_image || '';
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.realName,
						this.$msg.P_AUTH_REAL_NAME)) return false;
				if (!this.$util.checkField(this.cardID,
						this.$msg.P_AUTH_ID)) return false;
				if (!this.$util.checkField(this.frontURL,
						this.$msg.P_AUTH_ID_FRONT)) return false;

				this.islock = true;
				uni.showLoading({
					title: this.$msg.API_SUBMITING
				});
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName.trim(),
					idno: this.cardID.trim(),
					front_image: this.frontURL.trim() || '',
					back_image: this.backURL.trim() || '',
				});
				if (!result) {
					this.islock = false;
					return false;
				}
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.settings();
					this.islock = false;
				}, 1000);
			},
			// 点击上传
			async selectImg(val) {
				this.setStorage();
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				// console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				// console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				// console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.getStorage();
				if (val == 'front') {
					this.frontURL = reultURL;
					console.log(`frontURL:`, this.frontURL);
				}
				if (val == 'back') {
					this.backURL = reultURL;
					console.log(`backURL:`, this.backURL);
				}
			},
		}
	}
</script>

<style>
</style>