<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_BANK_CARD}}</view>
		</header>

		<view class="left_in" style="padding:20px 18px 60px 18px;">
			<view class="common_card" style="margin: 0 0 16px 0;padding: 14px 20px;">

				<view class="form_label"> {{$msg.BANK_REAL_NAME}} </view>
				<view class="form_input">
					<image src="/static/real-name.svg" mode="aspectFit"></image>
					<input v-model="realName" type="text" :placeholder="$msg.P_BANK_REAL_NAME"
						placeholder-class="placeholder"></input>
					<template v-if="realName && realName.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="realName=''"></image>
					</template>
				</view>

				<view class="form_label" style="margin-top: 16px;"> {{$msg.BANK_NAME}} </view>
				<view class="form_input">
					<image src="/static/real-name.svg" mode="aspectFit"></image>
					<input v-model="bankName" type="text" :placeholder="$msg.P_BANK_NAME" placeholder-class="placeholder"></input>
					<template v-if="bankName && bankName.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="bankName=''"></image>
					</template>
				</view>

				<view class="form_label" style="margin-top: 16px;"> {{$msg.BANK_ID}} </view>
				<view class="form_input">
					<image src="/static/id-card.svg" mode="aspectFit"></image>
					<input v-model="cardSN" :password="isMask" :placeholder="$msg.P_BANK_ID"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @tap="toggleMask()"></image>
				</view>
			</view>
			<view style="padding:10px 0 25px 0;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
					{{$msg.COMMON_SUBMIT}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				realName: '',
				bankName: '',
				cardSN: '',
				islock: false,
			}
		},
		computed: {},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async getAccount() {
				const result = await this.$http.getAccount();
				if (!result.real_name) this.$linkTo.auth();
				if (result.bank_card_info) {
					this.realName = result.bank_card_info.realname || '';
					this.bankName = result.bank_card_info.bank_name || '';
					this.cardSN = result.bank_card_info.card_sn || '';
				}
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.realName,
						this.$msg.P_BANK_REAL_NAME)) return false;
				if (!this.$util.checkField(this.bankName,
						this.$msg.P_BANK_NAME)) return false;
				if (!this.$util.checkField(this.cardSN,
						this.$msg.P_BANK_ID)) return false;
				this.islock = true;

				uni.showLoading({
					title: this.$msg.API_SUBMITING
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.realName.trim(),
					bank_name: this.bankName.trim(),
					card_sn: this.cardSN.trim(),
				});
				if (!result) {
					this.islock = false;
					return false;
				}
				console.log('result:', result);
				uni.showToast({
					title: this.$msg.COMMON_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					this.islock = false;
					this.$linkTo.settings();
				}, 1000)
			},
		}
	}
</script>

<style>
</style>