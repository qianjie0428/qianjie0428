<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{$msg.MENU_DEPOSIT}}</view>
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)" style="cursor: pointer;"
				@tap="$linkTo.funds($C.KEY_DEPOSIT)"></image>
		</header>

		<view class="right_in" style="padding:20px 0 60px 0;">

			<template v-if="assets">
				<AssetsCard :info="assets" />
			</template>

			<view class="common_card" style="margin: 16px 18px;padding: 14px 20px;">
				<view class="form_label"> {{$msg.DEPOSIT_AMOUNT}} </view>
				<view class="form_input">
					<input v-model="amount" type="digit" :placeholder="$msg.P_DEPOSIT_AMOUNT"
						placeholder-class="placeholder"></input>
					<template v-if="amount && amount.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @tap="amount=''"></image>
					</template>
				</view>
				<view style="padding-top: 4px;font-size: 11px;margin-bottom: 16px;text-align: right;">
					{{$msg.DEPOSIT_TIP_AMOUNT}}
				</view>
				<view :style="{color:$theme.getColor($theme.SECOND)}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$msg.DEPOSIT_RULE_TITLE}}
					</view>
					<block v-for="(v,k) in $msg.DEPOSIT_RULES" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・`+ v}}</view>
					</block>
				</view>
			</view>

			<view style="padding:10px 18px 25px 18px;">
				<BtnLock :isDisabled="islock" @tap="handleSubmit" className="btn_submit radius_22">
					{{$msg.DEPOSIT_BTN}}
				</BtnLock>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				user: null,
				amount: '',
				islock: false,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			async handleSubmit() {
				this.islock = true;
				if (!this.$util.checkField(this.amount, this.$msg.P_DEPOSIT_AMOUNT)) return false;
				this.islock = false;
				this.$linkTo.service();

				// uni.showLoading({
				// 	title: this.$msg.API_SUBMITING,
				// });
				// const result = await this.$http.post(`api/app/recharge`, {
				// 	money: this.amount,
				// 	type: 5,
				// 	image: this.is_url || '',
				// 	desc: this.value2 || '',
				// });
				// if (!result) return null;
				// console.log(result);
			}
		}
	}
</script>

<style>
</style>