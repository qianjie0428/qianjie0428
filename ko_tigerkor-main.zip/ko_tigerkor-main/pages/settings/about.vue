<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="common_header">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{setTitle}}</view>
		</header>

		<view class="right_in" style="padding:20px 18px 60px 18px;overflow-y: auto;max-height: 86vh;">
			<template v-if="!detail">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<view v-html="detail.content"></view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				detail: null
			}
		},
		computed: {
			setTitle() {
				return !this.detail ? this.$msg.MENU_ABOUT : this.detail.title;
			},
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getDetail();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getDetail();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getDetail() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/article/about-us`);
				if (!result) return false;
				// console.log(result);
				this.detail = {
					title: result.title,
					content: result.content,
				}
			}
		}
	}
</script>

<style>
</style>