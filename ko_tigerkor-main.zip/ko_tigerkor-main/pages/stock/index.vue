<template>
	<view :class="isAnimat ? 'fade_in' : 'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@tap="$linkTo.goBack()"></image>
			<view class="dynamic_title">{{ $msg.STOCK_DETAIL }}</view>
			<!-- <image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
				@tap="changeTab($C.KEY_DEPOSIT)"></image> -->
		</header>

		<view class="right_in" style="padding:16px 8px 16px 8px;">
			<template v-if="detail">
				<view class="common_card" style="padding: 20px;margin:0;">
					<view style="display: flex;align-items: center;">
						<CustomLogo :logo="detail.logo" :name="detail.name"></CustomLogo>
						<view style="line-height: 1.4;font-size: 16px;font-weight: 700;padding-left: 12px;">
							{{ detail.name }}<text style="font-size:13px;padding-left: 10px;font-weight: 300;"
								:style="{ color: $theme.LOG_LABEL }">({{ detail.code }})</text>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
						<view style="flex:1;">
							<view> {{ $msg.STOCK_PRICE }} </view>
							<view style=" font-size: 16px;" :style="{ color: $theme.setRiseFall(detail.rate) }">
								{{ $fmt.amount(detail.current_price, curLgre) }}
							</view>
						</view>
						<view style="flex:1;text-align: center;">
							<view> {{ $msg.STOCK_RATE }} </view>
							<view style="font-size: 16px;" :style="{ color: $theme.setRiseFall(detail.rate) }">
								{{ $fmt.percent(detail.rate) }}
							</view>
						</view>
						<view style="flex:1;text-align: right;">
							<view> {{ $msg.STOCK_RATENUM }} </view>
							<view style="font-size: 16px;" :style="{ color: $theme.setRiseFall(detail.rate_num) }">
								{{ $fmt.decimal(detail.rate_num) }}
							</view>
						</view>
					</view>
					<template v-if="detail.open">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;font-size: 14px;border-top: 1px solid #F3F3F3;margin-top: 6px;">
							<view style="flex:1;">
								<view style="font-size: 12px;color: #CCC;"> {{ $msg.STOCK_OPEN }} </view>
								<view> {{ $fmt.amount(detail.open, curLgre) }} </view>
							</view>
							<view style="flex:1;text-align: center;">
								<view style="font-size: 12px;color: #CCC;"> {{ $msg.STOCK_CLOSE }} </view>
								<view> {{ $fmt.amount(Math.abs(detail.close, curLgre)) }} </view>
							</view>
							<view style="flex:1;text-align: center;">
								<view style="font-size: 12px;color: #CCC;"> {{ $msg.STOCK_HIGH }} </view>
								<view> {{ $fmt.amount(Math.abs(detail.high, curLgre)) }} </view>
							</view>
							<view style="flex:1;text-align: right;">
								<view style="font-size: 12px;color: #CCC;"> {{ $msg.STOCK_LOW }} </view>
								<view> {{ $fmt.amount(Math.abs(detail.low, curLgre)) }} </view>
							</view>
						</view>
					</template>
				</view>
			</template>
		</view>

		<view class="flex_row_between common_tabs" style="padding:12px 18px;">
			<block v-for="(v, k) in $msg.STOCK_TAB_TIME" :key="k">
				<view @tap="changeTimes(k)" class="item" :class="curKline === k ? `item_act` : ``">
					{{ v }}
				</view>
			</block>
		</view>

		<view class="common_card" style="background-color: #FFF;padding:8px;margin:8px;">
			<view id="kline-stock" style="width: 100%;height:400px;">
			</view>
		</view>

		<template v-if="isShowBuy">
			<view style="padding:24px 8px 60px 8px;">
				<BtnLock :isDisabled="islock" @tap="openBuy" className="btn_submit radius_22">
					{{ $msg.STOCK_BUY }}
				</BtnLock>
			</view>
		</template>

		<!-- buy modal -->
		<template v-if="showBuy">
			<CommonBuy :title="$msg.STOCK_ORDERS_TITLE" @close="modalClose">
				<view style="padding:12px 12px 40px 12px;">
					<view class="form_label">{{ $msg.STOCK_BUY_SHARES }} </view>
					<view class="form_input">
						<input v-model="qty" type="number" :placeholder="$msg.P_STOCK_BUY_SHARES"
							placeholder-class="placeholder"></input>
						<template v-if="qty && qty.length > 0">
							<image src="/static/del.svg" mode="aspectFit" @tap="qty = ''"></image>
						</template>
					</view>
					<Balance :balance="!user ? '' : $fmt.amount(detail.project_type_id == 1 ? user.money : user.usd, curLgre)"
						deposit />
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
						<view>{{ $msg.STOCK_TOTAL + `:` }} </view>
						<view style="padding:0 0 0 12px;" :style="{ color: $theme.getColor($theme.PRIMARY) }">
							{{ $fmt.amount(total, curLgre) }}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content:  space-between;padding-top: 6px;">
						<view>{{ $msg.STOCK_FREEZE + `:` }} </view>
						<view style="padding:0 0 0 12px;">
							{{ $fmt.amount(feeRate, curLgre) }}
						</view>
					</view>
					<view style="padding:24px 0 10px 0;margin-top:8px;">
						<BtnLock :isDisabled="islock" @tap="handleBuy" className="btn_submit radius_22">
							{{ $msg.STOCK_BUY }}
						</BtnLock>
					</view>
				</view>
			</CommonBuy>
		</template>

		<template v-if="showConfirm">
			<CommonConfirm :title="$msg.STOCK_ASK_TITLE" @cancel="cancel" @confirm="confirm">
				<view style="font-size: 14px;font-weight: 700;padding:0 0;">
					{{ detail.name }} <text style="padding-left: 12px;font-size: 11px;font-weight: 300;"
						:style="{ color: $theme.getColor($theme.INFO) }">({{ detail.code }})</text>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding:6px 0;">
					{{ $msg.STOCK_BUY_SHARES }}:
					<view>
						<text style="font-size: 14px;font-weight: 500;" :style="{ color: $theme.getColor($theme.PRIMARY) }">
							{{ $fmt.numer(qty) }}</text>
						<text style="font-size: 11px;font-weight: 100;padding-left: 4px;"
							:style="{ color: $theme.getColor($theme.INFO) }">{{ $msg.STOCK_SHARES }}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding:0 0 12px 0;">
					{{ $msg.STOCK_TOTAL }}:
					<text style="font-size: 14px;font-weight: 500;"
						:style="{ color: $theme.getColor($theme.PRIMARY) }">{{ $fmt.amount(total, curLgre) }}</text>
				</view>
				<view class="line_h"></view>
				<view style="padding-top: 12px;font-size: 12px;">{{ $msg.IPO_MODAL_CONTENT }}</view>
			</CommonConfirm>
		</template>
	</view>
</template>

<script>
	import {
		init,
		dispose,
		utils,
	} from '@/common/klinecharts.min.js';
	export default {
		data() {
			return {
				isAnimat: false,
				symbol: '',
				curKline: 0,
				detail: null,
				chart: null,
				chartData: [],
				qty: '',
				user: null,
				fee: 1,
				askInfo: null,
				islock: false,
				showBuy: false,
				showConfirm: false,
				timer: null,
			}
		},
		computed: {
			isKR() {
				return this.detail && this.detail.project_type_id == 1;
			},
			total() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.current_price, this.$decimal)
			},
			feeRate() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.current_price * this.fee, this.$decimal)
			},
			isShowBuy() {
				return this.detail && (this.detail.project_type_id == 1 || this.detail.project_type_id == 2)
			},
			curLgre() {
				return this.detail && this.isKR ? this.$fmt.code.KEY_KR : this.$fmt.code.KEY_US;
			}
		},
		onLoad(opt) {
			this.symbol = opt.symbol || this.symbol;
			this.gid = opt.gid || this.gid;
			this.showBuy = opt.tag == 'buy';
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getStockDetail();
			this.chart = null;
			this.initKline();
		},
		onReady() {
			this.initKline();
		},
		onHide() {
			this.isAnimat = false;
			this.clearSomething();
			this.chart = null;
			this.cancel();
			this.modalClose();
		},
		deactivated() {
			this.clearSomething();
			this.chart = null;
			this.cancel();
			this.modalClose();
		},
		onUnload() {
			this.clearSomething();
			this.chart = null;
			this.cancel();
			this.modalClose();
		},
		onPullDownRefresh() {
			this.chart = null;
			this.getStockDetail();
			this.changeTimes(this.curKline);
			this.cancel();
			this.modalClose();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 停止并清理数据
			clearSomething() {
				if (this.chart) this.chart.clearData();
				dispose("kline-stock");
				if (this.timer) this.clearTimer();
			},

			initKline() {
				this.chart = init("kline-stock");
				if (this.chart) {
					this.chart.setStyles({
						"candle": {
							"type": "candle_solid",
							"tooltip": {
								"showRule": "none",
							},
							area: {
								lineSize: 2,
								lineColor: this.$theme.getColor(this.$theme.PRIMARY),
								value: 'close',
								backgroundColor: [{
									offset: 0,
									color: '#ffbfb919'
								}, {
									offset: 1,
									color: this.$theme.getColor(this.$theme.PRIMARY),
								}]
							},
							bar: {
								downColor: '#0b51b0',
								upColor: '#ea4445',
								noChangeColor: '#888888',
								downBorderColor: '#0b51b0',
								upBorderColor: '#ea4445',
								noChangeBorderColor: '#888888',
								upWickColor: '#ea4445',
								downWickColor: '#0b51b0',
								noChangeWickColor: '#888888'
							},
							// 价格标记
							priceMark: {
								show: true, // 是否展示
								// 最新价标记
								last: {
									show: true,
									upColor: '#F92855',
									downColor: '#0b51b0',
									noChangeColor: '#888888',
									line: {
										show: true,
										// 'solid' | 'dashed'
										style: 'dashed',
										color: '#0b51b0',
										dashedValue: [4, 4],
										size: 1
									},
								},
							},
						},
					});
					this.chart.customApi = {
						formatDate: (dateTimeFormat, timestamp) => {
							if (this.curKline == 0) {
								return utils.formatDate(dateTimeFormat, timestamp, "HH:mm")
							} else {
								return utils.formatDate(dateTimeFormat, timestamp, 'YYYY-MM-DD')
							}
						},
					};
					// this.chart.setPriceLineColor();
					console.log(this.chart);
					this.chart.setTimezone(this.$fmt.getTimeZone());
					this.chart
						.setPriceVolumePrecision(2, 0);
				}
			},

			async getStockDetail() {
				uni.showLoading({
					title: this.$msg.API_REQUEST_DATA,
				})
				const result = await this.$http.get(`api/product/info`, {
					code: this.symbol,
					time_index: this.curKline
				});
				if (!result) return null;
				console.log(result);
				this.detail = result.length <= 0 ? null : !result[0].gid ? null : result[0];
				if (this.detail && this.detail.project_type_id) {
					console.log(`info:`, this.detail);
					this.changeTimes(this.curKline);
				}
			},

			// 时轴切换
			async changeTimes(val) {
				this.chartData = null;
				console.log(`?`, this.chartData);
				this.clearSomething();
				this.initKline();
				this.curKline = val;
				this.getKlineData();
				if (this.isKR) {
					if (!this.timer) this.onSetTimeout();
				} else {}
			},

			async openBuy() {
				this.qty = '';
				this.showBuy = true;
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') || this.fee;
				this.user = await this.$http.getAccount();
			},
			modalClose() {
				this.showBuy = false;
				this.qty = '';
			},
			cancel() {
				this.showConfirm = false;
			},
			async handleBuy() {
				if (!this.qty || this.qty * 1 <= 0) {
					uni.showToast({
						title: this.$msg.P_STOCK_BUY_SHARES,
						icon: 'none'
					});
					return false;
				}
				this.showBuy = false;
				this.showConfirm = true;
			},
			cancel() {
				this.showConfirm = false;
			},

			async confirm() {
				uni.showLoading({
					title: this.$msg.API_SUBMITING,
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.qty,
					gid: this.detail.gid,
					price: this.detail.current_price,
					// ganggan: this.curLever,
				});
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.cancel();
					this.modalClose();
					this.$linkTo.position();
				}, 1000)
			},

			async getKlineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					code: this.detail.code,
					ac_time: this.curKline,
					project_type_id: this.detail.project_type_id,
				})
				if (!result) return null;
				result.forEach(v => {
					v.volume = v.vol || 0;
				})
				this.chartData = result;
				// console.log(`chartData:`, this.chartData);
				if (this.chart && this.chartData && this.chartData.length > 0) {
					this.chart.customApi = {
						formatDate: (dateTimeFormat, timestamp) => {
							if (this.curKline == 0) {
								return utils.formatDate(dateTimeFormat, timestamp, "HH:mm")
							} else {
								return utils.formatDate(dateTimeFormat, timestamp, 'YYYY-MM-DD')
							}
						},
					};
					if (this.chart) this.chart.clearData();
					this.chart.applyNewData(this.chartData);
					// 获取图标上的数据
					const dataList = this.chart.getDataList();
					// 数据数组的最后一个元素
					const lastData = dataList[dataList.length - 1];
					console.log(`lastData:`, lastData);
					this.detail.current_price = lastData.close;
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					this.getKlineData();
				}, 1000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style></style>