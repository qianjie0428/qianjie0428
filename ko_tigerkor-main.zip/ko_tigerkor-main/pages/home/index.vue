<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="bg_primary">
		<header class="common_header" style="gap:12px;">
			<image src="/static/logo_head.png" mode="heightFix" :style="$theme.setImageSize(16)"></image>
			<view style="font-size: 20px;font-weight: 600;">{{!user?'':user.nick_name}}</view>
			<image src="/static/search.svg" mode="heightFix" :style="$theme.setImageSize(20)"
				style="cursor: pointer;margin-left: auto;" @tap="$linkTo.search()">
			</image>
		</header>

		<view style="text-align: center;">
			<image src="/static/banner2.png" widthfix="heightFix" style="width: 90%;height: 128px;border-radius: 8px;">
			</image>
		</view>

		<view class="common_card btns" style="margin: 16px 18px 0 18px;padding: 20px 8px;">
			<block v-for="(v,k) in btns" :key="k">
				<view class="item" @tap="v.action">
					<image mode="aspectFit" :src="`/static/home/btn_${k}.png`" :style="$theme.setImageSize(32)"
						style="cursor: pointer;">
					</image>
					<view style="font-size: 13px;margin-top: 4px;text-align: center;font-weight: 500;cursor: pointer;"
						:style="{paddingBottom:k<4 ?'20px':''}">{{v.name}}</view>
				</view>
			</block>
		</view>

		<!-- <template v-if="assets">
			<CommonTitle :title="$msg.ASSETS_TITLE"></CommonTitle>
			<AssetsCard :info="assets"></AssetsCard>
		</template> -->

		<CommonTitle :title="$msg.INDEX_TITLE">
			<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
				@tap="$linkTo.markets($C.KEY_INDI)">
				{{$msg.INDEX_ALL}}
			</view>
		</CommonTitle>
		<view class="flex_row_between common_tabs" style="padding:6px 4px;border-radius: 6px;margin:0 12px 4px 12px;"
			:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
			<block v-for="(v,k) in $msg.PLACE_TAB_BEST" :key="k">
				<view @tap="changeTabBest(k)" class="item_sec" :class="curBest===k?`item_sec_act`:``">
					<text>{{v}}</text>
				</view>
			</block>
		</view>

		<view class="left_in" style="padding:0 0 0 0;margin: -10px 0;">
			<template v-if="bests && Object.values(bests).length>0">
				<view class="card_row" style="padding-top: 12px;background-color:transparent;">
					<block v-for="(v,k) in bests" :key="k">
						<CardItem :detail="v" @action="linkTo" show />
					</block>
				</view>
			</template>
		</view>

		<CommonTitle :title="$msg.STOCK_TITLE">
			<view :style="{color:$theme.getColor($theme.PRIMARY)}" style="cursor: pointer;"
				@tap="$linkTo.markets($C.KEY_STOCK)">
				{{$msg.STOCK_ALL}}
			</view>
		</CommonTitle>
		<!-- <view class="flex_row_between common_tabs" style="padding:6px 4px;border-radius: 6px;margin:0 12px 4px 12px;"
			:style="{backgroundColor:$theme.getColor($theme.PRIMARY_RGBA)}">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item_sec" :class="curKey===k?`item_sec_act`:``">
					<text>{{v}}</text>
				</view>
			</block>
		</view> -->

		<!-- <view class="flex_row_between common_tabs" style="flex:1;gap:14px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @tap="changeTab(k)" class="item" :class="curKey===k?`item_act`:``">
					{{v}}
				</view>
			</block>
		</view> -->
		<view class="right_in" style="padding:6px 18px 60px 18px;margin-top: -10px;">
			<block v-for="(v,k) in list" :key="k">
				<view @tap="$linkTo.stockDetail(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
					<view class="flex_row_between" style="gap: 12px;width: 100%;">
						<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
						</view>
					</view>
					<view class="flex_row_between" style="gap: 12px;">
						<view style="width: 48%;">{{v.industry}}</view>
						<view style="font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.amount(v.price,v.lgre)}}
						</view>
						<text style="font-size: 15px;margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
							{{ $fmt.percent(v.rate)}}
						</text>
					</view>
				</view>
			</block>
		</view>

		<view style="text-align: center;line-height: 1.6;" :style="{color:$theme.getColor($theme.INFO)}">{{$msg.COMMON_100}}
		</view>

		<view style="height: 60px;"></view>

		<FooterSmall :actKey="$C.KEY_HOME"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	// import HomeCurves from './components/HomeCurves.vue';
	export default {
		// components: {
		// 	HomeCurves
		// },
		data() {
			return {
				isAnimat: false,
				user: null,
				btns: ext.btns(),
				list: null,
				bests: null,
				curKey: null,
				tabs: {
					[this.$fmt.code.KEY_KR]: this.$msg.STOCK_TABS_KR,
					// [this.$fmt.code.KEY_US]: this.$msg.STOCK_TABS_US,
				},
				curId: 141,
				curBest: 0,
				timer: null,
			}
		},
		computed: {
			assets() {
				if (!this.user) return null;
				return {
					total: this.user.totalZichan * 1 || 0,
					usd: this.user.usd * 1 || 0,
					balance: this.user.money * 1 || 0,
					frozen: this.user.frozen * 1 || 0,
					totalPL: this.user.totalYingli * 1 || 0,
					holdPL: this.user.holdYingli * 1 || 0,
				}
			},
			curGpIndex() {
				return this.$C.GPINDEX[this.curKey] || Object.keys(this.tabs)[0];
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		async onPullDownRefresh() {
			this.clearTimer();
			this.user = await this.$http.getAccount();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.curKey = val;
				this.list = null;
				this.changeTabBest(this.curBest);
				this.getStock();
				this.clearTimer();
				if (this.curKey === this.$fmt.code.KEY_KR)
					if (!this.timer) this.onSetTimeout();
			},
			async changeTabBest(val) {
				this.curBest = val;
				this.getTop();
			},

			linkTo(val) {
				console.log(val);
				// this.$linkTo.stockDetail(val.gid, val.gid);
				return false;
			},

			async getStock() {
				this.list = await this.$http.getStocks(this.curGpIndex);
			},

			async getTop() {
				const result = await this.$http.getTop(this.curBest);
				if (!result) return false;
				this.bests = result.tops;
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					// this.getTop();
					if (this.curKey === this.$fmt.code.KEY_KR) this.getStock();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>