import * as linkTo from '@/common/linkTo.js';
import {
	Msg
} from '@/localize/index.js';

export const btns = () => {
	return [{
			name: Msg.MENU_AI,
			action: linkTo.ai
		}, {
			name: Msg.MENU_OTC,
			action: linkTo.otc
		}, {
			name: Msg.MENU_IPO,
			action: linkTo.ipo
		}, {
			name: Msg.MENU_SCR,
			action: linkTo.scr
		}, {
			name: Msg.MENU_DEPOSIT,
			action: linkTo.deposit
		}, {
			name: Msg.MENU_WITHDRAW,
			action: linkTo.withdraw
		}, {
			name: Msg.MENU_AUTH,
			action: linkTo.auth
		}, {
			name: Msg.MENU_SERVICE,
			action: linkTo.service
		},

	]
};