<template>
	<view class="flex_row_center" :style="{color:color}">
		<view>{{copyright}}</view>
		<view style="padding-left: 40px;">{{version}}</view>
	</view>
</template>

<script>
	export default {
		name: "CopyrightVersion",
		props: {
			color: {
				type: String,
				default: '',
			}
		},
		computed: {
			copyright() {
				return this.$APP_NAME + ` © ` + this.$fmt.setYear()
			},
			version() {
				return this.$msg.COMMON_VERSION + ` ` + this.$VERSION
			},
		},
		beforeMount() {},
	}
</script>

<style>

</style>