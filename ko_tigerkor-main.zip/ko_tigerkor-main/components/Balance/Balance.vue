<template>
	<view class="balance">
		<view>{{$msg.COMMON_BALANCE+`:`}} </view>
		<view style="padding:0 16px 0 12px;">{{balance}}
		</view>
		<template v-if="deposit">
			<view class="balance_btn" @tap="$linkTo.deposit()">
				{{$msg.MENU_DEPOSIT}}
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Balance",
		props: {
			// 余额值
			balance: {
				type: [Number, String],
				default: 0
			},
			// 是否需要快捷充值入口
			deposit: {
				type: Boolean,
				default: false
			},
		},
	}
</script>

<style>

</style>