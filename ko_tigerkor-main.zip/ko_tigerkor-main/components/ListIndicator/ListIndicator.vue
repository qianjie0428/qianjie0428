<template>
	<view class="table" style="padding: 0 0;margin-top: 10px;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view @tap="linkTo(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
					<view class="flex_row_between" style="gap: 12px;width: 100%;">
						<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
						<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
							{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
						</view>
						<view style="margin-left: auto;">
							<text class="rate" style="color: #FFF;width: 80px;display: inline-block;font-size: 15px;"
								:style="{backgroundColor:$theme.setRiseFall(v.rateNum)}">
								{{$fmt.percent(v.rateNum,v.lgre)}}
							</text>
						</view>
					</view>

					<view class="flex_row_between" style="gap: 12px;">
						<view class="flex_row_between table_primary_tr" style="flex:1;">
							<view>{{$msg.INDI_CLOSE}}</view>
							<view>{{$fmt.amount(v.close,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr" style="flex:1;text-align: right;">
							<view>{{$msg.INDI_OPEN}}</view>
							<view>{{$fmt.amount(v.open,v.lgre)}}</view>
						</view>
					</view>
					<view class="flex_row_between" style="gap: 12px;">
						<view class="flex_row_between table_primary_tr" style="flex:1;">
							<view>{{$msg.INDI_HIGH}}</view>
							<view>{{$fmt.amount(v.high,v.lgre)}}</view>
						</view>
						<view class="flex_row_between table_primary_tr" style="flex:1;text-align: right;">
							<view>{{$msg.INDI_LOW}}</view>
							<view>{{$fmt.amount(v.low,v.lgre)}}</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "ListIndicator",
		props: {
			list: {
				type: Object,
				default: {}
			}
		},
		methods: {
			linkTo(val, gid) {
				this.$emit('action', {
					code: val,
					id: gid
				})
			}
		}
	}
</script>

<style>

</style>