<template>
	<footer class="footer">
		<view class="tabbar">
			<block v-for="(v,k) in navs" :key="k">
				<!-- <template v-if="k==2">
					<view class="tab special">
						<view :style="setStyleNav(curActive ==v.key)" @tap="v.action">
							<image mode="aspectFit" :src="`/static/tabbar_${k}.png`" :style="$theme.setImageSize(48)">
							</image>
						</view>
					</view>
				</template>
				<template v-else> -->
				<view :style="setStyleNav(curActive ==k)" @tap="v.action">
					<image mode="aspectFit" :src="`/static/footer/${k+(curActive ==k?`_act`:``)}.png`"
						:style="$theme.setImageSize(18)" style="cursor: pointer;"></image>
				</view>
				<!-- </template> -->
			</block>
		</view>
		<view class="tabbar_label">
			<block v-for="(v,k) in navs" :key="k">
				<view style="font-size: 12.48px;flex:1;text-align: center;cursor: pointer;"
					:style="{color: curActive ==k ? $theme.getColor($theme.PRIMARY) : '#838b9c'}">
					{{ v.name}}
				</view>
			</block>
		</view>
	</footer>
</template>

<script>
	export default {
		name: "FooterSmall",
		props: {
			actKey: {
				type: String,
				default: 'home'
			}
		},
		data() {
			return {
				curActive: 0,
				navs: {
					[this.$C.KEY_HOME]: {
						name: this.$msg.MENU_HOME,
						action: this.$linkTo.home,
					},
					[this.$C.KEY_MARKET]: {
						name: this.$msg.MENU_MARKET,
						action: () => {
							this.$linkTo.markets()
						},
					},
					[this.$C.KEY_NEW]: {
						name: this.$msg.MENU_NEWS,
						action: this.$linkTo.news,
					},
					[this.$C.KEY_POSITION]: {
						name: this.$msg.MENU_POSITION,
						action: this.$linkTo.position,
					},
					[this.$C.KEY_ACCOUNT]: {
						name: this.$msg.MENU_ACCOUNT,
						action: this.$linkTo.settings,
					},
				},
			};
		},
		computed: {},

		beforeMount() {
			this.curActive = this.actKey;
			// // 根据url，找到包含当前url在数组的下标。 
			// const curURL = this.$route.fullPath.slice(7).split('/');
			// const temp = this.navs.findIndex(item => item.url.split('/')[0] == curURL[0]);
			// this.curActive = temp;
		},
		methods: {
			// // 跳转到 指定页面
			// linkTo(val) {
			// 	console.log(`val111:`, val);
			// 	uni.navigateTo({
			// 		url: this.$linkTo.PAGES + val,
			// 	})
			// },

			// // footer 主题样式
			// setStyle() {
			// 	return {
			// 		position: 'fixed',
			// 		bottom: 0,
			// 		left: 0,
			// 		right: 0,
			// 		padding: `8px 0`,
			// 		backgroundColor: `#FFFFFF`,
			// 		box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1),
			// 		zIndex: 9,
			// 	}
			// },
			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? '#546bff' : '#838b9c',
					textAlign: `center`,
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.footer {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 9;
		box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
		width: 100%;
		max-width: 750px;
		margin: 0 auto;
	}

	.footer>.tabbar {
		position: relative;
		display: flex;
		justify-content: space-around;
		align-items: center;
		gap: 12px;
		width: 100%;
		height: 28px;
		background-color: var(--white);
		padding-top: 6px;
	}

	.footer>.tabbar_label {
		display: flex;
		justify-content: space-around;
		align-items: center;
		gap: 12px;
		width: 100%;
		background-color: var(--white);
		padding-bottom: 6px;
	}
</style>