<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view @tap="linkTo(v.code,v.gid)" style="border-bottom: 1px solid #CCC;padding: 8px 0;">
				<view class="flex_row_between" style="gap: 12px;width: 100%;">
					<CustomLogo :logo="v.logo" :name="v.name"></CustomLogo>
					<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
						{{v.name}}<text style="font-size: 13px;font-weight: 300;padding-left: 12px;">({{v.code}})</text>
					</view>
					<view style="margin-left: auto;">
						<image :src="`/static/star_dark${v.track?``:`_un`}.svg`" mode="aspectFit" :style="$theme.setImageSize(16)"
							@click.stop="handleTrack(v.gid)"></image>
					</view>
				</view>
				<view class="flex_row_between" style="gap: 12px;">
					<text style="font-size: 13px;font-weight: 300;flex:1;">({{v.code}})</text>
					<view style="flex:2;font-size: 15px;" :style="{color:$theme.setRiseFall(v.rate)}">
						{{$fmt.amount(v.price,v.lgre)}}
					</view>
					<text style="font-size: 15px;flex:1;" :style="{color:$theme.setRiseFall(v.rateNum)}">
						{{ $fmt.decimal(v.rateNum)}}
					</text>
					<view class="table_cell" style="width: 20%;text-align: right;">
						<text class="rate" style="color: #FFF;width: 100%;display: inline-block;"
							:style="{backgroundColor:$theme.setRiseFall(v.rate)}">
							{{ $fmt.percent(v.rate)}}
						</text>
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ListTrack",
		props: {
			list: {
				type: Object,
				default: {}
			}
		},
		methods: {
			linkTo(val, gid) {
				this.$linkTo.stockDetail(val, gid);
			},
			track(val) {
				this.$emit('track', val);
			}
		}
	}
</script>

<style>

</style>