<template>
	<header class="common_header" :class="layout===$C.HEADER_1?`common_head`:``">
		<template v-if="layout===$C.HEADER_1">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(32)" class="btn_back"
				@tap="$linkTo.goBack()" style="padding-left: 16px;"></image>
			<view class="dynamic_title" :class="`slide_in_${dir}`">{{title}}</view>
			<template v-if="msg">
				<view class="btn_notify" @tap="$linkTo.notify()">
					<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(24)"></image>
				</view>
			</template>
			<slot></slot>
		</template>

		<!-- logo_head.png -->





		<template v-if="layout===$C.HEADER_2 || layout===$C.HEADER_3">
			<image :src="avatar==''?`/static/avatar.png`: avatar" mode="aspectFit" :style="$theme.setImageSize(60)"
				class="btn_menu" style="padding-left: 16px;" @tap="$linkTo.settings()"></image>
		</template>

		<template v-if="layout===$C.HEADER_2">
			<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(24)" class="btn_notify"
				style="padding-left: 12px;" @tap="$linkTo.notify()"></image>
			<view class="dynamic_data" style="padding-left: 12px;" :class="`slide_in_${dir}`">
				<view style="border-radius: 12px;line-height: 2;width: max-content;margin-left: auto;"
					:style="{backgroundColor:$theme.WIHTE_20}">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-left:9px;">
						<view style="color:#FFFFFF;padding-right:9px;">{{$fmt.amount(total,$util.isUS())}}</view>
						<view style="border-radius: 12px;padding:0 9px;min-width: 80px;"
							:style="{backgroundColor:$theme.WIHTE_80,color:$theme.setRiseFall(hold)}">
							{{$fmt.amount(hold,$util.isUS())}}
							<!-- <image :src="`/static/fill_${hold>0?`up`:`down`}.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)" style="padding-left: 12rpx;"></image> -->
						</view>
					</view>
				</view>
			</view>
		</template>

		<template v-if="layout===$C.HEADER_3">
			<view class="dynamic_data" style="padding-left: 12px;" :class="`slide_in_${dir}`">
				<view style="border-radius: 12px;line-height: 2;width: max-content;margin:0 auto;"
					:style="{backgroundColor:$theme.WIHTE_20}">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-left:9px;">
						<view style="color:#FFFFFF;padding-right:9px;">{{$fmt.amount(total,$util.isUS())}}</view>
						<view style="border-radius: 12px;padding:0 9px;min-width: 80px;"
							:style="{backgroundColor:$theme.WIHTE_80,color:$theme.setRiseFall(hold)}">
							{{$fmt.amount(hold,$util.isUS())}}
							<!-- <image :src="`/static/fill_${hold>0?`up`:`down`}.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)" style="padding-left: 12rpx;"></image> -->
						</view>
					</view>
				</view>
			</view>
			<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(36)" class="btn_notify"
				style="padding-right: 12px;" @tap="$linkTo.notify()"></image>
		</template>
	</header>
</template>

<script>
	/**
	 * 1. 回退按钮、动态标题、消息按钮
	 * 2. menu按钮图标、消息按钮、动态数据
	 * 3. menu按钮图标 、动态数据、消息按钮
	 */
	export default {
		name: "CommonHeader",
		props: {
			layout: {
				type: String,
				required: true
			},
			title: {
				type: String,
				default: ''
			},
			// 动态数据 total
			total: {
				type: Number,
				default: 0,
			},
			// 动态数据 hold
			hold: {
				type: Number,
				default: 0,
			},
			// 标题动画方向
			dir: {
				type: String,
				default: 'left',
			},
			msg: {
				type: Boolean,
				default: false
			},
			// avatar
			avatar: {
				type: String,
				default: ''
			},
		},
	}
</script>

<style>

</style>