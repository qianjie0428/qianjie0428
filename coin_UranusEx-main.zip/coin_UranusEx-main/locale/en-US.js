export default {
	// ===============  新增 2024.10.09 start  ==============
	LAUNCH_TIPS: [
		`Connecting...`,
		`Determining application version...`,
		`Network environment safety inspection in progress...`,
		`Connecting to international investing institutes...`,
		`connecting to institutional account permissions...`,
	],
	// ===============  新增 2024.10.07 start  ==============
	CONTRACT_HISTORY_PROFIT_RATE: `Profit rate`,
	// ===============  新增 2024.09.12 start  ==============
	UNPUBLISHED: `Unpublished`, // 未公布
	PUBLISH_DATE: `Publish Date`, // 公布日期

	// ===============  新增 2024.09.06 start  ==============
	CONTRACT_VIEW: `Click To View`,
	CONTRACT_ORDER_DATE: `Date`,
	// contract history
	CONTRACT_HISTORY_LOT: `Buy lots`,
	CONTRACT_HISTORY_MARGIN: `Margin`,
	CONTRACT_HISTORY_PRICE_BUY: `Buy price`,
	CONTRACT_HISTORY_PRICE_SELL: `Sell price`,
	CONTRACT_HISTORY_FEE: `Transaction fee`,
	CONTRACT_HISTORY_PROFIT: `Profit`,
	CONTRACT_HISTORY_DATE: `Date`,


	// ===============  新增 2024.09.03 start  ==============
	RULE_ITEMS: [
		` Invite friends to join Uranus, and you and your friends will have the opportunity to receive a digital currency blind box with a maximum value of $1,000.
		Step 1: Share your invitation link with your friends.
		Step 2: After your friend registers, if the contract transaction volume reaches 1,000 USDT within 7 days, you and your friend will each receive a digital currency blind box.
		Note: The friends you invite must log in to Uranus and complete the transaction before they can receive the blind box. If the friends you invite do not participate in the transaction within 7 days after registration, you and your friends will not be able to receive the blind box.`,
		` Each blind box can provide you with a maximum value of $1,000 in cryptocurrency, including $BTC, $ETH, $DOGE, $SHIB, $TRX, $USDT and other digital currencies and contract experience gold. Blind box rewards are updated irregularly, please refer to the actual activation.`,
		` Blind box rewards will be issued to your account within 24 hours, and you can view the rewards in "Recommendation Rewards".`,
		` There is no upper limit on the number of blind boxes. The more friends you invite, the more blind boxes you get. Go and invite more friends!`,
		` In addition to the blind box rewards, you can also get a permanent 30% commission for each transaction completed by your friends.`,
		` The invitation rebate reward will be issued between 20:00-21:00 (UTC+8) the next day after the invitee completes the transaction.`,
		` Sub-accounts cannot participate in this activity.`,
	],
	INVITE_INVITED: `Invited`, // 已邀请
	INVITE_ACT: `Activated`, // 已激活
	INVITE_DAY: `Day Rebate`, // 当日返佣
	INVITE_ACCRUE: `Accrue Rebate`, // 累计返佣
	INVITE_CODE: `Invitation Code`, // 邀请代码
	INVITE_LINK: `Invitation Link`, // 邀请链接
	INVITE_RULE: `Reward Rules`, // 规则

	// ===============  新增 2024.08.22 start  ==============
	TOTAL_ASSETS_BTC: `Total Asset Value(BTC)`,
	WEALTH_YIELD: `Rate of return`,
	WEALTH_TENOR: `Number of days`,
	WEALTH_CONTRACT: `Yield per Contract`,
	WEALTH_BTN_SUB: `Subscription`,
	WEALTH_KEYWORD: `Enter Keyword`,
	WEALTH_FILTER: `Filter`,

	FORGOT_PASSWORD: `Forgot Password ?`,
	FORGOT_TITLE: `Forgot Login Password`,
	FORGOT_ACCOUNT: `Account`,
	FORGOT_VERIFY_CODE: `Verify Code`,

	WITHDRAW_MINIMUM: `Minimum`,
	DEPOSIT_MINIMUM: `Minimum`,

	pingcang: 'Close order lot size',

	// ===============  新增 2024.08.20 start  ==============
	CTC_QTY: `Quantity`,
	CTC_RATE: `Exchange Rate`,
	CTC_TIP1: `Number of Transactions Greater Than`,
	CTC_TIP2: `Limit`,
	CTC_GENORDER_TITLE: `Order Generated,Please Complete Payment`,
	CTC_TOTAL: `Total Amount`,
	CTC_SELL_METHOD: `Seller's Payment Method`,
	CTC_NEXT_STEP: `Customer Support`,
	CTC_BUY_BTN: `Confirm to sell USDT`,
	CTC_BUY_BUY: `Confirm to purchase USDT`,
	CTC_BY_AMOUNT: `By Amount`,
	CTC_AVAILABLE: `Available`,
	CTC_USDT: `USDT`,
	CTC_USD: `USD`,
	CTC_MIN: 'Min quantity',
	CTC_MAX: 'Max quantity',
	CTC_BUY: `Buy`,
	CTC_SELL: `Sell`,
	INDICATOR_TITLE: `Indicator`,
	CANDLE_TITLE: `Candle`,
	// =================== 新增2024.08.20 end===================


	// ===============  新增 2024.08.16 start  ==============
	IEO_SUB_TOKEN_NAME: `Token name`,
	IEO_SUB_PRICE: `Token price`,
	IEO_SUB_QTY: `Quantity`,
	IEO_SUB_LOWER: `Lower limit`,
	IEO_SUB_UPPER: `Upper limit`,
	IEO_SUB_ST: `Start time`,
	IEO_SUB_ET: `End time`,
	IEO_SUB_WIN: `Winning announcement time`,
	IEO_SUB_ISSUE_QTY: `Issuance quantity`,
	IEO_SUB_BTN: `Subscribe`,

	IEO_SUB_RECORD_TIME: `Time`,
	IEO_SUB_TOKEN_NAME: `Token`,
	IEO_SUB_RESULT: `Result`,
	IEO_SUB_NEW_TIME: `Listing time`,

	// 存款提示
	DEPOSIT_TIPS_ITEMS_LIST: [
		`Please make sure to deposit only `,
		` assets to this address, other assets may result in irrecoverable.`,
		`Minimum deposit amount: `,
		`Deposits less than this amount will not be sent to your account and cannot be refunded.`,
		`Please make sure to check the security of your device and browser to prevent information from being tampered with or leaked.`
	],
	// 提款提示
	WITHDRAW_TIPS_ITEMS: [`Please check and enter the correct withdrawal address.`,
		`Sending to the wrong address will result in loss of funds.`,
		`Withdrawal fees will be deducted from the withdrawal amount.`
	],

	// =================== 新增2024.08.16 end===================


	// ===============  新增 2024.08.13 start  ==============
	TIP_FILL_EMAIL_CODE: `Please fill in the email verification code`,
	ACCOUNT_PHONE: `Phone Number`,
	TIP_ENTER_ACCOUNT_PHONE: `Please Enter Phone Number`,
	GET_SEND_CODE: `Getting verification code`,
	COMMON_SUBMIT: `Submit`,
	COMMON_ALL: `ALL`,
	COIN_TITLE: `Coins`,
	CONTRACT_TITLE: `Contract`,
	TXT_TIME: `Time`,
	TABS_TIMES: [`1M`, `5M`, `15M`, `30M`, `1H`, `4H`, `1D`, `1W`, `1M`],
	// Convert 闪兑
	CONVERT_TITLE: `Convert`,
	CONVERT_RECORD_TITLE: `Record`,
	CONVERT_AVAILABLE: `Available Balance`,
	CONVERT_RATES: `Today's Exchange Rates `,
	COIN_NAME: `Name`,
	COIN_PRICE: `Price`,
	COIN_CHANGE: `Change`,
	// Assets
	ASSETS_TITLE: `Assets`,
	// deposit
	DEPOSIT_TIP: `Tips`,
	DEPOSIT_TIP_ITEMS: [`Please make sure to deposit only USDT-ERC20 assets to this address, other assets may result in irrecoverable.
	`, `Minimum deposit amount: 1 USDT-ERC20.`,
		`Deposits less than this amount will not be sent to your account and cannot be refunded.`,
		`Please make sure to check the security of your device and browser to prevent information from being tampered with or leaked.`
	],
	// CTC
	CTC_TITLE: `C2C`,
	CTC_AMOUNT: `Amount`,
	CTC_REFERENCE_PRICE: `Reference Price`,
	CTC_RECORD_TITLE: `Record`,
	// Referral rewards
	REFERRAL_TITLA: `Referral`,
	REFERRAL_TIP: `Dear Uranus users,`,
	REFERRAL_DESC: `The Uranus referral program is designed to reward users who bring friends to our platform. Invite friends to register on Uranus using your referral link, and you will receive a lifetime commission of 30% of the transaction fee for every trade they complete. In addition, both you and your friends have a chance to win a mystery gift of crypto worth up to 1,500 USDT. Join us to make your referrals more competitive and maximize your passive income. Start inviting friends now and earn commissions`,

	// =================== 新增2024.08.13 end===================


	LAUNCH_TITLE: 'Online trading platform',
	LAUNCH_PROGRESS_TITLE: 'Loading...',
	TRANSLATE_TITLE: 'Please select language',
	WELCOME: `Welcome`,
	HELLO: '',

	// Check Network
	TIP_NETWORK_TYPE_NONE: 'There is no network or the network status is poor.',

	BTN_BUY: 'Buy',

	// API TIP
	API_TOKEN_EXPIRES: 'Login status has expired, please log in again',
	API_HTTP_ERROR: 'Request abnormality, please check your network',
	REQUEST_DATA: 'Loading . . .',
	API_EMPTY_DATA: 'Empty Data',
	API_EMPTY_CONTENT: 'Empty Content',
	API_SEND_CODE: 'Sending verification code',
	API_SEND_CODE_SUCCESS: 'Verification code sent successfully',
	API_SIGN_IN_NOW: 'Logging in',
	API_SIGN_UP_NOW: 'Registering',
	API_DATA_SUBMIT: 'Submitting',
	API_POST_SUCCESS: 'Success',
	API_GET_ACCOUNT_INFO: 'Get account information',
	API_STATUS_UPLOAD: 'Uploading...',

	// common text 
	COMMON_CANCEL: 'Cancel',
	COMMON_CONFIRM: 'Confirm',
	COMMON_NEXT_STEP: 'Next',
	// 输入值的小数位置最大不可超过设置值
	COMMON_TIP_ENTER_POINT_PREFIX: `Up to `,
	COMMON_TIP_ENTER_POINT_SUFFIX: ` decimal places`,
	COMMON_TOP_ENTER_NUMBER: 'Please enter a valid value',
	COMMON_COPY: 'Copy',
	COMMON_COPY_SUCCESS: 'Copy Success',
	COMMON_MIN_LENGTH: 'Minimum 8 Characters',
	COMMON_MORE: 'More',
	COMMON_BUY: 'Buy',
	COMMON_SELL: 'Sell',


	TABBAR_HOME: `Home`,
	TABBAR_MARKET: 'Market',
	TABBAR_COIN: 'Trade', // coin trade
	TABBAR_CONTRACT: 'Contract', // contract trade
	TABBAR_ACCOUNT: 'Account',





	// Wealth 交易
	TRADE_WEALTH_TITLE: 'DeFi',
	TRADE_WEALTH_RECORD_TITLE: 'Mining Record',
	TRADE_WEALTH_HOLD_RECORD: 'Hold Record',
	TRADE_WEALTH_HISTORY: 'History',
	TRADE_WEALTH_NEW_USERS: 'New Users',
	TRADE_WEALTH_BUY_DETAIL: 'Buy Detail',
	TRADE_WEALTH_RATE: 'Rate',
	TRADE_WEALTH_CYCLE: 'Cycle',
	TRADE_WEALTH_CYCLE_UNIT: 'Day',
	TEADE_WEALTH_MIN_PRICE: 'Min Price',
	// 买入弹层
	TRADE_WEALTH_BUY_AMOUNT: 'Please Enter Amount',
	TRADE_WEALTH_BUY_AMOUNT_TIP: 'Amount Must Bigger Min Price',
	// 持有列表
	TRADE_WEALTH_HOLD_RATE: 'Rate',
	TRADE_WEALTH_HOLD_CYCLE: 'Cycle',
	TRADE_WEALTH_HOLD_PRICE: 'Price',

	TRADE_WEALTH_HOLD_NUM: 'Num',
	TRADE_WEALTH_HOLD_PROFIT: 'Kar ve zarar',

	TRADE_WEALTH_HOLD_PAY_PRICE: 'Pay Price',
	// TRADE_WEALTH_HOLD_PROFIT: 'Profit',
	TRADE_WEALTH_HOLD_SN: 'SN',
	TRADE_WEALTH_HOLD_CRETIME: 'Create Time',
	TRADE_WEALTH_HOLD_ENDTIME: 'End Time',

	//理财
	LICAI_LICAI: 'Finance',
	LICAI_REN: 'Person',
	LICAI_YUGUSHOUYILV: 'Estimated yield',
	LICAI_ZHOUQI: 'Purchase days',
	LICAI_ZUIDIMAIRU: 'Purchase quantity',
	LICAI_MINGCHENG: 'Token name',
	LICAI_LEIXING: 'Type',
	LICAI_FAFANGRIQI: 'Release Date',
	LICAI_QINGSHURUMEIRUJINE: 'Please enter the purchase amount',
	LICAI_CHICANG: 'Position',
	LICAI_YISHUHUI: 'Redeemed',
	LICAI_KEFU: 'Contact Customer Service',


	// access
	SIGN_IN_TITLE: "Login Account",
	SIGN_UP_TITLE: "Register Account",
	BTN_SIGN_IN: 'Login',
	BTN_SIGN_UP: 'Register',
	BTN_SIGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Go To The Login',
	ACCOUNT_NAME: 'Account',
	ACCOUNT_EMAIL: 'Mobile or Email',
	ACCOUNT_PASSWORD: 'Password',
	VERIFY_ACCOUNT_PASSWORD: 'Verify Password',
	INVITATION_CODE: 'Invitation Code',
	TIP_REMEMBER_PWD: 'Remember Password',
	TIP_AGREE: 'You have agreed to our',
	TIP_PRVITE_PACT: '(Privacy Agreement)',
	TIP_VERIFY_CODE: 'Verify COde',
	TIP_ENTER_EMAIL: 'Enter Your Email Account',
	TIP_ENTER_EMAIL_CODE: 'Enter Your Email Code',
	TIP_EMAIL_CODE: 'Email Code',

	TIP_ENTER_ACCOUNT_NAME: 'Enter Your Mobile or Email',
	TIP_ENTER_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_VERIFY_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_INVITATION_CODE: 'Enter Your Invitation Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_CHECK_AGREE: 'Please checked agree',
	TIP_SUCCESS_SIGNIN: 'Sign In Suceesfully',
	TIP_SUCCESS_REGISTER: 'Registration Suceesfully, Please Sign In',
	TIP_SIGN_OUT_SUCCESS: 'Sign Out Suceesfully',

	Heyue_baozhengjin: "Margin",

	PRVITE_PACT_TITLE: 'Privte And Pact',
	ABOUT_US_TITLE: 'About US',

	// card label
	CARD_ASSETS_TOTAL: 'Total',
	CARD_ASSETS_AVAIL: 'Avail',
	CARD_ASSETS_FREEZE: 'Freeze',
	// card btn text
	CARD_BTN_TREAD_LOG: 'Record',


	// search
	SEARCH_TITLE: 'Search',
	TIP_SEARCH: 'Enter Coin',
	SEARCH_HISTORY: 'History',
	SEARCH_CLEAR: 'Clear',
	LOADING_SEATCH: 'Searching...',
	SEATCH_RESULT_COUNT: 'Result Count',
	SEATCH_HOT_PICKS: 'Hot Picks',



	// 期权
	Qiquan_name: 'Options',
	Qiquan_price: 'Please enter amount',
	Qiquan_zhang: 'Buy up',
	Qiquan_die: 'Buy dip',
	Qiquan_time: 'Select expiration time',
	Qiquan_profit: 'Profit',
	Qiquan_result: 'Trading Results',
	Qiquan_progress: 'Trading in progress...',
	Qiquan_name_coin: 'Name',
	Qiquan_type: 'Type',
	Qiquan_BUY_PRICE: 'Buy Price',
	Qiquan_now_PRICE: 'Now Price',
	Qiquan_ordersn: 'Order sn',
	Qiquan_Amount: 'Transaction Amount',
	Qiquan_Amount1: 'Amount',

	Qiquan_Expected: 'Expected profit and loss',
	Qiquan_pl: 'Profit and Loss',
	Qiquan_pl_Money: 'Profit and Loss Money',
	Qiquan_buytime: 'Buy Time',
	Qiquan_ying: 'Profit',
	Qiquan_shu: 'loss',
	Qiquan_success: 'Successful transaction',
	Qiquan_endprice: 'End Amount',


	max_ping1: 'Can close',
	max_ping2: 'positions',

	// page/market/index
	MARKET_INDEX_TAB_TRACK: 'Track', // 关注
	MARKET_INDEX_TAB_STOCK: 'Market', // 股票市场
	MARKET_INDEX_TAB_HOP: 'Hot', // 热门股票
	MARKET_INDEX_TAB_KPI: 'Index', // 市场指标
	MARKET_INDEX_TAB_RISE: 'Rise', // 
	MARKET_INDEX_TAB_FALL: 'Fall', // 
	MARKET_INDEX_TAB_COIN: 'Coin', // Coin
	// 去市场看看
	MARKET_INDEX_TIP_GO_COIN: 'Go Coin',


	// 个人中心
	ACCOUNT_CENTER_TITLE: 'Account',


	COIN_PRICE_TYPE_MARKET: 'Market',
	COIN_PRICE_TYPE_LIMIT: 'Limit',

	// Coin overview
	COIN_VIEW_TAB_MINUTE: 'Minute',
	COIN_VIEW_TAB_DAILY: 'Daily',
	COIN_VIEW_TAB_MONTHLY: 'Monthly',
	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_VIEW_BTN_BUY: 'Buy',
	COIN_VIEW_BTN_SELL: 'Sell',
	COIN_VIEW_OPEN: 'Open',
	COIN_VIEW_CLOSE: 'Close',
	COIN_VIEW_HIGH: 'High',
	COIN_VIEW_LOW: 'Low',
	COIN_VIEW_AMOUNT: 'Trade Amount',

	COIN_VIEW_TAB_DEPTH: 'Depth',
	COIN_VIEW_TAB_TRADE: 'Latest Trade',

	COIN_VIEW_TRADE_TITLE_DATE: 'Date Time',
	COIN_VIEW_TRADE_TITLE_PRICE: 'Price',
	COIN_VIEW_TRADE_TITLE_AMOUNT: 'Quantity',

	COIN_VIEW_DEPTH_TITLE_PRICE: 'Price',
	COIN_VIEW_DEPTH_TITLE_BUY_QTY: 'Buy QTY',
	COIN_VIEW_DEPTH_TITLE_SELL_QTY: 'Sell QTY',

	COIN_BUY_TITLE_PRICE: 'Price',
	COIN_BUY_TITLE_QTY: 'Quantity',

	COIN_BUY_BALANCE: 'Balance',
	COIN_BUY_MAX_QTY: 'Max QTY',
	COIN_BUY_TOTAL_AMOUNT: 'Margin',
	COIN_BUY_TIP_ENTER_QTY: 'Enter Quantity',
	COIN_BUY_TIP_ENTER_PRICE: 'Enter Amount',
	COIN_BUY_TIP_ENTER_POINT: 'Up to 4 decimal places',

	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',

	COIN_CUR_ORDER: 'Current Orders',
	COIN_TRADE_RECORD: 'Trade Record',

	COIN_RECORD_TITLE: 'Record',
	COIN_RECORD_CURRENT: 'Current',
	COIN_RECORD_HISTORY: 'History',
	COIN_RECORD_SUCCESS: 'Success',

	COIN_RECORD_TIP_CUR_COIN: 'Only show the current coin',

	COIN_CURRENT_PRICE: 'Price',
	COIN_CURRENT_QTY: 'Quantity',
	COIN_CURRENT_TOTAL: 'Total',
	COIN_CURRENT_BTN_CANCEL: 'Cancel',

	COIN_HISTORY_TRADE_FEE_buy: 'Buy Fee',

	COIN_HISTORY_TRADE_FEE: 'Close Fee',
	COIN_HISTORY_TRADE_PRICE: 'Trade Price',
	COIN_HISTORY_TRADE_QTY: 'Trade Volume',

	COIN_BUY_PRICE: 'Buy Price',
	COIN_CLOSE_PRICE: 'Close Price',

	COIN_HISTORY_TIP_CANCEL: 'Cancel',
	COIN_HISTORY_TIP_TRADE: 'Trade',
	ZhuangTai: 'Status',
	// Contract 
	CONTRACT_DETAIL_BNT_BUY: 'Buy(Long)',
	CONTRACT_DETAIL_BTN_SELL: 'Sell(Short)',
	CONTRACT_PROFIT: 'Profit Amount',
	CONTRACT_LOSS: 'Loss Amount',
	CONTRACT_PROFIT_LOSS_SET: 'Take Profit And Stop Loss(Optional)',
	CONTRACT_LEVER: `Lever`,
	CONTRACT_FEE: 'Fee',
	CONTRACT_DESC_MODAL_TITLE: 'Contract Desc',
	CONTRACT_DESC_BTN: 'OK',
	CONTRACT_DESC_CONTENT: [
		`Contract Deposit: (Purchase Number*Nominal Value)/Multiple, nominal value 1000.`,
		`Number of vacancies: Balance sheet numbers, margins, margin fees.`,
		`Handling Fee: Margin * Currency Handling Rate (0.05%)*Multiple.`,
		`User Rights: User Balance + Total Margin + Position Gain/Loss.`,
		`Risk Ratio: User Privilege/Total Margin 100, generally less than 20% for liquidation.`
	],


	CONTRACT_RECORD_CURRENT: 'Current',
	CONTRACT_RECORD_HOLD: 'Holding',
	CONTRACT_RECORD_HISTORY: 'History',

	CONTRACT_RECORD_TIP_CUR_CONTRACT: 'Only show current contract',

	CONTRACT_HOLD_QUICK_CLOSE: 'All Close',

	CONTRACT_HOLD_BTN_PROFIT_LOSS: 'Take Profit And Stop Loss',
	CONTRACT_HOLD_BTN_CLOSE: 'Close Order',

	CONTRACT_HOLD_BUY_PRICE: 'Buy price', // 单价	
	CONTRACT_HOLD_BUY_QTY: 'Buy lot size', // 购买数量
	CONTRACT_HOLD_BUY_TOTAL: 'Margin', // 购买总价

	CONTRACT_HOLD_CURRENT_PRICE: 'Current Price',
	CONTRACT_HOLD_BUY_FEE: 'Fee', // 手续费
	CONTRACT_HOLD_BUY_PL: `Profit or Loss`,

	CONTRACT_RATE: `Risk/Reward`,

	CONTRACT_HOLD_TAKE_PROFIT: 'Take Profit',
	CONTRACT_HOLD_STOP_LOSS: 'Stop Loss',
	CONTRACT_HOLD_FLOAT_PL: `Float P & L`,

	CONTRACT_PROFIT_LOSS_MODAL_TITLE: 'Take Profit And Stop Loss',

	CONTRACT_TAKE_PROFIT_AMOUNT: 'Take Profit Amount',
	CONTRACT_STOP_LOSS_AMOUNT: 'Stop Loss Amount',
	CONTRACT_CLOSE_QTY: 'Enter Quantity',
	CONTRACT_ESTIMATED_PROFIT: 'Estimated Profit',
	CONTRACT_ESTIMATED_LOSS: 'Estimated Loss',
	CONTRACT_TIP_ENTER_PROFIT_BUY: 'Profit must be greater than price',
	CONTRACT_TIP_ENTER_PROFIT_SELL: 'Profit must be less than price',
	CONTRACT_TIP_ENTER_LOSS_BUY: 'Loss must be less than price',
	CONTRACT_TIP_ENTER_LOSS_SELL: 'Loss must be greater than price',

	// Notify
	NOTIFY_TITLE: 'Announcement',


	// Profile
	PROFILE_AUTH_VERIFIED: 'Verified',
	PROFILE_AUTH_UNVERIFIED: 'Unverified',
	PROFILE_SETTING_TITLE: 'Setting',
	PROFILE_SERVICE_TITLE: 'Support',
	PROFILE_ADDRESS: 'Withdraw Address', // 提现地址
	PROFILE_BANK: 'Bank Account',
	PROFILE_DEFAULT_COIN: 'Default Coin',
	PROFILE_LANGUAGE: 'Language',
	PROFILE_SIGN_IN_PASSWORD: 'Sign In Password',
	PROFILE_PAY_PASSWORD: 'Pay Password',

	PROFILE_QA: `Q & A`,
	PROFILE_PACT: 'Privte And Pact',
	PROFILE_SHARE: 'Referral',
	PROFILE_SERVICE: 'Support',
	PROFILE_ABOUT: 'About Us',

	SHARE_LINK: 'Share Link',
	SHARE_COPYLINK: 'Copy Share Link',

	// account assets and contract
	ACCOUNT_TAB_ASSETS_TITLE: 'Capital Account',
	ACCOUNT_TAB_CONTRACT_TITLE: 'Contract Account',
	ACCOUNT_HIDE_ZERO_DATA: 'Hide Balance Assets',

	ASSETS_LIST_BALANCE: 'Available',
	ASSETS_LIST_USING: 'Using',
	ASSETS_LIST_FREEZE: 'Frozen',

	ASSETS_RECORD_TAB_HOLD: 'Hold',
	ASSETS_RECORD_TAB_SELL: 'Sell',

	ASSETS_RECORD_HOLD_STATUS: 'Hold',

	ASSETS_CONTRACT_RECORD: 'Contract Order',


	// Deposit
	DEPOSIT_TITLE: 'Deposit',
	DEPOSIT_RECORD_TITLE: 'Deposit Record',
	DEPOSIT_ADDRESS: 'Address',
	DEPOSIT_AMOUNT: 'Amount',
	DEPOSIT_ENTER_AMOUNT: 'Enter Amount',
	DEPOSTI_UPLOAD: 'Upload',
	DEPOSIT_RECORD_AMOUNT: 'Trade Amount',
	DEPOSIT_RECORD_SN: 'Order SN',
	DEPOSIT_RECORD_CT: 'Date Time',
	DEPOSIT_RECORD_DESC: 'Desc',
	DEPOSIT_COIN: 'Coin',

	// withdraw
	WITHDRAW_TITLE: 'Withdrawal',
	WITHDRAW_ADDRESS: 'Address',
	WITHDRAW_AMOUNT: 'Quantity',
	WITHDRAW_ENTER_AMOUNT: 'Please Enter Quantity',
	WITHDRAW_PASSWORD: 'Password',
	WITHDRAW_ENTER_PASSWORD: 'Enter Password',
	WITHDRAW_MIN_AMOUNT: 'Minimum Amount',
	WITHDRAW_AVAILABLE_AMOUNT: 'Balance',
	WITHDRAW_FEE_AMOUNT: 'Transaction Fee',
	WITHDRAW_RECORD_TITLE: 'Withdrawal Record',
	WITHDRAW_RECORD_AMOUNT: 'Trade Amount',
	WITHDRAW_RECORD_SN: 'Order SN',
	WITHDRAW_RECORD_CT: 'Date Time',
	WITHDRAW_RECORD_DESC: 'Trade Desc',
	WITHDRAW_RECORD_FEE: 'Fee',
	WITHDRAW_RECORD_ADDRESS: 'Address',
	WITHDRAW_RECORD_COIN: 'Coin',
	WITHDRAW_COIN: 'Coin',
	WITHDRAW_BANK_CODE: 'Bank Account',
	WITHDRAW_TIP_ADD_ADDRESS: 'Go Add Address',
	WITHDRAW_TIP_ENTER_ADDRESS: 'Enter Address',
	WITHDRAW_TIP_CHOOSE: 'Choose Coin',
	WITHDRAW_MODAL_TITLE: 'Want to cancel a withdrawal?',

	// 劃轉
	TRANSFER_TITLE: 'Transfer',
	TRANSFER_IN_ACCOUNT: 'Transfer In Account',
	TRANSFER_OUT_ACCOUNT: 'Transfer Out Account',
	TRANSFER_TIP: 'The transfer-in account cannot be the same as the transfer-out account',
	TRANSFER_AMOUNT: 'Transfer Amount',
	TRANSFER_BALANCE: 'Balance',
	TRANSFER_ASSETS_TITLE: 'Capital',
	TRANSFER_CONTRACT_TITLE: 'Contract',
	TRANSFER_Options_TITLE: 'Options',


	TRANSFER_RECORD_TITLE: 'Transfer Record',
	TRANSFER_RECORD_DESC: 'Desc',
	TRASNFER_RECORD_REVIEW: 'Under review', // 审核中
	TRANSFER_RECORD_PASS: 'Passed', // 已通过
	TRANSFER_RECORD_REJECT: 'Rejected', // 已拒绝

	// 变更登入密码、变更支付密码
	PASSWORD_OLD: 'Old Password',
	PASSWORD_NEW: 'New Password',
	PASSWORD_VERIFY: 'Verify New Password',
	PASSWORD_ENTER_OLD: 'Enter Old Password',
	PASSWORD_ENTER_NEW: 'Enter New Password',
	PASSWORD_ENTER_VERIFY: 'Verify New Password',
	PASSWORD_TIP_VERIFY_FAIL: 'New password is different',

	// Address
	ADDRESS_INDEX_TITLE: 'Withdraw Address',
	ADDRESS_ADD_TITLE: 'Add Withdraw Address',
	ADDRESS_TIP_ENTER_ADDRESS: 'Enter Address',
	ADDRESS_CHOOSE_COIN: 'Choose Coin',
	ADDRESS_WALLET_ADDRESS: 'Wallet Address',
	ADDRESS_WALLET_IMAGE: 'Upload Image',

	// TRADE_IPO
	TRADE_IPO_TITLE: 'IEO',
	TRADE_IPO_NAME: 'Token name',
	TRADE_IPO_RECORD_TITLE: 'IEO Record',
	TRADE_IPO_LIST_PRICE: 'Token price',
	TRADE_IPO_LIST_TOTAL: 'Total',
	TRADE_IPO_LIST_RC: 'Reserve Capacity',
	TRADE_IPO_LIST_LOCK: 'Lock',
	TRADE_IPO_LIST_DAY: 'Day',
	TRADE_IPO_DETAIL_TITLE: 'Detail',
	TRADE_IPO_PRICE: 'Price',
	TRADE_IPO_CT: 'Date Time',
	TRADE_IPO_SN: 'Order SN',
	TRADE_IPO_RECORD_DESC: 'Desc',
	TRADE_IPO_DETAIL_URL: 'White Paper',
	TRADE_IPO_DETAIL_WEBSITE: 'Website',
	TRADE_IPO_DETAIL_COIN_DESC: 'Coin Desc',
	TRADE_IPO_RECORD_APPLY_AMOUNT: 'Apply Amount',
	TRADE_IPO_RECORD_APPLY: 'Apply',
	TRADE_IPO_RECORD_SUCCESS: 'Success',
	// IPO 交易 申购成功记录
	TRADE_IPO_SUCCESS_SUB: 'Subscription',
	TRADE_IPO_SUCCESS_PRICE: 'Price',
	TRADE_IPO_SUCCESS_QUANTITY: 'Quantity',
	TRADE_IPO_SUCCESS_AMOUNT: 'Success Amount',
	TRADE_IPO_SUCCESS_FREEZE: 'Freeze',
	TRADE_IPO_SUCCESS_CT: 'Date Time',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order SN',
	TRADE_IPO_SUCCESS_UNPAY_AMOUNT: 'Unpay Amount',

	// Capital flow
	FLOW_TITLE: 'Capital Flow',
	FLOW_AMOUNT_AFTER: 'Balance',
	FLOW_AMOUNT_BEFORE: 'Amount Before',
	FLOW_AMOUNT: 'Amount',
	FLOW_CT: 'Date',
	FLOW_DESC: 'Details',

	// AUTH
	AUTH_TITLE: 'KYC',
	AUTH_REAL_NAME: 'Real Name',
	AUTH_CARD_ID: 'Card ID',
	AUTH_CARD_F: 'Card Front Image',
	AUTH_CARD_B: 'Card Back Image',

	// 借贷 Borrow
	BORROW_TITLE: 'Loan',
	BORROW_TIP_UPLOAD: 'Please upload your credentials',
	BORROW_TIP_UPLOAD_TIP: 'Upload your credit score',
	BORROW_BTN_UPLOAD: 'Upload',
	BORROW_BTN_NOW: 'Borrow Now',
	BORROW_TIP_SUCCESS: 'Congratulations, the review was successful!',
	BORROW_RECORD: 'Apply Record',
	BORROW_RECORD_AMOUNT: 'Amount',
	BORROW_RECORD_LOANS: 'Loans',
	BORROW_RECORD_STATUS_APPLY: 'Apply',
	BORROW_RECORD_STATUS_PASS: 'Passed',
	BORROW_RECORD_STATUS_FAIL: 'Fail',
	BORROW_LINK_SERVICE: 'Contact Customer Service',
	BORROW_TIP_YOUR_SCORE: 'Your credit score',
	BORROW_REUPLOAD: 'Click Reupload',
	BORROW_TIP_UPLOAD_FAIL: 'Audit failure',
	BORROW_ENTER_AMOUNT: 'Please Enter Amount',
	BORROW_TIP_REVIEW: 'Under Review',

	CTC_LISHI: 'History',

}