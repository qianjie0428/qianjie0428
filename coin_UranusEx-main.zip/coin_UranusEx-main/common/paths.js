// 页面URL 硬编码 通常用于指定跳转
export const LAUNCH = `/pages/launch/index`; // 启动页
export const ACCOUNT_ACCESS = `/pages/account/access`; // 登入、注册
export const HOME = `/pages/home/index`; // 主页

export const FORGOT = `/pages/account/forgot`;

export const SERVICE = `/pages/service`; // 客服
export const ABOUT_US = `/pages/about`; // 关于
export const PRVITE_PACT = `/pages/pact`; // 用户隐私协议
export const SHARE = `/pages/share`; // 分享
export const QA = `/pages/qa`; // 常见问题
export const ADDRESS_INDEX = `/pages/address/index`; // address
export const ADDRESS_ADD = `/pages/address/add`; // address

export const SEARCH = `/pages/search/index`; // 搜索 
export const NOTIFIY_INDEX = `/pages/notify/index`; // 公告
export const NOTIFY_DETAIL = `/pages/notify/detail`; // 公告 詳情


export const TRADE_WEALTH = `/pages/trade/wealth/index`; // Wealth 理财
export const TRADE_WEALTH_RECORD = `/pages/trade/wealth/wealthRecord`; // Wealth 记录

// Coin、Track etc
export const MARKET_INDEX = `/pages/market/index`;

// contract
export const CONTRACT_INDEX = `/pages/contract/index`; // contract
export const CONTRACT_RECORD = `/pages/contract/record`; // contract record

// coin trade
export const COIN_INDEX = `/pages/coin/index`; // coin trade
export const COIN_DETAIL = `/pages/coin/detail`; // coin trade detail
export const CION_RECORD = `/pages/coin/record`; // coin trade record

export const DEPOSIT_INDEX = `/pages/deposit/index`; // deposit
export const DEPOSIT_RECORD = `/pages/deposit/record`; // deposit record

export const WITHDRAW_INDEX = `/pages/withdraw/index`; // withdraw
export const WITHDRAW_RECORD = `/pages/withdraw/record`; // withdraw record

export const TRANSFER_INDEX = `/pages/transfer/index`; // Transfer
export const TRANSFER_RECORD = `/pages/transfer/record`; // Transfer

export const CONVERT_INDEX = `/pages/convert/index`; // convert
export const CONVERT_RECORD = `/pages/convert/record`; // convert

export const CTC_INDEX = `/pages/ctc/index`; // ctc
export const CTC_RECORD = `/pages/ctc/record`; // ctc
// 
export const CTC_GENORDER = `/pages/ctc/genOrder`; // ctc
export const CTC_TRADE = `/pages/ctc/trade`; // ctc trade

export const ASSETS_INDEX = `/pages/assets/index`; // Assets
export const ASSETS_REACORD = `/pages/assets/record`; // Assets record
export const ASSETS_CONTRACT = `/pages/assets/contract`; // Assets contract

export const PROFILE_INDEX = `/pages/profile/index`; // 个人中心 页面
// 变更登入密码、变更支付密码
export const ACCOUNT_PASSWORD = `/pages/account/password`;

export const TRADE_IPO = `/pages/trade/ipo/index`; // IPO 交易
export const TRADE_IPO_DETAIL = `/pages/trade/ipo/detail`; // IPO 详情
export const TRADE_IPO_RECORD = `/pages/trade/ipo/record`; // IPO 记录

export const CAPITAL_FLOW = `/pages/account/flow`; // Capital flow 交易记录

export const ACCOUNT_AUTH = `/pages/account/auth`; // 认证

export const BORROW_INDEX = `/pages/borrow/index`; // borrow
export const BORROW_RECORD = `/pages/borrow/record`; // borrow record

// ============== old  =========================


// export const ACCOUNT_CENTER = `/pages/account/center`; // 个人中心

// export const ACCOUNT_BANK_CARD = `/pages/account/bankCard`; // 银行卡 绑定换绑
// export const ACCOUNT_TRADE_LOG = `/pages/account/tradeLog`; // 账户交易记录
// export const ACCOUNT_AVATAR = `/pages/account/avatar`; // 变更头像
// export const ACCOUNT_LOAN = `/pages/account/loan`; // 贷款
// export const ACCOUNT_CREDIT_SCORE = `/pages/account/creditScore`; // 信用积分
// export const ACCOUNT_NOMINEE = `/pages/account/nominee`; // 遗传继承

// export const TRADE_DAY = `/pages/trade/day/index`; // 日内交易
// export const TRADE_LARGE = `/pages/trade/large/index`; // 大宗交易
// export const TRADE_IPO = `/pages/trade/ipo/index`; // ipo交易
// // export const TRADE_EA = `/pages/trade/ea/index`; // EA 交易
// export const TRADE_VIP = `/pages/trade/vip/index`; // VIP 抢筹
// export const TRADE_ISSUANCE = `/pages/trade/issuance/index`; // 新股配售


// // 市场概况
// export const MARKET_OVERVIEW = `/pages/market/overview`;

// // 单股概况
// export const STOCK_OVERVIEW = `/pages/stock/overview`;
// // 单股买入
// export const STOCK_BUY = `/pages/stock/buy`;