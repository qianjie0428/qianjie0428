<template>
	<view>
		<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
			<block v-for="(item,index) in $lang.MARKET_HOT_TABS" :key='index'>
				<view class="btn_common" :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</scroll-view>

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block"
					style="display: flex;align-items: center;padding:10px;border-radius: 8rpx;box-shadow: none;"
					@click="link(item.code)">

					<view style="width: 90rpx;text-align: center;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex: 0 0 70%;padding-left: 6px;">
						<view style="font-size: 32rpx;color: #121212">
							{{item.name}}
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)" style="padding-left: 20rpx;"></image>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="font-size: 28rpx;color: #121212">
								{{$util.formatMoney(item.price)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<view style="font-size: 26rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{$util.formatMoney(item.close)}}{{$lang.CURRENCY_UNIT}}
							</view>
							<view :style="$theme.setStockRiseFall(item.rate>0)">
								{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
					</view>

					<view style="margin-left: auto;">
						<image :src="`/static/stock_${item.follow?'follow':'unfollow'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(36)" @click.stop="handleUnFollow(item.gid)">
						</image>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketHotTop',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				curTab: 0,
			}
		},
		created() {
			this.getData();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},
			// 设置样式
			setStyle(val, w = 50) {
				return {
					minWidth: `${w}rpx`,
					margin: '8rpx',
					padding: `8rpx 12rpx`,
					borderRadius: `16rpx`,
					backgroundColor: val ? this.$theme.SECOND : this.$theme.TRANSPARENT,
					color: val ? '#FFFFFF' : '#333333',
					textAlign: 'center',
				}
			},
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				this.getData();
			},
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: this.curTab
				})
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		}
	}
</script>
<style lang="scss" scoped>
	.btn_common {
		padding: 6rpx 12rpx;
		font-size: 28rpx;
		text-align: center;
		margin-right: 12rpx;
		display: inline-block;
	}
</style>