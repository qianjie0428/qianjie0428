<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;padding-bottom: 200rpx;">
		<header class="common_header" style="background-color: #FFFFFF;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.WITHDRAW_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="">
			<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
				<view style="display: flex;align-items: center;" @tap="chooseCoin()">
					<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{curMode.name}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;">
							<!-- <view :style="setStyle()">{{$lang.WITHDRAW_COIN}}</view> -->
							<image src="/static/arrow_right.png" mode="aspectFit" style="padding-left: 20rpx;"
								:style="$theme.setImageSize(20)"></image>
						</view>
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
				<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.WITHDRAW_ADDRESS}}</view>
				<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{curMode.name}}</view>
			</view>
			<view class="common_block" style="padding:24rpx;border-radius: 24rpx;">
				<template v-if="isAddAddress">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="font-size: 28rpx;width: 80%;word-wrap: break-word;"
							:style="{color:$theme.LOG_VALUE}">
							{{curAddress}}
						</view>
						<view style="margin-left: auto;" :style="setStyle()" @click="isaddressList=true">Select</view>
					</view>
				</template>
				<template v-else>
					<view style="text-align: center;font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}"
						@tap="linkAddress()">
						{{$lang.WITHDRAW_TIP_ADD_ADDRESS}}
					</view>
				</template>
			</view>
			<!-- 
			<template v-else>
				<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
					<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.WITHDRAW_BANK_CODE}}</view>
				</view>
				<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_VALUE}"> {{bankCode}}</view>
				</view>
			</template> -->

			<view style="padding-left:40rpx;padding: 24rpx 40rpx;display: flex;align-items: center;">
				<view style="font: 28rpx;font-weight: 700;">
					{{$lang.WITHDRAW_AMOUNT}}
				</view>
				<view style="margin-left: auto;">
					<template v-if="userInfo">
						<text style="padding-right: 24rpx;"
							:style="{color:$theme.LOG_LABEL}">{{$lang.WITHDRAW_AVAILABLE_AMOUNT}}:</text>
						<text
							:style="{color:$theme.SECOND}">{{$util.formatCurrency(userInfo.money)+ `  `+userInfo.name}}</text>
					</template>
				</view>

			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
				<input v-model="amount" type="digit" :placeholder="$lang.WITHDRAW_MINIMUM +` ` +curMode.min"
					:placeholder-style="$theme.setPlaceholder()"></input>
				<view style="margin-left: auto;">
					<view style="display: flex;align-items: center;padding-right: 16rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{curMode.name}}</view>
						<view :style="{color:$theme.PRIMARY}" style="padding-left: 12rpx;" @click="handleAll()">
							{{$lang.COMMON_ALL}}
						</view>
					</view>
				</view>
			</view>
			<template v-if="userInfo">
				<view
					style="padding: 0 40rpx;line-height: 1.6;display: flex;align-items: center;justify-content: space-between;">
					<text :style="{color:$theme.LOG_LABEL}">{{$lang.WITHDRAW_FEE_AMOUNT}}</text>
					<text :style="{color:$theme.SECOND}">{{$util.formatCurrency(fee)+ `  `+userInfo.name}}</text>
				</view>
			</template>

			<view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;margin-top: 24rpx;">
				{{$lang.WITHDRAW_PASSWORD}}
			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.WITHDRAW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
				</template>
				<template v-else>
					<input v-model="password" type="password" :placeholder="$lang.WITHDRAW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					style="margin-left: auto;padding-right:20px;" :style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
		</view>

		<view class="common_block" style="padding:24rpx;border-radius: 24rpx;margin-top: 40rpx;">
			<view style="padding-bottom: 12rpx;">{{$lang.DEPOSIT_TIP}}</view>
			<block v-for="(item,index) in $lang.WITHDRAW_TIPS_ITEMS" :key="index">
				<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}"> {{item}}</view>
			</block>
		</view>

		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;background-color: #FFFFFF;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="name"></u-picker>

		<!-- 地址选择 -->
		<!-- <u-picker :show="isaddressList" keyName="address" :columns="[coin_addresslist]" @cancel="isaddressList=false"
			@confirm="confirmAddress" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"></u-picker> -->

		<u-popup :show="isaddressList" mode="bottom" @close="isaddressList=false" @open="isaddressList=true" closeable>
			<view style="padding:80rpx 40rpx;">
				<view style="padding-top: 20rpx;height: 560px;overflow-y: auto;padding-bottom: 100rpx;">
					<block v-for="(item,index) in coin_addresslist" :key="index">
						<view @click="confirmAddress(item)" style="line-height: 2.4;border-bottom: 1px Solid #ECECEC;">
							<view style="font-size: 28rpx;font-weight: 700;">{{item.name}}</view>
							<view style="margin-left: auto;">
								{{item.address}}
							</view>
						</view>
					</block>
				</view>
			</view>
		</u-popup>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				curMode: null, // 当前选中充值模式
				curAddress: '', // 当前选中coin的address
				amount: '', // 输入金额
				password: '', // 输入密码
				isShow: false, // 密码显隐
				// bankCode: '', // bank account
				userInfo: null,
				addressList: [], // 用户设置的conin address 列表
				isAddAddress: false, // 是否显示添加地址按钮
				coin_addresslist: "",
				isaddressList: false,
				type: 1
			};
		},
		computed: {
			coinList() {
				return [{
						name: 'ERC20-USDT',
						min: 10,
						fee: 0.05,
					}, {
						name: 'TRC20-USDT',
						min: 10,
						fee: 0.05,
					},
					{
						name: 'BTC',
						min: 0.001,
						fee: 0.01,
					},
					{
						name: 'ETH',
						min: 0.001,
						fee: 0.01,
					}, {
						name: 'TRX',
						min: 100,
						fee: 0.05,
					}
				]
			},
			// 如果选择非银行
			isCoin() {
				return !this.curMode.includes('Bank');
			},
			// 计算手续费
			fee() {
				// 根据选择币种，计算手续费
				if (this.amount > 0) {
					return Number((this.amount * this.curMode.fee).toFixed(4));
				} else {
					return 0;
				}
			}
		},
		onShow() {
			this.isAnimat = true;
			this.isShow = uni.getStorageSync('show');
			this.getAddressList();
			this.getAccountInfo();
			this.curMode = this.coinList[0];
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// all 事件
			handleAll() {
				this.amount = this.userInfo.money;
			},

			linkRecord() {
				uni.navigateTo({
					url: this.$paths.WITHDRAW_RECORD
				})
			},
			// 跳转到添加地址页面
			linkAddress() {
				uni.navigateTo({
					url: this.$paths.ADDRESS_ADD
				})
			},

			// 選擇一種coin
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curMode = e.value[0];
				this.isShowCoinList = false;

				const temp = this.addressList.filter(item => item.name == this.curMode.name);
				this.isAddAddress = temp && temp.length >= 1;
				this.coin_addresslist = temp;

				if (e.value[0].name == 'ERC20-USDT') {
					this.name = "USDT"
					this.type = 1
				} else if (e.value[0].name == 'TRC20-USDT') {
					this.name = "USDT"
					this.type = 2
				} else if (e.value[0].name == 'BTC') {
					this.name = e.value[0].name
					this.type = 3
				} else if (e.value[0].name == 'ETH') {
					this.name = e.value[0].name
					this.type = 4
				} else if (e.value[0].name == 'TRX') {
					this.name = e.value[0].name
					this.type = 5
				}

				if (this.isAddAddress) this.curAddress = temp[0].address;
				
				this.getAccountInfo()
				// console.log(`list:`, this.isAddAddress, this.curAddress);
			},
			confirmAddress(val) {
				console.log(`confirmAddress:`, val);
				this.curAddress = val.address;
				this.isaddressList = false;
				// console.log(`list:`, this.isAddAddress, this.curAddress);
			},

			async getAddressList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/fastinfo`);
				if (!result) return false;
				console.log(`result:`, result);
				if (result.bank_card_info) {
					this.addressList = !result.bank_card_info || result.bank_card_info.length <= 0 ? [] :
						result.bank_card_info.map(item => {
							return {
								name: item.huobi,
								address: item.address,
							}
						});
					console.log(`list:`, this.addressList);
					// 初始获取数据时，设置默认值的地址

					const temp = this.addressList.filter(item => item.name == this.curMode.name);
					this.isAddAddress = temp && temp.length >= 1;
					this.coin_addresslist = temp;
					console.log(7777, this.coin_addresslist)
					if (this.isAddAddress) this.curAddress = temp[0].address;
					// console.log(`list:`, this.isAddAddress, this.curAddress);
				}
			},

			async handleSubmit() {
				if (this.curMode.name == '') {
					uni.showToast({
						title: this.$lang.WITHDRAW_TIP_CHOOSE,
						icon: 'none'
					});
					return false;
				}
				if (this.curAddress == '' || !this.isAddAddress) {
					uni.showToast({
						title: this.$lang.WITHDRAW_TIP_ENTER_ADDRESS,
						icon: 'none'
					});
					return false;
				}
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.WITHDRAW_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				if (this.amount * 1 < this.curMode.min) {
					uni.showToast({
						title: this.$lang.WITHDRAW_MINIMUM + this.curMode.min,
						icon: 'none'
					});
					return false;
				}

				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const temp = this.curMode.name.includes(this.coinList[0]);
				const result = await this.$http.post(`api/app/withdraw`, {
					// type: temp ? 1 : 2, // erc20传1    trc20传2
					type: this.type, // 支持多币种
					// total: this.amount,
					amount: this.amount,
					address: this.curAddress,
					// pay_pass: this.password,
					remakes: "",
				});
				if (!result) return false;
				uni.showToast({
					// title: result,
					icon: 'success'
				});

				setTimeout(() => {
					this.curAddress = '';
					this.curMode = this.coinList[0];
					this.amount = '';
					this.linkRecord();
				}, 1000)

			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.post(`api/user/assets`, {
					type: 2,
					name:this.name
				});
				if (!result) return false;
				console.log(`result`, result);
				this.userInfo = result[0];
			},

			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					color: '#6D41FF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		},
	}
</script>


<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>