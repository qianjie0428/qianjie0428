<template>
	<view class="launch">
		<!-- <view style="position: relative;">
			  <image src="/static/bg.png" mode="widthFix" style="width: 100%;"></image>
		</view> -->

		<view style=" justify-content: center;display: flex;padding-top:10vh">
			<image src="/static/logo2.png" mode="aspectFit" :style="$theme.setImageSize(320)"></image>
		</view>

		<!-- <view style="margin-top: 20px;text-align: center;font-size: 36rpx;font-family: 700;position: absolute;bottom: 55%;width: 100%;"
			:style="{color:$theme.SECOND}">
			{{$lang.LAUNCH_TITLE}}
		</view> -->

		<!-- 		<view style="display: flex;align-items: center;justify-content: center;">
			<image src='/static/launch_logo.png' mode="aspectFit" :style="$theme.setImageSize(200,150)">
			</image>
		</view> -->
		<!-- 		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 36rpx;font-family: 700;color:#333333;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view> -->

		<view style="padding:40rpx;line-height: 1.4;margin-top: 50px;">
			<view style="padding-top: 24rpx;" :style="{color:$theme.PRIMARY}" v-if="percentage>0">
				{{$lang.LAUNCH_TIPS[0]}}
			</view>
			<view style="padding-top: 30rpx;" :style="{color:$theme.PRIMARY}" v-if="percentage>20">
				{{$lang.LAUNCH_TIPS[1]}}
			</view>
			<view style="padding-top: 30rpx;" :style="{color:$theme.PRIMARY}" v-if="percentage>40">
				{{$lang.LAUNCH_TIPS[2]}}
			</view>
			<view style="padding-top: 30rpx;" :style="{color:$theme.PRIMARY}" v-if="percentage>60">
				{{$lang.LAUNCH_TIPS[3]}}
			</view>
			<view style="padding-top: 30rpx;" :style="{color:$theme.PRIMARY}" v-if="percentage>80">
				{{$lang.LAUNCH_TIPS[4]}}
			</view>
		</view>

		<view style="position: absolute;left: 0;right: 0;bottom: 5vh;">
			<!-- <view style="text-align: center;color: #FFFFFF;font-size: 32rpx;margin-top: 40rpx;">
				{{$lang.LAUNCH_PROGRESS_TITLE}}
				{{`${percentage} %`}}
			</view> -->

			<!-- <view style="display: flex;align-items: center;justify-content: center;">
				<image src='/static/launch_logo.png' mode="scaleToFill" :style="$theme.setImageSize(300,300)">
				</image>
			</view> -->
			<view
				style="position:relative;margin:30rpx 120rpx;background-color:#FFFFFF;height:10px;border-radius: 20rpx;padding:0 3px;margin-top: 30px;">
				<view :style="setStyle"></view>
				<view style="background-image: url('/static/launch_loading.png');
			background-repeat: no-repeat;
			background-position: center center;
			background-size: cover;width: 100%;height: 100%;position: absolute;left: 0;right: 0;top: 0;bottom: 0;z-index: 99;">
				</view>
			</view>
			<view style="text-align: center;font-size: 32rpx;margin-top: 40rpx;color: #b5d5ff;">
				<!-- {{$lang.LAUNCH_PROGRESS_TITLE}} -->
				{{`${percentage} %`}}
			</view>
		</view>
	</view>

</template>

<script>
	export default {
		components: {},
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		computed: {
			// 设置进度条递进样式
			setStyle() {
				// 当前方向
				const _direction = 'left';
				const temp = {
					position: 'absolute',

					bottom: 0,
					[`${_direction}`]: 0, // 决定进度条的递进方向
					height: '20rpx',
					width: `${this.percentage}%`,
					...this.$theme.LAUNCH_PROGRESS,
					borderRadius: '20rpx',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		onShow() {
			this.$util.setAppLang();
			// 每次切换语言后，都调用setTabbar将底部导航重新排序
			this.$util.switchTabBar();
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							uni.switchTab({
								url: this.$paths.HOME,
							})
						}, 1500);
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.launch {
		width: 100%;
		min-height: 100vh;
		background-image: url('/static/bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		// background-image: linear-gradient(135deg, #F5F6FB, #F5F6FB);
	}
</style>