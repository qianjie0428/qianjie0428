<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="common_header" style="background-color: #FFFFFF;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.DEPOSIT_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="padding-bottom: 200rpx;">
			<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
				<view style="display: flex;align-items: center;" @tap="chooseCoin()">
					<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{curMode.name}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;">
							<!-- <template v-if="isCoin">
								<view :style="setStyle()">{{$lang.DEPOSIT_COIN}}</view>
							</template> -->
							<image src="/static/arrow_right.png" mode="aspectFit" style="padding-left: 20rpx;"
								:style="$theme.setImageSize(20)"></image>
						</view>
					</view>
				</view>
			</view>

			<!-- <template v-if="isCoin"> -->
			<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
				<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.DEPOSIT_ADDRESS}}</view>
				<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">USDT</view>
				<!-- <view style="margin-left: auto;color:#6D41FF;font-size: 24rpx;" @tap="handleCopy()"> Copy </view> -->
			</view>
			<view style="padding: 0px 10px;">
				<view style="display: flex;align-items: center;background-color: #FFFFFF;border-radius: 10px;padding: 10px;">
				          <!-- <view
				            style="font-size: 24rpx;width: 280px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"
				            :style="{color:$theme.LOG_VALUE}"> {{curAddress}}
				          </view> -->
				          <view style="width: 70%;">
				            <view style="word-wrap: break-word;">{{curAddress}}</view>
				          </view>
				          
				          <view style="margin-left: auto;" @tap="handleCopy()">
				            <view style="display: flex;align-items: center;">
				              <view style="font-size: 24rpx;color:#6D41FF;padding-right: 8rpx;">{{$lang.COMMON_COPY}}
				              </view>
				              <image src="/static/copy.svg" mode="aspectFit" style="margin-left: auto;"
				                :style="$theme.setImageSize(32)"></image>
				            </view>
				          </view>
				        </view>
			</view>
			<view>
				<!-- <view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;">
					{{$lang.DEPOSIT_AMOUNT}}
				</view>
				<view class="common_input_wrapper"
					style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
					<input v-model="amount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view> -->
			</view>
			<!-- </template>
			<template v-else>
				<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
					<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.WITHDRAW_BANK_CODE}}</view>
				</view>
				<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_VALUE}"> {{bankCode}}</view>
				</view>
			</template> -->

			<!-- <template v-if="isNextStep"> -->
			<!-- <view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;">
				{{$lang.DEPOSIT_AMOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
				<input v-model="amount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view> -->
           <view style="margin-top: 10px;" class="justify-center flex"> 
			   <!-- <canvas id="qrcode" canvas-id="qrcode" style="width: 200px;height: 210px;">
			   	<img :src="imgUrl" alt="" style="width: 200px;">
			   </canvas> -->
		   </view>
			

			<view class="common_block" style="padding:24rpx;border-radius: 24rpx;margin-top: 0;">
				<view style="font: 28rpx;font-weight: 700;line-height: 3;">
					{{$lang.DEPOSIT_TIP}}
				</view>

				<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}"> {{
					$lang.DEPOSIT_TIPS_ITEMS_LIST[0] +` `+curMode.name+ $lang.DEPOSIT_TIPS_ITEMS_LIST[1]
					}}</view>
				<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}"> {{
					$lang.DEPOSIT_TIPS_ITEMS_LIST[2] +curMode.min+` `+curMode.name
				}}</view>
				<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.DEPOSIT_TIPS_ITEMS_LIST[3]}}
				</view>
				<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.DEPOSIT_TIPS_ITEMS_LIST[4]}}
				</view>

				<!-- <block v-for="(item,index) in $lang.DEPOSIT_TIPS_ITEMS_LIST" :key="index">
					<view style="padding-bottom:10px;" :style="{color:$theme.LOG_LABEL}"> {{item}}</view>
				</block> -->

				<!-- <view style="text-align: center;" :style="{color:$theme.LOG_VALUE}"> {{bankCode}}</view> -->
			</view>
			<!-- <view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;">
					{{$lang.DEPOSTI_UPLOAD}}
				</view>

				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #FFFFFF;border-radius: 8rpx;margin: 20rpx;">
					<image :src="!obverseUrl?`/static/icon_upload.png`:obverseUrl" @click="selectImg()"
						style="margin:20rpx;width:440rpx;height:240rpx;">
					</image>
				</view>
			</template> -->
		</view>


		<!-- <view style="position: fixed;bottom: 10rpx;left: 0;right: 0;background-color: #FFFFFF;">
		<template v-if="isNextStep">
		<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</template>
			<template v-else>
				<view class="common_btn" style="margin:40rpx auto;width: 80%;"  @click="handleSubmit()">
					{{$lang.COMMON_NEXT_STEP}}
				</view>
			</template>
		</view> -->

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"
			keyName="name"></u-picker>
	</view>
</template>

<script>
	// import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import UQRCode from 'uqrcodejs';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				curMode: null, // 当前选中充值模式
				curAddress: '', // 当前选中coin的address
				// isNextStep: false, // 是否点击过下一步
				// amount: '', // 输入金额
				// obverseUrl: null, // 上传凭证
				curCoinRule: [], // 当前选中币规则
				imgUrl: null, // 二维码转为图片的 base64 
				type:"",
			};
		},
		computed: {
			coinList() {
				return [{
					name: 'USDT-ERC20',
					min: 1,
				}, {
					name: 'USDT-TRC20',
					min: 1,
				}, {
					name: 'ETH',
					min: 0.01,
				}, 
				{
					name: 'BTC',
					min: 0.001,
				}, 
				// {
				// 	name: 'TRX',
				// 	min: 1000,
				// },
				]
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getCoinfg("erc20");
			this.curMode = this.coinList[0];
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			genQRCode() {
				let qr = null; // 每调用该函数一次，就重新生成一个二维码
				qr = new UQRCode();
				console.log(`qr:`, qr);
				// 设置二维码内容
				qr.data = this.curAddress;
				// 设置二维码大小，必须与canvas设置的宽高一致
				qr.size = 250;
				// 调用制作二维码方法
				qr.make();
				// 获取canvas上下文
				let canvasContext = uni.createCanvasContext('qrcode', this); // 如果是组件，this必须传入
				// 设置uQRCode实例的canvas上下文
				qr.canvasContext = canvasContext;
				// 调用绘制方法将二维码图案绘制到canvas上
				qr.drawCanvas();
				// 通过uni.createCanvasContext方式创建绘制上下文的，对应导出API为uni.canvasToTempFilePath
				// 调用完ctx.draw()方法后不能第一时间导出，否则会异常，需要有一定的延时
				// setTimeout(() => {
				// 	// this.genCanvasToFile();
				// }, 300);
			},
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.DEPOSIT_RECORD
				})
			},

			// 提交
			async handleSubmit() {
				// if (!this.amount || this.amount <= 0) {
				// 	uni.showToast({
				// 		title: this.$lang.DEPOSIT_ENTER_AMOUNT,
				// 		icon: 'none'
				// 	});
				// 	return false;
				// }
				// if (this.amount * 1 < this.curMode.min) {
				// 	uni.showToast({
				// 		title: this.$lang.DEPOSIT_MINIMUM + this.curMode.min,
				// 		icon: 'none'
				// 	});
				// 	return false;
				// }

				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: this.curMode.name,
					// image: this.obverseUrl || '',
					curAddress:this.curAddress,
					// desc: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.curAddress = '';
					this.curMode = this.coinList[0];
					this.isNextStep = false;
					this.amount = '';
					this.obverseUrl = '';
					this.linkRecord();
				}, 1000);
			},

			// copy address
			async handleCopy() {
				const result = await uni.setClipboardData({
					data: this.curAddress, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			// 選擇一種coin
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curMode = e.value[0];
				this.type = this.curMode.name
				console.log('sasasasas====',this.curMode)
				this.isShowCoinList = false;
				let type = "erc20"
				if (this.curMode.name.includes('BTC')) {
					type = "btc"
				} else if (this.curMode.name.includes('USDT-ERC20')) {
					type = "erc20"
				} else if (this.curMode.name.includes('USDT-TRC20')) {
					type = "trc20"
				} else if (this.curMode.name.includes('ETH')) {
					type = "eth"
				}
				this.getCoinfg(type);
				// 重置一些值
				this.isNextStep = false;
			},
			async getCoinfg(type) {
				console.log("进入了")
				
				const result = await this.$http.get(`api/app/czfan?type=`+type);
				console.log('result==',result)
				if (!result) return false;
				console.log(`result:`, result);
				this.curAddress=result.value
				// this.imgUrl=result.img
				// this.curMode.name=result.type
				
				// const temp = result.reduce((map, item) => {
				// 	map.set(item.key, item.value);
				// 	return map;
				// }, new Map());
				if (this.curMode.name.includes('btc')) {
					this.curMode.name = "BTC"
				} else if (this.curMode.name.includes('erc20')) {
					this.curMode.name = "USDT-ERC20"
				} else if (this.curMode.name.includes('trc20')) {
					this.curMode.name = "USDT-TRC20"
				} else if (this.curMode.name.includes('eth')) {
					this.curMode.name = "ETH"
				}
				// this.genQRCode();
			},

			// // 点击上传
			// async selectImg() {
			// 	const result = await uni.chooseImage({
			// 		count: 1,
			// 		sizeType: ['compressed'],
			// 		sourceType: ['album'],
			// 	});
			// 	console.log('result:', result);
			// 	const imageFile = result[1].tempFiles[0];
			// 	console.log('imageFile:', imageFile);
			// 	this.upimg(imageFile.path);
			// },
			// // 上传图片
			// async upimg(tempFilePath) {
			// 	uni.showLoading({
			// 		title: this.$lang.API_STATUS_UPLOAD,
			// 	})
			// 	let Request = "Qwd3N5yp"
			// 	let time = parseInt(new Date().getTime() / 1000)
			// 	let str_url = ("/api/app/upload").toLowerCase()
			// 	let mdd = md5("XPFXMedS" + Request + str_url + time);

			// 	const result = await uni.uploadFile({
			// 		url: this.$http.BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
			// 		filePath: tempFilePath,
			// 		name: 'file',
			// 	});
			// 	console.log('result:', result);
			// 	uni.hideLoading();
			// 	if (result[1].statusCode == 200) {
			// 		const temp = JSON.parse(result[1].data);
			// 		console.log('temp:', temp);
			// 		this.obverseUrl = temp[0].url;
			// 	}
			// 	console.log(`obverseUrl`, this.obverseUrl);
			// 	// this.setStorageData();
			// },
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					color: '#6D41FF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>


<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>