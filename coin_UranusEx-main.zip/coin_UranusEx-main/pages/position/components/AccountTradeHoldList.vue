<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="padding:30rpx;" @tap="handleShowModal(item)">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="flex-1">
						<view class="flex bold" :style="{color:$theme.LOG_VALUE}"
							style="font-size: 36rpx;line-height: 1.6;">
							{{item.name}}
							<view style="padding: 0px 5px;">{{item.code}}</view>
						</view>
						</view>
						<view style="margin-right: 20px;" :style="$theme.setStockRiseFall(item.rate*1>0)">{{$util.formatMoney(item.currentPrice)}}</view>
						<view class="flex"  style="background-color: blue;color: #fff;padding: 5px 10px;border-radius: 20px;">
							<image :src="`/static/arrow_${item.rate*1>0?'rise':'fall'}.png`" mode="widthFix" style="width: 10px;margin-right: 10px;"></image>
							<view >{{$util.formatMoney(item.profit*1)}}</view>
						</view>
					</view>
 
 
                 <view class="flex" style="padding: 10px;">
					<view class="flex-1"
						style="align-items: center;justify-content: space-between;padding-top: 10rpx;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_PROFIT_RATE}}</view>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatNumber(item.profitRate,2)}}%
						</view>
					</view>

					<view class="flex-1" style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_BUY_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>

					<view  style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_BUY_AMOUNT}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.buyNum)+` ${$lang.QUANTITY_UNIT}`}}
						</text>
					</view>
					</view>
					
					
					
					
					
					
					
                  <view class="flex" style="padding: 10px;margin-right: 10px;">
					<view class="flex-1" style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_TOTAL_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.totalPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>

					<view class="flex-1" style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_HOLD_LABEL_CUR_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.currentPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>
					
					<view  style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_FEE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.buyFee)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>
						</view>
				</view>
			</block>
		</template>

		<template v-if="isShow">
			<AccountTradeHoldInfo :info="itemInfo" @action="handleClose"></AccountTradeHoldInfo>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import AccountTradeHoldInfo from './AccountTradeHoldInfo.vue';
	export default {
		name: 'AccountTradeHoldList',
		components: {
			CustomTitle,
			EmptyData,
			AccountTradeHoldInfo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			handleShowModal(val) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.itemInfo = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/paihang`, {
					current: this.curTab
				})
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
			

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/order`, {
					status: 1, // 1持仓，2历史
					gp_index: 0,
				});
				console.log(result);
				if (!result) return false;
				// 过滤保留合法数据
				const temp = !result.data || result.data.length <= 0 ? [] :
					result.data.filter(item => item.order_buy && item.order_buy.id > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						name: item.goods_info.name,
						// 持仓盈利率 =（最终价 - 买入价） / 买入价 *100%
						profitRate: (item.goods_info.current_price * 1 - item.order_buy.price * 1) /
							item.order_buy.price * 100,
						profit: item.order_buy.yingkui, // 盈利额							
						buyNum: item.order_buy.num, // 购买数量							
						totalPrice: item.goods_info.current_price * 1 * item.order_buy.num, // 购买总价
						buyPrice: item.order_buy.price, // 买入单价
						currentPrice: item.goods_info.current_price, // 最新价格
						// 弹层所需数据
						buyCreateTime: item.order_buy.created_at,
						lever: item.order_buy.double,
						buyFee: item.order_buy.buy_fee,
						amount: item.order_buy.amount,
						code: item.goods_info.number_code,
						id: item.id,
						typeId: item.goods_info.project_type_id,
						floatProfit: item.order_buy.float_yingkui * 1, // 浮动盈亏
					}
				})
				console.log(this.list);
			},
		},
	}
</script>

<style>
</style>