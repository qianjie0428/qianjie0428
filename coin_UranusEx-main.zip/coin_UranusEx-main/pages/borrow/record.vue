<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="$lang.BORROW_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="padding-bottom: 60rpx;">
			<view class="common_block" style="border-radius: 24rpx;">
				<view class="common_input_wrapper"
					style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
					<input v-model="amount" type="digit" :placeholder="$lang.BORROW_ENTER_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()" disabled=""></input>
				</view>
			</view>

			<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: #6D41FF;color:#FFFFFF;"
				@click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>

			<view style="font-size: 32rpx;font-weight: 900;line-height: 2.4;padding:0 40rpx;">{{$lang.BORROW_RECORD}}
			</view>

			<template v-if="!list ||list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="border-radius: 24rpx;margin:20rpx;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.BORROW_RECORD_AMOUNT}}</view>
							<view style="font-size: 48rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
								{{item.money}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:item.status==-1?setColor[0]: setColor[item.status]}">
								{{item.status==-1?setStatus[0]:setStatus[item.status]}}
							</view>
							<template v-if="item.status==2">
								<view :style="{color:setColor[item.status]}">
									<text style="padding-right: 40rpx;">{{$lang.BORROW_RECORD_LOANS}}</text>
									<text>{{item.money}}</text>
								</view>
							</template>
						</view>
						<view style="text-align: right;" :style="{color:$theme.LOG_LABEL}">
							{{item.created_at}}
						</view>
					</view>
				</block>
			</template>
		</view>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				amount: '', // 输入框
				list: [{
					amount: 13579,
					successAmount: 579,
					status: 1
				}], // 申请列表
			};
		},
		computed: {
			setStatus() {
				return [
					this.$lang.BORROW_RECORD_STATUS_FAIL,
					this.$lang.BORROW_RECORD_STATUS_APPLY,
					this.$lang.BORROW_RECORD_STATUS_PASS,

				]
			},
			setColor() {
				return ['#FF533B', '#FFAD41', '#6D41FF']
			}
		},
		onLoad(opt) {
			console.log(opt);
			
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
			this.getBorrowInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getBorrowInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/daikuan`);
				// if (!result) return false;
				console.log('info result:', result);
				this.info = result;
				this.amount=(result.zong_money*1).toFixed(4)
			},
			async handleSubmit() {
				if (!this.$util.checkInputNumber(this.amount)) return false;
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/dk_shenqing`, {
					money: this.amount,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: '',
					icon: 'success'
				});
				// this.amount = '';
				setTimeout(() => {
					this.getList();
				}, 1000);
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/dk_log`);
				if (!result) return false;
				console.log('result:', result);
				this.list = result;
			},
		},
	}
</script>

<style>
</style>