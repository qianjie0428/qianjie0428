<template>
	<view style="background-image: linear-gradient(180deg, #9edaf2, transparent);height: 350px;">
		<!-- <view style="background-image: url(/static/waik.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;height: 300px;top: 0;"></view> -->
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx; ">
			<view class="" @click="$util.goBack()">
				<!-- <view class="arrow rotate_225" :style="$theme.setImageSize(20)"></view> -->
			</view>
			<text class="flex-1 text-center" style="color:#121212;">{{$lang.LICAI_LICAI}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$theme.setImageSize(40)"></image>
			</view>
		</view>

		<view style="width: 100%;justify-content: center;display: flex;margin-top: 40px;">
			<!-- <image src="/static/waitu.gif" mode="widthFix" style="width: 40%;"></image> -->
		</view>

		<!-- <view class="flex" style="padding: 0px 30px; justify-content: space-between; color: #aaabac;">
			<view class="font-size-12">Product name</view>
			<view class="font-size-12">Interest rate</view>
		</view> -->

		<view class="common_input_wrapper"
			style="background-color:#F5F6FB;border-radius: 16rpx;height: 32rpx;padding-left: 20rpx;margin:0 48rpx;">
			<input v-model="keyword" type="text" :placeholder="$lang.WEALTH_KEYWORD"
				:placeholder-style="$theme.setPlaceholder()"></input>
			<view style="margin-left: auto;padding-right: 24rpx;" :style="{color:$theme.LOG_LABEL}">
				{{$lang.WEALTH_FILTER}}
			</view>
		</view>

		<view style="padding: 0px 15px;padding-bottom: 200rpx;">
			<template v-if="!setList || setList.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in setList" :key="index">
					<view style="padding:30rpx;background-color: #ffffff;margin:30rpx 0;border-radius:24rpx;">
						<!-- <view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;color:#121212;font-size: 36rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
							<view style="font-size: 18px;">{{item.name}}</view>
							<view @click="handleInfo(item)"
								style="background-color: #09bdab;color: #ffffff;padding:0 12rpx;border-radius: 12rpx;">
								{{$lang.BTN_BUY}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.WEALTH_YIELD}}</view>
							<view style="color:#09bdab;font-size: 28rpx;">{{item.syl}}%</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.WEALTH_TENOR}}
							</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.zhouqi}}
							</view>
						</view>
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.WEALTH_CONTRACT}}</view>
							<view style="color:#333333;font-size: 28rpx;">≈{{item.value}}
								{{$util.formatCurrency( item.syl)}}%
							</view>
						</view> -->
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<WealthBuy :info="infos" @action="handleClose"></WealthBuy>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import WealthBuy from './components/WealthBuy.vue';
	export default {
		components: {
			EmptyData,
			WealthBuy,
		},
		data() {
			return {
				list: [],
				isShow: false,
				info: {}, // 选中一条数据
				keyword: '', // g过滤
			};
		},
		computed: {
			setList() {
				if (this.keyword == '') return this.list;
				return this.list.filter(item => item.name.includes(this.keyword) || item.name.toLowerCase().includes(this.keyword));
			}
		},
		onShow() {
			this.getList();
		},
		onLoad() {},

		onHide() {},
		methods: {
			linkDesc() {
				uni.navigateTo({
					url: this.$paths.LEVEL_DESC
				})
			},

			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose(val) {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
				// result.map(item => {
				// 	return {
				// 		...item,
				// 		// syl*0.01 / zhouqi
				// 		value: (item.syl * 0.01) / (item.zhouqi * 1)
				// 	}
				// });
			}
		}
	}
</script>

<style>
</style>