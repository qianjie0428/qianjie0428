<template>
	<view>
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 28rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:6%">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="padding-left: 10px;font-size: 36rpx;color:#121212;">
								{{item.name}}
							</view>
							<view style="display: flex;align-items: center;">
								<text style="font-size: 28rpx;padding-left: 10px;flex:70%"
									:style="{color:$theme.LOG_LABEL}">{{item.code}}</text>
								<view :style="setStyle()" @click="handleDetail(item)">
									{{$lang.BTN_BUY}}
								</view>
							</view>
						</view>
					</view>

					<view
						style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
						<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_PRICE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_POST_QTY}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.fa_amount*1)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>


					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_MIN_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.min_num*1+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_MAX_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.max_num*1+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>

					<template v-if="item.shengou_date">
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_SUB_CT}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{item.shengou_date}}</view>
						</view>
					</template>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				list: [],
				itemInfo: {}, // 单条数据详情
			}
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.itemInfo=val;
				this.handleShowModal();
			},
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: this.$lang.TRADE_IPO_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.purchase();
				}
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.itemInfo.id,
					// price: this.price
				})
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result.map(item => {
					return {
						id: item.id,
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						shengou_date: item.shengou_date,
						fa_amount: item.fa_amount,
						min_num: item.min_num,
						max_num: item.max_num,
						// rate: item.goods.rate,
						// rate_num: item.goods.rate_num,
					}
				})
			},
		}

	}
</script>

<style>
</style>