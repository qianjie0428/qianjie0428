<template>
	<div id="container" ref="chartContainer" style="width: 100%; height: 500px;"></div>
</template>

<script>
	import {
		KLineChartPro,
		DefaultDatafeed
	} from '@/node_modules/@klinecharts/pro';
	import '@/node_modules/@klinecharts/pro/dist/klinecharts-pro.css';
	import CustomDatafeed from './CustomDatafeed.js';

	export default {
		name: 'KLineChart',
		props: {
			name: {
				type: String,
				default: ''
			}
		},
		mounted() {
			this.initChart();
		},
		methods: {
			initChart() {
				const chart = new KLineChartPro({
					container: document.getElementById('container'),
					// Default symbol info
					symbol: {
						exchange: 'XNYS',
						market: 'stocks',
						name: '',
						shortName: this.name,
						ticker: 'BABA',
						priceCurrency: 'usd',
						type: 'ADRC',
					},
					// Default period
					period: {
						multiplier: 15,
						timespan: 'minute',
						text: '15m'
					},
					// The default data access is used here. If the default data is also used in actual use, you need to go to the https://polygon.io/ apply for API key
					datafeed: new CustomDatafeed(`IR3qS2VjZ7kIDgnlqKxSmCRHqyBaMh9q`, this.name)
				})
			}
		}
	}
</script>

<style scoped>
	/* 自定义图表容器的样式 */
</style>