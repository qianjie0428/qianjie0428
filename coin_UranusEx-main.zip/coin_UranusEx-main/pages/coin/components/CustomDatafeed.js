export default class CustomDatafeed {
	constructor(apiKey, symbol) {
		this._apiKey = apiKey;
		this._prevSymbolMarket = null;
		this._ws = null;
		this.symbol = symbol;
		this.searchSymbols(this.symbol);
		this.getHistoryKLineData();
		this.subscribe();
	}

	async searchSymbols(search = '') {
		const response = await fetch(
			`https://api.polygon.io/v3/reference/tickers?apiKey=${this._apiKey}&active=true&search=${search}`);
		const result = await response.json();
		return (result.results || []).map((data) => ({
			ticker: data.ticker,
			name: data.name,
			shortName: data.ticker,
			market: data.market,
			exchange: data.primary_exchange,
			priceCurrency: data.currency_name,
			type: data.type,
			logo: 'data:image/png;base64,...', // 示例图标
		}));
	}

	async getHistoryKLineData(symbol, period, from, to) {
		const response = await fetch(
			`https://api.starlight.cyou/api/product/lishi?ac_time=0&project_type_id=1&code=${this.symbol}`);
		const result = await response.json();
		console.log(77777, result);

		return (result.data || []).map((data) => ({
			timestamp: data.timestamp,
			open: data.open,
			high: data.high,
			low: data.low,
			close: data.close,
			volume: data.vol,
			turnover: data.count,
		}));
	}

	subscribe(symbol, period, callback) {
		console.log(symbol);
		if (this._prevSymbolMarket !== this.symbol) {
			this._ws?.close();
			this._ws = new WebSocket(`wss://delayed.polygon.io/${this.symbol}`);
			this._ws.onopen = () => {
				this._ws?.send(JSON.stringify({
					action: 'auth',
					params: this._apiKey
				}));
			};
			this._ws.onmessage = (event) => {
				const result = JSON.parse(event.data);
				if (result[0]?.ev === 'status') {
					if (result[0].status === 'auth_success') {
						this._ws?.send(JSON.stringify({
							action: 'subscribe',
							params: `T.${symbol.ticker}`
						}));
					}
				} else if (result?.sym) {
					callback({
						timestamp: result.s,
						open: result.o,
						high: result.h,
						low: result.l,
						close: result.c,
						volume: result.v,
						turnover: result.vw,
					});
				}
			};
		} else {
			this._ws?.send(JSON.stringify({
				action: 'subscribe',
				params: `T.${symbol.ticker}`
			}));
		}
		this._prevSymbolMarket = this.symbol;
	}

	unsubscribe(symbol, period) {
		// Unsubscribe logic if needed
	}
}