<template>
	<view
		style="margin:20rpx 30rpx;border-radius: 4px;display: flex;align-items: center;background-color: #FFFFFF;padding:0 20px;min-height: 40px;line-height: 40px;">
		<image src="/static/horn.svg" mode="aspectFit" :style="$theme.setImageSize(36)"></image>
		<template v-if="info">
			<u-notice-bar :text="title" speed="80" :url="linkNotify" :color="$theme.SECOND" bgColor="#FFFFFF"
				icon=""></u-notice-bar>
		</template>
		<!-- <image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(30)" @click="actionEvent()"></image> -->
		<view style="margin-left: auto;" @click="linkDetail()">{{$lang.COMMON_MORE}}</view>
	</view>
</template>

<script>
	export default {
		name: 'NotifyPrimary',
		data() {
			return {
				info: null,
			}
		},
		computed: {
			title() {
				if (this.info) {
					console.log(111, this.info);
					const temp = this.info.biaoti || this.$lang.LAUNCH_TITLE;
					return temp;

				}
			},

			linkNotify() {
				if (this.info) {
					const val = this.info.id;
					return this.$paths.NOTIFY_DETAIL + `?id=${val}`
				}
			}
		},
		beforeMount() {
			this.getList();
		},
		methods: {
			linkDetail() {
				uni.navigateTo({
					url: this.$paths.NOTIFY_DETAIL + `?id=${this.info.id}`
				})
			},
			async getList() {
				const result = await this.$http.get(`api/app/gglist`, {
					locale: this.$LANGCODE,
				});
				console.log(`result:`, result);
				if (!result) return false;
				this.info = result.length > 0 ? result[0] : [];
			},
		}
	}
</script>

<style>
</style>