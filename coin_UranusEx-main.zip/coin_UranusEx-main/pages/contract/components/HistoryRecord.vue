<template>
	<view style="padding-bottom: 80px;">
		<!-- 	<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
			<u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" :label="$lang.COIN_RECORD_TIP_CUR_COIN"
					v-model="isShowCurCoin" labelColor="#999" labelSize="24rpx" @change="filterCoin"
					:checked="isShowCurCoin" iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group>
		</view> -->
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 16rpx;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 30rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
							{{item.name}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 30rpx"
							:style="{color:item.fx==1?'#6D41FF':$theme.SECOND}">
							{{item.fxText}}
						</view>
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:$theme.FALL}">
							{{item.lever+` X`}}
						</view>
						<view class="common_tag" style="margin-left: auto;" :style="setStyle(item.direct)">
							{{item.directText}}
						</view>
						<!-- <view style="margin-left: auto;" :style="{color:item.status==1? $theme.FALL:'#B8B8B8'}">
							{{item.status==1?$lang.COIN_HISTORY_TIP_CANCEL:$lang.COIN_HISTORY_TIP_TRADE}}
						</view> -->
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_LOT}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.quantity)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HOLD_BUY_TOTAL}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.baozhengjin)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_PRICE_BUY}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.buyprice)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_PRICE_SELL}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.price)}}
						</view>
					</view>


					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_FEE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.fee)}}
						</view>
					</view> -->

					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.CONTRACT_HISTORY_PROFIT_RATE}}
						</view>
						<view style="font-size: 28rpx;" :style="item.direct==1?
								$theme.setStockRiseFall(item.rateBuy>0):
								$theme.setStockRiseFall(item.rateSell>0)">
							{{$util.formatCurrency(item.direct==1? item.rateBuy:item.rateSell)}}%
						</view>
					</view>


					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_PROFIT}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatCurrency(item.interest)}}
						</view>
					</view>

					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">0.1358</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_HISTORY_TRADE_QTY}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">0.55</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HISTORY_DATE}}</view>
						<view style="font-size: 26rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'HistoryRecord',
		components: {
			EmptyData
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				isShowCurCoin: true, // 是否僅顯示當前coin
			}
		},
		created() {},

		methods: {
			// 過濾出當前coin的數據
			filterCoin(e) {
				this.isShowCurCoin = e;
				// this.getList(); // 重新請求數據
				this.$emit('action', this.isShowCurCoin);
			},
			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			// setStyle(val) {
			// 	const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
			// 	return {
			// 		backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
			// 		color: temp,
			// 		borderRadius: `8rpx`,
			// 		minWidth: `60rpx`,
			// 		padding: `6rpx 16rpx`,
			// 		fontSize: `22rpx`,
			// 		textAlign: `center`,
			// 	}
			// },
		}
	}
</script>

<style>
</style>