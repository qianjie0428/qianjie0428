<template>
	<view :class="isAnimat?'fade_in':'fade_out' " style="min-height: 100vh;">
		<view style="background-color: #FFFFFF;">
			<HeaderSecond :title="coinName"></HeaderSecond>
		</view>

		<view style="margin:20rpx 8rpx;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="border-radius: 24rpx;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.FLOW_AMOUNT_AFTER}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCurrency(item.after)}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.FLOW_AMOUNT_BEFORE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCurrency(item.before)}}
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.FLOW_AMOUNT}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatCurrency(item.money)}}
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.FLOW_CT}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.FLOW_DESC}}</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;"></view>
							<text :style="{color:$theme.LOG_VALUE}"
								style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from "@/components/EmptyData.vue";
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				coinName: '', // 當前coin
				list: [], // 列表数据
			}
		},
		onLoad(opt) {
			console.log(opt);
			// 通過id獲取數據，更新title的名為number_code
			this.coinName = opt.name || '';
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getList() {
				const result = await this.$http.post(`api/user/finance`, {
					type: 2,
					name: this.coinName,
				});
				if (!result) return false;
				console.log(`result:`, result);
				this.list = result;
			},
		},
	}
</script>

<style>
</style>