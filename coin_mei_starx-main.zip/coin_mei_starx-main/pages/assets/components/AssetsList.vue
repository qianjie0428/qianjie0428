<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: flex-end;padding-right: 40rpx;">
			<!-- <view style="padding-right: 12rpx;">{{$lang.ACCOUNT_HIDE_ZERO_DATA}}</view> -->
			<!-- <u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" label="" v-model="isHideZero"
					labelColor="#666666" labelSize="24rpx" @change="changeHideZero" :checked="isHideZero"
					iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group> -->
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;" @tap="linkRecord(item)">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="margin-right: auto;padding-right: 40rpx;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:1 1 auto;font-size: 32rpx;font-weight: 500;" :style="{color:$theme.SECOND}">
							{{item.name}}
						</view>
						<view style="margin-left: auto;">
							<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(20)">
							</image>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.ASSETS_LIST_BALANCE}}</view>
						<view :style="{color:$theme.SECOND}">{{$util.formatCoin(item.zong_money*1)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.ASSETS_LIST_USING}}</view>
						<view :style="{color:$theme.SECOND}">{{$util.formatCoin(item.money*1)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.ASSETS_LIST_FREEZE}}</view>
						<view :style="{color:$theme.SECOND}">{{$util.formatCoin(item.freeze*1)}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'AssetsList',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				isHideZero: false, // 是否過濾掉0餘額
			}
		},
		methods: {
			// 過濾掉0餘額數據
			changeHideZero(e) {
				this.isHideZero = e;
				this.$emit('action', this.isHideZero);
			},

			linkRecord(val) {
				if (!val || val == '' || val <= 0) return false;
				uni.navigateTo({
					url: this.$CONSTANTS.ASSETS_REACORD + `?name=${val.name}&type=2`,
				})
			},
		}
	}
</script>

<style>
</style>