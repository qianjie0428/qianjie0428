<template>
	<view>
		<CustomTitle :title="$lang.STOCK_INDUSTRY_TITLE">
			<view style="margin-left: auto;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.STOCK_INDUSTRY_DESC}}
				{{info.count}} {{$lang.STOCK_INDUSTRY_DESC_SUFFIX}}
			</view>
		</CustomTitle>
		<block v-for="(item,index) in $lang.STOCK_INDUSTRY_DATA_LABELS" :key="index">
			<view style="margin: 6px;padding: 6px;border-bottom: 1px solid #4b4b97; ">
				<view style="display: flex;align-items: center; justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{item}}</view>
					<view :style="{color:$theme.LOG_VALUE}">{{formatData[index].value0}}{{formatData[index].unit0}}
					</view>
				</view>
				<view style="display: flex;align-items: center; justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.STOCK_INDUSTRY_DATA_TITLES[0]}}</view>
					<view :style="$theme.setStockRiseFall(formatData[index].value1>0)">
						{{formatData[index].value1}}{{formatData[index].unit1}}
					</view>
				</view>
				<view style="display: flex;align-items: center; justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.STOCK_INDUSTRY_DATA_TITLES[1]}}</view>
					<view :style="$theme.setStockRiseFall(formatData[index].value2>0)">
						{{formatData[index].value2}}{{formatData[index].unit2}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'StockIndustry',
		components: {
			CustomTitle,
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		computed: {
			formatData() {
				return [{
					value0: this.info.marketcap_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.marketcap,
					unit1: ` ${this.$lang.UNIT_BILION}`,
					value2: this.info.marketcap_avg,
					unit2: ` ${this.$lang.UNIT_BILION}`,
				}, {
					value0: this.info.net_income_growth_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.net_income_growth,
					unit1: ` %`,
					value2: this.info.net_income_growth_avg,
					unit2: ` %`,
				}, {
					value0: this.info.debt_ratio_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.debt_ratio,
					unit1: ` %`,
					value2: this.info.debt_ratio_avg,
					unit2: ` %`,
				}, {
					value0: this.info.per_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.per,
					unit1: ` 배`,
					value2: this.info.per_avg,
					unit2: ` 배`,
				}, {
					value0: this.info.pbr_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.pbr,
					unit1: ` 배`,
					value2: this.info.pbr_avg,
					unit2: ` 배`,
				}, {
					value0: this.info.roe_rank,
					unit0: ` ${this.$lang.UNIT_POS}`,
					value1: this.info.roe,
					unit1: ` %`,
					value2: this.info.roe_avg,
					unit2: ` %`,
				}];
			},
		}
	}
</script>