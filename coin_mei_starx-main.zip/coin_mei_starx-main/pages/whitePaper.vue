<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<HeaderSecond title="WhitePaper" :color="$theme.SECOND"></HeaderSecond>

		<view style="padding: 40rpx;">
			<template >
				<web-view :src="url"></web-view>
			</template>
		
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
				url:""
			};
		},
		computed: {},
		onLoad() {
			// this.getData()
			this.url=this.$http.BASE_URL+'/upload/baipi/PMA_WhitePaper.pdf'
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/article/about-us`);
				console.log('result:', result);
				if (!result) return false;
				this.info = {
					title: result.title || this.$lang.ABOUT_US_TITLE,
					content: result.content,
				}
			},
		},
	}
</script>