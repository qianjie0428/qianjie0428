<template>
	<view>
		<view class="common_mask" @click="actionEvent()"></view>
		<view class="common_popup" style="min-height:35vh;margin:auto">
			<view class="popup_header" style="color:#FFF;" :style="{backgroundColor:$theme.PRIMARY}">
				{{$lang.TRADE_WEALTH_BUY_DETAIL}}

				<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
					style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);" @click="actionEvent()">
				</image>
			</view>
			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<!-- <view style="color: #666666;">{{$lang.LICAI_MINGCHENG}}</view> -->
				<view class="flex">
					<view style="font-size: 16px;">{{info.name}}</view>
				</view>
			</view>

			<template v-if="info.is_new==1">
				<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
					<view style="color: #666666;">{{$lang.FUNDS_MODAL_ESTIMATE}}</view>
					<view class="flex">
						<view
							style="background-color: #B2E8CD;font-size: 10px;padding: 5px;width: 80px;text-align: center;border-radius: 5px;color: #00B45A;">
							{{$lang.TRADE_WEALTH_NEW_USERS}}
						</view>
					</view>
				</view>
			</template>

			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">{{$lang.FUNDS_MODAL_ESTIMATE}}</view>
				<view class="flex">
					<view style="color: #000;">{{info.syl}}</view>
				</view>
			</view>

			<!-- <view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">预估收益</view>
				<view class="flex" >
					<view style="color: #000;">{{info.zhouqi+$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
				</view>
			</view> -->

			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">{{$lang.FUNDS_PERIOD}}</view>
				<view class="flex">
					<view style="color: #000;">{{info.zhouqi+$lang.TRADE_WEALTH_CYCLE_UNIT}}</view>
				</view>
			</view>

			<!-- <view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">发放日期</view>
				<view class="flex" >
					<view style="color: #000;">2024-06-15</view>
				</view>
			</view> -->

			<view class="flex" style="justify-content: space-between;padding: 10px 20px;">
				<view style="color: #666666;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
				<view class="flex">
					<view style="color: #000;">{{$util.formatCoin(info.min_price)}}</view>
				</view>
			</view>

			<!-- <view
					style="display: flex;align-items: center;justify-content: space-between;line-height:3;padding:0 60rpx;">
					<view style="color:#666666;">{{$lang.TEADE_WEALTH_MIN_PRICE}}</view>
					<view style="color:#333333;font-size: 28rpx;">{{$util.formatDate(new Date())}}</view>
				</view> -->
			<!-- <view
				style="display: flex;align-items: center;justify-content: space-between;line-height:3;padding:0 40rpx;">
				<view style="color:#000;font-size: 16px;">{{$lang.LICAI_QINGSHURUMEIRUJINE}}</view>
			</view> -->
			<view class="common_input_wrapper"
				style="padding-left: 20px;margin:30rpx 40rpx;background-color: #FFFFFF;border: 1px solid #E8EAF3;"
				v-if="info.is_new!=1">
				<input v-model="amount" :placeholder="$lang.TRADE_WEALTH_BUY_AMOUNT" type="number" style="width: 80%;"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>

			<view class="access_btn" style="margin:40px auto; width: 90%;" :style="{backgroundColor:$theme.PRIMARY}"
				@tap.stop="handleBuy()" v-if="info.is_new!=1">
				{{$lang.BTN_BUY}}
			</view>
			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="home()" v-if="info.is_new!=0">
				{{$lang.LICAI_KEFU}}
			</view>

		</view>
	</view>
	</view>
</template>

<script>
	export default {
		name: 'WealthBuy',
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isShow: true,
				amount: "", // 数量
			}
		},
		computed: {},
		created() {},
		methods: {
			actionEvent() {
				this.isShow = false;
				this.$emit('action', 1);
			},
			home() {
				uni.navigateTo({
					url: '/pages/service',
				})
			},

			async handleBuy() {
				if (this.amount == '' || this.amount <= 0) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT);
					return false;
				}
				if (this.amount < this.info.min_price) {
					uni.$u.toast(this.$lang.TRADE_WEALTH_BUY_AMOUNT_TIP);
					return false;
				}
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.info.name} Payment Amount ${this.$util.formatMoney(this.amount)}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.info.id,
					ganggan: 1,
					price: this.amount,
				});
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				setTimeout(() => {
					this.actionEvent();
				}, 1000);
			}
		}
	}
</script>

<style>
	.common_popup {
		position: fixed;
		bottom: 0;
		left: 50%;
		width: 100%;
		z-index: 1113;
		animation: popopUp 300ms forwards;
		border-radius: 30px 30px 0 0;
		background-color: #FFFFFF;
	}

	.popup_header {
		height: 96rpx;
		line-height: 96rpx;
		border-bottom: 1px solid #ccc;
		font-size: 16px;
		font-weight: 700;
		padding: 0 10px 0 10px;
		color: #121212;
		background-color: #FFFFFF;
		border-radius: 30px 30px 0 0;
		position: relative;
		text-align: center;
	}

	.common_input_wrapper {
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		margin: 10px 0;
		padding: 10px 0px;
		border-radius: 6px;
		background-color: #FFFFFF;
	}

	.common_input_wrapper+* {
		margin-top: 0;
	}

	.common_input_wrapper>image {
		padding: 0 10px;
	}

	.access_btn {
		margin: 0 30px;
		font-size: 32rpx;
		line-height: 96rpx;
		font-weight: 500;
		border-radius: 30px;
		text-align: center;
		background-color: var(--primary);
		color: #FFFFFF;
	}
</style>