<template>
	<view style="background-image: linear-gradient(180deg, #9edaf2, transparent);
	background-position: 0 0;background-repeat: no-repeat;background-size:100%  350px;">
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx; ">
			<view class="" @click="$util.goBack()">
				<view class="arrow rotate_225" :style="$theme.setImageSize(20)"></view>
			</view>
			<text class="flex-1 text-center" style="color:#121212;">{{$lang.FUNDS_TITLE}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$theme.setImageSize(40)"></image>
			</view>
		</view>

		<view style="width: 100%;justify-content: center;display: flex;">
			<image src="/static/jijintu.JPG" mode="widthFix" style="width: 100%;"></image>
		</view>

		<view style="padding: 0px 15px;padding-bottom: 200rpx;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;background-color: #ffffff;margin:30rpx 0;border-radius:24rpx;">
						<!-- <view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;color:#121212;font-size: 36rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
							<view style="font-size: 16px;line-height: 1.2;margin-right: 20px;">{{item.name}}</view>
							<view style="color:#09bdab;font-size: 28rpx;background-color: #1677e7;padding: 3px 15px;border-radius: 8px;color: #fff;" @click="handleInfo(item)">{{$lang.BTN_BUY}}</view>
						</view>
						
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding: 10px 0px;">
							<view style="color:#666666;">{{$lang.FUNDS_PERIOD}}</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}
							</view>
						</view>
						
						<view class="flex" style="border: 2px #97bcd1 solid;border-radius: 10px;background: linear-gradient(-50deg, white 50%, #1678e7 50%);">
							<view
								style="align-items: center;justify-content: space-between;line-height: 1.5;padding: 0px 40px;">
								<view class="text-center" style="color:#fff;">{{$util.formatCoin(item.min_price)}}</view>
								<view class="text-center" style="color:#fff;font-size: 28rpx;">{{$lang.LICAI_ZUIDIMAIRU}}
								</view>
							</view>
							<view
								style="align-items: center;justify-content: space-between;line-height: 1.5;margin-left: 50px;">
								<view  class="text-center" style="color:#666666;">{{item.fudu}}%</view>
								<view class="text-center" style="color:#333333;font-size: 28rpx;">{{$lang.FUNDS_RATE}}</view>
							</view>
						</view>
						
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<WealthBuy :info="detail" @action="handleClose"></WealthBuy>
		</template>
	</view>
</template>

<script>
	import WealthBuy from './components/WealthBuy.vue';
	export default {
		components: {

			WealthBuy,
		},
		data() {
			return {
				list: [],
				isShow: false,
				detail: {}, // 选中一条数据
			};
		},
		computed: {},
		onShow() {
			this.getList();
		},

		onHide() {},
		methods: {
			linkDesc() {
				uni.navigateTo({
					url: this.$CONSTANTS.LEVEL_DESC
				})
			},

			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose(val) {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.detail = item;
				this.isShow = true;
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			}
		}
	}
</script>

<style>
	.gradient-background {
	            width: 100%; /* 可根据需要调整宽度 */
	            height: 300px; /* 可根据需要调整高度 */
	            background: linear-gradient(-135deg, white 50%, blue 50%);
	            /* 使用斜切渐变 */
	        }
</style>