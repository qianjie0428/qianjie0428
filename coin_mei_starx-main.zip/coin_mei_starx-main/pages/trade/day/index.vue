<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header" style="background-color: #FFFFFF;">
			<view class="flex" @click="$util.goBack()">
				<view class="flex-1">
					<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				</view>
				
			</view>
			<view class="flex-1 text-center font-size-18" style="padding-left: 0;text-align: center;">
				<text style="color:#121212;">{{$lang.TRADE_DAY_TITLE}}</text>
			</view>
			<view class="" style="padding-left: 0;"  @click="Record()">
				<text style="color:#121212;font-size: 12px;">{{$lang.SHENQING_JILV}}</text>
			</view>
		</header>

		<view
			style="margin-bottom: 28rpx;border-radius: 10rpx;display: flex;align-items: center;justify-content: space-between;padding:5px 24rpx;">
			<block v-for="(item,index) in $lang.TRADE_DAY_TABS" :key='index'>
				<view :style="setStyle(curTab==index)" @click="changeTab(index)" class="flex-1">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<TradeDayBuy @action="changeTab" v-if="isUpdate"></TradeDayBuy>
		</template>

		<template v-else-if="curTab==1">
			<TradeDaySuccessList :list="successList" @chicang_list="getSuccessList" v-if="isUpdate"></TradeDaySuccessList>
			
		</template>
		<template v-else>
			<TradeDayOrderList :list="orderList" v-if="isUpdate"></TradeDayOrderList>
		</template>
	</view>
</template>

<script>
	import TradeDayBuy from './components/TradeDayBuy.vue';
	import TradeDayOrderList from './components/TradeDayOrderList.vue';
	import TradeDaySuccessList from './components/TradeDaySuccessList.vue';
	export default {
		components: {
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				orderList: [], // 申请列表
				successList: [], // 通过列表
				isUpdate: true, // 页面子组件强刷
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.refreshChild();
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 此为驱动子组件强刷的方案。
			refreshChild() {
				this.isUpdate = false;
				this.$nextTick(() => {
					this.isUpdate = true;
				})
			},
			
			Record(){
				uni.navigateTo({
					url:'/pages/trade/day/Record'
				})
			},
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 1) this.getSuccessList();
				if (this.curTab == 2) this.getOrderList();
			},

			async getOrderList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/Rinei/rineiorder`,{
					status: this.curTab + 0, 
				});
				if (!result) return false;
				console.log(result);
				this.orderList = result.length <= 0 ? [] : result.map((item, index) => {
					return {
						...item,
						// 状态值明文、icon
						...this.$theme.setStatusPrimary(item.status),
						// 状态值 样式:字号、字色、背景等
						style: this.$theme.setStatusPrimary(item.status),
					}
				});
			},

			async getSuccessList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/Rinei/rineiorder`,{
				   status:1
				});
				if (!result) return false;
				console.log(result);
				this.successList = result.length <= 0 ? [] : result;
			},
			setStyle(val) {
				return {
					// minWidth: `120rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					textAlign: 'center',
					backgroundColor: val ? '#6d41ff' : '#FFFFFF',
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `16rpx`,
				}
			}
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>