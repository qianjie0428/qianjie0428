<template>
	<view>
		<view style="display: flex;align-items: center;padding:36rpx">
			<view style="width: 8rpx;height: 28rpx;" :style="{backgroundColor:$theme.PRIMARY}"></view>
			<view style="font-size: 28rpx;font-weight: 700;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_SCORE_INFO}}
			</view>
		</view>

		<view class="card_bg">
			<view style="color:#C9C9C9;font-size: 28rpx;padding-top: 36rpx;padding-left: 120rpx;">
				{{$lang.COPY_DETAIL_SCORE_CURRENT}}
			</view>
			<view style="font-size: 56rpx;font-weight: 700;color: #FFFFFF;line-height: 2.4;padding-left: 160rpx;">
				{{info.pingfen.split('/')[0]}}
			</view>
			<view style="color:#C9C9C9;font-size: 28rpx;padding-left: 80rpx;">{{$lang.COPY_DETAIL_SCORE_TIP}}</view>
		</view>

		<!-- 六项评分 -->
		<view style="padding: 36rpx;">
			<block v-for="(item,index) in $lang.COPY_DETAIL_SCORE_SIX" :key="index">
				<view style="display: flex;align-items: center;line-height: 2.4;">
					<view style="flex:0 0 44%;font-size: 28rpx;color:#8E8D92;">{{item}}</view>
					<view style="flex:0 0 6%;text-align: center; font-size: 28rpx;font-weight: 500;">
						{{scoreData[index]}}
					</view>
					<view style="flex:0 0 50%;">
						<view style="margin-left:20rpx;border-radius: 10rpx;background-color: #25262A;">
							<view :style="$theme.tradeCopyScore(scoreData[index],setColor[index], 10)">
							</view>
						</view>
					</view>
				</view>
			</block>
		</view>

		<!-- 评分走势 -->
		<ChartScoreArea :info="chartData"></ChartScoreArea>
	</view>
</template>

<script>
	import ChartScoreArea from './ChartScoreArea.vue';
	export default {
		name: 'TabScore',
		components: {
			ChartScoreArea
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		computed: {
			scoreData() {
				return [this.info.yingli * 1, this.info.fengkong * 1,
					this.info.wenjian * 1, this.info.feijiaoxing * 1,
					this.info.zijin * 1, this.info.churuc * 1
				];
			},
			setColor() {
				return ['#16E2E2', '#16E2B8', '#18AF5F', '#F6B544', '#F67544', '#A944F6']
			},
			// 评分图表数据
			chartData() {
				if (this.info) return this.info.pingfentu;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.card_bg {
		background-image: url(/static/trade_copy_score.png);
		background-repeat: no-repeat;
		background-position: center;
		background-size: 90%;
		width: 100%;
		height: 280rpx;
	}
</style>