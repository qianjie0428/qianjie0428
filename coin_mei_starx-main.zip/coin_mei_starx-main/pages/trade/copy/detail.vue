<template>
	<view>
		<header class="common_header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text style="color:#121212">{{$lang.COPY_DETAIL_TITLE}}</text>
			</view>
		</header>

		<template v-if="!info">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<template v-if="curTab==0">
				<!-- 此部分信息 只在 curTab==0时显示 -->
				<view style="display: flex;align-items: center;padding:36rpx;padding-bottom: 12rpx;">
					<view style="flex:0 0 6%">
						<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
					</view>
					<view style="flex:0 0 88%;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-left: 20rpx;">
							<view style="font-size: 26rpx;" :style="{color:$theme.WHITE}">{{info.name}}</view>
							<view style="margin-left: auto;padding:2rpx 8rpx;border-radius: 4rpx;"
								:style="{backgroundColor:$theme.RGBConvertToRGBA($theme.PRIMARY,20)}">
								<text style="font-size: 24rpx;"
									:style="{color:$theme.PRIMARY}">{{info.pingfen.split('/')[0]}}</text>
								<text style="color:#121212;font-size: 20rpx;">/{{info.pingfen.split('/')[1]}}</text>
							</view>
						</view>
						<view style="display: flex;align-items: center;padding-left: 20rpx;padding-top: 12rpx;">
							<image :src="`/static/flags/${info.guojia}.svg`" mode="scaleToFill"
								style="border-radius: 8rpx;" :style="$theme.setImageSize(56,48)"></image>
							<view style="padding-left: 10rpx;color:#8E8D92;font-size: 24rpx;">{{info.tip}}
							</view>
						</view>
					</view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 36rpx;">
					<view>
						<text style="color:#333;padding-right: 20rpx;">{{$lang.TRADE_COPY_FOLLOWERS}}</text>
						<text>{{info.gentoushu}}</text>
					</view>
					<view>
						<text style="color:#333;padding-right: 20rpx;">{{$lang.TRADE_COPY_RATE}}</text>
						<text :style="{color:info.zongshouyilv*1>0?$theme.RISE:$theme.FALL}">
							{{`${info.zongshouyilv>0?'+':'-'}`+  info.zongshouyilv+` %`}}
						</text>
					</view>
				</view>

				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 36rpx;">
					<view>
						<text style="color:#333;padding-right: 20rpx;">{{$lang.TRADE_COPY_TOTAL}}</text>
						<text>{{info.zongshouyi*1}}</text>
					</view>
					<view>
						<text style="color:#333;padding-right: 20rpx;">{{$lang.COPY_DETAIL_30DAY_PROFIT}}</text>
						<text>{{info.gentouyi*1}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;padding:0 36rpx;">
					<view style="font-size: 24rpx;">
						<text style="color:#333;padding-right: 20rpx;">{{$lang.TRADE_COPY_TOTAL_AMOUNT}}</text>
						<text>{{info.gentouzong+` USD`}}</text>
					</view>
				</view>

				<view style="padding:0 36rpx; padding-top: 40rpx;border-bottom: 1px solid #FFF;">
					<view style="color: #333 !important;" v-html="info.jieshao"></view>
				</view>
			</template>

			<view style="display: flex;align-items: center;padding: 28rpx 36rpx 0 36rpx;">
				<block v-for="(item,index) in tabs" :key="index">
					<view :style="setStyleTab(curTab==index)" @tap="changeTab(index)">{{item}}</view>
				</block>
			</view>

			<template v-if="curTab==0">
				<!-- 总收益 -->
				<template v-if="isShowKlineTotalReturns">
					<view style="display: flex;align-items: center;padding:36rpx;">
						<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
						<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
							{{$lang.COPY_DETAIL_TOTAL_RETURNS}}
						</view>
						<view style="margin-left: auto;color:#333;font-size: 24rpx;">
							{{$lang.COPY_DETAIL_TOTAL_RETURNS_TIP}}
						</view>
					</view>

					<view style="display: flex;align-items: center;padding:0 36rpx 36rpx 36rpx;">
						<block v-for="(item,index) in setTimeTabs" :key="index">
							<view :style="setStyleTime(curTime==item)" @tap="changeTime(item)">{{item}}</view>
						</block>
					</view>

					<!-- <KlineTotalReturns :list="klineDataTotalReturns" ref="klineTotal">
					</KlineTotalReturns> -->

					<ChartTotalReturns :list="klineDataTotalReturns" ref="klineTotal"></ChartTotalReturns>

				</template>

				<!-- 数据 -->
				<view style="display: flex;align-items: center;justify-content: space-between;padding:0 36rpx;">
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;">
							{{$lang.COPY_DETAIL_CLOSE_PROFIT+`(USD)`}}
						</view>
						<view style="font-size: 28rpx;"
							:style="{color:info.pingcangyingkui*1>0?$theme.RISE:$theme.FALL}">
							{{info.pingcangyingkui}}
						</view>
					</view>
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;text-align: center;">
							{{$lang.COPY_DETAIL_TRADE_COUNT}}
						</view>
						<view style="font-size: 28rpx;text-align: center;">{{info.jiaoyicishu}}</view>
					</view>
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;text-align: right;">
							{{$lang.COPY_DETAIL_AVERAGE_PROFIT}}
						</view>
						<view style="font-size: 28rpx;text-align: right;">{{info.pingjunyingli}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding:36rpx;">
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;">
							{{$lang.COPY_DETAIL_AVERAGE_DT+`(%)`}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:info.pingjuntime*1>0?$theme.RISE:$theme.FALL}">
							{{info.pingjuntime}}
						</view>
					</view>
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;text-align: center;">
							{{$lang.COPY_DETAIL_WIN_RATE}}
						</view>
						<view style="font-size: 28rpx;text-align: center;">{{info.shenglv}}</view>
					</view>
					<view>
						<view style="color:#8E8D92;font-size: 24rpx;text-align: right;">
							{{$lang.COPY_DETAIL_AVERAGE_PROFIT}}
						</view>
						<view style="font-size: 28rpx;text-align: right;">{{info.eryingli}}</view>
					</view>
				</view>

				<!-- 月度表现 -->
				<template v-if="isShowMonthProfitLoss">
					<ChartMonthProfitLoss :list="chartDataMonthProfitLoss"></ChartMonthProfitLoss>
				</template>

				<!-- 周盈亏 -->
				<template v-if="isShowWeekProfitLoss">
					<ChartWeekProfitLoss :list="chartDataWeekProfitLoss"></ChartWeekProfitLoss>
				</template>

				<!-- 交易量 柱状图 -->
				<template v-if="isShowTradeVol">
					<ChartTradeVolume :list="chartDataTradeVol"></ChartTradeVolume>
				</template>
			</template>

			<template v-else-if="curTab==1">
				<TabData :info="info"></TabData>
			</template>
			<template v-else-if="curTab==2">
				<TabScore :info="info"></TabScore>
			</template>
			<template v-else-if="curTab==3">
				<template v-if="list && list.gentoushu.length>0">
					<ChartFollowers :list="list.gentoushu"></ChartFollowers>
				</template>
				<template v-if="list && list.gentouzong.length>0">
					<ChartAmount :list="list.gentouzong"></ChartAmount>
				</template>
			</template>
			<template v-else>
				<TabOrders :info="info"></TabOrders>
			</template>

		</template>
		<!-- position fixed 的余量 -->
		<view style="height: 160rpx;"></view>
		<view
			style="position: fixed;bottom:0;left: 0;right: 0;background-color: #FFF; border-top: 1px solid #FFF;z-index: 9;">
			<view
				style="margin:28rpx auto;width: 90%;border-radius:50rpx;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
				:style="{backgroundColor:$theme.PRIMARY}" @click="handleCopy()">
				{{$lang.TRADE_COPY_TITLE}}
			</view>
		</view>

		<!-- 跟单弹层 -->
		<template v-if="isShow">
			<view class="mask" @tap="handleClose()"></view>
			<view class="modal_wrapper">
				<view
					style="background-color:#FFF;border-radius: 24rpx 24rpx 0 0;padding-top:40rpx;padding-bottom: 20rpx;">
					<view style="text-align: center;font-size: 32rpx;font-weight: 700;">
						{{$lang.TRADE_COPY_TITLE}}
					</view>
					<view style="padding:0;">
						<view style="display: flex;align-items: center;padding:36rpx;padding-bottom: 12rpx;">
							<view style="flex:0 0 6%">
								<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
							</view>
							<view style="flex:0 0 88%;">
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-left: 20rpx;">
									<view style="font-size: 26rpx;" :style="{color:$theme.WHITE}">{{info.name}}</view>
									<view style="margin-left: auto;padding:2rpx 8rpx;border-radius: 4rpx;"
										:style="{backgroundColor:$theme.RGBConvertToRGBA($theme.PRIMARY,20)}">
										<text style="font-size: 24rpx;"
											:style="{color:$theme.PRIMARY}">{{info.pingfen.split('/')[0]}}</text>
										<text
											style="color:#121212;font-size: 20rpx;">/{{info.pingfen.split('/')[1]}}</text>
									</view>
								</view>
								<view style="display: flex;align-items: center;padding-left: 20rpx;padding-top: 12rpx;">
									<image :src="`/static/flags/${info.guojia}.svg`" mode="scaleToFill"
										style="border-radius: 8rpx;" :style="$theme.setImageSize(56,48)"></image>
									<view style="padding-left: 10rpx;color:#8E8D92;font-size: 24rpx;">{{info.tip}}
									</view>
								</view>
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;padding:0 36rpx;">
							<view>
								<view style="color:#8E8D92;">{{$lang.COPY_MODAL_NET_VALUE}}</view>
								<view>{{info.xiadanjingzhi}}</view>
							</view>
							<view>
								<view style="color:#8E8D92;text-align: right;">{{$lang.COPY_MODAL_FOLLOW_FEE}}</view>
								<view style="text-align: right;">
									{{info.zhouqi}}{{$lang.COPY_MODAL_DAY}}
								</view>
							</view>
						</view>

						<!-- <view style="display: flex;align-items: center;padding:36rpx">
							<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
							<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
								{{$lang.COPY_MODAL_CHOOSE_ACCOUNT}}
							</view>
						</view>

						<view> 罗列账户，radio 单选 </view> -->

						<view style="display: flex;align-items: center;padding:36rpx">
							<view style="width: 8rpx;height: 28rpx;" :style="{backgroundColor:$theme.PRIMARY}"></view>
							<view style="font-size: 28rpx;font-weight: 700;padding-left: 40rpx;">
								{{$lang.COPY_MODAL_CHOOSE_MODE}}
							</view>
						</view>
						<view style="font-size: 24rpx;padding-left: 36rpx;">{{$lang.COPY_MODAL_MODE_TIP}}
						</view>
						<view style="color:#999;font-size: 20rpx;padding-left: 36rpx;">{{$lang.COPU_MODA_MODE_TIP1}}
						</view>

						<view
							style="margin:36rpx;border:1px solid #25262A1A;border-radius: 16rpx;padding:12rpx 24rpx;display: flex;align-items: center;">
							<input v-model="quantity" type="digit" :placeholder="$lang.COPY_MODAL_QTY"
								:placeholder-style="$theme.setPlaceholder()" style="flex: 1 0 auto;"></input>
							<view style="margin-left: auto;color:#8E8D92;">USDT</view>
						</view>

						<view style="margin: 20rpx 36rpx;border:1px solid #25262A1A;">
							<view style="display: flex;align-items: center;line-height: 1.8;">
								<block v-for="(item,index) in percentList" :key="index">
									<view :style="setStylePercent(item==curPercent)" @click="changePercent(item)">
										{{item*100+` %`}}
									</view>
								</block>
							</view>
						</view>

						<view
							style="margin: 20rpx 36rpx;display: flex;align-items: center;justify-content: space-between;color:#999999;font-size: 20rpx;">
							<view>{{$lang.COPY_MODAL_BALANCE}}</view>
							<view>{{balance+` USDT`}}</view>
						</view>
						<view
							style="margin: 20rpx 36rpx;display: flex;align-items: center;justify-content: space-between;color:#999999;font-size: 20rpx;">
							<view>{{$lang.COPY_MODAL_AMOUNT}}</view>
							<template v-if="info">
								<view>{{info.shouxufei.split('/')[0] * 1+` USDT`}}</view>
							</template>
						</view>

						<view
							style="margin:28rpx auto;width: 90%;border-radius:50rpx;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
							:style="{backgroundColor:$theme.PRIMARY}" @tap="handleSubmit()">
							{{$lang.TRADE_COPY_TITLE}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	
	import KlineTotalReturns from './components/KlineTotalReturns.vue';
	import ChartMonthProfitLoss from './components/ChartMonthProfitLoss.vue';
	import ChartWeekProfitLoss from './components/ChartWeekProfitLoss.vue';
	import ChartTradeVolume from './components/ChartTradeVolume.vue';

	// import TabCharts from './components/TabCharts.vue';
	import TabData from './components/TabData.vue';
	import TabScore from './components/TabScore.vue';
	import TabOrders from './components/TabOrders.vue';
	import KlineCount from './components/KlineCount.vue';
	import KlineAmount from './components/KlineAmount.vue';

	import ChartTotalReturns from './components/ChartTotalReturns.vue';
	import ChartFollowers from './components/ChartFollowers.vue';
	import ChartAmount from './components/ChartAmount.vue';

	export default {
		components: {
	
			ChartTradeVolume,
			KlineTotalReturns,
			ChartMonthProfitLoss,
			ChartWeekProfitLoss,

			ChartTotalReturns,
			ChartFollowers,
			ChartAmount,

			// TabCharts,
			TabData,
			TabScore,
			TabOrders,
			KlineCount,
			KlineAmount,
		},
		data() {
			return {
				id: '', // url带入值
				info: null,
				curTab: 0, // current tab
				curTime: 7, // 当前天数 总收益k线所需
				isShow: false, // 是否显示弹层
				quantity: '', // 输入数量
				curPercent: -1, // 當前選中 百分比
				balance: '', // 账户余额
				list: null, // investors 跟投分栏的数据
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.COPY_DETAIL_CHARTS,
					this.$lang.COPY_DETAIL_DATA,
					this.$lang.COPY_DETAIL_SCORE,
					this.$lang.COPY_DETAIL_INVESTORS,
					this.$lang.COPY_DETAIL_ORDERS,
				]
			},
			setTimeTabs() {
				return [7, 30, 90, 180, 365]
			},

			// 总收益 图表数据
			klineDataTotalReturns() {
				return this.list && this.list.chengzhang &&
					this.list.chengzhang.length > 0 ? this.list.chengzhang : []
			},
			// 是否显示总收益图表
			isShowKlineTotalReturns() {
				// console.log(`IS:`, this.klineDataTotalReturns);
				return this.klineDataTotalReturns.length > 0;
			},

			// 月度表现 图表数据
			chartDataMonthProfitLoss() {
				return this.list && this.list.monthlyDayshouyi &&
					this.list.monthlyDayshouyi.length > 0 ? this.list.monthlyDayshouyi : []
			},
			// 是否显示每周盈亏图表
			isShowMonthProfitLoss() {
				return this.chartDataMonthProfitLoss.length > 0;
				return false;
			},

			// 每周盈亏图表数据
			chartDataWeekProfitLoss() {
				return this.list && this.list.weeklyDayshouyi &&
					this.list.weeklyDayshouyi.length > 0 ? this.list.weeklyDayshouyi : []
			},
			// 是否显示每周盈亏图表
			isShowWeekProfitLoss() {
				return this.chartDataWeekProfitLoss.length > 0;
			},

			// 交易量图表数据
			chartDataTradeVol() {
				return this.list && this.list.jiaoyiliang &&
					this.list.jiaoyiliang.length > 0 ? this.list.jiaoyiliang : []
			},
			// 是否显示交易量柱状图
			isShowTradeVol() {
				return this.chartDataTradeVol.length > 0;
			},

			// 可用餘額的百分之多少
			percentList() {
				return [0.25, 0.50, 0.75, 1]
			},
		},
		onLoad(opt) {
			this.id = opt.id || '';
		},
		onShow() {
			this.getDetail();
			if (this.curTab == 0 || this.curTab == 3) {
				this.getChartList();
			}
		},
		onPullDownRefresh() {
			this.getDetail();
			if (this.curTab == 0 || this.curTab == 3) {
				this.getChartList();
			}
			uni.stopPullDownRefresh();
		},
		methods: {
			linkBack() {
				// 默认回退一级
				uni.navigateBack({
					delta: 1,
				})
			},

			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0 || this.curTab == 3) {
					this.getChartList();
				}
				this.getDetail();
			},
			changeTime(val) {
				this.curTime = val;
				this.getChartList();
			},


			// 打开跟单弹出
			handleCopy() {
				this.isShow = true;
				this.getAccountInfo();
			},
			handleClose() {
				this.isShow = false;
			},

			// 選擇輸入值的百分比
			changePercent(val) {
				this.curPercent = val;
				// 计算公式
				const temp = this.info.shouxufei.split('/')[0] * 1;
				// 100%(应该是余额-跟随费用)* 当前选中百分比
				this.quantity = Number(this.$util.formatNumber((this.balance * 1 - temp) * this.curPercent, 4));
			},

			// 跟单弹出提交
			async handleSubmit() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.COPY_MODAL_QTY,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/gentouea/buy`, {
					id: this.info.id,
					price: this.quantity,
				});
				if (!result) return false;
				// console.log(`result:`, result);
				uni.showToast({
					title: this.$lang.COMMON_SUCCESS,
					icon: 'success'
				})
				// 提交成功之后，关闭弹层 请求页面数据
				this.isShow = false;
				this.quantity = '';
				this.curPercent = '';
				setTimeout(() => {
					this.getDetail();
				}, 1000);
			},

			async getDetail() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/GentouEa/gentou_xq`, {
					id: this.id
				});
				if (!result) return false;
				// console.log(`result:`, result);
				this.info = result;
				// 处理 +123% -123%
				this.info.zongshouyilv = this.info.zongshouyilv.split('%')[0] * 1;
			},

			async getChartList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/gentouea/order_log`, {
					sfid: this.id,
					day: this.curTime
				});
				if (!result) return false;
				// console.log(`investors result:`, result);
				this.list = result;
				// klineTotal
				if (this.isShowKlineTotalReturns && this.$refs.klineTotal) {
					this.$refs.klineTotal.renderInit();
				}

			},

			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				// api/user/fastInfo
				const result = await this.$http.get(`api/user/assets`, {
					type: 1, // 合約賬戶
					name: 'USDT',
				});
				if (!result) return false;
				// console.log(`assets:`, result);
				this.balance = result.money || '';
			},

			setStyleTab(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.WHITE,
					fontSize: `28rpx`,
					fontWeight: val ? 700 : 100,
					padding: `12rpx 24rpx`,
					borderBottom: `6rpx solid ${val?this.$theme.WHITE:this.$theme.TRANSPARENT}`,
				}
			},

			setStyleTime(val) {
				return {
					fontSize: `24rpx`,
					textAlign: `center`,
					borderRadius: `32rpx`,
					padding: `4rpx 8rpx`,
					color: val ? this.$theme.WHITE : '#8E8D92',
					border: `1px solid ${val ? '#3B3B3D' : this.$theme.TRANSPARENT}`,
					backgroundColor: this.$theme.TRANSPARENT,
					minWidth: `120rpx`,
				}
			},

			// 設置百分比的選中樣式
			setStylePercent(val) {
				return {
					width: `50%`,
					textAlign: `center`,
					// backgroundColor: this.$theme.TRANSPARENT,
					color: val ? this.$theme.PRIMARY : '#8E8D92',
				}
			},
		}
	}
</script>
<style lang="scss" scoped>
	.common_header {
		padding: 0 40rpx;
		display: flex;
		align-items: center;
		padding-top: 48rpx;
		padding-bottom: 20rpx;
		// border-bottom: 1px solid #3B3B3D;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}

	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 11;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 13;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>