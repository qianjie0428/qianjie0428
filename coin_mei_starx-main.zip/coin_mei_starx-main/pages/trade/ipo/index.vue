<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header" style="background-color: #FFFFFF;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.TRADE_IPO_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="padding-bottom: 200rpx;">

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="border-radius: 24rpx;">
						<view style="display: flex;align-items: center;">
							<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
							<view style="padding-left: 20rpx;font-size: 32rpx;" :style="{color:$theme.SECOND}">
								{{item.goods.name}}
							</view>
							<view style="margin-left: auto;">
								<template v-if="item.end_day">
									<view class="common_tag" :style="setStyle(item.data)">
										{{item.end_day+` `+$lang.TRADE_IPO_LIST_DAY}}
									</view>
								</template>
							</view>
							<view style="color: #6e42ff;" @tap="openURL(item.baipishu_url)">{{$lang.TRADE_IPO_DETAIL_URL}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between; line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_TOTAL}}</view>
							<view :style="{color:$theme.SECOND}">{{$util.formatCoin(item.fa_amount)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.IPO_START_CT}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{item.shengou_date}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.IPO_END_CT}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{item.gb_date}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.IPO_DATE}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{item.online_date}}</view>
						</view>
						<!-- 动态进度 余力 -->
						<view style="background-color: #E8E8E8;border-radius: 24rpx;position: relative;height: 20rpx;">
							<view
								style="position: absolute;left: 0;right: 0;top:0;bottom: 0; background-color: #121212;border-radius: 24rpx;"
								:style="{width:setWidth(item.fa_amount*1,item.sell_num*1)*100 +`%`}">
							</view>
						</view>
						<view style="display: flex;align-items: center;line-height: 1.8;">
							<view :style="{color:$theme.SECOND}">{{$lang.TRADE_IPO_LIST_RC+ ` `}}
								{{$util.formatNumber(setWidth(item.fa_amount*1,item.sell_num*1)*100,2) +`%`}}
							</view>
							<view style="margin-left: auto;margin-top: 8px;" :style="{color:$theme.PRIMARY}" @tap="showModal(item)">
								{{$lang.IPO_SUB_NOW}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<template v-if="isShow">
			<view class="mask" @tap="handleClose()"></view>
			<view class="modal_wrapper">
				<view style="background-color: #FFFFFF;border-radius: 16rpx 16rpx 0 0;">
					<view style="display: flex;align-items: center;border-radius: 16rpx 16rpx 0 0;line-height: 3;"
						:style="{backgroundColor:$theme.PRIMARY}">
						<view style="flex:0 0 5%;"></view>
						<view style="flex:1 1 auto; text-align: center;font-size: 32rpx;font-weight: 700;color: #FFF;">
							{{detail.goods.name}}
						</view>
						<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(48)"
							style="padding-right: 24rpx;" @tap="handleClose()"></image>
					</view>

					<view style="padding: 40rpx;padding-bottom: 100rpx;">
						<view style="display: flex;align-items: center;justify-content:space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_PRICE}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{$util.formatCoin(detail.price)}}</view>
						</view>

						<TitleSecond :title="$lang.CONTRACT_CLOSE_QTY"></TitleSecond>
						<view class="common_input_wrapper"
							style="background-color:#F5F6FB;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 0;">
							<input v-model="quantity" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_QTY"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
						<view
							style="background-color: #F6F8FC;display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<block v-for="(item,index) in qtyList" :key="index">
								<view :style="setStyle(curQuantity == item)" @tap="changeQty(item)">{{item}}</view>
							</block>
						</view>

						<view style="display: flex;align-items: center;justify-content:space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_TOTAL}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{$util.formatCoin(total)}}</view>
						</view>

						<view class="common_btn" style="margin:40rpx auto;width: 80%;margin-top: 80rpx;" @click="handleBuy()">
							{{$lang.COMMON_BUY}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			TitleSecond
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				isShow: false, // 弹层
				detail: {},
				quantity: 0, // 数量输入框
				curQuantity: 100, // 当前选中预设值
			};
		},
		computed: {
			qtyList() {
				return [100, 500, 1000, 5000]
			},
			total() {
				return this.quantity * 1 <= 0 ? 0 : this.$util.formatNumber(this.quantity * 1 * this.detail.price * 1, 4)
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
			this.quantity = this.curQuantity;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeQty(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			async showModal(val) {
				// this.isShow = true;
				this.detail = val;
				const result = await uni.showModal({
					title: this.$lang.IPO_MODAL,
					cancelText: this.$lang.COIN_CURRENT_BTN_CANCEL,
					confirmText: this.$lang.COMMON_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.handleBuy();
				}
			},


			// handleClose() {
			// 	console.log(111);
			// 	this.isShow = false;
			// },
			async handleBuy() {
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.quantity,
					id: this.detail.id,
					// price: this.price
				})
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				// this.handleClose();
				setTimeout(() => {
					this.linkRecord();
				}, 1000);
			},
			// linkDetail(val) {
			// 	uni.navigateTo({
			// 		url: this.$CONSTANTS.TRADE_IPO_DETAIL + `?id=${val}`,
			// 	})
			// },
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.TRADE_IPO_RECORD
				})
			},
			openURL(val) {
				window.open(val)
			},

			// 计算每条数据的进度百分比 fa_amount - sell_num
			setWidth(val1, val2) {
				const tempVal1 = val1 * 1;
				const tempVal2 = val2 * 1;
				return tempVal2 / tempVal1;
			},


			setStyle(val) {
				const temp = val == 1 ? this.$theme.FALL : this.$theme.RISE;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result;
			},

			setStyle(val) {
				return {
					width: `25%`,
					textAlign: `center`,
					backgroundColor: val ? this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20) : this.$theme.TRANSPARENT,
					color: val ? this.$theme.RISE : this.$theme.LOG_VALUE
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}

	.mask {
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 1111;
		background-color: rgba(0, 0, 0, 0.6);
		cursor: pointer;
	}

	.modal_wrapper {
		position: fixed;
		bottom: 0;
		left: 50%;
		right: 0;
		z-index: 11113;
		width: 100%;
		background-color: transparent;
		animation: popopUp 300ms forwards;
		transform: translateX(-50%);
	}
</style>