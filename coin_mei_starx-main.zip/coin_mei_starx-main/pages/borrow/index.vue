<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- 获取到贷款信息，并且status:2 -->
		<template v-if="info && info.status==2">
			<view class="header_bg">
				<header class="common_header">
					<view class="left"  @click="$util.goBack()">
						<image src="/static/arrow_left_w.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
					</view>
					<view class="center" style="padding-left: 0;text-align: center;">
						<text style="color: #FFFFFF;">{{$lang.BORROW_TITLE}}</text>
					</view>
				</header>

				<view style="font-size: 96rpx; font-weight: 900;line-height:1.6;text-align: center;color:#FFFFFF;">
					{{info.xinyong}}
				</view>
				<view
					style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#FFFFFF;text-align: center;">
					{{$lang.BORROW_TIP_YOUR_SCORE}}
				</view>
			</view>
			<view class="common_block" style="border-radius: 24rpx;">
				<view style="display: flex;align-items: center;justify-content: center;padding: 24px;margin: 20rpx;">
					<image src="/static/borrow_pass.png" mode="aspectFit" :style="$theme.setImageSize(360,200)">
					</image>
				</view>

				<view
					style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#6D41FF;text-align: center;">
					{{$lang.BORROW_TIP_SUCCESS}}
				</view>

				<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: #6D41FF;color:#FFFFFF;"
					@click="linkRecord()">
					{{$lang.BORROW_BTN_NOW}}
				</view>
			</view>
			<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
				<view style="display: flex;align-items: center;justify-content: center;" @tap="linkService()">
					<image src="/static/borrow_service_1.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
					<view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 2.4;color:#6D41FF;">
						{{$lang.BORROW_LINK_SERVICE}}
					</view>
				</view>
			</view>
		</template>
		<template v-else>
			<!-- info:null  status -1 审核失败， 1 审核中 -->
			<view :style="$theme.setBGCover(`borrow_bg`)">
				<header class="common_header">
					<view class="left"  @click="$util.goBack()">
						<image src="/static/arrow_left_w.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
					</view>
					<view class="center" style="padding-left: 0;text-align: center;">
						<text style="color: #FFFFFF;">{{$lang.BORROW_TITLE}}</text>
					</view>
				</header>

				<view style="font-size: 96rpx; font-weight: 900;line-height:1.6;text-align: center;color:#FFFFFF;">
					???
				</view>
				<view
					style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#FFFFFF;text-align: center;">
					{{$lang.BORROW_TIP_UPLOAD}}
				</view>

				<template v-if="!info">
					<view style="padding:0 40rpx;">
						<template v-if="!obverseUrl">
							<view @click="selectImg()"
								style="display: flex;align-items: center;flex-direction: column; justify-content: center;padding: 24px;background-color: #9A97FF;border-radius: 8rpx;margin: 20rpx;min-height: 720rpx;border:1px solid #E8EAF3;">
								<image src="/static/icon_upload_w.png" style="margin:20rpx;width:80rpx;height:60rpx;">
								</image>
								<view
									style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#FFFFFF;text-align: center;">
									{{$lang.BORROW_TIP_UPLOAD_TIP}}
								</view>
							</view>
							<view class="common_btn"
								style="margin:80rpx auto;width: 80%;background-color: #9A97FF;color:#6E6BB4;">
								{{$lang.BORROW_BTN_UPLOAD}}
							</view>
						</template>
						<template v-else>
							<view
								style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #9A97FF;border-radius: 8rpx;margin: 20rpx;min-height: 720rpx;border:1px solid #E8EAF3;">
								<image :src="obverseUrl" @click="selectImg()" style="width:440rpx;height:700rpx;">
								</image>
							</view>
							<view class="common_btn"
								style="margin:80rpx auto;width: 80%;background-color:#FFFFFF;color:#121117;"
								@click="handleUpload()">
								{{$lang.BORROW_BTN_UPLOAD}}
							</view>
						</template>
					</view>
					<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
						<view style="display: flex;align-items: center;justify-content: center;" @tap="linkService()">
							<image src="/static/service_w.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image>
							<view
								style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 2.4;color:#FFFFFF;">
								{{$lang.BORROW_LINK_SERVICE}}
							</view>
						</view>
					</view>
				</template>

				<!-- status:-1 -->
				<template v-if="info && info.status==-1">
					<view
						style="display: flex;align-items: center;flex-direction: column; justify-content: center;padding: 24px;background-color:#FFFFFF;border-radius: 24rpx;margin: 20rpx;min-height: 720rpx;border:1px solid #E8EAF3;">
						<image src="/static/borrow_fail.png" style="margin:20rpx;width:360rpx;height:200rpx;">
						</image>
						<view
							style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#FF533B;text-align: center;">
							{{$lang.BORROW_TIP_UPLOAD_FAIL}}
						</view>
					</view>
					<view class="common_btn"
						style="margin:80rpx auto;width: 80%;background-color:#FFFFFF;color:#121117;"
						@click="handleReUpload()">
						{{$lang.BORROW_REUPLOAD}}
					</view>

					<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
						<view style="display: flex;align-items: center;justify-content: center;" @tap="linkService()">
							<image src="/static/service_w.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image>
							<view
								style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 2.4;color:#FFFFFF;">
								{{$lang.BORROW_LINK_SERVICE}}
							</view>
						</view>
					</view>
				</template>

				<!-- status:1 -->
				<template v-if="info && info.status==1">
					<view
						style="display: flex;align-items: center;flex-direction: column; justify-content: center;padding: 24px;background-color:#FFFFFF;border-radius: 24rpx;margin: 20rpx;min-height: 720rpx;border:1px solid #E8EAF3;">
						<image src="/static/borrow_apply.png" style="margin:20rpx;width:360rpx;height:200rpx;">
						</image>
						<view
							style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;color:#FFAD41;text-align: center;">
							{{$lang.BORROW_TIP_REVIEW}}
						</view>
					</view>
					<!-- <view class="common_btn"
						style="margin:80rpx auto;width: 80%;background-color:#FFFFFF;color:#121117;"
						@click="handleReUpload()">
						{{$lang.BORROW_REUPLOAD}}
					</view> -->

					<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
						<view style="display: flex;align-items: center;justify-content: center;" @tap="linkService()">
							<image src="/static/service_w.png" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image>
							<view
								style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 2.4;color:#FFFFFF;">
								{{$lang.BORROW_LINK_SERVICE}}
							</view>
						</view>
					</view>
				</template>
			</view>
		</template>
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				obverseUrl: null, // 上传凭证
				info: null, // 获取贷款信息
			};
		},
		onLoad(opt) {
			console.log(opt);
		},
		onShow() {
			this.isAnimat = true;
			this.getBorrowInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getBorrowInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.BORROW_RECORD
				});
			},
			linkService() {
				this.$util.linkCustomerService();
			},

			// 点击重新上传，切换到 info:null 界面，用于执行重新上传逻辑
			handleReUpload() {
				this.info = null;
				this.obverseUrl = null;
			},

			async handleUpload() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/dk_submit`, {
					image: this.obverseUrl || '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.getBorrowInfo();
				}, 1000);
			},

			async getBorrowInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/daikuan`);
				// if (!result) return false;
				console.log('info result:', result);
				this.info = result;
				this.info.status=2;
				
				this.obverseUrl = this.info.image;
			},

			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				this.upimg(imageFile.path);
			},
			// 上传图片
			async upimg(tempFilePath) {
				uni.showLoading({
					title: this.$lang.API_STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: this.$http.BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});
				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					this.obverseUrl = temp[0].url;
				}
				console.log(`obverseUrl`, this.obverseUrl);
				// this.setStorageData();
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/borrow_header.png);
		background-repeat: no-repeat;
		background-position: 0;
		background-size: 100%;
		width: 100%;
		height: 480rpx;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>