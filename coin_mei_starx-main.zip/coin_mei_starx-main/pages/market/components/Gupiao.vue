<template>
	<view style="padding-top: 10rpx;margin:20rpx;min-height: 100vh;">
		<template v-if="!list || Object.values(list).length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in Object.values(list)" :key="index">
				<view class="common_block"
					style="padding:10px;background-color: #FFFFFF;margin:20rpx 0;border-radius: 24rpx;"
					@click="linkInfo(item.code)">
					<view style="display: flex;align-items: center;">
						<view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:1 0 40%;padding-left: 40rpx;">
							<view :style="{color:$theme.SECOND}" style="font-size: 32rpx;line-height: 1.6;">
								{{item.name}}
							</view>

						</view>
						<view style="margin-left: auto;">
							<view style="font-size: 32rpx;font-weight: 700;text-align: right;"
								:style="{color:$theme.SECOND}">
								{{$util.formatCoin(item.current_price)}}
							</view>
							<view style="font-size: 28rpx;text-align: right;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>

	export default {
		name: 'MarketCoin',
		data() {
			return {
				// curTab: 0,
				list: null,
				socket: null, // websocket
				isConnected: false, // 是否链接socket
			}
		},
		computed: {
			// tabs() {
			// 	return [
			// 		this.$lang.MARKET_INDEX_TAB_HOP,
			// 		this.$lang.MARKET_INDEX_TAB_RISE,
			// 		this.$lang.MARKET_INDEX_TAB_FALL,
			// 	]
			// },
			// // 在此，根據val，對數據 排序[hot:val,rise:rate,fall:rate]
			// setList() {
			// 	if (!this.list || Object.values(this.list).length <= 0) {
			// 		return []
			// 	}
			// 	const temp = Object.values(this.list);
			// 	if (this.curTab == 0) return temp;
			// 	if (this.curTab == 1) {
			// 		return temp.sort((a, b) => b.rate - a.rate);
			// 	} else {
			// 		return temp.sort((a, b) => a.rate - b.rate);
			// 	}
			// }
		},
		beforeMount() {
			this.getList();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		onHide() {
			if (this.socket) this.disconnect();
		},
		methods: {
			// changeTab(val) {
			// 	this.curTab = val;

			// },
			// 设置样式
			setStyle(val, w = 120) {
				return {
					minWidth: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `44rpx`,
				}
			},

			// 跳转到详情
			linkInfo(val) {
				uni.reLaunch({
					url: this.$CONSTANTS.FOREX_DETAIL + `?code=${val}`
				});
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},

			// websocket链接
			connect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.pid] && data.pid && data.last > 0) {
							this.list[data.pid].current_price = data.last;
							this.list[data.pid].rate = data.pcp || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`, {
					gp_index: 3
				});
				console.log(result);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
				if (this.socket) this.disconnect();
				// 启动 websocket链接
				this.connect();
			}
		}
	}
</script>

<style>
</style>