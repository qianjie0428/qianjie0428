<template>
	<view>
		<view class="flex flex-b gap10 padding-10">

			<view v-for="(item, key, index) in list" :key="key" v-if="index < 3"
				style="background-color: #fff;padding: 20px;" class="flex-1 text-center radius30"
				@click="linkInfo(item.locate)">
				<view class="font-size-10">{{item.name}}</view>
				<view class="font-size-10" :style="$theme.setStockRiseFall(item.rate>0)">
					{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
				</view>
				<view style="font-size: 34rpx;font-weight: 700;" :style="$theme.setStockRiseFall(item.rate>0)">
					{{$util.formatCoin(item.current_price) }}
				</view>
			</view>
		</view>


		<!-- <view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.news">
				
			</TitlePrimary>
		</view>
		<view  style="margin:10rpx 40rpx;" >
			<view v-for="(item,index) in news_list" class="margin-top-10" @click="tiaozhuan(item.id)">
				<view class="bold font-size-14" style=" width: 100%; white-space: nowrap;overflow: hidden; text-overflow: ellipsis;">{{item.title}}</view>
				<view class="hui1 font-size-12">{{item.created_at}}</view>
				<view class="font-size-12 hui3" style="display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 3;overflow: hidden;text-overflow: ellipsis;white-space: normal;">{{item.sum_title}}</view>
				<view style="height: 1px;background-color: #999999;margin-top: 10px;"></view>
			</view>
		</view> -->

		<view>
			<NotifyPrimary ref="notify"></NotifyPrimary>
		</view>


		<!-- 	<view style="padding: 10px;">
			<image src="/static/home1.png" mode="aspectFit" style="width: 100%;"></image>
		</view> -->

		<view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.TABBAR_MARKET">
				<view style="font-size: 13px;margin-left: auto;" @click="linkMarket()" :style="{color:$theme.SECOND}">
					{{$lang.COMMON_MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view>

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;padding:40rpx;">
					<view style="display: flex;align-items: center;" @click="linkInfo(item.locate)">
						<view style="margin-right: auto;">
							<CustomLogo :logo="item.logo" :name="item.name" :size="50"></CustomLogo>
						</view>
						<view style="padding-left: 30rpx;flex:auto">
							<view style="align-items: center;" class="flex-b flex">
								<view style="padding-right: 60rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
									{{item.name}}
								</view>
								<view style="font-size: 32rpx;font-weight: 500;text-align: center;"
									:style="$theme.setStockRiseFall(item.rate>0)">
									{{$util.formatCoin(item.current_price)}}
								</view>
								<view class="text-center" style="padding: 2px 4px;border-radius: 5px;width: 70px;"
									:style="$theme.setStockRiseFall2(item.rate>0)">
									{{`${item.rate>0?'+':'-'} `+($util.formatNumber($util.formatMathABS(item.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
					<view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;line-height: 1.4;">
						{{`24H: ` }}<template v-if="item.vol">{{(item.vol*1).toFixed(0)}}</template>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import NotifyPrimary from '../../notify/components/NotifyPrimary.vue';
	export default {
		name: 'CoinList',
		components: {
			TitlePrimary,
			NotifyPrimary
		},
		data() {
			return {
				gpIndex: 1,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
				list3: "",
				news_list: ""
			};
		},
		created() {
			this.getList();
			// this.get_NewsList()
			if (this.$refs.notify) this.$refs.notify.getList();
		},

		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			tiaozhuan(id) {
				uni.navigateTo({
					url: "/pages/webview?id=" + id
				})
				// window.location.href=url
			},
			isValidIndex(index) {
				// this.iindex=this.iindex+1;
				// console.log(this.iindex <= 2)
				// return this.iindex <= 2;  
			},
			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$CONSTANTS.MARKET_INDEX + `?type=0`,
				})
			},
			// 跳转到 coin trade index
			linkInfo(code) {
				uni.reLaunch({
					url: this.$CONSTANTS.COIN_INDEX + `?code=${code}`
				});
			},

			// websocket链接
			connect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WS_COIN_URL);
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {


							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/list`, {
					page: this.curPage,
					gp_index: this.gpIndex
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				if (this.socket) this.disconnect();
				this.connect(); // 启动 websocket链接
			}
		}
	}
</script>

<style>
</style>