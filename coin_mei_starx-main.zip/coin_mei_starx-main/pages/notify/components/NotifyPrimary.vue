<template>
	<view
		style="margin:20rpx 30rpx;border-radius: 4px;display: flex;align-items: center;background-color: #FFFFFF;padding:0 20px;">
		<image src="/static/horn.png" mode="aspectFit" :style="$theme.setImageSize(30)"></image>
		<template v-if="list.length>0">
			<u-notice-bar :text="title" speed="80" @click="linkTo" :color="$theme.SECOND" bgColor="#FFFFFF"
				direction="column" icon=""></u-notice-bar>
		</template>
		<!-- <image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(30)" @click="actionEvent()"></image> -->
	</view>
</template>

<script>
	export default {
		name: 'NotifyPrimary',
		data() {
			return {
				list: []
			}
		},
		computed: {
			title() {
				if (this.list.length > 0) {
					return this.list.map(item => item.biaoti)
				} else {
					return this.$lang.NOTIFY_TITLE
				}
			},
		},
		created() {
			this.getList();
		},
		methods: {
			linkTo(val) {
				console.log(val);
				uni.navigateTo({
					// url:"/pages/webview?id="+this.list[val].id
					url: this.$CONSTANTS.NOTIFIY_INDEX
				})
			},
			async getList() {
				const result = await this.$http.get(`api/app/gglist`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result || [];
			}
		}
	}
</script>

<style>
</style>