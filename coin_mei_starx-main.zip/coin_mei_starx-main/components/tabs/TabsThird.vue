<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding: 10px 10px 0 10px;" @touchmove.stop>
		<block v-for="(item,index) in tabs" :key="index">
			<view @click="handleChange(index)"
				style="display: inline-block; width:max-content;height: 20px;padding:4px 6px;margin-right: 20px;text-align: center;"
				:style="setStyle(current === index)">
				{{item}}
			</view>
		</block>
	</scroll-view>
</template>

<script>
	export default {
		name: "TabsThird",
		props: ['tabs'],
		data() {
			return {
				current: 0,
			};
		},
		methods: {
			setStyle: (active = true) => {
				return {
					color: active ? this.$theme.PRIMARY : this.$theme.TEXT,
					borderBottom: `3px solid ${active ?  this.$theme.PRIMARY:'transparent'}`,
				}
			},
			handleChange(val) {
				this.current = val;
				this.$emit('action', val);
			},
		}
	}
</script>

<style>

</style>