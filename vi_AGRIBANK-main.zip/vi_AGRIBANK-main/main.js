import Vue from 'vue';
import App from './App';
import * as theme from '@/common/theme.js';
// import * as http from '@/common/http.js';

Vue.config.productionTip = false;
Vue.prototype.$theme = theme;
// Vue.prototype.$http = http; // http api

App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()