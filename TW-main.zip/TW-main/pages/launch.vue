<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding:0 0;">
			<view style="margin-top: 200px;">
				<image src='/static/applogo.png' mode="aspectFit" :style="$util.setImageSize(200,200)">
				</image>
			</view>
		</view>
		<view class="font-size-16 text-center" style="color: #fff;margin-top: 10px;">玖瞬數位軟體</view>
		<view class="font-size-12 text-center" style="color: #fff;margin-top: 10px;">登入後即可完整使用APP功能</view>

		<view style="display: flex;align-items: center;justify-content: center;">
			<!-- <image src="/static/launch_img.png" mode="aspectFit" :style="$util.setImageSize(512)"></image> -->

		</view>

		<view style="display: flex;align-items: center;justify-content: center;">
			<!-- <view style="margin-top: 20px;text-align: center;font-size: 32rpx;font-family: 700;color:#FFFFFF;">
				온라인 주식 거래 어플리케이션
			</view> -->
		</view>
		<view style="border-top: 1px #7d7d7d dashed;margin-top: 100px;"></view>

		<view style="margin-top: 170px;">
			<view style="position:relative;margin:30rpx 120rpx;height:12rpx;border-radius: 20rpx;padding:0 3px;">
				<view :style="setStyle"></view>
				<!-- <view :style="imgMove"> </view> -->
			</view>
			<view style="text-align: center;color: #bca27c;font-size: 30rpx;margin-top: 30rpx;">
				正在載入 {{`${percentage} %`}} . . .
			</view>
		</view>

	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		computed: {
			setStyle() {
				const temp = {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '30rpx',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg, #725842 ,#725842)`,
					borderRadius: '20rpx',
				};
				return temp;
			},
			// 圆点的位移
			imgMove() {
				const temp = {
					backgroundImage: `url('/static/launch_loading_icon.png')`,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: `${this.percentage}% 0px`,
					backgroundSize: 'auto',
					width: ' 100%',
					height: '40rpx',
					position: 'absolute',
					left: 0,
					right: 0,
					top: '-12rpx',
					bottom: 0,
					zIndex: 99,
				};
				return temp;
			}
		},
		onLoad() {
			this.onSetTimeout();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						uni.$u.sleep(1500).then(() => {
							uni.switchTab({
								url: HOME,
							})
						})
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					// console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100vw;
		min-height: 100vh;
		background-image: url('/static/lanuch_sc.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>