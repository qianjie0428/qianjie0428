<!-- 银转证 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="入金" @action="handleBack()"></CustomHeader>
		<view class=" " style="padding:20rpx;">
			<view style="text-align: center;color: #fff;	font-size: 30rpx;margin: 5px 0;">帳戶餘額</view>
			<view class="bold" style="text-align: center; font-size: 52rpx;color: #ccc;margin: 5px 0;">
				{{$util.formatNumber(userInformation.money)}}
			</view>

			<!-- <view style="display: flex;justify-content:center;align-items: center;margin-top: 30rpx;">
				<view v-for="(item,index) in items" :key="index"
					style="border-radius: 100px;height: 24px;text-align: center;line-height: 24px;width: 100px;"
					:style="{color:Inv==index?'#000':'#fff',backgroundColor:Inv==index?'#f3c997':''}"
					@click="Inv=index">{{item}} </view>
			</view> -->

			<!-- <view v-show="Inv == 0">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;margin-top: 10px;background-color: #66564a;border-radius: 10px;">
					<text style="flex:25%;">收款名稱</text>
					<text style="flex:55%;text-align: center;font-weight: 500;">{{BankUser}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser)">複製</text>
					<view class="duplicate" @tap="service()">客服</view>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
					<text style="flex:20%;">收款銀行</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">{{BankName}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName)">複製</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
					<text style="flex:20%;">應收帳款</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNO}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNo)">複製</text>
				</view>
			</view>

			<view v-show="Inv == 1">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
					<text style="flex:25%;">收款名稱</text>
					<text style="flex:55%;text-align: center;font-weight: 500;">{{BankUser_2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser_2)">複製</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
					<text style="flex:20%;">收款銀行</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">{{BankName_2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName_2)">複製</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
					<text style="flex:20%;">應收帳款</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNO_2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNO_2)">複製</text>
				</view>
			</view> -->
			<!-- 查看 -->
			<!-- <view
				style="display: flex;align-items: center;font-size:14px;color: #fff;font-weight: 700;padding:10px;background-color: #66564a;border-radius: 10px;margin-top: 10px;">
				<text style="flex:20%;">儲值記錄</text>
				<text style="flex:60%;text-align: center;font-weight: 500;"> </text>
				<text style="flex:20%;text-align: right;" @tap="capitalDetails()">詳情</text>
			</view> -->

			<!-- 充值金额 -->
		<!-- 	<view style="display: flex;align-items: center;font-size:12px;color: #fff;padding:10px;margin-top: 10px;border-radius: 10px;">
				
				<text style="flex:200%;text-align: center;font-weight: 500;color:#ccc;">
					最低儲值金額為
					<text style="color:#ccc">{{` 1000000 `}}</text></text>
				<text style="flex:20%;text-align: right;"></text>
			</view> -->
           <view class="color-white font-size-16" style="padding: 10px 0px;">入金金額</view>
			<view class="recharge">
				<input placeholder="輸入入金金額" type="number" v-model="value1" style="background-color: #66564a;color: #fff;"
					placeholder-style="font-size:14px;"></input>
			</view>

			<!-- <view style="display: flex;align-items: center;flex-wrap: wrap;margin-top: 30rpx;">
				<block v-for="(item,index) in qtyList" :key="index">
					<view style="flex:40%;text-align: center;line-height: 2.4;margin: 12rpx 24rpx;border-radius: 16rpx;border: 1px #ccc solid;"
						:style="{color:item==curAmount?'#000':'#fff',backgroundColor:item==curAmount?'#f3c997':'#45382e' }"
						@click="quantity(item)">{{$util.formatNumber(item)}}</view>
				</block>
			</view> -->

			<!-- 			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:30%;text-align: left;">인증서 업로드</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">인증서를 업로드하렴 클릭하세요.</text>
				<text style="flex:10%;text-align: right;"></text>
			</view> -->

			<!-- 			<u-upload
				:fileList="fileList6"
				@afterRead="afterRead"
				@delete="deletePic"
				name="6"
				multiple
				:maxCount="1"
				width="250"
				height="150"
				style="margin:10vw;"
			>
				<image src="/static/positive.png" 
				mode="widthFix" style="width: 250px;height: 150px;"></image>
			</u-upload> -->

			<!-- 儲值 -->
			<view @click="to_recharge()" style="background-color:#f3c997;margin: 50rpx 30rpx;
					border-radius: 10rpx;
					padding: 20rpx 0;
					text-align: center;
					color: #000;
					font-size: 28rpx;">
				確認
			</view>
			<!-- <view style="font-size: 14px;font-weight: 700;text-align: center;line-height: 1.8;color: #fff;">友情提示</view>
			<view style="padding-bottom:6px;line-height: 1.6;color: #fff;">1. 當日交易的經費可在2個交易日後提領。</view>
			<view style="padding-bottom:6px;line-height: 1.6;color: #fff;">2. 儲值需要身分驗證和銀行帳戶關聯。</view>
			<view style="padding-bottom:6px;line-height: 1.6;color: #fff;">3. 儲值時間：交易日9:00-15:30。</view>
			<view style="padding-bottom:6px;line-height: 1.6;color: #fff;">4. 每次儲值金額不能低於10,000韓元。</view>
			<view style="padding-bottom:6px;line-height: 1.6;color: #fff;">5. 申請後2小時內儲值。</view> -->
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import {
		pathToBase64
	} from '@/common/js_sdk.js'
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				qtyList: [1000000, 5000000, 10000000, 50000000], // 备选数组
				curAmount: 1000000, // 当前选中值

				serviceService: '請聯絡客服查看。',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: '頻道 1'
					},
					{
						name: '頻道 2'
					},
				],
				Inv: 0,
				items: ['頻道 1', '頻道 2']
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			//客服
			service() {
				uni.navigateTo({
					url: '/pages/service/service'
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/capitalDetails/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('請先檢查您的密碼');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: '複製成功',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(val) {
				this.curAmount = val;
				this.value1 = val;
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "載入中，請稍等...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					// uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = '金融卡',
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/certificateBank/silver-b'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {

				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value

				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				uni.hideLoading();


			},
		},

		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},

	}
</script>

<style lang="scss">
	//充值金额
	.recharge {
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}
</style>