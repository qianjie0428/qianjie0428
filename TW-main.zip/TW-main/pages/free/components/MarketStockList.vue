<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding: 5px 8px;">
			<view style="padding: 12rpx 10rpx;display: flex;align-items: center;border-radius: 10px;background-color: #40342a;"
				
				@click="$u.route('/pages/productDetails/productDetails',{code:item.code});">
		
				<view style="flex: 6%;padding:10rpx 0;">
					
						<view :style="$util.setImageSize(60)"
							style="background-color:#18BFB4;text-align: center;line-height: 60rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
							{{item.name.slice(0,1)}}
						</view>
					
				</view>
		
				<view style="flex: 44%;padding-left: 10rpx;">
					<view class="color-white">{{item.name}}</view>
					<view style="font-size: 24rpx;color: #ccc;">{{item.code}}</view>
				</view>
		
				<view style="flex:30%;font-size: 16px;":style="{color:`${item.rate>0?'#ff1b45':'#39b44c'}`}">
					{{$util.formatNumber(item.price*1)}}
				</view>
		
				<view style="flex:20%;" :style="{color:`${item.returns>0?'#ff1b45':'#39b44c'}`}">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<image mode="aspectFit" :src="`/static/${item.rate>0?'up':'down'}.png`"
							:style="$util.setImageSize(20)"></image>
						<view :style="{color:`${item.rate>0?'#ff1b45':'#39b44c'}`}">{{(1*item.rate).toFixed(2)}}%</view>
					</view>
				</view>
		
			</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketStockList',
		components: {
			EmptyData,
			CustomLogo
		},
		data() {
			return {
				list: [],
				socket: null, // websocket
			}
		},
		computed: {

		},
		created() {
			this.getList();
		},
		methods: {
			setStyle(val) {
				return {
					// backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					borderRadius: `44rpx`,
					padding: `8rpx`,
					width: `160rpx`,
					textAlign: `center`,
				}
			},

			// 跳转到详情
			linkInfo(val) {
				uni.navigateTo({
					// url: this.$paths.STOCK_OVERVIEW + `?code=${val}`
				})
			},
			async getList() {
			    try {
			        const response = await this.$http.get(`api/user/collect_list`);
			        console.log('response:', response);
			        const result = response.data ? response.data.data.list : [];
			        console.log('result:', result);
			        if (!Array.isArray(result)) {
			            console.error('API 返回的数据不是数组:', result);
			            this.list = [];
			            return;
			        }
			        const temp = result.length <= 0 ? [] : result;
			        this.list = temp.length <= 0 ? [] : temp.map(item => {
			            return {
			                name: item.goods.ct_name || 0,
			                code: item.goods.code || 0,
			                price: item.goods.current_price || 0,
			                rate: item.goods.rate || 0,
			                type_id: item.goods.project_type_id || 0,
			            };
			        });
			        console.log(222222222,this.list);
			    } catch (error) {
			        console.error('获取数据时发生错误:', error);
			        this.list = [];
			    }
			}

		}
	}
</script>

<style>
</style>