<!-- 收藏的 -->
<template>
	<view class="lanuch_sc">
		<Header :title="$lang.FAVORITES"></Header>

		<view style="padding:0px 10px;">
			<view class="sc_bg5" style="padding:40px 30px;">
				<view class="bold font-size-18 margin-top-10">{{userInformation.nick_name}}</view>
				<view style="margin-top: 10px;color: #888888;">{{userInformation.p_mobile}}</view>
			</view>
		</view>

		<view style="padding: 0px 15px;margin-top: 15px;">
			<view style="display: flex;align-items: center;background-color: #4b3d32;border-radius: 30px;">
				<view :class="Inv==0?'with-bottom-line':'with-bottom-line2'" @click="qiehuan(0)"
					style="flex:30%;text-align: center;">
					指數
				</view>
				<view :class="Inv==1?'with-bottom-line':'with-bottom-line2'" @click="qiehuan(1)"
					style="flex:30%;text-align: center;">
					收藏
				</view>
			</view>
		</view>


		<view v-if="Inv==0" class="common_block sy_zs" style="margin-top: 30rpx;">
			<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
				<text style="flex:60%;color: #fff;">名稱/代碼</text>
				<text style="flex:40%;color: #fff;">波動率</text>
				<text style="flex:18%;color: #fff;">漲跌幅</text>
				<!-- <view style="flex:6%;"> </view> -->
			</view>
			<u-gap height="1" bgColor="#EEEEEE"></u-gap>
			<GoodsList :list="zhishu_list"></GoodsList>
		</view>

		<view v-if="Inv==1" class="common_block sy_zs" style="margin-top: 30rpx;">
			<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
				<text style="flex:60%;color: #fff;">名稱/代碼</text>
				<text style="flex:40%;color: #fff;">波動率</text>
				<text style="flex:18%;color: #fff;">漲跌幅</text>
				<!-- <view style="flex:6%;"> </view> -->
			</view>
			<u-gap height="1" bgColor="#EEEEEE"></u-gap>
			<MarketStockList ref="all"></MarketStockList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import MarketStockList from './components/MarketStockList.vue';
	export default {
		components: {
			Header,
			EmptyData,
			MarketStockList,
			GoodsList,
		},
		data() {
			return {
				downloadUrl: '',
				updateDesc: "",
				update: '',
				goodsList: [],
				closeOnClickOverlay: false,
				business: '',
				updata: true,
				goodsList: [],
				// exchange: '',
				userInformation: "",
				cardManagement: '',
				timerId: null,
				Inv: 1,
				zhishu_list: "",
			}
		},
		//页面显示了，会触发多次，只要页面隐藏，然后再显示出来都会触发
		onShow() {
			this.startTimer()
			this.gaint_info()
			this.zhishu()
			
			this.$refs.all.getList()
		},
		onLoad() {
			this.startTimer()
			this.gaint_info()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		onReachBottom() {
			// this.page = this.page + 1;
			// this.good_list()
		},
		methods: {
			async zhishu() {
				let result = await this.$http.get('api/goods/zhishu', {
					inv: 1
				})
				this.zhishu_list = result.data.data.list
			},
			setLogo(val) {
				return this.$BaseUrl + val;
			},
			qiehuan(index) {
				this.Inv = index
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {})
				this.userInformation = list.data.data;
			},
			//产品세부
			productDetails(gid) {
				uni.navigateTo({
					url: `/pages/productDetails/productDetails?gid=${gid}`
				});
			},
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.good_list()
				}, 3000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let result = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = result.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
		},
	}
</script>

<style lang="scss">
	.with-bottom-line {
		background-color: #f7cc9b;
		border-radius: 30px;
		padding: 5px;
		color: #000;
	}

	.with-bottom-line2 {
		color: #ccc;
	}
</style>