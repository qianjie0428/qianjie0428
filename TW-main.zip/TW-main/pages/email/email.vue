<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="通知" @action="$u.route({type:'navigateBack'})"></CustomHeader>
		<view>
			<block v-for="(item,index) in cardManagement" :key="index">
				<view class="text-center color-white">{{item.time1}} {{item.time2}}</view>
				<view style="padding: 10px;">
					<view style="background-color: #44477a;color: #fff;padding: 10px;border-radius: 10px;">{{item.ct_desc}}</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components:{CustomHeader},
		data() {
			return {
				//
				tablist: [{
					name: '全部'
				}, {
					name: '信號通知'
				}, {
					name: '社群'
				}, {
					name: '常見'
				}],
				current: 0,
				cardManagement: [],
			}
		},
		onShow() {
			this.gaint_info()
		},
		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},

		methods: {
			change(index) {
				console.log(index)
				this.current = index;
			},
			
			async gaint_info() {
					let response = await this.$http.get('api/user/finance',{
						type:2
					});
					this.cardManagement = response.data.data
				},
			
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
		},
	}
</script>
