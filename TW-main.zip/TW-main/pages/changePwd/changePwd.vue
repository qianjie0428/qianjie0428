<!-- 修改登陆密码 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="修改登入密碼" @action="handleBack()"></CustomHeader>

	<view style="padding:10px 15rpx;margin:0 20rpx;border-radius: 10px;">
		<view style="padding: 10px;">
			<view class="color-white font-size-15">當前密碼</view>
			<view style="padding: 20rpx;
			margin: 10rpx 0;
			background: #201c19;
			border-radius: 15rpx;color: #ccc;">
				<input placeholder="請輸入當前密碼"  v-model="value"
					placeholder-style="font-size:12px"></input>
			</view>
			<view class="color-white font-size-15 margin-top-10">新密碼</view>
			<view style="padding: 20rpx;
			margin: 10rpx 0;
			background: #201c19;
			border-radius: 10rpx;color: #ccc;">
				<input placeholder="請輸入新密碼" v-model="value2"
					placeholder-style="font-size:12px"></input>
			</view>
			<view class="color-white font-size-15 margin-top-10">確認新密碼</view>
			<view style="padding: 20rpx;
			margin: 10rpx 0;
			background: #201c19;
			border-radius: 10rpx;color: #ccc;">
				<input placeholder="請再次輸入新密碼"  v-model="value3"
					placeholder-style="font-size:12px"></input>
			</view>

			<view @click="changePassword" style="background-color: #dabb8f;margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #000;">確認修改</view>
		</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 顶部导航回退操作
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//修改登录密码
			async changePassword() {
				let list = await this.$http.post('api/user/updateLoginPassword', {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('已完成.');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
	}
</script>

<style lang="scss">
	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}
</style>