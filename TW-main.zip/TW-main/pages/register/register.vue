<!-- 注册 -->
<template>
	<view class="launch">
		<view style="justify-content: flex-end; display: flex;align-items: center;padding: 10px 10px 0 0;"
			@click="$util.linkCustomerService()">
			<image src="../../static/sy_kf.png" mode="aspectFit" style="width: 30px;height: 30px;"></image>
		</view>
		<view style="display: flex;justify-content: center;">
			<image mode="widthFix" src="/static/applogo.png" :style="$util.setImageSize(200)">
			</image>
		</view>
		<view class="font-size-16 text-center" style="color: #fff;">玖瞬數位軟體</view>
		<view class="font-size-12 text-center" style="color: #fff;margin-top: 10px;">登入後即可完整使用APP功能</view>

		<view class="padding-20 ">
			<view style="border-radius: 10px;background-color: #65544999;">
				<view
					style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top: 12px;">
					<view
						style="width: 90%;line-height: 20px;height: 10px;position: relative;font-size: 16px;color: #DABB8F">
						電話號碼</view>
					<input shape="" :placeholder="$lang.USER_NAME" placeholderStyle="font-size: 13px;color: #6d6b69"
						prefixIconStyle="font-size: 22px;margin-left:10px" v-model="value1" type="number" maxlength="10"
						style="margin-top:20px;background-color: #201c19;width: 85%;color: #ccc;padding: 10px;border-radius: 5px;flex: 100%;"></input>

					<!-- <view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;color: #DABB8F"> 密碼</view>
				<input shape="" :placeholder="$lang.PASSWORD" prefixIcon="lock-fill" 
					placeholderStyle="font-size: 13px;color: #6d6b69"
					prefixIconStyle="font-size: 22px;margin-left:10px" v-model="value2" type="password"
					style="margin-top:60rpx;background-color: #201c19;width: 85%;color: #ccc;padding: 10px;border-radius: 5px;"></input> -->


					<view style="width: 90%;font-size: 16px;color: #DABB8F;padding: 10px 0px;">密碼</view>
					<view class="flex"
						style="background-color: #201c19;padding: 10px;border-radius: 5px;width: 85%;color: #ccc;">
						<input v-model="value2" :password="isMask" shape="" :placeholder="$lang.PASSWORD"
							prefixIcon="lock-fill" placeholderStyle="font-size: 13px;color: #6d6b69"
							style="font-size: 13px;flex: 100%;"></input>
						<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleAmount()" style=""></image>
					</view>

					<view style="width: 90%;font-size: 16px;color: #DABB8F;padding: 10px 0px;">確認密碼</view>
					<view class="flex flex-b"
						style="background-color: #201c19;padding: 10px;border-radius: 5px;width: 85%;color: #ccc;">
						<input v-model="value3" :password="isMask" shape="" :placeholder="$lang.PASSWORD_CONFIRM"
							prefixIcon="lock-fill" placeholderStyle="font-size: 13px;color: #6d6b69"
							style="font-size: 13px;flex: 100%;"></input>
						<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleAmount()" style=""></image>
					</view>

					<!-- <view style="width: 85%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;color: #DABB8F">確認密碼</view>
							<input shape="" :placeholder="$lang.PASSWORD_CONFIRM" prefixIcon="lock-fill" 
								placeholderStyle="font-size: 13px;color: #6d6b69"
								prefixIconStyle="font-size: 22px;margin-left:10px" v-model="value3" type="password"
								style="margin-top:60rpx;background-color: #201c19;width: 85%;color: #ccc;padding: 10px;border-radius: 5px;"></input> -->

					<view
						style="width: 90%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 10px;color: #DABB8F">
						推薦碼</view>
					<input shape="" :placeholder="$lang.INVITATION_CODE" prefixIcon="lock-fill"
						placeholderStyle="font-size: 13px;color: #6d6b69"
						prefixIconStyle="font-size: 22px;margin-left:10px" v-model="code"
						style="margin-top:40rpx;background-color: #201c19;width: 85%;color: #ccc;padding: 10px;border-radius: 5px;flex: 100%;"></input>



					<view class=""
						style="padding: 20px;width: 90%;justify-content: center;align-items: center;flex-direction: column;display: flex;">
						<view class="text-center color-white"
							style="width: 70%;margin-top:20rpx;background-color: #DABB8F;padding: 10px;border-radius: 40px;"
							@click="gain_register">註冊</view>
					</view>

					<view class="flex" style="padding: 10px;" @tap="signIn()">
						<view class="color-white font-size-15">有帳號，</view>
						<view class="font-size-15" style="color: #dabb8f;border-bottom: 1px #dabb8f solid;">去登入</view>
					</view>

				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nick_name: '',
				value1: '',
				value2: '',
				value3: '',
				code: '',
				isMask: null, // 掩码
				yan_show: true,
			};
		},
		methods: {
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					url: '/pages/signin/signin'
				});
			},
			toggleAmount() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			//注册
			async gain_register() {
				if (this.value1 == '') {
					uni.$u.toast('請輸入您的電話號碼');
				}
				if (this.value1 && this.value1.length < 10) {
					uni.$u.toast('請輸入十位以上的電話號碼');
				} else if (this.value2 == '') {
					uni.$u.toast('請輸入您的密碼');
				} else if (this.value3 == '') {
					uni.$u.toast('請輸入您的密碼');
				} else if (this.value3 != this.value2) {
					uni.$u.toast('兩個密碼不匹配');
				} else if (!this.code) {
					uni.$u.toast('請輸入您的推薦碼');
				} else {
					let list = await this.$http.post('api/app/register', {
						mobile: this.value1.trim(),
						password: this.value2,
						confirmpass: this.value3,
						invite: this.code.trim(),
						code: 123456,
					})
					// console.log(list.data.code);
					if (list.data.code == 0) {
						uni.$u.toast('註冊完成，請登入');
						setTimeout(() => {
							uni.navigateTo({
								url: '/pages/signin/signin'
							});
						}, 1000)
					} else {
						uni.$u.toast(list.data.message);
					}
				}
			},

		},

	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100vw;
		min-height: 100vh;
		background-image: url('/static/lanuch_sc.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>