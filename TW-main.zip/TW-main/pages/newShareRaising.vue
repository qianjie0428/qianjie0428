<!-- 新股抢筹/配售 -->
<template>
	<view >
		<CustomHeader :title="$lang.NEW_SHARE_RAIS" @action="handleBack()"></CustomHeader>

		<view
			style="padding: 10px;margin:20px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
			<TradeHeader :title="$lang.NEW_SHARE_RAIS" icon="shares" @action="applyPurchase()"></TradeHeader>

			<view v-for="(item,index) in funding" :key="index"
				style="border-bottom: 0.037037rem solid #e0e0e0;margin:10px;padding-bottom: 10px;">
				<view class="display" style="margin: 20rpx 0;">
					<view class="">
						<view class="corporation">{{item.goods.name}}</view>
						<view class="area" v-if="item.goods.locate=='깊은'">
							<view class="deep">{{item.goods.locate}}</view>
							<view class="deep-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='북쪽'">
							<view class="north">{{item.goods.locate}}</view>
							<view class="north-number">{{item.goods.code}}</view>
						</view>
						<view class="area" v-if="item.goods.locate=='상하이'">
							<view class="shanghai">{{item.goods.locate}}</view>
							<view class="shanghai-number">{{item.goods.code}}</view>
						</view>

					</view>
					<!-- 申购 -->
					<view @tap="purchase(item.id,item.peishou_price)" style="background-color: #4b5fcc;
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx">
						요청서
					</view>
				</view>

				<view class="display">
					<view class="display find">
						<view class="">
							발행 가격</view>
						<view class="">{{item.price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}/공유하다</view>
					</view>
					<view class="display ration">
						<view class="">
							배치 가격</view>
						<view class="">{{item.peishou_price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			TradeHeader,
			EmptyData
		},
		data() {
			return {
				funding: ''
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			// 기록 보관 保持记录中
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/ration'
				});
			},
			// 우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.funding = list.data.data
				// console.log(this.funding, '99999999');
			},
		},
		mounted() {
			this.scramble()
		}
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	.purchase {
		background-color: #212265;
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	// .science {
	// 	// margin: 30rpx;
	// 	// padding-bottom: 30rpx;
	// 	border-bottom: 0.037037rem solid #e0e0e0;


	// }
</style>