<!-- 实时传输 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="出金" @action="handleBack()"></CustomHeader>

		<view class="" style="padding:30rpx;">

			<view class="text-center font-size-18" style="color: #fff;">
				目前可出金金額
			</view>
			<view class="text-center bold margin-top-10 font-size-24" style="color: #ccc;">
				{{$util.formatNumber(userInformation.money)}}
			</view>
			<!-- <view class="text-center">
				자금 동결 {{userInformation.freezeMoney}}
			</view> -->
			<!-- <view style="width: 50%;margin-left: 25%;"
				class="radius10 color-white text-center margin-top-10">
				當前可轉讓餘額
			</view> -->
			<template>
			  <view style="color: #fff; padding: 10px 0px;">
			    <view style="padding: 10px 0px;">出金銀行帳號</view>
			
			    <!-- 显示选中的数据 -->
			    <u-button @click="show = true"   style="background-color: #f8f8f8; color: #333;">
			      {{ selectedData ? selectedData.bank_name + ' - ' + selectedData.card_sn : '選擇帳戶' }}
			    </u-button>
			
			    <!-- 弹出窗口 -->
			    <u-popup :show="show" mode="center" :round="10" @close="close" @open="open">
			      <view>
			        <block v-for="(item, index) in cardManagement" :key="index">
			          <view class="padding-10">
			            <view
			              style="background-color: #f7cd9b; border-radius: 10px; padding: 10px 20px;"
			              @click="selectData(item)"
			            >
			              <view style="padding: 5px 10px;color: #000;">
			                <view class="font-size-16">{{ item.card_sn }}</view>
			                <view class="flex flex-b">
			                  <view class="font-size-15 bold">{{ item.realname }}</view>
			                  <view style="padding: 10px 0px;">{{ item.bank_name }}</view>
			                </view>
			              </view>
			            </view>
			          </view>
			        </block>
			      </view>
			    </u-popup>
			  </view>
			</template>

			<view class="margin-top-20 hui2">
				<view style="color:#ccc;">出金金額</view>
				<view class="margin-top-10 input-container">
					<input placeholder="請輸入出金金額" v-model="value1"
						style="background-color:#66564a;color: #fff;padding: 10px;border-radius: 5px;" placeholderStyle="color:#ccc;font-size:12px;">
						<span class="input-text"  @click="whole(tixian_money1())">全額</span>
						<!-- <view @click="whole(tixian_money1())" class="color-white">전액</view> -->
					</input>
				</view>
			</view>

			<view class="margin-top-10 hui2">
				<view style="color:#ccc;">交易密碼</view>
				<view class="margin-top-10">
					<input placeholder="請輸入交易密碼"v-model="value2"
						style="background-color:#66564a;color: #fff;padding: 10px;border-radius: 5px;"
						placeholderStyle="color:#8c8c8c;font-size:12px;"></input>
				</view>
			</view>
			<view class="margin-top-30 text-center radius10 padding-10 color-white" style="background-color: #f3c997;color: #000;"
				@click="to_withdraw()">
				確認出金
			</view>

			<!-- <view class="guize color-white">
				<view>1. 賣出收益需等待2個交易日後才能提取。</view>
				<view>2. 提款時需驗證實名並確認帳戶後再提款。</view>
				<view>3. 提款交易可用時間：平日上午09:00至下午15:30（*週末及公眾假期不可提款）</view>
				<view>4. 每次提現最低金額為10,000單位。</view>
				<view style="color:#ff3636"> 5.請求提領後，原則上當天入金，2小時內完成入金。</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value1: '',
				value2: '',
				 show: false,
				value3: "",
				userInformation: '',
				cardManagement: [],
				 show: false, // 控制弹窗显示状态
				      selectedData: null, // 存储选中的数据项
			};
		},
		methods: {
			// tixian_money() {
			// 	let money = this.userInformation.money - this.userInformation.freezeMoney;
			// 	return money < 0 ? 0 : this.$util.formatNumber(money)
			// },
			tixian_money() {
				let money = this.userInformation.with;
				return money < 0 ? 0 : this.$util.formatNumber(money)
			},
			tixian_money1() {
				let money = this.userInformation.money - this.userInformation.freezeMoney;
				return money < 0 ? 0 : money
			},
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			 async to_withdraw() {
			      if (!this.selectedData) {  // 判断是否选择了提款账户
			        uni.$u.toast('請選擇提款帳戶');  // 未选择时提示用户选择
			        return;  // 终止函数
			      }
			
			      uni.showLoading({
			        title: "請稍候......",
			        mask: true
			      });
			
			      try {
			        let response = await this.$http.post('api/app/withdraw', {
			          type: 1,
			          total: this.value1,               // 提现金额
			          pay_pass: this.value2,             // 支付密码
			          card_sn: this.selectedData.card_sn, // 传递选中的卡号
			          remakes: this.selectedData.bank_name // 传递银行名称作为备注
			        });
			
			        if (response.data.code === 0) {
			          uni.$u.toast(response.data.message);
			          setTimeout(() => {
			            uni.switchTab({
			              url: '/pages/user/user'
			            });
			            uni.hideLoading();
			          }, 500);
			        } else {
			          uni.$u.toast(response.data.message);
			        }
			      } catch (error) {
			        console.error("提款请求失败:", error);
			        uni.$u.toast("提款请求失败");
			      } finally {
			        uni.hideLoading();
			      }
			    },
			  
			 open() {
			      this.show = true;
			    },
				close() {
				      this.show = false;
				    },
			       selectData(item) {
			            this.selectedData = item; // 将选中的数据存储
			            this.show = false; // 关闭弹窗
			          },
			home() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			whole(money) {
				this.value1 = money
				// console.log(this.value1, '123');
			},
			async gaint_BankCard() {
				let response = await this.$http.get('api/User/BankCard');
				this.cardManagement = response.data.data
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},


		},
		onShow() {
			this.gaint_info()
			this.gaint_BankCard()
		},
		onLoad(option) {

		}
	}
</script>

<style lang="scss">
	.guize {
		margin-top: 10px;

		view {
			padding-top: 2px;
			font-size: 12px;
			line-height: 1.6;

			text {
				color: #ff3636;
			}
		}
	}
	.input-container {
	  position: relative;
	  // display: inline-block;
	}
	
	.input-container input {
	  padding-right: 50px;  /* 给右侧留出空间以放置文字 */
	}
	
	.input-text {
	  position: absolute;
	  right: 10px;
	  top: 50%;
	  transform: translateY(-50%);
	  color: #ccc;
	  // pointer-events: none;  /* 让文字不可点击 */
	}
</style>