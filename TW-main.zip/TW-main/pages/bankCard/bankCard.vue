<!-- 绑定银行卡 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="綁定約定帳戶" @action="handleBack()"></CustomHeader>
		
		<!-- <view style="padding:0px 15px;margin-top: 10px;">
			<view class="shiming " style="border-radius: 10px;padding: 20px 40px;">
				<view class="bold font-size-17">銀行帳戶資訊認證</view>
				<view>為了交易成功，請連結您的帳號</view>
			</view>
		</view> -->
       <view class="padding-top-20">
		   <view style="">
		   	<view style="padding: 10px;">
				<view>
					<block v-for="(item,index) in cardManagement" :key="index" >
					<view class="padding-10">
						<view style="background-color: #f7cd9b;border-radius: 10px;">
							<view class="padding-20">
								<view class="flex flex-b">
									<view class="font-size-18">{{item.bank_name}}</view>
									<view style="border: 1px #444 solid;padding: 5px 10px; border-radius: 5px;" @click="shanchu(item.id, index)">删除</view>
								</view>
								<view style="padding: 10px 0px;">{{item.card_sn}}</view>
							</view>
						</view>
					</view>
					</block>
				</view>
				
		   
		   <!-- 	<view class="bank-name">
		   		<view class="">銀行名稱: </view><text> {{cardManagement.bank_name}}</text>
		   	</view>
		   	<view class="bank-name">
		   		<view class="">銀行帳號: </view> <text> {{cardManagement.card_sn}}</text>
		   	</view>
			<view class="bank-name">
				<view class="">分行名稱: </view><text> {{cardManagement.bank_sub_name_address}}</text>
			</view>
			<view class="bank-name">
				<view class="">銀行代碼: </view> <text> {{cardManagement.bank_sub_name}}</text>
			</view>
			<view class="bank-name">
				<view class="">請輸入戶名:</view> <text> {{cardManagement.realname}}</text>
			</view> -->
		   	
		   
		   	<view @tap='handleChangeCard()' style="background-color:#fad19e;
		   margin: 50rpx 30rpx;
		   border-radius: 10rpx;
		   padding: 20rpx 0;
		   text-align: center;
		   color: #000;
		   font-size: 28rpx;">
		   		新增約定帳戶
		   	</view>
		   	</view>
		   </view>
	   </view>
		
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				cardManagement: [],
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			handleChangeCard() {
				uni.navigateTo({
					url: '/pages/changeCard/changeCard'
				});
			},
			 async shanchu(id, index) {
			      // 显示确认删除的弹窗
			      uni.showModal({
			        title: '確認刪除？',
			        // content: '確定要刪除此銀行卡嗎？',
			        success: async (res) => {
			          if (res.confirm) {
			            try {
			              // 调用接口删除
			              let response = await this.$http.post('api/user/Bankdelete', { id });
			              
			              if (response.data.code === 0) {
			                // 从列表中删除该项
			                this.cardManagement.splice(index, 1);
			                
			                // 显示删除成功的提示
			                uni.showToast({
			                  title: '刪除成功',
			                  icon: 'success'
			                });
			              } else {
			                uni.showToast({
			                  title: response.data.message || '删除失败',
			                  icon: 'none'
			                });
			              }
			            } catch (error) {
			              console.error("删除失败:", error);
			              uni.showToast({
			                title: '删除失败，请重试',
			                icon: 'none'
			              });
			            }
			          }
			        }
			      });
			    },
			  
			  
			//用户信息
			async gaint_info() {
				let response = await this.$http.get('api/User/BankCard');
				this.cardManagement = response.data.data
			},
		},

	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		background-color: #201c19;
		display: flex;
		font-size: 28rpx;
		margin-top: 10px;
		color: #ccc;
		// border: 2rpx solid #f4f4f4;
		border-radius: 10px;

		view {
			width: 30%;
		}

		text {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>