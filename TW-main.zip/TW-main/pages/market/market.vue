<!-- 行情 -->
<template>
	<view class="sc_kxbg2">
		<!-- <Header :title="$lang.FAVORITES"></Header> -->
		<!-- <view class="flex" style="justify-content: space-between;padding:0px 15px;padding-top: 25px;">
			<image src="../../static/applogo.png" mode="widthFix" style="width: 35px;margin-left: 10px;"></image>
			<view class="flex" style="padding: 5px 20px;border-radius: 30px;">
				<view class="common_header_right" @click="$u.route({url:'/pages/service/service'});">
					<image mode="aspectFit" src="/static/sy_kf.png" :style="$util.calcImageSize(25)"></image>
				</view>
				<view class="common_header_right margin-left-20" @click="$u.route({url:'/pages/email/email'});">
					<image mode="aspectFit" src="/static/sy_tz.png" :style="$util.calcImageSize(25)"></image>
				</view>
			</view>
		</view> -->
		<view class=" text-center color-white font-size-18 padding-15">市場</view>
        
		<view style="padding: 0px 15px;">
		<view>
			<!-- <Sshichang :btns="$util.mqBtnsConfig()" @action="handleBtnClick" col="33.33"></Sshichang> -->
		</view>
		</view>

		<view>
			<TabOne v-if="current==0"></TabOne>
			<TabTwo v-if="current==1"></TabTwo>
			<TabThree v-if="current==2"></TabThree>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Sshichang from '@/components/Sshichang.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import TabTwo from '@/components/market/TabTwo.vue'
	import TabThree from '@/components/market/TabThree.vue'
	export default {
		components: {
			Header,
			Sshichang,
			TabOne,
			TabTwo,
			TabThree,
		},
		data() {
			return {
				current: 1
			}
		},
		onShow() {},


		methods: {
			handleBtnClick(index) {
				this.current = index;
			},
		},

		mounted() {},

		onLoad(op) {
			if (op.type) {
				this.current = op.type
			}
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">

</style>