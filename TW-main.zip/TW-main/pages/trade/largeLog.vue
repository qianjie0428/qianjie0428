<!-- 大宗交易 记录 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="申請列表" style="background-color: #2d2d2d;" @action="handleBack()"></CustomHeader>
		
		<view class="flex flex-b" style="background-color: #252525;padding: 10px 20px ;margin-top: 5px;color: #ddd;">
			<view style="font-size: 12px;flex: 20%;">名稱/股票代碼</view>
			<view style="font-size: 12px;flex: 20%;">申購價/申請量</view>
			<view style="font-size: 12px;flex: 15%;">成交額</view>
			<view style="font-size: 12px;">狀態</view>
		</view>
		<view class="" style="min-height: 68vh;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<view v-for="(item,index) in list" :key="index" >
				<view class="flex flex-b" style="padding: 10px;margin-top: 5px;color: #ddd;">
					<view style="flex: 15%;margin-left: 5%">
						<view>{{item.goods.name}}</view>
						<view style="font-size: 10px;">{{item.goods.code}}</view>
					</view>
					<view style="flex: 20%;text-align: center;">
						<view style="font-size: 10px;">{{item.price}}</view>
						<view style="font-size: 10px;">{{item.num}} 股</view>
					</view>
					<view style="flex: 20%;text-align: center;color: #d3c997;font-size: 14px;">{{item.amount}}</view>
					<view style="flex: 5%;font-size: 10px;">{{transStatus(item.admin_status)}}</view>
				</view>
				<view style="padding: 8px 0px;">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
			</view>	
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad(option) {},
		onShow() {
			this.getList();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			transStatus(admin_status){
								if(admin_status==0){
									return '申請中'
								}else if (admin_status==1){
									
									return '申購成功'
								}else if (admin_status==2){
									
									return '申購失败'
								}
								
							},

			async getList(e) {
				let result = await this.$http.post(`api/goods-bigbill/user-order-log`, {})
				this.list = result.data.data
			},
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #fff;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #fff;
		}
	}
</style>