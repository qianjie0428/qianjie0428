<!-- 日内交易 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">日內交易</view>
		</view>
		<view style="display: flex;align-items: center;background-color: #252525;">
			
			<view class="flex-1 text-center " style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(0)"
				:style="{color:current==0?'#fff':'#666666'}">日間交易
				<view :style="{backgroundColor:current==0?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			
			<view class="flex-1 text-center " style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(1)"
				:style="{color:current==1?'#fff':'#666666'}">申請詳情
				<view :style="{backgroundColor:current==1?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			
			<view class="flex-1 text-center" style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(2)"
				:style="{color:current==2?'#fff':'#666666'}">銷售歷史
				<view :style="{backgroundColor:current==2?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
		</view>
		<view v-if="current==0" style="justify-content: center;display: flex;width: 100%;">
			<!-- <image src="/static/waitu.gif" mode="widthFix" style="width: 50%;"></image> -->
		</view>
		<view class="" style="padding: 6px;min-height: 68vh;">
			
			<template v-if="current==0">
				<view style="padding:20px;">
					<view class="font-size-15 margin-top-10 color-white">請輸入金額</view>
					<input placeholder="請輸入金額"
						placeholderStyle="font-size: 10px;color: #ccc"
						 v-model="amount" type="number"
						maxlength="11" style="margin-top:10px;background-color: #66564a;padding: 10px;border-radius: 10px;color: #fff;"></input>
				</view>
				
				<view class="flex" style=" justify-content: flex-end; margin-right: 20px;">
					<view style="margin-right: 5px;color: #ccc;">可用餘額:</view>
					<view style="margin-right: 10px;color: #fff;">{{$util.formatNumber(userInformation.money)}}</view>
					<view style="color: #fbd29f;" @click="rujin()">儲值</view>
				</view>
				
				<view class="purchase" @click="handleBuy()"
					style="background-color:#f3c997;margin: 30rpx; border-radius: 20rpx; padding: 20rpx 0; text-align: center; color: #000; font-weight: 600;">
					購買</view>

				<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#fff;">
					<view style="padding-bottom: 6px;">指導:</view>
					<view style="padding-bottom: 6px;">當日交易是投資者在同一天買賣股票並根據交易利潤結算利潤的交易方式。</view>
					<view style="padding-bottom: 6px;">投資者統一透過AI購買特定股票，並在賣出時進行結算。</view>
					<view style="padding-bottom: 6px;">如果購買後出現獲利，會立即顯示在「銷售歷史」中，您可以透過賣出立即獲利。</view>
					<view style="padding-bottom: 6px;">為了維護當日交易品種的機密性和利益，申請購買後的一段時間內將不會提供股票代碼和詳細資訊。</view>
				</view>
			</template>

			<template v-else-if="current==1">
				<view style="display: flex;align-items: center;padding:10px;color: #fff;">
					<view style="flex: 40%;">數量</view>
					<view style="flex: 30%;">透過金額</view>
					<view style="flex: 30%;text-align: right;">情況</view>
				</view>
				<view>
					<block v-for="(item,index) in list" :key="index">
						<view
							style="display: flex;align-items: center;border-bottom:1px solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
							<view style="flex: 40%;color: #fff;">{{$util.formatNumber(item.money)}}</view>
							<view style="flex: 30%;color:#f3c997;font-size: 16px;">{{$util.formatNumber(item.success)}}
							</view>
							<view style="flex: 30%;font-size:24rpx;text-align: right;color: #fff;">{{item.zt}}</view>
						</view>
					</block>
				</view>
			</template>
			<template v-else-if="current==2">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom:1px solid #e0e0e0;margin-top:10px;padding:10px 0;">
						<view style="display: flex;align-items: center;">
							<view style="flex:15%;color:#fff;">數量</view>
							<view style="flex:35%;text-align: right;padding-right: 16px;color: #f3c997;">
								{{$util.formatNumber(item.money)}}
							</view>
							<view style="flex:20%;color:#fff;">買入金額</view>
							<view style="flex:35%;color:#f3c997;font-size: 16px;text-align: right;">
								{{$util.formatNumber(item.success)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#fff;">訂單號</view>
							<view style="flex:70%;font-size: 15px;text-align: right;color:#ccc;">{{item.ordersn}}
							</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#fff;">日期時間</view>
							<view style="flex:70%;font-size: 15px;text-align: right;color:#ccc;">{{item.created_at}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel" @confirm="handleBuyConfirm()"
			:showCancelButton='true' content='點選查看操作.' cancel-text="取消" confirm-text="確認">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				options: {},
				current: 0,
				userInformation: '',
				amount: '',
				list: [],
				showBuyConfirm: false,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {},
		onShow() {
			this.gaint_info()
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
		    rujin(){
				uni.navigateTo({
					url:'/pages/certificateBank/silver'
				})
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getSQList();
				} else if (this.current == 2) {
					this.getOrderList();
				}
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast('請輸入金額');
					return false;
				}
				this.showBuyConfirm = true;
			},

			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},

			async buy() {
				const result = await this.$http.post('api/rinei/buy', {
					money: this.amount,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.amount = '';
					this.handleChangeTab(1);
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},

			// 申请列表
			async getSQList() {
				const result = await this.$http.get('api/rinei/sq-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 持仓列表
			async getOrderList() {
				const result = await this.$http.get('api/rinei/order-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>