<!-- 大宗交易 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex " style="background-color: #2d2d2d;padding: 20px 10px;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">紅利股票</view>
		</view>
		
		<view  style="display: flex;align-items: center;">
			<view class="flex-1 text-center">
				<view style="color: #fff;font-size: 15px;">股票</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #f3c997;"></view> -->
			</view>
			<view class="flex-1 text-center">
				<view style="color: #666666;font-size: 15px;" @click="handlePayHistory()">申請列表</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #252525;"></view> -->
			</view>
		</view>
		<view class="flex flex-b" style="background-color: #252525;padding: 10px;margin-top: 5px;color: #ddd;">
			<view>股票名稱</view>
			<view>申購價</view>
			<view>股票代碼</view>
		</view>
		
		<view >
		<view style="padding: 15px;border-radius: 10px;">
			
			<!-- <TradeHeader  icon="block_trade" @action="handlePayHistory()"></TradeHeader> -->
			<TradeList type="bigbill" :height="85" @action="handleGoodDetail"></TradeList>
		</view>

		<u-popup :show="show" @close="close" mode="bottom" :closeable='closeable' :round="10">
			<view v-if="info" class="largeAmount" style="background-color: #2d2d2d;">
				<view class="business" style="color: #fff;">
					紅利股票
				</view>
				<view class="flex" style="padding: 10px 20px;">
					<view style="flex: 60%; color: #fff;">
						<view class="flex margin-top-10">
							<view>股票代碼 :</view>
							<view class="margin-left-5">{{info.goods.code}}</view>
						</view>
						<view class="flex margin-top-10">
							<view>市價 :</view>
							<view class="margin-left-5">{{$util.formatNumber(info.goods.current_price)}}</view>
						</view>
						<view class="flex margin-top-10">
							<view>漲跌 :</view>
							<view class="margin-left-5">{{info.goods.rate}}%</view>
						</view>
					</view>
					<view style="flex: 50%; color: #fff;">
						<view class="flex margin-top-10">
							<view>名稱 :</view>
							<view class="margin-left-5">{{info.goods.name}}</view>
						</view>
						<view class="flex margin-top-10">
							<view>申購價 :</view>
							<view class="margin-left-5">{{$util.formatNumber(info.price)}}</view>
						</view>
						<view class="flex margin-top-10">
							<view>合計 :</view>
							<view class="margin-left-5">{{info.price*this.value1*1000/ganggan|addZero}} </view>
						</view>
					</view>
				</view>
				<view class="fund margin-left-10">
					可用餘額 <text>{{$util.formatNumber(availableFunds.money)}}</text>
				</view>
				
				
				
				
				
				<!-- <view class="flex">
					<view class="price flex-1" style="color: #ccc;">購買價格</view>
					<view class="purchase-price" style="color: #f3c997;margin-right: 60px;font-size: 15px;padding-top: 5px;">{{$util.formatNumber(info.price)}}</view>
				</view> -->
				
				<view class="padding-15">
					<view class="" style="background-color: #66564a;padding: 10px;border-radius: 10px;">
						<input type="number" style="color: #fff;" placeholder="請輸入購買數量" v-model="value1"></input>
						<!-- <view class="hand">확인</view> -->
					</view>
				</view>
				
				<!-- <view class="price" style="color: #ccc;">槓桿作用</view>
				<view class="available" @click="ganggan_show=true" style="background-color: #66564a;padding: 10px;border-radius: 10px;">
					<input type="number" style="pointer-events: none;color: #fff;" :disabled="true" placeholder=""
						v-model="ganggan" inputAlign='right'>
					</input>
				</view> -->
				<!-- <view class="amount">購買價格 <text>{{info.price*this.value1/ganggan|addZero}} </text> </view> -->
				<!-- <view class="available">
					<u-input type="password" placeholder="비밀번호 6자리 입력해주세요." v-model="value2"></u-input>
				</view> -->
				
				<view class="purchase" @click="bulkPurchase(info.id)" style="background-color:  #f3c997;margin: 30rpx;
			border-radius: 20rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #000;
			font-weight: 600;">確認買入</view>
			</view>
		</u-popup>
		<u-action-sheet :show="ganggan_show" :actions="actions" title="選擇您的槓桿" @close="ganggan_show = false"
			@select="Select">
		</u-action-sheet>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				options: {},
				show: false,
				closeable: true,
				value1: '',
				value2: '',
				value3: '',
				availableFunds: '',
				info: null,
				list: [],
				ganggan: 1,
				ganggan_show: false,
				actions: [{
					name: '1',
					index: 1
				}],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
			// this.largeAmount()
			this.available()
		},
		onShow() {
			this.available()
			this.show = false
			
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async getList() {
				const result = await this.$http.get(`api/goods-bigbill/list`, {});
				this.list = result.data.data.map(item => {
					return {
						id: item.id,
						name: item.goods.name,
						code: item.goods.code,
						price: item.price,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				})
			},
			// 单项详情
			handleGoodDetail(val) {
				this.show = true;
				this.bulkDetails(val);
				// this.getList();
			},
			// 查看购买历史
			handlePayHistory() {
				uni.navigateTo({
					url: '/pages/trade/largeLog'
				});
			},

			Select(e) {
				console.log(e);
				this.ganggan = e.index
			},
			close() {
				this.show = false
				// console.log('close');
			},

			// 单条数据详情
			async bulkDetails(val) {
				const result = await this.$http.get('api/goods-bigbill/detail', {
					id: val
				})
				this.info = result.data.data
				console.log('ceshi111')
				console.log(this.info)
			},
			//点击购买
			async bulkPurchase(id) {
				if (this.value1 == '') {
					uni.$u.toast('請輸入購買數量');
				} 
				// if (this.value2 == '') {
				// 	uni.$u.toast('펀드 비밀번호를 입력해주세요');
				// }
				
				let list = await this.$http.post('api/goods-bigbill/doOrder', {
					id: id,
					num: this.value1*1000,
					// pay_pass: this.value2,
					ganggan: this.ganggan
					// password: this.value3,
				})
				if (list.data.code == 0) {
					this.show = false
					uni.$u.toast(list.data.message);
					this.value1 = ''
					this.value2 = ''
					this.value3 = ''
					this.available()
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/largeLog'
						});
					}, 1000)
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						this.show = true
					}, 1000)
				}
			},
			// 사용 가능한 자금 可用资金
			async available() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.availableFunds = list.data.data
				this.actions = list.data.data.ganggan
			},
		},

		//取小数点之后的2位
		filters: {
			addZero: function(data) {
				return data.toFixed(0)
			}
		},

	}
</script>

<style lang="scss">
	//弹窗
	.largeAmount {
		padding: 30rpx;

		.business {
			text-align: center;
			font-size: 30rpx;
			color: #333;
			border-bottom: 1px solid #e0e0e0;
			height: 45px;
			line-height: 45px;
			border-top-left-radius: 10px;
			border-top-right-radius: 10px;

		}

		.price {
			color: #333;
			font-weight: 500;
			margin: 5px 0 0 6px;
		}

		.purchase-price {
			color: #ea3544;
			margin: 10rpx;
			font-weight: 600;
		}

		.purchase-text {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;

			.hand {
				border-left: 1rpx solid #e0e0e0;
				padding-left: 30rpx;
			}
		}

		.amount {
			color: #ccc;
			font-size: 28rpx;
			padding: 0 9px;

			text {
				color: #f3c997;
				margin-left: 20rpx;
			}
		}

		.available {
			padding: 0 20rpx;
			border-radius: 10rpx;
			margin: 20rpx 0;
		}

		.fund {
			color: #fff;
			font-size: 28rpx;
			padding: 0 9px;

			text {
				color: #f3c997;
				margin-left: 20rpx;
			}
		}
	}
</style>