<template>
	<view style="min-height: 100vh;background: #2d2d2d;">
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">ETF</view>
		</view>
		<view style="display: flex;align-items: center;background-color: #252525;">
			
			<view class="flex-1 text-center " style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(0)"
				:style="{color:current==0?'#fff':'#666666'}">台股
				<view :style="{backgroundColor:current==0?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			
			<view class="flex-1 text-center " style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(1)"
				:style="{color:current==1?'#fff':'#666666'}">美股
				<view :style="{backgroundColor:current==1?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			
			<view class="flex-1 text-center" style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(2)"
				:style="{color:current==2?'#fff':'#666666'}">港股
				<view :style="{backgroundColor:current==2?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			<view class="flex-1 text-center" style="font-size: 15px;margin-top: 10px;"   @click="handleChangeTab(3)"
				:style="{color:current==3?'#fff':'#666666'}">陸股
				<view :style="{backgroundColor:current==3?'#f3c997':'#252525'}" style="width: 100%;height: 2px;margin-top: 10px;"></view>
			</view>
			
		</view>
		
		<view style="padding: 5px 0px;">
			<view class="flex" style="background-color: #252525;padding: 5px 15px;color: #666666;">
				<view class="flex-3">股票名称</view>
				<view class="flex-2">现价</view>
				<view class="flex">涨跌幅</view>
			</view>
		</view>
		
		<GoodsListEtf :list="goodsList"></GoodsListEtf>
		
		
		
	</view>
</template>

<script>
	import GoodsListEtf from '@/components/GoodsListEtf.vue';
	export default {
		components: {
			GoodsListEtf,
		},
		data() {
			return {
				
				current: 0,
				page: 1,
				goodsList: [],
				gp_index: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {},
		onShow() {
			this.page = 1;
			this.good_list()
		},
		
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				this.good_list();
			},
		   async good_list() {
		   
		   	// this.list=[]
		   	let result = await this.$http.get('api/goods/etf', {
		   		current: this.current
		   	})
		   	// if(this.page==1){
		   	this.goodsList = result.data.data
		   	// }else{
		   	// 	this.list = this.list.concat(list.data.data)
		   	// }
		   
		   },
			
		},
	}
</script>