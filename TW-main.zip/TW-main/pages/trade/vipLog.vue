<!-- 短打交易记录 -->
<template>
	<view class="" style="background-color: #2d2d2d; min-height: 100vh;">
		<CustomHeader title="購買記錄" style="background-color: #2d2d2d;" @action="handleBack()"></CustomHeader>
		<TradeLog url="duanda"></TradeLog>
		
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import TradeLog from '@/components/TradeLog.vue';
	export default {
		components: {
			CustomHeader,TradeLog
		},
		data() {
			return { };
		},
		onLoad(option) {
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
		}
	}
</script>

