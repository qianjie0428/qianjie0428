<!-- 新股配售 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-20 color-white flex-1">存股借券</view>
		</view>
		<view  style="display: flex;align-items: center;">
			<view class="flex-1 text-center">
				<view style="color: #fff;font-size: 15px;">股票</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #f3c997;"></view> -->
			</view>
			<view class="flex-1 text-center">
				<view style="color: #666666;font-size: 15px;" @click="jilu()">申請列表</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #252525;"></view> -->
			</view>
		</view>
		<view class="flex flex-b" style="background-color: #252525;padding: 10px;margin-top: 5px;color: #ddd;">
			<view>股票名稱</view>
			<view>申購價</view>
			<view>股票代碼</view>
		</view>
		
		
		<view style="padding: 10px;">
		<view class="" style="border-radius: 10px;">
			<!-- <TradeHeader :title="``" icon="block_trade" @action="handlePayHistory()"></TradeHeader> -->
			<view style="margin-top: 10px;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<view style="">
				<view v-for="(item,index) in list" :key="index" >
					<view class="flex" style="color: #fff;" @tap="purchase(item.id,item.peishou_price)">
						<view  class="flex-1">{{item.goods.name}}</view>
						<view class="flex-1 text-center" style="color: #f0c38e;">{{item.price}}</view>
						<view class="flex-1 text-right">{{item.goods.code}}</view>
					</view>
					<view style="padding: 8px 0px;">
						<view style="border-top: 1px #444 solid;"></view>
					</view>
					<!-- <view class="display " style="margin: 20rpx 0;">
						
						<view class="flex">
							<view>
								<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
							</view>
							<view class="margin-left-10 flex-1">
								<view class="corporation" style="color: #fff;">{{item.goods.name}}</view>
								<view style="color: #ccc;">{{item.goods.code}}</view>
							</view>
							<view class="purchase" @tap="purchase(item.id,item.peishou_price)">
								購買
							</view>

						</view>
					</view>

					<view class="display">
						<view class="display flex">
							<view class="flex-1" style="color: #ccc;">
								發行價</view>
							<view style="color: #f3c997;">{{item.price}}</view>
						</view>
						<view class="display flex margin-top-10">
							<view class="flex-1" style="color: #ccc;">
								配售價格</view>
							<view style="color: #f3c997;">{{item.fa_price}}
							</view>
						</view>
						
						
					</view> -->
					</view>
				</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
import EmptyData from '@/components/EmptyData.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,EmptyData,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				options: {},
				list: [],
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
			this.scramble()
		},

		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			jilu() {
				uni.navigateTo({
					url: '/pages/trade/saleLog'
				});
			},
			handlePayHistory(){
				return false;
			},
			// 기록 보관
			ration() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/ration'
				});
			},
			// 우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods/goodsvipscramble', {})
				// console.log(.list, '99999999');
				this.list = list.data.data;
				
			},
		},
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 35rpx;
		font-weight: 600;
		color: #333;

	}

	.purchase {
		background-color: #f3c997;
		color: #000;
		border-radius: 10rpx;
		padding: 10rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}
</style>