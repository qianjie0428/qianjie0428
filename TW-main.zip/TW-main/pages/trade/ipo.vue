<!-- 新股申购 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="新股認購" style="background-color: #2d2d2d;" @action="handleBack()"></CustomHeader>
		
		<view  style="display: flex;align-items: center;background-color: #252525;">
			<view class="flex-1 text-center">
				<view style="color: #fff;padding: 10px 30px;border-radius: 30px;font-size: 15px;">產品列表</view>
				<view style="width: 100%;height: 2px;background-color: #f3c997;"></view>
			</view>
			<view class="flex-1 text-center" @click="handleChangeTab(0)">
				<view style="color: #666666;padding: 10px 30px;border-radius: 30px;font-size: 15px;">申請記錄</view>
				<view style="width: 100%;height: 2px;background-color: #252525;"></view>
			</view>
			<view class="flex-1 text-center" @click="handleChangeTab(1)">
				<view style="color: #666666;padding: 10px 30px;border-radius: 30px;font-size: 15px;">交易記錄</view>
				<view style="width: 100%;height: 2px;background-color: #252525;"></view>
			</view>
		</view>
		<view style="padding: 15px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block  v-for="(item,index) in list" :key="index">
					<view class="margin-top-10">
					<view class="" style="padding: 10px;border-radius: 10px;background-color: #252525;" >
						<view style="align-items: center;" class="flex">
							<view>
								<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
							</view>
							<view class="margin-left-10 flex-1">
								<view style="font-size: 18px;color: #fff;">{{item.goods.name}}</view>
								<view style="color: #ccc;">{{item.goods.code}}</view>
							</view>
							
							<view @click="to_skip(item.id)" class="common_btn btn_primary"
								style="padding:2px 4px;width: 80px;margin-top: 0;background-color: #f3c997;color: #000;">申請</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #fff;">認購價格</view>
							<view style="color: #f3c997;">{{$util.formatNumber(item.price)}}</view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">수익률</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.shiying)}}</view>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
							<view style="color: #fff;">購買時間</view>
							<view style="color: #fff;">{{item.shengou_date}}</view>
						</view>
					</view>
					</view>
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								
							</view>
							<view class="subscription-times">購買時間<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">購買價格<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								本益比<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							數量<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				if (val == 0) {
					this.applyPurchase();
				} else if (val == 1) {
					this.luckyNumber();
				}
			},
			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/calendar`, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			applyPurchase() {
				uni.navigateTo({
					url: `/pages/trade/ipoLog`
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>