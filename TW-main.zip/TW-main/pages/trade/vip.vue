<template>
	<view class="" style="background-color: #2d2d2d;min-height: 100vh;">
		<!-- <CustomHeader :title="title" @action="handleBack()"></CustomHeader> -->
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">價值股</view>
		</view>
		<view  style="display: flex;align-items: center;">
			<view class="flex-1 text-center">
				<view style="color: #fff;font-size: 15px;">股票列表</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #f3c997;"></view> -->
			</view>
			<view class="flex-1 text-center">
				<view style="color: #666666;font-size: 15px;" @click="handlePayHistory()">購買記錄</view>
				<!-- <view style="width: 100%;height: 2px;background-color: #252525;"></view> -->
			</view>
		</view>
		<view class="flex flex-b" style="background-color: #252525;padding: 10px;margin-top: 5px;color: #ddd;">
			<view>股票名稱</view>
			<view>申購價</view>
			<view>股票代碼</view>
		</view>
		
		<!-- <view  style="display: flex;align-items: center;background-color: #2d2d2d;">
			<view class="flex-1 text-center">
				<view style="color: #fff;padding: 10px 30px;border-radius: 30px;font-size: 15px;">產品列表</view>
				<view style="width: 100%;height: 2px;background-color: #f3c997;"></view>
			</view>
			<view class="flex-1 text-center">
				<view style="color: #666666;padding: 10px 30px;border-radius: 30px;font-size: 15px;" @click="handlePayHistory()">交易記錄</view>
				<view style="width: 100%;height: 2px;background-color: #252525;"></view>
			</view>
			<view class="flex-1 text-center">
				<view style="color: #666666;padding: 10px 30px;border-radius: 30px;font-size: 15px;" @click="handlePay()">分配詳情</view>
				<view style="width: 100%;height: 2px;background-color: #252525;"></view>
			</view>
		</view> -->
		
		<view class="" style="min-height: 68vh;padding-top: 10rpx;">
			<!-- <view class="take-notes">
			<view class="name">고객명</view>
			<view class="up-down">
				<view class="price">우대 가격</view>
				<view class="downRange">변경 사항</view>
			</view>
			<view class="" style="width: 20%;"></view>
		</view> -->
			<EmptyData v-if="list.length<=0"></EmptyData>
			<view class="science" v-for="(item,index) in list" :key="index" style="background-color: #2d2d2d;">
				<view class="flex " style="color: #ddd;" @tap="goBuy(item)">
					<view class="flex-1">{{item.goods.name}}</view>
					<view class="flex-1 text-center" style="color: #f3c997;">{{item.price}}</view>
					<view class="flex-1 text-right">{{item.goods.code}}</view>
				</view>
				<view style="padding: 8px 0px;">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				
				
				
				
				
				<!-- <view class="flex" style="margin: 20rpx 0;">
					<view>
						<image src="/static/gp_tu.png" mode="widthFix" style="width: 40px;"></image>
					</view>
					<view class="margin-left-10 flex-1">
						<view class="corporation">{{item.goods.name}}</view>
						<view class="area" >
							<view class="deep">{{item.goods.locate}}</view>
							<view class="deep-number" style="color: #ccc;">{{item.goods.code}}</view>
						</view>
					</view>
					<view class="detailed" @tap="goBuy(item)">
						買入
					</view>
				</view>
				<view class="flex" style="justify-content: space-between;">
					<view class="color-white">
						申購價
					</view>
					<view class="price ">
						{{item.price}}
					</view>
					
				</view>
				<view class="flex" style="justify-content: space-between;margin-top: 5px;">
					<view class="color-white">
						折價
					</view>
					<view class="price">
						{{item.zhekou}}%
					</view>
					
				</view> -->
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeHeader from '@/components/TradeHeader.vue';
	import TradeList from '@/components/TradeList.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
			TradeHeader,
			TradeList
		},
		data() {
			return {
				list: []
			}
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			handlePayHistory(){
				uni.navigateTo({
					url: '/pages/trade/vipLog'
				});
			},
			handlePay(){
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//去到购买
			goBuy(item) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/placeOrder/placeOrder' +
						`?item=${encodeURIComponent(JSON.stringify(item))}`

				});
				// console.log(item, '=========抛出去');
			},
			//列表
			async scramble(item) {
				let list = await this.$http.get('api/GoodsScramble/list', {
					id:this.id,
					// page: 1,
					// limit: 500,
				})
				this.list = list.data.data
			},
		},
		mounted() {
			this.scramble()
		},
	}
</script>

<style lang="scss">
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: center;
			align-items: center;
			padding: 30rpx 30rpx 30rpx;
			border-bottom: 1rpx solid #e0e0e0;
			font-size: 28rpx;

			.up-down {
				width: 40%;
				display: flex;
				justify-content: space-between;
				align-items: center;
			}

			.name {
				width: 30%;
			}

			.price {
				width: 100%;
			}

			.downRange {
				width: 100%;
			}

		}

	}

	.science {
		margin: 30rpx;
		padding-bottom: 30rpx;
		// border-bottom: 0.037037rem solid #e0e0e0;

		.corporation {
			font-size: 30rpx;
			font-weight: 600;
			color: #fff;

		}

		.price {
			color: #f3c997;
			font-size: 26rpx;
		}

		.detailed {
			background-color: #f3c997;
			color: #fff;
			border-radius: 10rpx;
			padding: 10rpx 40rpx;
			font-size: 26rpx
		}

		.find {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}

		.ration {
			width: 45%;

			view:nth-child(2) {
				color: #f85252;
			}
		}
	}
</style>