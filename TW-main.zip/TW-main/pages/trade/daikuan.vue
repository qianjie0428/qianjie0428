<template>
	<view class="common_page_bg8" style="min-height: 100vh;">
		<view class="flex padding-20">
			<view @click="daikuan()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center color-white">
				貸款
			</view>
		</view>

		<view style="padding: 20px;margin-top: 230px;">
			<view class="" style="background-color: #3a2f28;padding: 20px;border-radius: 10px;">
				<view class="flex"
					style="background-color: #f3c997;padding: 15px;border-radius: 10px;justify-content: center;display: flex;"
					@click="qianwang()">
					<view style="color: #000;">
						前往貸款
					</view>
					<image src="/static/youjt.png" mode="widthFix" style="width: 20px;margin-left: 10px;"></image>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 10px;"></image>
					<view style="margin-left: 20px; color: #fff;font-size: 15px;">
						產品優勢
					</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>
				<view>
					<view>
						<view class="flex">
							<image src="/static/dz.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">
								客製化VIP貸款服務
							</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">
							最高借貸金額為1000萬USDT,最高支持3X貸款,限額包括BTC、ETH、USDT等40+主流
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/ll.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">
								利率水準
							</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">
							等級越高，貸款金額越大，利率越低
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/lh.png" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">
								資金運用靈活
							</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">
							貸款期限從30天，隨借還
						</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/lc.png" mode="widthFix" style="width: 23px;"></image>
							<view class="bold margin-left-10 color-white">
								簡化貸款流程
							</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">
							1-3天完成貸款
						</view>
					</view>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left:10px;"></image>
					<view class="color-white" style="margin-left: 20px;font-size: 15px;">
						如何借錢
					</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>

				<view class="flex text-center" style=" justify-content: space-between;  ">
					<view class="flex-1">
						<image src="/static/qq.png" mode="widthFix" style="width: 20px;"></image>
						<view class="color-white">
							步驟1
						</view>
						<view class="color-white">
							填寫貸款申請表
						</view>
					</view>
					<view class="flex-1">
						<image src="/static/ww.png" mode="widthFix" style="width: 20px;"></image>
						<view class="color-white">
							步驟2
						</view>
						<view class="color-white">
							確認貸款需求
						</view>
					</view>
				</view>

				<view class="flex text-center margin-top-20" style=" justify-content: space-between;">
					<view class="flex-1">
						<image src="/static/ee.png" mode="widthFix" style="width: 20px;"></image>
						<view class="color-white">
							步驟3
						</view>
						<view class="color-white">
							簽訂貸款合約
						</view>
					</view>
					<view class="flex-1">
						<image src="/static/rr.png" mode="widthFix" style="width: 20px;"></image>
						<view class="color-white">
							步驟4
						</view>
						<view class="color-white">
							資金擔保借貸
						</view>
					</view>
				</view>
			</view>



			<view style="margin-top: 20px;">
				<view style="background-color: #3a2f28;border-radius: 10px;">
					<view class="flex padding-25" style="justify-content: center;display: flex;">
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 10px;"></image>
						<view style="margin-left: 20px;color: #fff;font-size: 15px;">
							常見問題解答
						</view>
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>

					</view>


					<!-- 	<view class="flex">
				<view>使用场外借贷需要满足哪些条件?</view>
				<image src="/static/jia.png"></image>
			</view> -->

					<view style="padding: 10px;">
						<u-collapse @change="change" @close="close" @open="open">
							<u-collapse-item name="Docs guide">
								<template v-slot:title>
									<span style="color: #ccc;">使用場外借貸需要滿足什麼條件？</span>
								</template>
								<text class="u-collapse-content color-white">
									該平台上的做市商或具有VIP等級≥2級且具專業交易能力，或專業客戶在其他平台上具有同等條件
								</text>
							</u-collapse-item>
						</u-collapse>
						<u-collapse @change="change" @close="close" @open="open">
							<u-collapse-item name="Docs guide">
								<template v-slot:title>
									<span style="color: #ccc;">OTC貸款的貸款期限是多久？</span>
								</template>
								<text class="u-collapse-content color-white">
									貸款週期靈活：7天至1年，皆可貸款隨時還款，到期可續借
								</text>
							</u-collapse-item>
						</u-collapse>
						<u-collapse @change="change" @close="close" @open="open">
							<u-collapse-item name="Docs guide">
								<template v-slot:title>
									<span style="color: #ccc;">如何計算利息？</span>
								</template>
								<text class="u-collapse-content color-white">
									利息每日計算。如果還款額是逾期按貸款資產總額的0.5%按每筆加收利息天。
								</text>
							</u-collapse-item>
						</u-collapse>
						<u-collapse @change="change" @close="close" @open="open">
							<u-collapse-item name="Docs guide">
								<template v-slot:title>
									<span style="color: #ccc;">如何償還本金和利息？</span>
								</template>
								<text class="u-collapse-content color-white">
									利息於每月月底結算或資金和利息將在期末返還
								</text>
							</u-collapse-item>
						</u-collapse>
						<u-collapse @change="change" @close="close" @open="open">
							<u-collapse-item name="Docs guide">
								<template v-slot:title>
									<span style="color: #ccc;">我可以提前还款嗎？</span>
								</template>
								<text class="u-collapse-content color-white">
									是的，在藉貸期間，用戶可以增加貸款分為提前還款和延期還款。
								</text>
							</u-collapse-item>
						</u-collapse>
					</view>
				</view>
			</view>


		</view>




	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			open(e) {
				// console.log('open', e)
			},
			close(e) {
				// console.log('close', e)
			},
			change(e) {
				// console.log('change', e)
			},
			daikuan() {
				uni.navigateBack({
					delta: 1,
				})
			},
			qianwang() {
				uni.navigateTo({
					url: '/pages/service/service'
				})
			},

		}
	}
</script>

<style scoped>
	/deep/ .u-collapse-item__title {
		color: #fff;
		/* 修改为你需要的颜色 */
	}
</style>