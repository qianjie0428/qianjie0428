<template>
	<view>
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">交易細則</view>
		</view>
		
		<view style="color: #ccc;padding: 15px;">
			<view class="bold font-size-18">【集中市場交易制度介紹】</view>
			<view class="margin-top-10">一 交易時間：</view>
			<view class="margin-top-5">集中市場交易時間為星期一至星期五，撮合成交時間為9:00至13:30，委託時間8:30至13:30。另開、收盤前最後1分鐘，將模擬試算開、收盤價波動較大之個股，實施暫緩開、收盤作業。達到暫緩開盤標準之有價證券，將延後2分鐘，於9:02依序開盤撮合成交，暫緩開盤二分鐘內，投資人可持續新增、取消或修改委託。達到暫緩收盤標準之有價證券，則不會於13:30執行收盤撮合，投資人可於13:31起持續新增、取消或修改委託，至13:33分收盤。</view>
			
			<view class="margin-top-15">二 交易單位：</view>
			<view class="margin-top-5">買賣申報之數量，應為1交易單位或其整倍數三 每日升降幅度(即買賣申報價格範圍)依據本公司營業細則第 63 條有關升降幅度規定，股票以漲至或跌至當市開盤競價基準10％為限，故當日漲、跌停價格係以當市開盤競價基準為計算之基準，基準價乘以110％為漲停價格，基準價乘以90％為跌停價格，惟依同法第 62 條有關申報買賣價格之升降單位規定，依上述方式計算所得之漲、跌停價格仍須符合其升降單位之規定，茲舉例說明如下：假設某單一股票當市開盤競價基準為40.60元，當日升降幅度為10％，當日漲停價格計算方式為40.60元 * 110％ = 44.66元，當日跌停價格計算方式為40.60元 * 90％= 36.54元。依營業細則第62 條規定：股票每股及受益憑證每受益權單位市價10元至未滿50元者之升降單位為0.05元，故該股票當日符合升降單位規定之漲停價格可能為44.65元及44.7元，跌停價格可能為36.5元及36.55元，若分別選擇44.7元及36.5元，將超逾升降幅度10％限制，故依前述二項規定，該股票當日漲停價格應為44.65元，跌停價格應為36.55元，基此，漲、跌停價格二者始無超過10％限制。</view>
			
			<view class="margin-top-15">三 當日沖銷交易為提供投資人避險管道及健全交易機制，103年1月6日起投資人得以現股從事先買後賣之當日沖銷交易，並自103年6月30日開放先賣後買當日沖銷交易。</view>
			
			<view class="margin-top-15">四 交易費用：</view>
			<view class="margin-top-5">(一）買賣股票時，券商會各收取一次手續費，依成交金額的0.1425%計收，未滿新台幣20元按20元計收</view>
			<view class="margin-top-5">(二）證券交易稅0.3%</view>
			<view class="margin-top-5">(三）倉息（留倉費）為成交金額的0.03%/每交易日</view>
			<view class="margin-top-5">(四）配資無利息</view>
			
			<view class="margin-top-15">五 其他：</view>
			<view class="margin-top-10">(一）結算交割採非普通（T+0日）交割，即全面款券劃撥方式交割買進股票：應付款為當日委辦前交割賣出股票：應收款為第二個營業日上午11時後取得</view>
			<view class="margin-top-5">(二）外資投資市場買賣額度控管</view>
			<view class="margin-top-5">1.外資買進申報時，該數量即時累入外資委買數量控管，持有之認股權憑證數 × 行使比例累加至標的股票。</view>
			<view class="margin-top-5">2.外資賣出成交後，該數量自外資委買數量扣除</view>
			<view class="margin-top-5">(三）天然災害侵襲時應否休市處理措施：</view>
			<view class="margin-top-5">1.本公司集中交易市場休市時：</view>
			<view class="margin-top-5">(1）天然災害侵襲時，本公司集中交易市場是否休市，應以台北市市長宣布當日台北市公教機關是否停止上班為準據。</view>
			<view class="margin-top-5">(2）本公司集中交易市場休市時，則全體證券商當日停止營業，且當日應屆交割事務順延辦理。</view>
			<view class="margin-top-5">2.本公司集中交易市場不休市時：</view>
			<view class="margin-top-5">(1）非受災地區證券商：正常營業，且當日應屆交割事務正常辦理。</view>
			<view class="margin-top-5">(2）受災地區證券商：台北市以外地區因天然災害侵襲致當地縣市首長宣布當日公教機關停止上班時，於受災區域內之證券商得自行決定是否照常營業，不論營業否，其應行交割之證券部分均一律順延辦理，惟款項部分由非受災地區外之總公司或分公司辦理，或由本公司代墊。受災區域內停止營業證券商之委託人，若至照常營業之證券商開戶，得於當日開戶當日委託買賣。</view>
			<view class="margin-top-15">六 新股申購</view>
			<view class="margin-top-5">(（一）每5000元市值可申購一個申購單位，不足5000元的部分不計入申購額度。每一個新股申購單位為1000股，申購數量應當為1000股或其整數倍，但申購上限不得超過本次網上初始發行股數的千分之一。如果同一天有多只新股發行，可重複使用額度。</view>
		</view>
	</view>
</template>

<script>
	export default {
		components: {
		
		},
		data() {
			return {
				
			}
		},
		onLoad(opts) {
			
		},
		mounted() {
			
		},
		onShow() {
			
		},
		computed: {
			
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			
      }
	}
</script>