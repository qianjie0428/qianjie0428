<!-- 绑定银行卡 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="綁定約定帳戶" @action="handleBack()"></CustomHeader>
		
		<!-- <view style="padding:0px 15px;margin-top: 10px;">
			<view class="shiming " style="border-radius: 10px;padding: 20px 50px;">
				<view class="bold font-size-17">銀行帳戶資訊認證</view>
				<view>為了交易成功，請連結您的帳號</view>
			</view>
		</view> -->
		<view class="">
		<view style="">
			<view style="padding: 10px;">
			<view class="bank-name">
				<view class="">銀行名稱:</view> <input placeholder="請輸入銀行名稱" v-model="value"> </input>
			</view>
			<view class="bank-name">
				<view class="">銀行帳號: </view> <input placeholder="請輸入銀行帳號" v-model="value2"> </input>
			</view>
			<view class="bank-name">
				<view class="">分行名稱: </view> <input placeholder="請輸入分行名稱" v-model="value3"> </input>
			</view>
			<view class="bank-name">
				<view class="">銀行代碼: </view> <input placeholder="請輸入銀行代碼" v-model="value4"> </input>
			</view>
			<view class="bank-name">
				<view class="">戶名: </view> <input placeholder="請輸入戶名" v-model="value5"> </input>
			</view>
			
		
			<view @click="replaceBank()" style="background-color:#dabb8f;
		margin: 50rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #000;
		font-size: 28rpx;">
				確認
			</view>
			</view>
			</view>
			</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				value: '',
				value2: '',
				value3: '',
				value4: '',
				value5: ''

			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					bank_name: this.value,
					card_sn: this.value2,
					bank_sub_name_address: this.value3,
					bank_sub_name: this.value4,
					realname: this.value5,
				})
				if (list.data.code == 0) {
					uni.$u.toast('上傳成功');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/user/user'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
	}
</script>

<style lang="scss">
	.bank-name {
		padding: 30rpx 20rpx;
		background-color: #201c19;
		display: flex;
		font-size: 28rpx;
		margin-top: 10px;
		color: #ccc;
		// border: 2rpx solid #f4f4f4;
		border-radius: 10px;
	
		view {
			width: 30%;
		}
	
		text {
			margin-left: 60rpx;
			font-weight: 400;
			font-size: 28rpx;
		}
	}
</style>