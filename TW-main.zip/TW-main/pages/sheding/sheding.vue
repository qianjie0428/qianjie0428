<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<view class="flex padding-20" style="background-color: #2d2d2d;">
			<view @click="handleBack()">
				<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center font-size-18 color-white flex-1">密碼設置</view>
		</view>
		<view class="flex color-white font-size-16 padding-10 flex-b" style="border-bottom: 1px #222 solid;">
			<view class=" font-size-16">姓名</view>
			<view class=" font-size-16" v-if="userInformation.is_check == 1">{{userInformation.real_name}}</view>
		</view>
		<view class="flex color-white font-size-16 padding-10 flex-b" style="border-bottom: 1px #222 solid;">
			<view class=" font-size-16">手機號碼</view>
			<view class=" font-size-16">{{userInformation.mobile}}</view>
		</view>
		<view class="flex color-white font-size-16 padding-10 flex-b" style="border-bottom: 1px #222 solid;" @click="denglu()">
			<view class=" font-size-16">登入密碼</view>
			<image src="/static/jiantou.png" mode="widthFix" style="width: 20px;"></image>
		</view>
		<view class="flex color-white font-size-16 padding-10 flex-b" style="border-bottom: 1px #222 solid;" @click="zhifu()()">
			<view class=" font-size-16">交易密碼</view>
				<image src="/static/jiantou.png" mode="widthFix" style="width: 20px;"></image>
		</view>
		<view class="flex color-white font-size-16 padding-10 flex-b" style="border-bottom: 1px #222 solid;" @click="guanyu()">
			<view class=" font-size-16">隱私政策</view>
				<image src="/static/jiantou.png" mode="widthFix" style="width: 20px;"></image>
		</view>
	</view>
</template>

<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
				userInformation: {},
				cardManagement: '',
				is_check: '',
			}
		},
		onShow() {
			this.gaint_info()
			
		},
		

		methods: {
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				});
				this.userInformation = list.data.data;
				this.cardManagement = list.data.data.bank_card_info
			},
			handleBack(){
				uni.reLaunch({
					url:'/pages/user/user'
				})
			},
           denglu() {
           	uni.navigateTo({
           		url: '/pages/changePwd/changePwd'
           	})
           },
		   guanyu() {
		   	uni.navigateTo({
		   		url: '/pages/about/about'
		   	})
		   },
		   
		   zhifu() {
		   	uni.navigateTo({
		   		url: '/pages/payPwd/payPwd'
		   	})
		   },
	
		},
	}
</script>