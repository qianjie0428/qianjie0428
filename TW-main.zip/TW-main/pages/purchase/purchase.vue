<!-- 下单 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader :title="detailedData.name" @action="$u.route({type:'navigateBack'});"></CustomHeader>

		<view  style="padding: 6px;">
			<view style="display: flex;align-items: center;justify-content: center;">
				<text style="color: #fff;padding: 5px;border-radius: 10px;font-size:20px;">
					當前餘額</text>
			</view>
			<view style="display: flex;align-items: center;justify-content: center;">
				<text style="padding: 5px;border-radius: 10px;font-weight: 700;font-size: 25px;color: #fff;">
					{{$util.formatNumber(userinfo.money)}}</text>
			</view>
		</view>

		<view class="" style="padding: 6px 16px;" v-if="detailedData">
			<view style="display: flex;align-items: center;margin-top: 20rpx;">
				<view style="flex:50%;font-size: 32rpx;color: #ccc;">{{detailedData.name}}</view>
				<view style="flex:45%;font-size: 32rpx;" :style="{color:`${detailedData.rate>0?'#e5b682':'#ff3636'}`}"> {{$util.formatNumber(detailedData.current_price)}} </view>
				<view :style="{color:`${detailedData.rate>0?'#e5b682':'#ff3636'}`}" style="flex:15%;font-size: 32rpx;">
					{{detailedData.rate}}%
				</view>
			</view>

			<view class="margin-top-20 bold" style="color: #ccc;">
				選擇數量
			</view>
			<view class="margin-top-10 text-center">


				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==5?'actity':'noactity'" @click="quantity=5;quantity1=''">5</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==10?'actity':'noactity'" @click="quantity=10;quantity1=''">10
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==15?'actity':'noactity'" @click="quantity=15;quantity1=''">15
						</view>
					</u-col>

				</u-row>
				<u-row justify="space-between" gutter="10">
					<u-col span="4">
						<view :class="quantity==20?'actity':'noactity'" @click="quantity=20;quantity1=''">20
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==25?'actity':'noactity'" @click="quantity=25;quantity1=''">25
						</view>
					</u-col>
					<u-col span="4">
						<view :class="quantity==30?'actity':'noactity'" @click="quantity=30;quantity1=''">30
						</view>
					</u-col>

				</u-row>
			</view>
			<view class="flex-1" style="color: #ccc;">1張等於1000股</view>
			<view style="padding: 10px 0px;">
				<input placeholder="請輸入數量" type="number" class="f-dis-input" v-model="quantity" @input="sl_input" style="background-color: #66564a; color: #fff;"
					placeholder-style="font-size:12px" />
			</view>
			

			<!-- <view class="margin-top-20 bold color-white">
				레버리지를 선택하세요
			</view>
			<view class="margin-top-10 text-center">


				<u-grid :border="false" col="3">
					<u-grid-item v-for="(item,index) in userinfo.ganggan">
						<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
							{{item}}
						</view>
					</u-grid-item>
				</u-grid>


			</view> -->
			
			<view class="flex" style="color: #f4cb9b;font-size: 28rpx;">
				<view class="flex-1" style="color: #ccc;">付款金額</view>
				<view class="flex-2 text-right"><text
						v-if="detailedData.project_type_id==2">$</text>{{$util.formatNumber(detailedData.current_price*this.quantity*1000/this.ganggan)}}
				</view>
			</view>
			<view class="flex" style="color: #f4cb9b;font-size: 28rpx;">
				<view class="flex-1" style="color: #ccc;">手續費</view>
				<view class="flex-2 text-right"><text
			v-if="detailedData.project_type_id==2">$</text>{{$util.formatNumber(detailedData.current_price*this.quantity*1000/this.ganggan*fee)}}
				</view>
			</view>

			<view class="purchase" @click="placeOrder()" style="background-color:  #f4cb9b;color: #000;">
				確認
			</view>
		</view>


		<u-picker :show="show" :columns="columns" @cancel="show = false" @confirm="confirm" cancelText="取消"
			confirmText="詳細"></u-picker>


	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	var flag = false;
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				fee: null, // 手续费
				flag: 0,
				rise: "rise",
				fall: "fall",
				title: "1",
				show: false,
				columns: [
					// ["1", "5", "10", "20"]
				],
				list: '',
				quantity: '5',
				detailedData: "",
				quantity1: "",
				ganggan: 1,
				userinfo: ''
			};
		},
		mounted() {
			this.userInfo()
		},
		onLoad(option) {
			this.product(option.code)
			this.getconfig();
		},
		methods: {
			// 从配置中获取手续费值
			async getconfig() {
				const result = await this.$http.get('api/app/config', {});
				if (result.data.code == 0) {
					const temp = result.data.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					this.fee = temp.get('TransRate') || this.fee;
				}
			},
			sl_input(e) {
				console.log(e.detail.value);
				this.quantity = e.detail.value
			},
			// 是否选择
			chooseEmer(itype) {
				if (itype === 0) {
					this.flag = 0
				} else {
					this.flag = 1
				}
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 产品详情
			async product(code) {
				let list = await this.$http.get('api/product/info', {
					code: code,
				})
				this.list = list
				this.detailedData = list.data.data[0]
			},
			//购买
			async placeOrder() {
				if (flag) return;
				

				const money = this.$util.formatNumber(this.detailedData.current_price * this.quantity * 1000);
		
				const result = await uni.showModal({
					title: "確認購買",
					content: "買入股票"+' '+this.detailedData.name+'，'+"購買數量" + ' ' + this.quantity*1000+ '，' + "總付款金額 " + money ,
					cancelText: "取消", // 取消按钮的文字
					confirmText: "確認", // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#f55850',
					cancelColor: '#39B54A',
				});

				console.log(result);
				if (result[1].confirm) {
					this.buy();
				}
			},
			buy() {
				flag = true;
				uni.showLoading({
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				this.$http.post('api/product/purchase', {
					num: this.quantity*1000 || 0,
					gid: this.detailedData.gid,
					price: this.detailedData.current_price*1000,
					ganggan: this.ganggan
				}).then(res => {
					flag = false;
					uni.hideLoading();
					if (res.data.code == 0) {
						uni.$u.toast(res.data.data.message);
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/position/position',
							});
						}, 1000)
					} else {
						uni.$u.toast(res.data.message);
					}
					setTimeout(() => {
						flag = false;
					}, 2000)
				}).catch(er => {
					setTimeout(() => {
						flag = false;
					}, 2000)
				})
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/info', {})


				this.userinfo = list.data.data
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		border-radius: 20rpx;
		color: #fff;
		font-size: 40rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #f4cb9b;
		color: #000;
		font-weight: 700;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 30px;
	}

	.noactity {
		background-color: #45382e;
		color: #fff;
		border: 1px solid #f1f5f9;
		height: 70rpx;
		line-height: 70rpx;
		text-align: center;
		margin-bottom: 20rpx;
		border-radius: 30px;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		color: #121212;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>