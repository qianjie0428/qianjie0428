<template>
	<view class="sc_kxbg2" style="min-height: 115vh;">
		<!-- <Header :title="$lang.USER_CENTER"></Header> -->
		<view class="flex" style="padding:10px 15px;">
			<view class="flex-1">
				<image src="../../static/applogo.png" mode="widthFix" style="width: 40px;margin-left: 10px;"></image>
			</view>

			<view v-if="userInformation.is_check == 1" class="color-white margin-right-10 font-size-16">
				{{ userInformation.real_name }}
			</view>
			<view class="color-white font-size-15">
				ID:{{!userInformation||!userInformation.mobile?'':  (userInformation.mobile).replace(/^(\d{3})\d{4}(\d{3})$/, "$1****$2")}}
			</view>
		</view>
		<view class="padding-15">
			<Profile :info="userInformation"></Profile>
		</view>

		<view>
			<view class="flex" style="padding: 10px 30px;justify-content: space-between;color: ;">
				<view style="background-color: #fad19e;padding: 8px 50px;border-radius: 30px;" @click="tikuan()">出金
				</view>
				<view style="background-color: #fad19e;padding: 8px 50px;border-radius: 30px;" @click="cunkuan()">入金
				</view>
				<!-- <view style="background-color: #fad19e;padding: 8px 40px;border-radius: 30px;" @click="daikuan()">贷款</view> -->
			</view>
		</view>


		<NavList :list="$util.navListConfig(userInformation.is_check)" @action="handleNavClick"> </NavList>

		<view style="width: 100%;display: flex;margin-top: 15px;">
			<!-- <view @click="silver()"
				style="background-color: #695546;padding:10px;color:#fff;border-radius: 10px;text-align: center;flex:35%;margin:0 20px 10px 20px">
				聯繫客服</view> -->
			<view @click="clear()"
				style="background-color: #fad19e;padding:10px;color:#000;border-radius: 10px;text-align: center;flex:35%;margin:0 40px">
				登出</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	export default {
		components: {
			Header,
			Profile,
			NavList
		},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				userInformation: {},
				is_check: '',
				cardManagement: '',
				item: '',
			}
		},
		onShow() {
			this.gaint_info()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '載入中...',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				});
				this.userInformation = list.data.data;
				this.cardManagement = list.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			handleNavClick(val) {
				if (this.cardManagement) {
					uni.navigateTo({
						url: '/pages/bankCard/bankCard'
					});
				} else {
					uni.navigateTo({
						url: '/pages/changeCard/changeCard'
					});
				}
			},
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('登出成功');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/signin/signin'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},

			// 银转证
			silver() {
				uni.navigateTo({
					url: "/pages/service/service"
				})
			},

			// 卡管理
			// manage(bank_name, bank_sub_name, card_sn) {
			// 	uni.navigateTo({
			// 		url: '/pages/binding' +
			// 			`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
			// 	});
			// 	// console.log(bank_name, '22222');
			// },
			tikuan() {
				uni.navigateTo({
					url: '/pages/prove/prove'
				});
			},
			cunkuan() {
				uni.navigateTo({
					url: '/pages/certificateBank/silver'
				});
			},
			daikuan() {
				uni.navigateTo({
					url: '/pages/trade/daikuan'
				});
			},

			//版本更新
			Update() {
				uni.navigateTo({
					url: '/pages/versionUpdate/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({
					url: '/pages/userAgreement/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({
					url: '/pages/privacyAgreement/privacyAgreement'
				});
			},
		},
	}
</script>