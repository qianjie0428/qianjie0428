<template>
	<view class="" style="min-height: 100vh;background-color: #252525;">
		<view class="college-bg" style="background-color: #2d2d2d;">
			<view class="account">
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;" @tap="home()"></image>
				<view class="college-text">購買詳情</view>
				<view class=""></view>
			</view>
		</view>
		<view class="padding-15">
		<view style="background-color: #2d2d2d;padding: 15px;border-radius: 10px;">
			<view class="">
				<!-- <view class="corporation" style="color: #fff;font-size: 15px;">{{scrambleFor[0].goods.name}}</view> -->
				<!-- <view class="area" v-if="scrambleFor.goods.locate=='깊은'">
					<view class="deep">{{scrambleFor.goods.locate}}</view>
					<view class="deep-number">{{scrambleFor.goods.code}}</view>
				</view>
				<view class="area" v-if="scrambleFor.goods.locate=='북쪽'">
					<view class="north">{{scrambleFor.goods.locate}}</view>
					<view class="north-number">{{scrambleFor.goods.code}}</view>
				</view>
				<view class="area" v-if="scrambleFor.goods.locate=='상하이'">
					<view class="shanghai">{{scrambleFor.goods.locate}}</view>
					<view class="shanghai-number">{{scrambleFor.goods.code}}</view>
				</view> -->
				<view class="flex">
					<view class="flex-1 color-white">数量</view>
					<view class="quantity-input">
						<input class="" placeholder="請輸入數量" type="number" v-model="quantity" ></input>
						<!-- <view class="">랏</view> -->
					</view>
				</view>
				<view class="flex" style="padding: 10px 0px;">
					<view class="flex-1">
						<!-- <image src="../../../../../static/purchase/biaoqian.png" mode=""></image> -->
						<view class="color-white">可用餘額</view>
					</view>
					<view style="color: #f3c997;">
						{{$util.formatNumber(list.money)}}
					</view>
				</view>
				<view class="flex" style="padding: 10px 0px;">
					<view class="flex-1">
						<!-- <image src="../../../../../static/purchase/biaoqian.png" mode=""></image> -->
						<view class="color-white">支付金額</view>
					</view>
					<view style="color: #f3c997;">
						{{scrambleFor[0].price*this.quantity*1000|addZero}}
					</view>
				</view>
			<!-- <view class="flex margin-top-10">
				<view class="flex-1" style="color: #ccc;">發行價</view>
            <text style="color: #f3c997;">{{scrambleFor[0].fa_price}}</text>
			</view>
			<view class="flex margin-top-10">
				<view class="flex-1" style="color: #ccc;">配售價格</view>
			<text style="color: #f3c997;">{{scrambleFor[0].price}}</text>
			</view> -->
			<!-- <view class="flex margin-top-10">
				<view class="flex-1" style="color: #ccc;">上市日期</view>
			<text v-if="scrambleFor.online_date!=null" style="color: #fff;">{{scrambleFor.online_date}}</text>
			<text v-if="scrambleFor.online_date==null" style="color: #fff;">未宣布的</text>
			</view> -->
			
		</view>

			<!-- 	<view class="kunm">
			<view class="display custom">
				<view class="flex">
					<view class="hand">自訂訂閱</view>
					<view class="margin-left-10">
						<image src="../../../../../static/yuangou.png" mode=""></image>
					</view>
				</view>
			</view>
			<input placeholder="請輸入數量" type="number"  v-model="quantity" style="padding: 10px;border: 1px #ccc solid;border-radius: 10px;margin-top: 10px;color: #fff;">
			<view class="amount margin-top-10" style="color: #ccc;">支付金額 : <text>{{scrambleFor[0].price*this.quantity*1000|addZero}} </text> </view>
		</view> -->

		<view class="queren" @click="placeOrder(scrambleFor.id)" style="background-color: #f3c997;color: #000;">
			確認
		</view>
</view>
</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				quantity: '',
				scrambleFor: "",
				peishou_price: '',
				list: '',
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			async userInfo() {
			     let response = await this.$http.get('api/user/fastInfo', {});
			     this.list = response.data.data; // 将用户信息存储在 list 中
			   },
			async scrambleForFunds(id) {
				let list = await this.$http.get('api/goods/goodsvipscramble', {
					id:id
				})
				this.scrambleFor = list.data.data
				console.log(list.data.data, '輸入資金');
			},
			async placeOrder(id) {
				let list = await this.$http.post('api/Product/buy_scramble', {
					num: this.quantity*1000,
					id: this.scrambleFor[0].id,
					price: this.scrambleFor[0].price*1000,
					double: 1
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/saleLog'
						});
					}, 2000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(2)
			}
		},
		onLoad(option) {
			// const item = JSON.parse(decodeURIComponent(option.item));
			// this.objData = item;
			// console.log(this.objData);
			this.id = option.id
			this.peishou_price = option.peishou_price
		},
		mounted() {
			this.userInfo()
			this.scrambleForFunds()
		},
		


	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		// background-color:#1a0ebf;

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {
				// width: 97%;
				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}
	}

	.xuanhze {
		// width: 100%;
		background: #3a3028;
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		padding: 30rpx;
		// border-bottom: 4rpx solid #e0e0e0;


		.corporation {
			font-weight: 600;
			color: #fff;
			font-size: 32rpx;
		}

		.area {
			margin: 10rpx 0 30rpx 0;
		}

		.price {
			color: #666;
			margin: 20rpx 0;
			padding-bottom: 30rpx;
			border-bottom: 2rpx solid #f3f3f3;
			font-size: 28rpx;

			text {
				color: #f85252;
				margin-left: 20rpx;
			}
		}

	}
	.quantity-input {
		background-color: #f5f5f5;
		border: 2rpx solid #e0e0e0;
		border-radius: 10rpx;
		padding: 10rpx 20rpx;
		display: flex;
		font-size: 28rpx;
	}

	.kunm {
		padding: 30rpx;
		// border: 1rpx solid #f85252;
		box-shadow: 1px 1px 1px 1px #ececec;
		border-radius: 30rpx;
		margin: 30rpx;

		.custom {
			.hand {
				font-size: 35rpx;
				font-weight: bold;
				color: #ccc;
			}

			image {
				width: 30rpx;
				height: 30rpx;
			}
		}

		.inpl {
			border: 1rpx solid #ccc;
			border-radius: 10rpx;
			margin: 20rpx 0;
			font-size: 30rpx;
			color: #000;
			padding: 20rpx;
			
		}

		.amount {
			font-size: 24rpx;
			color: #666;

			text {
				color: #f33030;
				margin-left: 20rpx;
			}
		}
	}

	.queren {

		height: 80rpx;
		background-color:#1a0ebf;
		text-align: center;
		line-height: 80rpx;
		color: #fff;
		font-size: 32rpx;
		margin: 30rpx;
		border-radius: 10rpx;
	}
</style>