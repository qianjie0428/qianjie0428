<!-- 우승기록 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #252525;">
		<CustomHeader title="分配詳情" style="background-color: #2d2d2d;" @action="handleBack()"></CustomHeader>

		<view class="" style="padding: 0px 10px;">

			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 2px solid #ccc;background-color: #2d2d2d;padding: 10px;border-radius: 10px;margin-top: 10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view style="color: #ccc;">{{item.goods.name}}</view>
						<view style="font-size: 16px;color:seagreen;color: #ccc;">
							<view v-if="item.status==2" class="" @click="subscription(item)">訂閱</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;padding-bottom: 6px;">
						<view style="flex:25%;color: #ccc;">申購價</view>
						<view 
							style="flex:35%;text-align: right;padding-right: 20px;color: #f3c997;">
							{{$util.formatNumber(item.price)}}
						</view>
						<view style="flex:25%;color: #ccc;">申購數量</view>
						<view style="flex:25%;text-align: right;color: #fff;">
							{{$util.formatNumber(item.apply_amount)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding-bottom: 6px;">
						<view style="flex:25%;color: #ccc;">中簽金額</view>
						<view 
							style="flex:35%;text-align: right;padding-right: 20px;color: #f3c997;">
							{{$util.formatNumber(item.success_num_amount)}}
						</view>
						<view style="flex:25%;color: #ccc;">中簽數量</view>
						<view style="flex:25%;text-align: right;color: #fff;">
							{{$util.formatNumber(item.success)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding-bottom: 6px;">
						<view style="flex:25%;color: #ccc;">認繳金額</view>
						<view 
							style="flex:35%;text-align: right;padding-right: 20px;color: #f3c997;">
							{{$util.formatNumber(item.freeze)}}
						</view>
						<view style="flex:30%;color: #ccc;">未認繳金額</view>
						<view style="flex:25%;text-align: right;color: #f3c997;">
							{{$util.formatNumber(item.success_num_amount-item.freeze)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						>
						<view style="color: #ccc;">交易日期</view>
						<view style="color: #fff;">{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						>
						<view style="color: #ccc;">訂單號</view>
						<view style="color: #fff;">{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			// 우승기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},

			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							uni.navigateTo({
								url: this.$util.PAGE_URL.SERVICE
							});
						}, 500)
					} else {
						uni.redirectTo({
							url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
						});
						this.$router.go(0)

					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},

		},
		onLoad(option) {
			this.shengou()
			// this.gaint_info()
		}
		// mounted() {
		// 	// uni.showLoading({
		// 	// 	title: '加载中'
		// 	// });

		// },
	}
</script>