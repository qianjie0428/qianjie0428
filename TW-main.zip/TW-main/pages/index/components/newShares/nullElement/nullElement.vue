<!-- 学院 -->
<template>
	<view class="" style="min-height: 100vh;background-color: #2d2d2d;">
		
		<CustomHeader title="申購" style="background-color: #2d2d2d;" @action="handleBack()"></CustomHeader>
		
		<view >
		<view >
		<view class="padding-5 font-size-18" style="margin-top: 0;color: #000;background-color: #f3c997;">
			<h4>{{detailed.name}}</h4>	
			<view class="font-size-15" style="margin-top: 0;color: #444;">
				<h4>{{detailed.code}}</h4>	
			</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;padding: 10px 10px;">
			<view style="color: #ccc;">抽籤張數</view>
			<view style="color: #fff;">1張=1000股</view>
		</view>
		<view style="padding: 10px;">
			<input placeholder="" type="number" v-model="value" style="border: 1px #ccc solid;border-radius: 5px;padding: 8px;text-align: center;color: #fff;"/>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;padding: 10px 10px;">
			<view style="color: #ccc;">可用額度</view>
			<view style="color: #fff;">{{$util.formatNumber(userInformation.money)}}</view>
		</view>
		<view style="border-top: 1px #444 solid;"></view>
		<view style="padding: 10px 0px;">
			<view v-if="detailed.name!=null" class="common_btn btn_primary" style="margin: auto;width: 80%;background-color: #f3c997;" @click="position(price.id)">
			一鍵申購</view>
		</view>
		<view style="border-top: 1px #444 solid;"></view>
		<view >
			<view style="padding:10px 0px;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding: 0px 10px;">
					<view style="color: #ccc;">股票名稱</view>
					<view style="color: #fff;">{{detailed.name}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding: 0px 10px;">
					<view style="color: #ccc;">發行總張數</view>
					<view style="color: #fff;">{{$util.formatNumber(price.price)}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view> -->
				
				<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$util.THEME.TIP}">주가수익비율</view>
					<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(price.shiying)}}</view>
				</view> -->
				<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">發行總張數</view>
					<view style="color: #fff;">{{$util.formatNumber(price.fa_amount)}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				<!-- <view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">募集資金</view>
					<view style="color: #fff;">{{price.fa_muji_zijin}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view> -->
				<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">抽籤開始日</view>
					<view style="color: #fff;">{{price.shengou_date}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">抽籤截止日</view>
					<view style="color: #fff;">{{price.rj_date}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">抽籤日</view>
					<view style="color: #fff;">{{price.gb_date}}</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;padding: 0px 10px;">
					<view style="color: #ccc;">撥券日</view>
					<view v-if="price.online_date!=null" style="color: #fff;">{{price.online_date}}</view>
					<view v-if="price.online_date==null" style="color: #fff;">未宣布</view>
				</view>
				<view class="margin-top-5">
					<view style="border-top: 1px #444 solid;"></view>
				</view>
			</view>

			<!-- <u-steps current="0" :activeColor="$util.THEME.PRIMARY">
				<u-steps-item title="구독 날짜" :desc="title1.shengou_date"></u-steps-item>
				<u-steps-item title="발표일" :desc="title2.gb_date"></u-steps-item>
				<u-steps-item title="구독 날짜" :desc="title3.rj_date"></u-steps-item>
				<u-steps-item title="상장 예정" :desc="title4.online_date ? title4.online_date : '예고 없는'"></u-steps-item>
			</u-steps> -->
		</view>

		<!-- <view class="general" style="color: #fff;margin-top: -20px;">
			<h4>問題概述</h4>
			<view class="display">
				<view class="front" style="color: #ccc;">기금 모금</view>
				<view>{{price.fa_muji_zijin}}</view>
			</view>
				<view class="display">
				<view class="front">中签率</view>
				<view>{{price.success}}</view>
			</view>
			<view class="display">
				<view class="front" style="color: #ccc;">당첨일 발표</view>
				<view>{{price.gb_date}}</view>
			</view>
			<view class="display">
				<view class="front" style="color: #ccc;">기금 약속의 날</view>
				<view>{{price.rj_date}}</view>
			</view>
			<view class="display">
				<view class="front" style="color: #ccc;">상장일</view>
				<view v-if="price.online_date!=null">{{price.online_date}}</view>
				<view v-if="price.online_date==null">예고 없는</view>
			</view>
		</view> -->
		<!-- <view v-if="detailed.name!=null" class="common_btn btn_primary" style="margin: auto;width: 60%;background-color: #f3c997;" @click="position(price.id)">
確認</view> -->
		<!-- position(price.id) -->

		<!-- 弹窗 -->
		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm(confirmation)"
			:showCancelButton='showCancelButton' :content='content' cancel-text="取消" confirm-text="確認">
		</u-modal>
		
		<u-modal :show="show_mima"  :title="title" @confirm="position(confirmation)">
				<u--input
				    placeholder="請輸入您的密碼"
					type="password"
				    border="surround"
				    v-model="password"
				  ></u--input>
		</u-modal>

		<!-- 	<view class="purchase">
			<view class="apply">
				<h4>구독 수량</h4>
			</view>
			<input placeholder="구독 수량을 입력하세요." type="number" v-model="value">
			<view class="purchases" @click="purchase">申购</view>
		</view> -->
	</view>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				password:"",
				show_mima:false,
				value: 1,
				detailed: "",
				price: '',
				title1: '',
				title2: '',
				title3: '',
				title4: '',
				show: false,
				// shuliang:100,
				userInformation: {},
				title: '提示',
				content: '點擊以確認您的訂閱。',
				showCancelButton: true,
				confirmation:"",
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			shengou_mima(id) {
				this.show_mima = true;
				this.confirmation = id
				
			},
			//申购
			async position(id) {
				this.purchase(id)
				this.show = false;
				
				
				
				// let list = await this.$http.post('api/goods-shengou/password', {
				// 	password:this.password,
				// 	id: id,
				// 	// price: this.price
				// })
				
				// if (list.data) {
				// 	this.show_mima = false;
				// 	this.show = true;
					
				// } else {
				// 	this.show_mima = false;
				// 	uni.$u.toast(list.data.message);
				// }
				// 
				// this.confirmation = id
				
				
				// console.log(this.confirmation, '11111111111');
			},
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				});
				this.userInformation = list.data.data;
				this.cardManagement = list.data.data.bank_card_info
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm(confirmation) {
				// this.show = false;
				// console.log(confirmation, '点击确定');
				this.purchase(confirmation)
				this.show = false;
			},
			//跳转
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			// 点击申购
			async purchase(confirmation) {
				if (!this.value || isNaN(this.value) || this.value <= 0) {
				        uni.showToast({
				          title: '請輸入數量',
				          icon: 'none'
				        });
				        return;
				      }
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.value*1000,
					id: confirmation,
					// price: this.price
				})
				uni.$u.toast(list.data.message);
				if (list.data.code == 0) {
					uni.showLoading({
						title: "您的訂閱正在進行中。請稍等....",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						console.log(list,555555);
						uni.reLaunch({
							url: '/pages/position/position'
						});
						uni.hideLoading();
					}, 2000)
				} 
			},
			//
			async information() {
				let list = await this.$http.get('api/goods-shengou/detail', {
					id: this.id
				})
				// console.log(list.data.data);
				this.detailed = list.data.data.goods
				this.price = list.data.data
				this.title1 = list.data.data
				this.title2 = list.data.data
				this.title3 = list.data.data
				this.title4 = list.data.data
				// console.log(this.detailed, '세부');
			},

		},
		//传值过来接收
		onLoad(option) {
			this.id = option.id
			this.gaint_info()
			// this.price = option.fa_price
		},
		// 进入页面就开始渲染
		mounted() {
			// uni.showLoading({
			// 	title: '加载中'
			// });
			this.information()
		},

	}
</script>

<style lang="scss">
	page{
		background-color: #fff;
	}
	/deep/.u-input {
		background: #f5f5f5;
	}

	/deep/.u-modal__content__text {
		text-align: center;
	}

	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束
	/deep/.u-text {
		flex-direction: column !important;
	}

	.college-bg {
		padding: 60rpx 30rpx 30px;
		height: 80rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.company-name {
		margin-top: -60rpx;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;
		border-bottom: 1rpx dashed #ccc;
	}

	.issue {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx;
		font-size: 24rpx;

		view {
			width: 42%;
			display: flex;
			justify-content: space-between;
			align-items: center;

		}

		text {
			margin: 10rpx 0;
		}
	}

	.general {
		padding: 30rpx;
		font-size: 26rpx;

		h4 {
			font-size: 32rpx;
		}

		view {
			margin: 6rpx 0;
		}

		.front {
			color: #999;
		}
	}

	.purchase {
		padding: 30rpx;
		font-size: 26rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #f4f4f4;


		h4 {
			font-size: 32rpx;
		}

		.apply {
			display: flex;
			justify-content: space-between;
			align-items: center;

			text {
				color: #f85050;
				margin-left: 20rpx;
			}
		}

		input {
			background: #fff;
			display: block;
			margin: 30rpx 0;
			padding: 20rpx;
			border-radius: 10rpx;
			font-size: 28rpx;
			// color: #C0C4CC;

		}

		.purchases {
			background-image: linear-gradient(to right, #1a73e8, #014b8d);
			margin: 30rpx 0;
			border-radius: 10rpx;
			padding: 20rpx 0;
			text-align: center;
			color: #fff;
			font-weight: 600;
			font-size: 32rpx;
		}
	}

	.purchases {
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		margin: 30rpx 0;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 32rpx;
		margin: 30rpx;
	}
</style>