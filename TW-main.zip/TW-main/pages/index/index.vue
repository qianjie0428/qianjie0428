<!-- 主页 -->
<template>
	<view class="sc_kxbg2">
		<Header :title="$lang.HOME"></Header>

		<!-- <view style="width: 100%;justify-content: center;display: flex;">
			<image src="../../static/sy_tu.png" mode="widthFix" style="width: 92%;"></image>
		</view> -->
		<view class="flex" style="padding: 30px 10px;">
			<block v-for="(item,index) in zhishu_list.slice(0, 3)" :key="index">
				<view :style="inv==index?'border: #efc292 1px solid;':''" @click="zhishu_click(index)"
					style="padding:15px 25px;background-color: #40342A;border-radius: 10px;width: 20%;margin: 5px;">
					<view class="font-size-15 bold color-white text-center"
						style="  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
						{{item.name}}
					</view>

					<view class="font-size-18 text-center margin-top-10" style="color: #39b44c;"
						:style="{color:`${item.rate_num>0?'#fc4136':'#00b34f'}`}">
						{{$util.formatNumber(item.current_price*1)}}
					</view>
					<view class="text-center margin-top-5" :style="{color:`${item.rate_num>0?'#fc4136':'#00b34f'}`}"
						style="color: #fff;font-size: 15px;">{{item.rate_num}}</view>
					<view class="text-center margin-top-5" style="font-size: 15px;"
						:style="{color:`${item.rate>0?'#fc4136':'#00b34f'}`}">
						{{(1*item.rate).toFixed(2)}}%
					</view>

				</view>
			</block>
		</view>


		<view style="margin-top: -30px;">
			<ButtonGroup :btns="$util.businessBtnsConfig()" col="25"></ButtonGroup>

		</view>


		<!-- 动态渲染公告内容 -->

		<!-- <view style="padding: 10px 0px;">
			<view class="flex" style="background-color: #40342a;">
				<image src="../../static/horn.png" mode="widthFix" style="width: 25px;margin-left: 10px;"></image>
				<template>
					<div class="announcement-container">

						<div class="announcement-text" ref="announcementText"
							:style="{ animationDuration: animationDuration + 's' }">
							
							<span v-for="(text, index) in announcements" :key="index">
								{{ text }} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							</span>

						</div>
					</div>

				</template>
			</view> -->
		<!-- <template>
				<div class="ad-container">
					<div class="ad-content" :style="{ animationDuration: animationDuration + 's' }">
						<span v-for="(ad, index) in ads" :key="index" class="ad-item">
							{{ ad }}
						</span>
					</div>
				</div>
			</template> -->
		<!-- <view class="sy_zs" style="border-radius: 10px;padding:15px 5px;">
				<view style="color: #fff;">報價指數</view>
				
				<view class="chart" id="chart-type-k-line" style="width: 100%;height:200px;">
				</view>
				
				<view class="flex" style=" justify-content: space-between; margin-top: 10px;">
					

					<block v-for="(item,index) in zhishu_list.slice(0, 3)" :key="index" >
						<view :style="inv==index?'border: #efc292 1px solid;':''"  @click="zhishu_click(index)"
							style="padding:15px 25px;background-color: #40342A;border-radius: 10px;width: 18%;">
							<view class="font-size-15 bold color-white text-center" style=" width: 60px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{item.name}}</view>
							<view class="text-center" style="padding: 2px 0px;color: #fff;">{{item.code}}</view>
							<view class="font-size-18 text-center" style="color: #39b44c;">
								{{$util.formatNumber(item.current_price*1)}}</view>
							<view class="flex margin-top-5 justify-center">
								<view style="font-size: 15px;" :style="{color:`${item.returns>0?'#39b44c':'#39b44c'}`}">
									{{(1*item.rate).toFixed(2)}}%</view>
							</view>
						</view>
					</block>
					
				</view>
				<block v-for="(item,index) in zhishu_list" :key="index" >
					<view :style="inv==index?'border: #efc292 1px solid;':''"  @click="zhishu_click(index)" class="flex flex-b"
						style="padding:10px;background-color: #40342A;border-radius: 10px;margin-top: 5px;">
						<view class="color-white flex-2">
							{{item.name}}
						<span>{{item.code}}</span>
						</view>
						<view class="text-center flex-1" style="color: #39b44c;">
							{{$util.formatNumber(item.current_price*1)}}</view>
						<view class="text-right flex-1">
							<view :style="{color:`${item.returns>0?'#39b44c':'#39b44c'}`}">
								{{(1*item.rate).toFixed(2)}}%</view>
						</view>
					</view>
				</block>
			</view>
		</view>

		<view style="padding: 0px 10px;">
			<view class="sy_zs" style="margin-top: -80px;border-radius: 10px;">
				<view class="flex" style="padding: 10px 15px;">
					<view class="font-size-18 flex-1 color-white">熱門股票</view>
					<view class="flex" @click="gupiao()">
						<view class="color-white">更多</view>
						<image src="../../static/jiantou.png" mode="widthFix" style="width: 10px;margin-left: 5px;">
						</image>
					</view>
				</view>
				<GoodsList :list="goodsList"></GoodsList>
			</view> -->

		<view style="">
			<view class="bold color-white font-size-17" style="padding: 30px 15px;">推薦文章</view>
			<view class="flex horizontal-scroll" style="padding: 10px 0px;">
				<block v-for="(item,index) in Article" :key="index">
					<view @click="openNewsDetail(item.id)"
						style="background-color: #40342A;border-radius: 10px;width: 40%;border: 1px #d9d9d9 solid;height: 200px;margin-left: 10px">
						<view class="">
							<view style="width: ;">
								<image :src="item.pic" mode="widthFix" style="width: 150px;border-radius: 8px;">
								</image>
							</view>

							<view class="">
								<view class="" style="padding: 5px ;color: #fff;">{{item.title}}</view>
								<!-- <view class="font-size-15"
								style="color: #ccc;width: 90%;justify-content: flex-end; display: flex;">
								{{item.created_at}}
							</view> -->
							</view>
						</view>
					</view>

				</block>
			</view>
		</view>


	</view>




	<!-- <NotifyPrimary></NotifyPrimary> -->

	<!-- <Favorites :list="freeList"></Favorites> -->

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import NotifyPrimary from '@/components/notify/NotifyPrimary.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';

	import {
		init,
		registerLocale,
		dispose,
	} from 'klinecharts'


	export default {
		components: {
			Header,
			ButtonGroup,
			NotifyPrimary,
			Favorites,
			GoodsList,
		},
		data() {
			return {
				userinfo: [],
				// show_money: true,
				page: 1,
				goodsList: [],
				imageUrl: '',
				Article: "",
				gp_index: 0,
				freeList: [],
				contents: null,
				zhishu_list: "",
				inv: 0,
				announcements: [
					"永財投資公司堅持“立存久遠，做大做強”的企業願景，堅守“誠信、務實、負責”的企業精神，牢記對社會負責、對股東負責、對客戶負責、對員工負責、對企業自身負責的企業使命和社會責任，以投資領域的需求為基礎，以公司的服務水平和自身實力為保障，讓公司快速健康發展。在未來產業方面，看好包括新能源、半導體等領域、產業的發展，相信這些領域將在可持續發展引導下成為未來的趨勢。",
					// "公告 2：新的活动即将上线！",
					// "公告 3：更多功能敬请期待！"
				],
				animationDuration: 60,

			}
		},
		mounted() {
			this.kLineChart = init('chart-type-k-line')
			this.init()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
		async onShow() {
			this.page = 1;
			this.is_token()
			// this.good_list()
			this.article()
			this.zhishu()
			// this.startTimer()
		},

		onReachBottom() {
			this.page = this.page + 1;
			// this.good_list()
		},
		mounted() {
			// this.calculateAnimationDuration();
		},
		methods: {
			zhishu_click(index) {
				this.inv = index;
				// this.zhishu()
			},
			// calculateAnimationDuration() {
			// 	const textWidth = this.$refs.announcementText.offsetWidth;
			// 	const containerWidth = this.$refs.announcementText.parentNode.offsetWidth;
			// 	this.animationDuration = textWidth / 50; // 根据文字长度动态调整滚动速度
			// },


			// open(url) {
			// 	window.open(url)
			// },
			// 新闻列表页面

			openNewsDetail(id) {
				uni.navigateTo({
					url: `/pages/content/content?id=${id}`
				});
			},



			// async open(id) {
			//   try {
			//     let response = await this.$http.post('api/Article/info', { id }); 
			//     this.contents = response.data.data; 
			//     console.log("News details:", this.contents);

			//     if (this.contents) {
			//       // 使用 redirectTo 进行跳转，避免页面栈限制问题
			//       uni.redirectTo({
			//         url: `/pages/content/content?id=${id}&url=${this.contents.url}`
			//       });
			//     } else {
			//       console.error("No article details found for this ID.");
			//     }
			//   } catch (error) {
			//     console.error("Failed to fetch article details:", error);
			//   }
			// },

			// init() {

			// 	this.kLineChart.setStyles({
			// 		grid: {
			// 			show: true,
			// 			horizontal: {
			// 				show: true,
			// 				size: 1,
			// 				color: '#302F313A',
			// 				style: 'dashed',
			// 				dashedValue: [2, 2], // 虚线时的紧密程度
			// 			},
			// 			vertical: {
			// 				show: true,
			// 				size: 1,
			// 				color: '#302F313A',
			// 				style: 'dashed',
			// 				dashedValue: [2, 2], // 虚线时的紧密程度
			// 			}
			// 		},
			// 		"candle": {
			// 			"type": "area",
			// 			"tooltip": {
			// 				"showRule": "none",
			// 			},
			// 			area: {
			// 				lineSize: 2,
			// 				lineColor: '#f7cb9a',
			// 				value: 'close',
			// 				backgroundColor: [{
			// 					offset: 0,
			// 					color: '#6c5a4d'
			// 				}, {
			// 					offset: 1,
			// 					color: '#f7cb9a'
			// 				}]
			// 			},
			// 			bar: {
			// 				upColor: '#F92855',
			// 				downColor: '#39b44c',
			// 				noChangeColor: '#888888',
			// 				upBorderColor: '#F92855',
			// 				downBorderColor: '#39b44c',
			// 				noChangeBorderColor: '#888888',
			// 				upWickColor: '#F92855',
			// 				downWickColor: '#39b44c',
			// 				noChangeWickColor: '#888888'
			// 			},
			// 		},

			// 	});
			// 	// this.kLineChart.createIndicator('MA', false);
			// },
			// 银转证
			silver(money, bank_card_info, idno) {
				uni.$u.toast('請聯絡我們的客戶服務經理。');
				return
				// if (bank_card_info && idno !== null) {
				// uni.navigateTo({
				// 	//保留当前页面，跳转到应用内的某个页面
				// 	url: '/pages/service/service'
				// });
			},
			gupiao() {
				uni.reLaunch({
					url: '/pages/market/market'
				})
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					// this.good_list()
					// this.zhishu()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			async good_list() {

				// this.list=[]
				let result = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = result.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},
			async zhishu() {

				// this.list=[]
				let result = await this.$http.get('api/goods/zhishu', {
					inv: this.inv
				})
				// if(this.page==1){
				this.zhishu_list = result.data.data.list
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }
				if (this.kLineChart) {
					this.kLineChart.setPriceVolumePrecision(2, 0)
					this.kLineChart.applyNewData(result.data.data.lishi)
				}

			},
			async article() {
				try {
					let result = await this.$http.get('api/Article/list');
					this.Article = result.data.data;
					this.imageUrl = result.data.data.pic;
				} catch (error) {
					console.error('Error fetching article:', error);
				}
			},
			mounted() {
				this.article();
			},


			//用户信息
			async gaint_info() {
				let result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userinfo = result.data.data
			},
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: '請先登入',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/signin/signin'
						});
					}, 1000)
				} else {

				}
			},

		},
	}
</script>

<style scoped>
	.announcement-container {
		overflow: hidden;
		white-space: nowrap;
		width: 100%;
		/* 公告栏宽度 */
		background-color: #40342a;
		padding: 10px 0;
		position: relative;
		color: #ddd;
	}

	.horizontal-scroll {
		display: flex;
		overflow-x: auto;
		/* white-space: nowrap; */
	}


	.announcement-text {
		display: inline-block;
		white-space: nowrap;
		animation: scrollText linear infinite;
	}

	@keyframes scrollText {
		from {
			transform: translateX(15%);
			/* 从右侧开始 */
		}

		to {
			transform: translateX(-100%);
			/* 滚动到左侧 */
		}
	}
</style>