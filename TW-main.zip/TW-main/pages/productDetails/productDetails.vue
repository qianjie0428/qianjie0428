<template>
	<view style="background-color: #2d2d2d;min-height: 100vh;">

		<!-- <CustomHeader title="購買詳情" @action="handleBack()"></CustomHeader> -->
		
		<view style="">
		<view class="top1 sy_zs" style="border-radius: 10px;">
			<view class="flex flex-b pd10">
				<view @click="handleBack()">
					<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
				</view>
				<view style="color: #fff;font-size: 16px;"> {{productDetails.ct_name}} {{productDetails.number_code}}</view>
				<view @click="handleClickDelProduct(productDetails.gid)">
					<image :src="`/static/${productDetails.is_collected==1?'star2':'star'}.png`" mode="aspectFit"
						:style="$util.setImageSize(35)"></image>
				</view>
				<!-- <view class="flex align-center">
					<template v-if="!productDetails.logo || productDetails.logo==''">
						<view :style="$util.calcImageSize(50)"
							style="background-color:#f7cb9a;text-align: center;line-height: 50px;color: #000;border-radius: 100px;font-size: 18px;">
							{{productDetails && productDetails.name? productDetails.name[0]:''}}
						</view>
					</template>
					<template v-else>
						<image v-if="productDetails.logo" :src="getlogo()" mode="aspectFit"
							:style="$util.setImageSize(80)" style="border-radius: 100px;"></image>
					</template>
					<view>
						<image src="/static/arrow_left.png" mode="widthFix" style="width: 10px;"></image>
					</view>
					<view class="margin-left-15">
						<view class="text-center bold" style="color: #f7cb9a;font-size: 32rpx;">
							{{productDetails.name}}
						</view>
						<view style="color: #fff;font-size: 16px;"> {{productDetails.ct_name}} {{productDetails.number_code}}</view>
					</view>
				</view>

				<view @click="handleClickDelProduct(productDetails.gid)">
					<image :src="`/static/${productDetails.is_collected==1?'star2':'star'}.png`" mode="aspectFit"
						:style="$util.setImageSize(35)"></image>
				</view> -->
			</view>
			<view class="flex" style="padding: 10px;">
				<view style="flex: 55%;">
					<view class="num-font font-size-24 color-white">
						{{$util.formatNumber(productDetails.current_price)}}
					</view>
					<view class="flex" >
						<view style="background-color: #f7cb9a;padding: 0px 5px;">
							<span class="num-font " :style="{color:`${productDetails.rate>0?'#ff1b45':'#39b44c'}`}">
								{{$util.formatNumber(productDetails.rate_num)}}
							</span>
							<span class="num-font margin-left-5" :style="{color:`${productDetails.rate>0?'#ff1b45':'#39b44c'}`}">
								({{productDetails.rate}}%)
							</span>
						</view>
					</view>
				</view>
				<div  class="vertical-line" style="flex: 8%;"></div>
				<view style="flex: 50%;">
					<view class="flex  color-white">
						<view class="t2">成交量:</view>
						<view class="t3">
							{{$util.formatNumber(chengjiao)}}
						</view>
					</view>
					<view class="flex  color-white">
						<view class="t2">成交額:</view>
						<view class="t3">
							{{$util.formatNumber(chengjiaoe/100000000)}}(億)
						</view>
					</view>
				</view>
			</view>
			
			<view class="flex flex-b" style="padding: 10px;">
				
					<view class="color-white ">
						<view class="t2">今開</view>
						<view class="t3">{{$util.formatNumber(infos.open)}}
						</view>
					</view>
					<view class=" color-white">
						<view class="t2">昨收</view>
						<view class="t3">{{$util.formatNumber(infos.prev_close)}}
						</view>
					</view>
					<view class=" color-white">
						<view class="t2">最高</view>
						<view class="t3">{{$util.formatNumber(infos.high)}}
						</view>
					</view>
					<view class=" color-white">
						<view class="t2">最低</view>
						<view class="t3">{{$util.formatNumber(infos.low)}}</view>
					</view>
			</view>
		<!-- 	<view v-if="productDetails"
				style="display: flex;align-items: center;justify-content: space-between;padding:20rpx 30rpx;">
				<view class="num-font font-size-24" :style="{color:`${productDetails.rate>0?'#ff1b45':'#39b44c'}`}">
					{{$util.formatNumber(productDetails.current_price)}}
				</view>
				<view>
					<span class="num-font margin-left-20" :style="{color:`${productDetails.rate>0?'#ff1b45':'#39b44c'}`}">
						{{$util.formatNumber(productDetails.rate_num)}}
					</span>
				</view>
				<view>
					<span class="num-font margin-left-20" :style="{color:`${productDetails.rate>0?'#ff1b45':'#39b44c'}`}">
						{{productDetails.rate}}%
					</span>
				</view>
			</view> -->
			
		</view>
		</view>
		<view class=" " style="padding: 10px;">
			<!-- <view class="nav-box" style="margin-bottom: 0;">
				<view class="nav-item" :class="curren==0?'active':'active2'" @click="curren_click(0)">數據<span></span></view>
				<view class="nav-item" :class="curren==1?'active':'active2'" @click="curren_click(1)">요약<span></span></view>
				<view class="nav-item" :class="curren==2?'active':'active2'" @click="curren_click(2)">新聞<span></span></view>
			</view> -->

			<view v-show="curren==0" style="padding-bottom: 30px;">
				<view class="stock-chart" style="margin: 30rpx 0;">
					<view class="chart-time" style="position: relative;">
						<view class="txt" :class="ac_time==0?'active':'active2'" @click="ac_time_click(0)">5分</view>
						<view class="txt" :class="ac_time==1?'active':'active2'" @click="ac_time_click(1)">10分</view>
						<view class="txt" :class="ac_time==2?'active':'active2'" @click="ac_time_click(2)">30分</view>
						<view class="txt" :class="ac_time==3?'active':'active2'" @click="ac_time_click(3)">日K</view>
					</view>
					<view class="chart" id="chart-type-k-line" style="width: 100%;height:400px;">
					</view>
				</view>
				
				<view class="common_btn" style="width: 80%;background-color: #f7cb9a;color: #000;position: fixed;bottom: 20px;z-index: 9999;left: 7.5%;" @click="purchase">確認</view>
			</view>
			<InfoTwo v-if="curren==1" :code='code' :productDetails='productDetails'></InfoTwo>
			<InfoThree v-if="curren==2" :code='code' :productDetails='productDetails'></InfoThree>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import InfoTwo from '@/components/info/InfoTwo.vue'
	import InfoThree from '@/components/info/InfoThree.vue'
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {
			CustomHeader,
			InfoTwo,
			InfoThree
		},
		data() {
			return {
				zuoshou: 0,
				updata: true,
				productDetails: "",
				today: '',
				yesterday: '',
				buy: "",
				sell: "",
				divide: '',
				sky: '',
				circumference: '',
				moon: '',
				chengjiao:'',
				chengjiaoe:'',
				onePoint: '',
				halfhour: '',
				timerId: null,
				option: {},
				time_index: 0,
				list: [],
				gid: 0,
				kLineChart: null,
				ac_time: 1,
				curren: 0,
				infos:[]
			};

		},
		mounted() {
			this.kLineChart = init('chart-type-k-line')
			this.init()
		},
		
		methods: {
			getlogo() {
				return this.$BaseUrl + this.productDetails.logo
			},
			init() {

				this.kLineChart.setStyles({
					grid: {
						show: true,
						horizontal: {
							show: true,
							size: 1,
							color: '#302F313A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						},
						vertical: {
							show: true,
							size: 1,
							color: '#302F313A',
							style: 'dashed',
							dashedValue: [2, 2], // 虚线时的紧密程度
						}
					},
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: '#f7cb9a',
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#6c5a4d'
							}, {
								offset: 1,
								color: '#f7cb9a'
							}]
						},
						bar: {
							upColor: '#F92855',
							downColor: '#39b44c',
							noChangeColor: '#888888',
							upBorderColor: '#F92855',
							downBorderColor: '#39b44c',
							noChangeBorderColor: '#888888',
							upWickColor: '#F92855',
							downWickColor: '#39b44c',
							noChangeWickColor: '#888888'
						},
					},

				});
				this.kLineChart.createIndicator('MA', false);
				this.product()
				this.startTimer()
			},
			curren_click(index) {
				this.curren = index;

				this.$forceUpdate()
			},
			ac_time_click(index) {
				this.ac_time = index;
			},
			async qiehuan() {

				let list = await this.$http.post('api/product/lishi', {
					ac_time: this.ac_time,
					project_type_id: this.productDetails.project_type_id,
					code: this.productDetails.code
				})
				if (this.ac_time >= 1) {

					this.kLineChart.setStyles({
						"candle": {
							"type": "candle_solid",
						},

					});
				} else {

					this.kLineChart.setStyles({
						"candle": {
							"type": "area",
						},

					});
				}
				let result=list.data.data
				let leng=result.length-1;
				console.log(1111,leng);
				if(leng>3){
					this.infos.open=result[leng].open
					this.infos.close=result[leng].close
					this.infos.high=result[leng].high
					this.infos.low=result[leng].low
					this.infos.prev_close=result[leng-1].close
					
				}
				this.$forceUpdate()
				
				this.kLineChart.setPriceVolumePrecision(2, 0)
				this.kLineChart.applyNewData(list.data.data)
			},
			time_click(i) {
				this.time_index = i.index
				this.product()
			},
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				})
			},
			// 买入
			purchase() {
				uni.navigateTo({
					url: '/pages/purchase/purchase?code=' + this.code

				});
			},
			// 产品详情
			async product() {
				let list = await this.$http.get('api/product/info', {
					code: this.code,
					time_index: this.time_index
				})
				this.productDetails = list.data.data[0]
				this.chengjiao = list.data.data[0].info.data[0]['200013']
				this.chengjiaoe = list.data.data[0].info.data[0]['200067']
				
				
				this.qiehuan()

				// let new_price = this.productDetails.data.TDD_CLSPRC.replace(',', "");
				// let rate_num = this.productDetails.rate_num

				// this.zuoshou = (new_price * 1 - rate_num * 1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

			},
			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.product()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);
				// 在这里立即执行一次请求
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = !this.updata
					this.updata = true
					//按键样式判断
					this.productDetails.is_collected = this.productDetails.is_collected == 1 ? 0 : 1
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},

		},

		onLoad(option) {
			this.code = option.code
		},
		onShow() {
			this.startTimer()
		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},

	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #18BFB4;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}
		.vertical-line {
			border-left: 2px solid #ddd;
			/* 设置竖线的宽度和颜色 */
			height: 50px;
			/* 设置竖线的高度 */
			margin: 10px;
			/* 可选，添加一些外边距 */
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #18BFB4;
			}
		}

		.list1 {
			background: #e3edf7;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 48%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #ccc;
			}

			.t3 {
				font-size: 12px;
				color: #fff;
				font-family: Roboto;
			}
		}
	}

	.nav-box {
		margin-bottom: 16px;
		height: 51px;
		border-bottom: 1px solid #e5e8f6;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;


		.nav-item {
			// height: 30px;
			padding: 5px 0px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 17px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				// margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 17px;
			font-weight: 700;
			background-color: #f7cb9a;
			border-radius: 50px;
			

			span {
				// background: #f7cb9a;
			}
		}
		.active2 {
			
			color: #fff;
		
			
		}

	}

	.stock-chart {
		background: transparent;

		.chart-time {
			// background: rgba(255, 255, 255, 0.75);
			// border: 1px solid #999;
			background-color:#6e5c50;
			border-radius: 30px;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-pack: justify;
			-webkit-justify-content: space-between;
			justify-content: space-between;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			margin: 0 10px 10px;

			.txt {
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
				text-align: center;
				color: #fff;
				border-radius: 30px;
				padding: 5px 0;
			}

			.active.txt {
				color: #000;
				background-color:#f7cb9a;
				// box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
			}
		}
	}

	.b-btn {
		width: 100%;
		height: 46px;
		line-height: 46px;
		background: #18BFB4;
		border-radius: 10px;
		text-align: center;
		font-size: 17px;
		font-weight: 500;
		color: #fff;
	}

	.b-btn {
		width: 95%;
		margin: 16px auto 0;
	}
</style>