<template>
	<view style="min-height: 100vh; background-color: #2d2d2d;">
		<!-- 顶部标题栏 -->
		<CustomHeader title="新聞詳情" @action="handleBack" />

		<!-- 显示新闻封面图片 -->
		<view v-if="imageUrl" style="padding: 30rpx;">
			<image :src="imageUrl" mode="widthFix" style="width: 100%; border-radius: 10px;" />
		</view>

		<!-- 显示新闻内容 -->
		<view style="margin: 30rpx; padding: 30rpx; border-radius: 10px;">
			<!-- <view style="color: #fff; line-height: 1.6;" v-html="content"></view> -->
			<rich-text :nodes="content" style="color: #fff; line-height: 1.6;"></rich-text>
		</view>
	</view>
</template>

<script>
import CustomHeader from '@/components/CustomHeader.vue';

export default {
  components: {
    CustomHeader
  },
  data() {
    return {
      content: '',  // 存储新闻内容
      imageUrl: '', // 存储新闻封面图片 URL
      id: 0         // 新闻 ID
    };
  },
  onLoad(option) {
    this.id = option.id; // 获取传递的新闻 ID
    this.loadContent();   // 加载新闻内容
  },
  methods: {
    handleBack() {
      uni.switchTab({
        url: '/pages/user/user'
      });
    },
    async loadContent() {
      try {
        let response = await this.$http.get(`api/Article/info?id=${this.id}`);
        
        // 假设新闻内容在 response.data.data.content 中，封面图片在 response.data.data.image 中
        this.content = response.data.data.content;
        this.imageUrl = response.data.data.pic;
      } catch (error) {
        console.error("Failed to load content:", error);
      }
    }
  }
};
</script>

<style>
/* 需要的样式可以在这里调整 */
</style>
