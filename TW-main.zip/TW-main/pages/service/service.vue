<!-- 客服 -->
<template>
	<view class="common_page_bg">
		<CustomHeader :title="`客服`" @action="$u.route({type:'navigateBack'})"></CustomHeader>
		<web-view v-if="isWxMiniProgram" :src="list" :style="webviewStyles"></web-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "https://lin.ee/aOVHsW2", // 外部链接
				isWxMiniProgram: false, // 是否为微信小程序
				webviewStyles: {
					height: '91vh',
					width: "100%",
				}
			};
		},
		mounted() {
			window.location.href = this.list;

			this.isWxMiniProgram = true;
		}
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	iframe {
		width: 600px !important;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>