<!-- 资金明细 -->
<template>
	<view style="min-height: 100vh;background-color: #2d2d2d;">
		<CustomHeader title="帳務查詢" @action="handleBack()"></CustomHeader>

		<view class="" style="padding-bottom: 40px;">

			<u-tabs lineColor="#3a3028" :current="current" :list="list1" @click="select"
				:activeStyle="{color: '#eec394'}" style="border-radius: 40px;width: 90%;padding: 0px 15px;"
				:inactiveStyle="{color: '#ccc'}"></u-tabs>

			<view v-if="current == 0">
				<view class="" v-for="(item,index) in fundDetails" :key="index"
					style="margin-top: 10px;padding:0 6px 10px 6px;line-height: 1.8;border-bottom: 6px #555 solid;">
					<!-- 平衡 -->
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<!-- <text style="color:#ccc;">交易後餘額</text>
						<text style="color:#fff;">{{$util.formatNumber(item.after)}}</text> -->
						<!-- 审核中 -->
						<text v-if="item.status==0" style="color: #d50000;font-size: 12px;">待審核</text>
						<!-- 储值成功 -->
						<text v-if="item.status==1" style="color: #5AC725;font-size: 12px;">入金成功</text>
						<!-- 充值失败，联系客服 -->
						<text v-if="item.status==2" style="color: #F9AE3D;font-size: 12px;">未成功，請聯繫客服</text>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<text  style="color:#ccc;">交易前餘額: </text>
						<text style="color:#fff;">{{$util.formatNumber(item.before)}}</text>
					</view> -->
					<view style="display: flex;align-items: center; padding: 0px 10px;">
						<text style="color:#fff;font-size: 15px;font-size: 12px;">訂單編號 :</text>
						<text
							style="color:#fff;margin-left: 10px;">{{`${item.id}${item.id}${item.type}${item.uid}${item.id}`}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding: 0px 10px;">
						<text style="color:#ccc;">{{`${item.time1} ${item.time2}`}}</text>
						<text
							style="color:#eec394;">{{`${item.money>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.money),2))}}</text>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding: 0px 10px;">
						<!-- <text style="color:#ccc;width: 30%;">詳細：</text> -->
						<text style="color:#fff;">{{item.desc}}</text>
					</view>
				</view>
			</view>
			<view v-if="current == 1">
				<view v-for="(item,index) in rechargeRecord" :key="index"
					style="margin-top: 10px;border-bottom: 6px #555 solid;">
					<view class="takeNotes">
						<view class="display">
							<view class="business">
								<view>
									<!-- <view class="flex-1" style="color: #eec394;">{{item.desc_type}}</view> -->
									<view class="flex" style="padding:10px 10px;">

										<text style="color:#fff;font-size: 15px;font-size: 12px;">訂單編號 :</text>
										<text style="color:#fff;margin-left: 10px;flex: 30%">{{item.order_sn}}</text>
										<view class="underReview flex " v-if="item.status==0">
											<!-- <u-icon name="clock " color='#d50000' size="12"></u-icon> -->
											<view style="margin-left: 5px;color: #fff;font-size: 12px;">審核中</view>
										</view>
										<view v-if="item.status==1">
											<!-- <u-icon name="checkmark-circle" color='#5AC725'  size="12"></u-icon> -->
											<view style="margin-left: ;color: #fff;font-size: 12px;">審核通過</view>
										</view>
									</view>

									<view style="margin-top: 5px;">

										<view class="underReview_c flex" v-if="item.status==2">
											<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>

											<view style="margin-left: 5px;color: #F9AE3D;font-size: 12px;">未成功，請聯繫客服
											</view>
										</view>
									</view>
								</view>
							</view>

							<view class="flex" style="padding: 0px 10px;padding-bottom: 10px;">
								<view class="recharge flex-1" style="color: #fff;">{{item.created_at}}</view>
								<view class="money" style="color: #eec394;">
									{{`${item.money>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.money),2))}}
								</view>
							</view>
						</view>
					</view>
				</view>

			</view>
			<view v-if="current == 2">
				<view v-for="(item,index) in withdrawalRecords" :key="index"
					style="margin-top: 10px;padding:0 6px 10px 6px;line-height: 1.8;border-bottom: 6px #555 solid;">
					<view class="takeNotes">
						<view class="display">
							<view class="business">
								<!-- <view class="corporate color-white">{{item.desc_type}}</view> -->
							</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;padding: 5px 10px;">
						<view style="color:#ccc;font-size: 12px;">訂單編號 :</view>
						<view style="color:#fff;margin-left: 10px; flex: 30%;">{{item.order_sn}} </view>
						<view>
							<view class="underReview" v-if="item.status==0" style="display: flex;align-items: center;">
								<!-- <u-icon name="clock" color='#d50000' size="12" style="padding-right: 30rpx;"></u-icon> -->
								<view style="color:#fff ;font-size: 12px;">待審核</view>
							</view>
							<view class="underReview_b" v-if="item.status==1"
								style="display: flex;align-items: center;">
								<!-- <u-icon name="checkmark-circle" color='#5AC725' size="12"
									style="padding-right: 30rpx;"></u-icon> -->
								<view style="color:#fff ;font-size: 12px;">出金成功</view>
							</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding: 5px 10px;">
						<view style="color:#ccc;"> {{item.created_at}}</view>
						<view style="color:#cfc394;">
							{{`${item.money<0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.money),2))}}
						</view>
					</view>

					<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color:#ccc;"> 時間 </view>
						<view style="color:#fff;"> {{item.created_at}} </view>
					</view>
					<template v-if="item.status==2">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color:#ccc;"> 拒絕原因 </view>
							<view style="color:#fff;"> {{item.reason}} </view>
						</view>
					</template> -->

					<view class="underReview_c" v-if="item.status==2" style="display: flex;align-items: center;padding: 0 10px;">
						<!-- <u-icon name="close-circle" color='#F9AE3D' size="12" style="padding-right: 30rpx;"></u-icon> -->
						<view style="color:#fff ;font-size: 12px;">{{item.reason}}</view>
					</view>

					<view class="underReview_c" v-if="item.status==3" style="display: flex;align-items: center;">
						<u-icon name="close-circle" color='#F9AE3D' size="12" style="padding-right: 30rpx;"></u-icon>取消
					</view>
					<template v-if="item.status==0">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<u-button text="取消" type="error" @click="qx(item.id)"></u-button>
						</view>
					</template>
				</view>
			</view>

		</view>
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				current: 0,
				list1: [{
						name: '交易明細'
					},
					{
						name: '入金明細'
					},
					{
						name: '出金明細'
					},
				],
				fundDetails: [],
				rechargeRecord: "",
				withdrawalRecords: ['']
			};
		},
		onLoad(item) {
			this.current = Number(item.index);
		},
		onShow() {

			this.recharge()
		},
		methods: {
			async qx(id) {
				const result = await uni.showModal({
					title: "確定取消出金？",
					cancelText: "取消",
					confirmText: "確認",
				});
				if (result[1].confirm) {
					this.qx_post(id);
				}
			},

			async qx_post(id) {
				let list = await this.$http.post('api/app/qx', {
					id: id
				});
				console.log(list)
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.withdrawal()
				} else {
					uni.$u.toast(list.data.message);
				}
			},

			handleBack() {
				uni.switchTab({
					url: '/pages/user/user'
				});
			},
			select(item) {
				// console.log(item);
				this.current = item.index;
				// console.log(this.current, '9989999999');
			},

			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				console.log(this.fundDetails);

			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {})
				this.withdrawalRecords = list.data.data
			},

		},
		mounted() {
			this.fund()
			this.recharge()
			this.withdrawal()
		},
	}
</script>

<style lang="scss">
	.college-bg {

		padding: 20rpx;

		height: 80rpx;

		background-color: #212265;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>