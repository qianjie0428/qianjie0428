<!-- 国内库存余额/盈亏 -->
<template>
	<view class="sc_kxbg2">
		<!-- <Header :title="$lang.POSITION"></Header> -->
		<view class="flex" style="padding: 10px;">
			<view class="text-center flex-1 bold font-size-18 color-white">庫存</view>
			<view @click="xinxi()">
				<image v-if="shengouck === 1" src="/static/sy_xx.png" mode="widthFix" style="width: 25px;"></image>
				<image v-if="shengouck === 0" src="/static/sy_tz.png" mode="widthFix" style="width: 25px;"></image>
			</view>
		</view>
		<view style="padding: 6px 0;">
			<view style="padding: 10px;">
				<view style="display: flex;align-items: center;border: 1px #fad19e solid;border-radius: 5px;">
					<view :class="curTab==0?'with-bottom-line':'with-bottom-line2'" @click="changeTab(0)"
						style="flex:1;text-align: center;">
						未實現損益
					</view>
					<view :class="curTab==1?'with-bottom-line':'with-bottom-line2'" @click="changeTab(1)"
						style="flex:1;text-align: center;">
						已實現損益
					</view>
					<view :class="curTab==2?'with-bottom-line':'with-bottom-line2'" @click="changeTab(2)"
						style="flex:1;text-align: center;">
						新股庫存
					</view>
					<view :class="curTab==3?'with-bottom-line':'with-bottom-line2'" @click="changeTab(3)"
						style="flex:1;text-align: center;">
						抽籤
					</view>
				</view>
			</view>
		</view>

		<view style="padding: 10px;">
			<view style="background-color: #272822;border-radius: 10px;">
				<view class="flex flex-b padding-10">
					<view class="color-white text-center">
						<view>市值</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.frozen )}}</view>
					</view>
					<div v-if="curTab==0" class="vertical-line2"></div>
					<view class="color-white text-center" v-if="curTab==0">
						<view>預估損益</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.holdYingli )}}</view>
					</view>
					<div class="vertical-line2"></div>
					<view class="color-white text-center" v-if="curTab==1">
						<view>已實現損益</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.totalYingli )}}</view>
					</view>
					<div v-if="curTab==1" class="vertical-line2"></div>
					<view class="color-white text-center" v-if="curTab==2">
						<view>預估損益</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.holdYingli )}}</view>
					</view>
					<view class="color-white text-center" v-if="curTab==3">
						<view>已實現損益</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.holdYingli )}}</view>
					</view>
					<div v-if="curTab==2" class="vertical-line2"></div>
					<div v-if="curTab==3" class="vertical-line2"></div>
					<view class="color-white text-center">
						<view>可用餘額</view>
						<view class="margin-top-10">{{$util.formatNumber(userInformation.money)}}</view>
					</view>
				</view>
				<view v-if="curTab==0">
					<block v-for="(item,index) in holdSells" :key="index">
						<view style="padding: 5px 10px;">
							<view style="align-items: center;padding:5rpx;">
								<view class="flex" v-if="curTab==0">
									<view class="bold font-size-18 color-white">{{item.goods_info.name}}</view>
									<view class="margin-left-5 hui1">{{item.goods_info.code}}</view>
								</view>
								<view class="flex " style=" justify-content: space-between;">
									<view style="flex: 50%;">
										<view class="flex" v-if="curTab==0">
											<view class="flex-1" style="color:#ddd">股名</view>
											<view class="color-white">{{item.goods_info.name}}</view>
										</view>
										<view class="flex margin-top-10">
											<view v-if="curTab==0" class="flex-1" style="color:#ddd">預估損益</view>

											<view :style="{color:item.order_buy.float_yingkui>0?'#ff1b4b':'#39b44c'}"
												class="color-white" v-if="curTab==0">
												{{$util.formatNumber((item.goods_info.current_price*1*item.order_buy.num)-item.order_buy.amount )}}
											</view>

										</view>
										<view class="flex margin-top-10" v-if="curTab==0">
											<view class="flex-1" style="color:#ddd">買進成本</view>
											<view class="color-white" v-if="curTab==0">
												{{$util.formatNumber(item.order_buy.amount )}}
											</view>
										</view>
										<view class="flex margin-top-10" v-if="curTab==0">
											<view class="flex-1" style="color:#ddd">成交價</view>
											<view class="color-white">{{$util.formatNumber(item.order_buy.price) }}
											</view>
										</view>
									</view>
									<div v-if="curTab==0" class="vertical-line"></div>
									<view style="flex: 50%;">
										<view class="flex" v-if="curTab==0">
											<view class="flex-1" style="color:#ddd">股數</view>
											<view class="color-white">{{$util.formatNumber(item.order_buy.num )}}</view>
										</view>
										<view class="flex margin-top-10" v-if="curTab==0">
											<view class="flex-1" style="color:#ddd">報酬率</view>
											<view :style="{color:item.order_buy.float_yingkui>0?'#ff1b4b':'#39b44c'}"
												class="color-white">
												{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
											</view>
										</view>
										<view class="flex margin-top-10">
											<view v-if="curTab==0" class="flex-1" style="color:#ddd">現值</view>
											<view class="color-white" v-if="curTab==0">
												{{$util.formatNumber((item.goods_info.current_price*1*item.order_buy.num) )}}
											</view>
										</view>
										<view class="flex margin-top-10">
											<view v-if="curTab==0" class="flex-1" style="color:#ddd">市價</view>
											<view v-if="curTab==0" class="color-white">
												{{$util.formatNumber(item.goods_info.current_price) }}
											</view>
										</view>
									</view>
								</view>
								<view class="text-center"
									style="padding: 10px 10px;justify-content: center;display: flex;"
									@click="position(item.id)" v-if="curTab==0">
									<view
										style="background-color: #f7cc9b;width: 40%;padding: 5px ;border-radius: 5px;">
										賣出</view>
								</view>
								<view v-if="curTab==0" style="border-bottom: 1px #e9c195 solid;"></view>
							</view>
						</view>
					</block>
					<view style="margin-top: 30px;color: #272822;">.</view>
				</view>

				<view v-if="curTab==1">
					<block v-for="(item,index) in holdSells" :key="index">
						<view style="padding: 5px 10px;">
							<view style="align-items: center;padding:5rpx;">

								<view class="flex" v-if="curTab==1">
									<view class="bold font-size-18 color-white">{{item.goods_info.name}}</view>
									<view class="margin-left-5 hui1">{{item.goods_info.code}}</view>
								</view>
								<view class="flex " style=" justify-content: space-between;">
									<view style="flex: 50%;">

										<view class="flex" v-if="curTab==1">
											<view class="flex-1" style="color:#ddd">股名</view>
											<view class="color-white">{{item.goods_info.name}}</view>
										</view>
										<view class="flex margin-top-10">

											<view v-if="curTab==1" class="flex-1" style="color:#ddd">實現損益</view>

											<view :style="{color:item.order_sell.yingkui>0?'#ff1b4b':'#39b44c'}"
												class="color-white" v-if="curTab==1">
												{{$util.formatNumber(item.order_sell.yingkui )}}
											</view>
										</view>

										<view class="flex margin-top-10" v-if="curTab==1">

											<view class="flex-1" style="color:#ddd">買進價格</view>

											<view class="color-white">{{$util.formatNumber(item.order_buy.price) }}
											</view>
										</view>
										<view class="flex margin-top-10" v-if="curTab==1">
											<view class="flex-1" style="color:#ddd">買進成本</view>

											<view class="color-white" v-if="curTab==1">
												{{$util.formatNumber((item.order_buy.price*1*item.order_buy.num) )}}
											</view>
										</view>
									</view>

									<div v-if="curTab==1" class="vertical-line"></div>
									<view style="flex: 50%;">

										<view class="flex" v-if="curTab==1">
											<view class="flex-1" style="color:#ddd">股數</view>
											<view class="color-white">{{$util.formatNumber(item.order_buy.num )}}</view>
										</view>

										<view class="flex margin-top-10" v-if="curTab==1">
											<view class="flex-1" style="color:#ddd">報酬率</view>
											<view :style="{color:item.order_sell.yingkui>0?'#ff1b4b':'#39b44c'}"
												class="color-white">
												{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
											</view>
										</view>
										<view class="flex margin-top-10">

											<view v-if="curTab==1" class="flex-1" style="color:#ddd">賣出價格</view>

											<view class="color-white" v-if="curTab==1">
												{{$util.formatNumber(item.order_sell.price )}}
											</view>
										</view>
										<view class="flex margin-top-10">

											<view v-if="curTab==1" class="flex-1" style="color:#ddd">賣出金額</view>

											<view v-if="curTab==1" class="color-white">
												{{$util.formatNumber(item.order_sell.amount) }}
											</view>

										</view>

									</view>

								</view>

								<view v-if="curTab==1" style="border-bottom: 1px #e9c195 solid;padding: 5px 0px;">
								</view>

							</view>
						</view>

					</block>
					<view style="margin-top: 30px;color: #272822;">.</view>
				</view>

				<view v-if="curTab==3" style="padding: 0px 10px;">
					<template>
						<block v-for="(item,index) in ipoSuccess" :key="index" style="border-top: 1px #ddd solid;">
							<view class="flex" style="margin-top: 10px;">
								<view class="bold font-size-18 color-white">{{item.goods.name}}</view>
								<view class="flex-1" style="color: #8c8c8c; margin-left: 5px;">{{item.goods.code}}
								</view>
								<view style="color: #39b43a;">已中籤</view>
							</view>
							<view class=" flex">
								<view style="flex: 50%;">
									<view class="flex">
										<view class="flex-1" style="color: #ddd;">抽籤籤數</view>
										<view class="color-white">{{$util.formatNumber(item.apply_amount)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1 " style="color: #ddd;">中籤數量</view>
										<view class="color-white">{{$util.formatNumber(item.success)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1 " style="color: #ddd;">價格</view>
										<view class="color-white">{{$util.formatNumber(item.price)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">金額</view>
										<view class="color-white">{{$util.formatNumber(item.success_num_amount)}}</view>
									</view>
								</view>
								<div v-if="curTab==3" class="vertical-line"></div>
								<view style="flex: 50%;">
									<view class="flex">
										<view class="flex-1" style="color: #ddd;">抽籤日期</view>
										<view class="color-white">{{ $util.formatDate(item.created_at , 'YYYY-MM-DD') }}
										</view>
									</view>
									<!-- <view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">撥券日期</view>
										<view class="color-white">
											{{!item.goodsshengou.online_date?'': $util.formatDate(item.goodsshengou.online_date , 'YYYY-MM-DD') }}
										</view>
									</view> -->
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">股數</view>
										<view class="color-white">{{$util.formatNumber(item.success)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">庫存</view>
										<view class="color-white">是</view>
									</view>
								</view>
							</view>
							<view style="border-bottom: 1px #e9c195 solid;padding: 5px 0px;"></view>
						</block>
						<view style="margin-top: 30px;color: #272822;">.</view>
					</template>
				</view>

				<view v-if="curTab==2" style="padding: 0px 10px;">
					<template>
						<block v-for="(item,index) in  ipoApplys" :key="index">
							<view class="flex" style="margin-top: 10px;">
								<view class="bold font-size-18 color-white">{{item.goods.name}}</view>
								<view class="flex-1" style="color: #8c8c8c; margin-left: 5px;">{{item.goods.code}}
								</view>
								<view style="color: #39b43a;">{{transStatus(item.status)}}</view>
							</view>
							<view class=" flex">
								<view style="flex: 50%;">
									<view class="flex">
										<view class="flex-1" style="color: #ddd;">抽籤籤數</view>
										<view class="color-white">{{$util.formatNumber(item.apply_amount)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">中籤數量</view>
										<view class="color-white">{{$util.formatNumber(item.success)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1 " style="color: #ddd;">價格</view>
										<view class="color-white">{{$util.formatNumber(item.price)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1 " style="color: #ddd;">金額</view>
										<view class="color-white">{{$util.formatNumber(item.apply_amount*item.price)}}
										</view>
									</view>
								</view>
								<div v-if="curTab==2" class="vertical-line"></div>
								<view style="flex: 50%;">
									<view class="flex">
										<view class="flex-1" style="color: #ddd;">抽籤日期</view>
										<view class="color-white">{{ $util.formatDate(item.created_at , 'YYYY-MM-DD') }}
										</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">中籤日期</view>
										<view class="color-white">{{ $util.formatDate(item.updated_at , 'YYYY-MM-DD') }}
										</view>

									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">股數</view>
										<view class="color-white">{{$util.formatNumber(item.apply_amount)}}</view>
									</view>
									<view class="flex margin-top-10">
										<view class="flex-1" style="color: #ddd;">庫存</view>
										<view class="color-white">否</view>
									</view>
								</view>
							</view>
							<view style="border-bottom: 1px #e9c195 solid;padding: 5px 0px;"></view>
						</block>
						<view style="margin-top: 30px;color: #272822;">.</view>
					</template>
				</view>
			</view>
		</view>

		<u-modal :show="show" :title="title" @cancel="cancel" @confirm="confirm" :showCancelButton='showCancelButton'
			:content='content' cancel-text="取消" confirm-text="確認">
		</u-modal>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	export default {
		components: {
			Header
		},
		data() {
			return {
				gp_show: false,

				curTab: 0,
				items: ['持股狀況', '銷售歷史'],
				show: false,
				title: '賣單',
				content: '你確定要賣出嗎？',
				showCancelButton: true,
				holdSells: null,
				subscribe: null,
				ipoSuccess: null,
				ipoApplys: null,
				userInformation: '',
				info: [],
				item_show: false,

				curPage: 1, // 当前页码
				maxPage: 1, // 最大页码
			}
		},
		onLoad() {},
		onShow() {
			if (!uni.getStorageSync('token') || '') {
				uni.navigateTo({
					url: `/pages/signin/signin`,
				});
				return false;
			}
			this.gaint_info()
			this.shengouck()
			this.changeTab(this.curTab);
		},
		onHide() {},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		// 觸底加載
		onReachBottom() {
			if (this.curTab == 0 || this.curTab == 1) {
				console.log(this.curTab, this.curPage, this.maxPage);
				if (this.curPage < this.maxPage) {
					this.curPage++;
					this.getHoldSells();
				}
			}
		},
		onUnload() {},
		methods: {
			// tab 切换
			changeTab(index) {
				this.curTab = index;
				this.holdSells = [];
				this.ipoApplys = [];
				this.ipoSuccess = [];
				this.curPage = 1;
				this.maxPage = 1;

				if (this.curTab == 0 || this.curTab == 1) this.getHoldSells();
				if (this.curTab == 2) this.getIPOApplys();
				if (this.curTab == 3) this.getIPOSuccess();
			},

			sell(item) {
				this.info = item
				this.item_show = true;
			},

			// 平仓
			position(id) {
				console.log("Received ID:", id); // 查看是否接收到正确的 ID
				if (!id) {
					console.error("ID is undefined or null.");
					return;
				}
				this.item_show = false;
				this.show = true;
				this.confirmation = id; // 正确设置 confirmation
			},
			//点击取消
			cancel() {
				this.show = false;
				this.changeTab(this.curTab);
			},
			// 点击确认
			confirm() {
				if (this.confirmation) {
					// 确保 confirmation 不为空再调用 closingFunction
					this.closingFunction(this.confirmation); // 传入 confirmation
					this.show = false;
				} else {
					console.error("Confirmation ID is undefined.");
				}
			},

			// 平仓功能
			async closingFunction(confirmation) {
				uni.showLoading({
					title: "請稍等....",
					mask: true
				});
				try {
					// 发起 POST 请求，将 confirmation ID 传递给后端
					let list = await this.$http.post('api/user/sell', {
						id: confirmation // 使用传入的 confirmation 参数
					});

					// 判断返回结果是否成功
					if (list.data.code == 0) {
						uni.$u.toast(list.data.message);
					} else {
						uni.$u.toast(list.data.message);
					}
					setTimeout(() => {
						this.changeTab(this.curTab); // 刷新页面数据
					}, 1000);
				} catch (error) {
					console.error("Failed to execute closingFunction:", error);
				} finally {
					uni.hideLoading();
				}
			},

			//产品세부
			productDetails(code) {
				uni.navigateTo({
					url: `/pages/productDetails/productDetails?code=${code}`
				});
			},
			xinxi() {
				uni.navigateTo({
					url: '/pages/email/email'
				})
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor'
				});
			},
			transStatus(status) {
				if (status == 0) {
					return '未中籤'
				} else if (status == 2) {
					return '已中籤'
				}

			},

			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			async shengouck() {
				let list = await this.$http.get('api/user/shengouck', {
					// language: this.$i18n.locale
				})
				this.shengouck = list.data.data
			},
			// 구독기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-all-apply-log', {
					gp_index: 0
				})
				this.subscribe = list.data.data
				console.log(this.subscribe, '1111111111')
				// console.log(list.data.data)
			},

			// 持仓
			async getHoldSells() {
				let list = await this.$http.get('api/user/order', {
					page: this.curPage,
					status: this.curTab + 1,
					gp_index: 0
				})
				if (!list || !list.data || list.data.code != 0) {
					this.holdSells = [];
					return false;
				}
				this.maxPage = list.data.data.last_page; // 記錄最大頁碼
				const temp = list.data.data.data;
				let tempList = [];
				if (this.curTab == 0) {
					tempList = !temp || temp.length <= 0 ? [] :
						temp.filter(item => item.order_buy && item.order_buy.id > 0);
				} else if (this.curTab == 1) {
					tempList = !temp || temp.length <= 0 ? [] :
						temp.filter(item => item.order_buy && item.order_buy.id > 0 &&
							item.order_sell && item.order_sell.id > 0);
				}
				uni.hideLoading()
				if (tempList.length > 0) {
					this.holdSells.push(...tempList);
				}
				console.log(this.holdSells, this.holdSells.length);
				console.log('持平：', this.holdSells);
			},

			// 新股中签
			async getIPOSuccess() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/user-success-log`, {
					type: 2, // 传参 1或2
				})
				console.log(result);
				this.ipoSuccess = result.data.data;
				uni.hideLoading();
			},
			// 新股申购
			async getIPOApplys() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/userAllApplyLog`, {
					type: 2, // 传参 1或2
				})
				console.log(result.data.data);
				this.ipoApplys = result.data.data;
				uni.hideLoading();
			},


		},
	}
</script>

<style lang="scss">
	.with-bottom-line {
		background-color: #f7cc9b;
		border-radius: 5px;
		padding: 5px;
		color: #000;
	}

	.with-bottom-line2 {
		color: #ccc;
	}

	// .with-bottom-line::after {
	// 	content: "";
	// 	/* 必须设置，表示插入的内容为空 */
	// 	display: block;
	// 	/* 使得::after生成的元素成为块级元素 */
	// 	border-bottom: 2px solid #f7cc9b;
	// 	/* 添加底部横线 */
	// 	width: 60%;
	// 	/* 使横线宽度与父元素相同 */
	// 	margin-top: 5px;
	// 	/* 可选：添加一些顶部外边距 */
	// 	text-align: center;
	// 	margin-left: 20%;
	// }

	.bglan {
		background-color: #EEF4FF;
	}

	.bgyellow {
		background-color: #F8F8F8;
	}

	.vertical-line {
		border-left: 2px solid #333;
		/* 设置竖线的宽度和颜色 */
		height: 100px;
		/* 设置竖线的高度 */
		margin: 10px;
		/* 可选，添加一些外边距 */
	}

	.vertical-line2 {
		border-left: 2px solid #333;
		/* 设置竖线的宽度和颜色 */
		height: 50px;
		/* 设置竖线的高度 */
		margin: 10px;
		/* 可选，添加一些外边距 */
	}

	/* 遮罩层 */
	.overlay {
		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>