<!-- 登录 -->
<template>
	<view class="launch">
		<view style="justify-content: flex-end; display: flex;align-items: center;padding: 10px 10px 0 0;"
			@click="$util.linkCustomerService()">
			<image src="../../static/sy_kf.png" mode="aspectFit" style="width: 30px;height: 30px;"></image>
		</view>
		<view class="" style="display: flex;justify-content: center;">
			<image src="/static/applogo.png" mode="heightFix" :style="$util.setImageSize(200)">
			</image>
		</view>
		<view class="font-size-16 text-center" style="color: #fff;">玖瞬數位軟體</view>
		<view class="font-size-12 text-center" style="color: #fff;margin-top: 10px;">登入後即可完整使用APP功能</view>

		<view class="padding-20">
			<view style="border-radius: 10px;background-color: #65544999;">
				<view class="font-size-17 text-center" style="color: #DABB8F;padding-top: 12px;">請登入玖瞬數位軟體</view>
				<view style="display: flex;flex-direction: column;align-items: center;">
					<view style="width: 90%;height: 10px;font-size: 16px;color: #DABB8F;padding-top: 12px;">電話號碼</view>
					<input shape="" :placeholder="$lang.USER_NAME" placeholderStyle="font-size: 13px;color: #6d6b69"
						prefixIconStyle="font-size: 22px;margin-left:10px" v-model="value1" type="number" maxlength="10"
						style="margin-top:20px;background-color: #201c19;width: 85%;color: #ccc;padding: 10px;border-radius: 5px;flex: 100%;"></input>

					<!-- <view style="width: 90%;line-height: 20px;height: 0px;position: relative;font-size: 16px;margin-top: 20px;color: #DABB8F;">密碼</view> -->

					<view style="width: 90%;font-size: 16px;color: #DABB8F;padding: 10px 0px;">密碼</view>
					<view class="flex"
						style="background-color: #201c19;padding: 10px;border-radius: 5px;width: 85%;color: #ccc;">
						<input v-model="value2" :password="!isMask" shape="" :placeholder="$lang.PASSWORD"
							placeholderStyle="font-size: 13px;color: #6d6b69"
							style="font-size: 13px;flex: 100%;"></input>
						<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleAmount()" style=""></image>
					</view>




					<!-- 	<input shape="" :placeholder="$lang.PASSWORD" prefixIcon="lock-fill" 
				placeholderStyle="font-size: 13px;color: #6d6b69"
				prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="value2" type="password"
				style="margin-top:60rpx;background-color: #201c19;width: 85%;padding: 10px;border-radius: 5px;color: #ccc;"></input>
				<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
					:style="$util.setImageSize(40)" @click="toggleAmount()" style="padding-left: 20rpx;"></image>
				 -->
					<view class=""
						style="padding: 20px;width: 90%;justify-content: center;align-items: center;flex-direction: column;display: flex;">
						<view class="text-center color-white"
							style="width: 70%;margin-top:20rpx;background-color: #DABB8F;padding: 10px;border-radius: 470px;"
							@click="gain_login">{{$lang.SIGN_IN}}</view>
					</view>
					<view @tap="register()" class="padding-10">
						<view class="font-size-15 "
							style="padding: 5px 20px;color: #fff;border-bottom: 1px #dabb8f solid ;">註冊</view>
					</view>
				</view>
			</view>

			<view style="width: 70%;margin-top:60rpx;line-height: 20px;height: 20px;">
				<u-checkbox-group>
					<u-checkbox activeColor="#DABB8F" label="記住電話號碼" v-model="checked" labelColor="#38AA9A"
						labelSize="12px" :checked="checked"></u-checkbox>
				</u-checkbox-group>
				<!-- <view
				style="font-size: 14px;color: #38AA9A;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
				@tap="register()">
				{{$lang.SIGN_UP}}
				<u-icon name="arrow-right" color="#38AA9A" size="14" :bold="true"
					style="display: inline-block;"></u-icon>
			</view> -->
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				isMask: null, // 掩码
				checked: true,
				yan_show: true,
			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput') || '';
			let passinput = uni.getStorageSync('passinput') || '';

			if (userinput) {
				this.value1 = userinput
			}
			if (passinput) {
				this.value2 = passinput
			}

		},
		onHide() {
			uni.setStorageSync('userinput', this.value1);
			uni.setStorageSync('passinput', this.value2);
		},
		methods: {
			register() {
				console.log(22222)
				uni.navigateTo({
					url: '/pages/register/register'
				});
			},
			toggleAmount() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1.trim(),
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.setStorageSync('userinput', this.value1);
					uni.setStorageSync('passinput', this.value2);
					uni.$u.toast('登入成功');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 500)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	/* 启动页 */
	.launch {
		width: 100vw;
		min-height: 100vh;
		background-image: url('/static/lanuch_sc.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
	}
</style>