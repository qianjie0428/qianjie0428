import LANGUAGE_DATA from '@/common/language.js';
import Vue from 'vue';
import http from '@/common/api.js';

// 配色方案
const THEME = {
	PRIMARY_COLOR: '#181945',
	SECONDARY_COLOR: '#4b5fcc',
}
// 计算图片尺寸
const calcImageSize = (val) => {
	return {
		width: `${val}px`,
		height: `${val}px`,
	};
};

/**
 * @function 获取客服链接
 * @description API返回链接 ,或者默认客服链接 （开发完成向客户索取）
 */
export const getServiceURL = async () => {
	// 默认客服链接。用于无token时。（开发完成向客户索取）
	let url = `https://lin.ee/aOVHsW2`;
	if (!uni.getStorageSync(`token`) || uni.getStorageSync('token') == '') {
		return url;
	} else {
		const result = await http.get(`api/app/config`);
		if (!result) return url;
		const temp = result.data.data.reduce((map, item) => {
			map.set(item.key, item.value);
			return map;
		}, new Map());
		return !temp.get('CustomerLink') ? url : temp.get('CustomerLink');
	}
};

const linkService = async () => {
	// 获取客服链接
	const url = await getServiceURL();
	if (window.android) {
		window.open(url)
		// window.android.callAndroid("open," + url)
		return false;
	}
	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
		.nativeExt) {
		window.webkit.messageHandlers.nativeExt.postMessage({
			msg: 'open,' + url
		})
		return false;
	}
	let u = navigator.userAgent;
	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if (isiOS) {
		window.location.href = url;
		return false;
	}
	window.open(url)
};

/*
跳转到客服：
	上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	正常模式：`line`(跳轉到外鏈頁面)，`第三方`(跳轉内頁)
*/
const linkCustomerService = () => {
	// 上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	// uni.showToast({
	// 	title: `Lütfen müşteri hizmetleri ile iletişime geçin`,
	// 	icon: 'none'
	// });

	// 正常模式：`line`(跳轉到外鏈頁面)
	linkService();

	// 正常模式：`第三方`(跳轉内頁)
	// uni.navigateTo({
	// 	url: paths.SERVICE
	// });
}

/* 数字格式化， 比如 123,464.23 */
const formatNumber = (value, fixed = 2) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

// 日期格式化
const formatDate = (timeString) => {
	const date = new Date(timeString);
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');

	return `${year}.${month}.${day}`;
}

// 计算页面高度
const calcPageHeight = () => {
	const systemInfo = uni.getSystemInfoSync();
	const tabBarHeight = systemInfo.screenHeight - systemInfo.windowHeight;
	return systemInfo.screenHeight - tabBarHeight;
};

// 主页功能按钮组配置
const businessBtnsConfig = () => {
	return [
	{
		name: '紅利股票', // 日内交易 
		url: '/pages/trade/large',
		icon: 'trade_day'
	}, {
		name: '申購競拍', // 折价交易 	 
		url: '/pages/market/market',
		icon: 'large'
	}, {
		name: '價值股', // 新股认购
		url: '/pages/trade/vip',
		icon: 'discount_trade'
	}, {
		name: '存股借券', // 提款
		url: '/pages/trade/sale',
		icon: 'short_trade'
	},{
		name: '入金', //  VIP   
		url: '/pages/certificateBank/silver',
		icon: 'shares'
	}, {
		name: '交易細則', // 实名认证
		url: '/pages/jiaoyi',
		icon: 'auth'
	}, 
	// {
	// 	name: 'ETF', // 存款 
	// 	url: '/pages/trade/etf',
	// 	icon: 'apply_purchase'
	// }, 
	{
		name: '身分認證', // 存款 
		url: '/pages/authentication/authentication',
		icon: 'apply_purchase'
	}, 
	{
		name: '聯繫客服', // 客服中心
		url: '/pages/service/service',
		icon: 'service'
	}]
};

// 行情主页面，按钮组
const mqBtnsConfig = () => {
	return [{
		name: LANGUAGE_DATA.FULL_INFO,
		url: '',
		icon: 'full_info'
	}, {
		name: LANGUAGE_DATA.HOT_GOODS,
		url: '',
		icon: 'hot_goods'
	}, {
		name: LANGUAGE_DATA.MARKET_INDICATORS,
		url: '',
		icon: 'maket_indicators'
	}];
}

// 个人中心，功能列表
const navListConfig = (code) => {
	const data = [{
	// 	name: LANGUAGE_DATA.VERIFIED,
	// 	url: 'authentication',
	// 	icon: 'verify',
	// 	code: -1,
	// }, {
	// 	name: LANGUAGE_DATA.AUDIT,
	// 	url: 'authentication',
	// 	icon: 'verify',
	// 	code: 0,
	// }, {
	// 	name: LANGUAGE_DATA.AUDIT_FAILED,
	// 	url: 'authentication',
	// 	icon: 'failed',
	// 	code: 2
	}];
	const temp = data.filter(item => item.code == code);

	return [...temp,
	// {
	// 	name: LANGUAGE_DATA.SERVICE,
	// 	url: 'service',
	// 	icon: 'service'
	// }, 
	{
		name: '身分認證',
		url: 'authentication',
		icon: 'key'
	},{
		name: '設置約定帳戶',
		url: 'bankCard',
		icon: 'card'
	},{
		name: '帳務查詢',
		url: 'capitalDetails?index=0',
		icon: 'paypwd'
	},
	// {
	// 	name: '提領',
	// 	url: 'prove',
	// 	icon: 'capital_deatil'
	// }, 
	{ 
		name: '密碼設置',
		url: 'sheding',
		icon: 'verify'
	},  
	{
		name: '聯繫客服',
		url: 'service',
		icon: 'about'
	}, 
	// {
	// 	name: LANGUAGE_DATA.ABOUT,
	// 	url: 'about',
	// 	icon: 'about'
	// },
	]
};

const TRADE_LOG_STATUS = [{
		label: '擱置審查',
		color: 'gray'
	},
	{
		label: '經過',
		color: 'red'
	},
	{
		label: '拒絕',
		color: 'green'
	}
];
// 1是通过   0是待审核   2是拒绝     通过红色   拒绝绿色   待审核灰色
const calcTradeLogStatusLabel = (val) => {
	return TRADE_LOG_STATUS[val].label;
}
const calcTradeLogStatusColor = (val) => {
	return TRADE_LOG_STATUS[val].color;
}

const UTIL = {
	THEME,
	calcImageSize,
	formatNumber,
	formatDate,
	calcPageHeight,
	businessBtnsConfig,
	mqBtnsConfig,
	navListConfig,
	calcTradeLogStatusLabel,
	calcTradeLogStatusColor,
	getServiceURL,
	linkCustomerService,

	// 负数取绝对值
	formatMathABS: (val) => {
		return Math.abs(val);
	},
	// 设置input的placeholder样式
	setPlaceholder: (color = '', fontsize = '') => {
		return `color:${color == '' ? Vue.prototype.$theme.PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
	},

	// 设置图片尺寸（自定义size）
	setImageSize: (w = 0, h = 0) => {
		const _w = w > 0 ? w : 20;
		const _h = h > 0 ? h : _w;
		return {
			width: `${_w}rpx`,
			// 若为设置h值，则视为高=宽
			height: `${_h}rpx`,
		};
	},
}

export default UTIL;