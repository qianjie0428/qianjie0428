// 统一语言转换
const LANGUAGE_DATA = {
	SIGN_IN: "登入", // 登入  
	SIGN_UP: "會員註冊", // 創建賬戶  
	SIMGN_OUT: "登出", // 登出（注意：原文本中SIMGN_OUT可能是SIGN_OUT的拼寫錯誤）  
	USER_NAME: '輸入電話號碼', // 請輸入賬戶  
	PASSWORD: '輸入密碼', // 請輸入密碼  
	PASSWORD_CONFIRM: '再次輸入密碼', // 請再次輸入密碼  
	INVITATION_CODE: '輸入推薦碼', // 輸入邀請碼  
	// 底部導航   
	HOME: '首頁', // 主頁  
	FAVORITES: '關注股票', // 感興趣的  
	MARKET_QUOTATION: '實時行情', // 行情  
	POSITION: '國內股票持仓/盈賧', // 盈賧/餘額  
	USER_CENTER: '更多', // 個人中心（注意：原文本中“더보기”在中文繁體中可能不太對應，這裏用“更多”代替）  
	// 首頁 按鈕組  
	TRADE_SHORT: '短線交易', // 短打交易  
	TRADE_LARGE: '大宗交易', // 大宗交易（注意：原文本中兩個“TRADE_LARGE”可能有一個是錯誤的，這裏假設“TRADE_IPO”是錯誤的並更正）  
	TRADE_IPO: '新股申購', // 新股申購  
	TRADE_MARKET: '當日交易', // 日內交易  
	TRADE_DISCOUNT: '折價交易', // 折價交易  
	TRADE_SALE: '新股配售', // 新股配售  
	  
	SERVICE: '客服中心', // 客服  
	CHANGE_PWD: '更改登入密碼', // 更改登入密碼  
	CHANGE_PAY_PWD: '更改交易密碼', // 更改支付密碼（
	CARD_MANAGEMENT: '存取款賬戶聯動', // 存款/取款賬戶聯動  
	ABOUT: '公司介紹', // 關於我們  
	SEARCH: '搜尋', // 檢索  
	DETAIL: '詳情', // 詳情  
	  
	// =============== 2024.03.04 ==============  
	WITHDRAWAL: '提款', // 提款 Withdrawal  
	AUTH: '實名認證', // 身分驗證/ 實名登記  
	  
	ORDER: '智慧訂單', // 智能訂單  
	NEW_SHARE: '公開發行股', // 公開發行股  
	CREATE_BANK: '提款', // 提款  
	  
	ENPTY_DATA: '無記錄', // 暫無記錄  
	ALL_MSG: '股票', // 實時事件  
	PRODUCT_DEATIL: '股票詳細資訊', // 庫存詳情
	FULL_INFO: '全部摘要', // 完整摘要  
	HOT_GOODS: '熱門股票', // 熱門商品
	MARKET_INDICATORS: '市場指標', // 市場指標  
	MARKET_ISSUES: '市場議題', // 市場問題  
	CAPITAL_DETAIL: '存取款詳細記錄', // 資金明細/存取款記錄/資金流水
	AUDIT: '已確認[審核中]', // 已確認[審核中]  
	AUDIT_FAILED: '審核失敗[已確認]',  // 已确认[审核失败]

	
	
	
};
export default LANGUAGE_DATA;