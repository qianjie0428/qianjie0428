<template>
	<view class="padding-top-30">
	<view class="flex" style="justify-content: space-between;padding: 0px 15px;">
		<!-- <text class="common_header_left">{{title}}</text> -->
		<!-- <view>
			<image src="../static/logo2.png" mode="widthFix" style="width: 35px;margin-top: 5px;"></image>
		</view> -->
		<view  class="flex" @click="$u.route({url:'/pages/searchFor/searchFor'});" style="background-color: #695546;padding: 6px 20px;border-radius: 30px;width: 80%;">
			<image mode="aspectFit" src="/static/search_dark.png" :style="$util.calcImageSize(20)"></image>
			<view class="margin-left-5 font-size-13" style="color: #999;">搜尋股票代號</view>
		</view>
		
		<view class="flex" style="padding: 5px 10px;">
			<view class="common_header_right" @click="$util.linkCustomerService()">
				<image mode="aspectFit" src="/static/sy_kf.png" :style="$util.calcImageSize(25)"></image>
			</view>
			<view class="common_header_right " @click="$u.route({url:'/pages/email/email'});">
				<!-- <image mode="aspectFit" src="/static/sy_tz.png" :style="$util.calcImageSize(25)"></image> -->
			</view>
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		props: ["title"],
		data() {
			return {};
		}
	}
</script>
