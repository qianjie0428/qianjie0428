<template>
	<view style="padding:0px 10px;">
		<view style="background-color: #272822;border-radius: 10px;">
			<view class="flex flex-b" style="padding:20px 5px;">
				<view :style="selectedContent==0?'background-color:#f3c897;':'color:#898495;'" :current="current1"
					@click="showContent(0)" style="padding: 5px 10px;border-radius: 30px;">上市</view>
				<view :style="selectedContent==1?'background-color:#f3c897;':'color:#898495;'" @click="showContent(1)"
					style="padding: 5px 10px;border-radius: 30px;">上櫃</view>
				<view :style="selectedContent==2?'background-color:#f3c897;':'color:#898495;'" @click="showContent(2)"
					style="padding: 5px 10px;border-radius: 30px;">申購競拍</view>
				<view :style="selectedContent==3?'background-color:#f3c897;':'color:#898495;'" @click="showContent(3)"
					style="padding: 5px 10px;border-radius: 30px;">自選</view>
				<view :style="selectedContent==4?'background-color:#f3c897;':'color:#898495;'" @click="showContent(4)"
					style="padding: 5px 10px;border-radius: 30px;">熱門</view>
			</view>

			<view v-if="selectedContent ==0">
				<view style="margin-top: -10px;">
					<view class="flex flex-b titles" style="background-color: #40342a;padding: 5px;color: #fff;">
						<view class="flex-2">名稱/代碼</view>
						<view class="flex-1 t-r">最新價</view>
						<view class="flex-1 t-r">漲跌幅</view>
					</view>
					<view class="item flex flex-b padding-10" v-for="(item,index) in list2"
						@click="tiaozhuan(item.symbol)">
						<view class="t flex-2"><span class="t" :class="index>2?'num':''"> </span>
							<span style="font-weight: 700;color: #fff;font-size: 16px;">{{item.name}}</span>
							<view style="color: #ddd;font-size: 12px;">{{item.rowId.split('.')[0]}}</view>
						</view>
						<view class=" flex-1 t-r num-font"
							:style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
							{{$util.formatNumber(item.price)}}
						</view>
						<view class="flex-1">
							<view class=" t-r" :style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
								{{item.change}}
							</view>
							<view class=" t-r" :style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
								{{item.changePercent}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<view v-if="selectedContent ==1">
				<view style="margin-top: -10px;">
					<view class="flex flex-b titles" style="background-color: #40342a;padding: 5px;color: #fff;">
						<view class="flex-2">名稱/代碼</view>
						<view class="flex-1 t-r">最新價</view>
						<view class="flex-1 t-r">漲跌幅</view>
					</view>
					<view class="item flex flex-b padding-10" v-for="(item,index) in list2"
						@click="tiaozhuan(item.symbol)">
						<view class="t flex-2"><span class="t" :class="index>2?'num':''"> </span>
							<span class="font-size-16 bold"
								style="font-weight: 700;color: #fff;">{{item.symbolName}}</span>
							<view style="color: #ddd;font-size: 12px;">{{item.symbol.split('.')[0]}}</view>
						</view>
						<view class=" flex-1 t-r num-font"
							:style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
							{{$util.formatNumber(item.price)}}
						</view>
						<view class="flex-1">
							<view class=" t-r" :style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
								{{item.change}}
							</view>
							<view class=" t-r" :style="selectedContent>0?'color: #fc4136;':'color:#00b34f;'">
								{{item.changePercent}}
							</view>
						</view>
					</view>

				</view>
			</view>

			<view v-if="selectedContent ==2">
				<view style="">
					<template>
						<block v-for="(item,index) in calendar" :key="index">
							<view style="padding: 10px 5px;">
								<view class="" style="padding: 10px;border-radius: 10px;background-color: #2d2d2d;">
									<view class="flex">
										<view style="font-size: 16px;color: #ddd;">截止日：</view>
										<view class="flex-1" style="font-size: 16px;color: #e76b76;">
											{{item.rj_date}}
										</view>
										<view>
											<template v-if="item.canShengou==1">
												<view @click="to_skip(item.id)" class="text-center"
													style="padding:6px 4px;width: 80px;margin-top: 0;border-radius: 5px;"
													:style="{backgroundColor:transStatus2(item.canShengou)}">
													{{transStatus(item.canShengou)}}
												</view>
											</template>
											<template v-if="item.canShengou==3 || item.canShengou==2">
												<view class="text-center"
													style="padding:6px 4px;width: 80px;margin-top: 0;border-radius: 5px;color: #fff;"
													:style="{backgroundColor:transStatus2(item.canShengou)}">
													{{transStatus(item.canShengou)}}
												</view>
											</template>
										</view>
									</view>
									<view style="border-bottom: 1px #ddd solid;padding: 5px 0px;"></view>
									<view class="" style="padding: 10px 0px;">
										<view class="flex flex-b">
											<view class="flex color-white">
												<view>{{item.goods.code}}</view>
												<view class="margin-left-10">{{item.goods.name}}</view>
											</view>
											<view class=" color-white">可申購 {{$util.formatNumber(item.fa_amount)}}</view>
										</view>

										<view style="padding: 10px 0px;">
											<view class="flex"
												style="padding: 10px 0px;background-color: #363636;border-radius: 10px;">
												<view class="color-white text-center"
													style="line-height: 1.8;flex: 30%;">
													<view>承銷價</view>
													<view>{{$util.formatNumber(item.price)}}</view>
												</view>
												<view class="color-white text-center"
													style="line-height: 1.8;flex: 30%;">
													<view>市價</view>
													<view>{{$util.formatNumber(item.goods.current_price)}}</view>
												</view>
												<view class="color-white text-center"
													style="line-height: 1.8;flex: 30%;">
													<view>差價</view>
													<view style="color: #e76b76;">
														{{$util.formatNumber(item.goods.current_price-item.price)}}
													</view>
												</view>
												<view class="color-white text-center"
													style="line-height: 1.8;flex: 30%;">
													<view>報酬率</view>
													<view style="color: #e76b76;">
														{{$util.formatNumber((item.goods.current_price-item.price)/item.price*100) .split('.')[0]}}%
													</view>
												</view>
											</view>
										</view>
									</view>
								</view>
							</view>
						</block>
					</template>
				</view>
			</view>

			<view v-if="selectedContent ==3">
				<view class=" " style="margin-top: -10rpx;">
					<view class="flex flex-b titles" style="background-color: #40342a;padding:10px 5px;color: #fff;">
						<text style="flex:60%;color: #fff;">名稱/代碼</text>
						<text style="flex:40%;color: #fff;">最新價</text>
						<text style="flex:18%;color: #fff;">漲跌幅</text>
						<!-- <view style="flex:6%;"> </view> -->
					</view>

					<block v-for="(item,index) in list" :key="index">
						<view style="padding: 5px 0px;">
							<view style="padding: 12rpx 15rpx;display: flex;align-items: center;"
								@click="$u.route('/pages/productDetails/productDetails',{code:item.code});">


								<view style="flex: 50%;">
									<view class="color-white font-size-16">{{item.name}}</view>
									<view style="font-size: 24rpx;color: #ccc;">{{item.code}}</view>
								</view>

								<view style="flex:30%;font-size: 16px;"
									:style="{color:`${item.rate>0?'#ff1b45':'#39b44c'}`}">
									{{$util.formatNumber(item.price*1)}}
								</view>

								<view style="flex:20%;" :style="{color:`${item.returns>0?'#ff1b45':'#39b44c'}`}">
									<view style="display: flex;align-items: center;justify-content: space-between;">
										<image mode="aspectFit" :src="`/static/${item.rate>0?'up':'down'}.png`"
											:style="$util.setImageSize(20)"></image>
										<view :style="{color:`${item.rate>0?'#fc4136':'#00b34f'}`}">
											{{(1*item.rate).toFixed(2)}}%
										</view>
									</view>
								</view>

							</view>
						</view>
					</block>
				</view>
			</view>

			<view v-if="selectedContent ==4">
				<view style="margin-top: -10px;">
					<view class="flex flex-b titles" style="background-color: #40342a;padding:10px 5px;color: #fff;">
						<text style="flex:60%;color: #fff;">名稱/代碼</text>
						<text style="flex:40%;color: #fff;">最新價</text>
						<text style="flex:18%;color: #fff;">漲跌幅</text>
						<!-- <view style="flex:6%;"> </view> -->
					</view>
					<block v-for="(item,index) in goodsList.slice(0, 30)" :key="index">
						<view>
							<view style="padding: 5px 0px;border-radius: 10px;margin-top: 5px;">
								<view
									style="padding: 12rpx 10rpx;display: flex;align-items: center;border-radius: 10px;"
									@click="$u.route('/pages/productDetails/productDetails',{code:item.code});">



									<view style="flex: 44%;padding-left: 10rpx;">
										<view class="color-white font-size-16">{{item.name}}</view>
										<view style="font-size: 24rpx;color: #ccc;">{{item.code}}</view>
									</view>

									<view style="flex:20%;font-size: 16px;"
										:style="{color:`${item.rate>0?'#fc4136':'#00b34f'}`}">
										{{$util.formatNumber(item.current_price*1)}}
									</view>

									<view style="flex:20%;" :style="{color:`${item.returns>0?'#fc4136':'#00b34f'}`}">
										<view style="display: flex;align-items: center;justify-content: space-between;">
											<image mode="aspectFit" :src="`/static/${item.rate>0?'up':'down'}.png`"
												:style="$util.setImageSize(20)"></image>
											<view :style="{color:`${item.rate>0?'#fc4136':'#00b34f'}`}">
												{{(1*item.rate).toFixed(2)}}%
											</view>
										</view>
									</view>

								</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>
		<view style="text-align: center; color: #fff; display: block; margin: 0 auto; width: fit-content;">暫無更多數據</view>
	</view>
</template>

<script>
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		components: {

		},
		data() {

			return {
				show: false,
				selectedContent: 2,
				list1: [{
					name: '上市',
				}, {
					name: '上櫃',
				}, {
					name: '申購競拍'
				}, {
					name: '自選'
				}, {
					name: '熱門'
				}],
				columns: [
					[{
							name: '成交量',
						}, {
							name: '漲幅',
						}, {
							name: '跌幅'
						}, {
							name: '價差'
						}, {
							name: '股價'
						},

						{
							name: '成交金額'
						}
					]
				],
				list: [],
				list2: [],
				calendar: [],
				page: 1,

				zhishu_list: "",
				current1: 0,
				goodsList: "",
				inv: 0,
				current2: 0,
			}
		},
		methods: {
			showContent(content) {
				this.selectedContent = content;
				if (content == 0) {
					this.lists()
				} else if (content == 1) {
					this.lists()

				} else if (content == 2) {
					this.getList()
				} else if (content == 3) {
					this.collectlist()
				} else if (content == 4) {
					this.good_list()
				}
			},
			transStatus(canShengou) {
				if (canShengou == 1) {
					return '申購競拍';
				} else if (canShengou == 2) {
					return '未開始';
				} else if (canShengou == 3) {

					return '已截止';
				}

			},
			transStatus2(canShengou) {
				if (canShengou == 1) {
					return this.canShengouColor = '#f3c897'
				} else if (canShengou == 2) {
					return this.canShengouColor = "#3F51B5"
				} else if (canShengou == 3) {
					return this.canShengouColor = "#01C5C4"
				}

			},
			async collectlist() {
				try {
					const response = await this.$http.get(`api/user/collect_list`);
					console.log('response:', response);
					const result = response.data ? response.data.data.list : [];
					console.log('result:', result);
					if (!Array.isArray(result)) {
						console.error('API 返回的数据不是数组:', result);
						this.list = [];
						return;
					}
					const temp = result.length <= 0 ? [] : result;
					this.list = temp.length <= 0 ? [] : temp.map(item => {
						return {
							name: item.goods.ct_name || 0,
							code: item.goods.code || 0,
							price: item.goods.current_price || 0,
							rate: item.goods.rate || 0,
							type_id: item.goods.project_type_id || 0,
						};
					});
					console.log(222222222, this.list);
				} catch (error) {
					console.error('获取数据时发生错误:', error);
					this.list = [];
				}
			},
			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				this.calendar = result.data.data;
				uni.hideLoading();
			},
			tiaozhuan(symbol) {
				let code = (symbol + "").replace(".TWO", '')
				code = code.replace(".TW", '')

				const regex = /[a-zA-Z]/; // 正则表达式，匹配任何字母
				console.log(2222, code.length);

				uni.navigateTo({
					url: "/pages/productDetails/productDetails?code=" + code
				})
			},
			showContent(content) {
				this.selectedContent = content;
			},
			zhishu_click(index) {
				this.inv = index;
				// this.zhishu()
			},
			async good_list() {

				// this.list=[]
				let result = await this.$http.get('api/goods/list', {
					page: this.page,
					gp_index: this.gp_index
				})
				// if(this.page==1){
				this.goodsList = result.data.data
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }

			},

			async zhishu() {

				// this.list=[]
				let result = await this.$http.get('api/goods/zhishu', {
					inv: this.inv
				})
				// if(this.page==1){
				this.zhishu_list = result.data.data.list
				// }else{
				// 	this.list = this.list.concat(list.data.data)
				// }
				// this.kLineChart.setPriceVolumePrecision(2, 0)
				// this.kLineChart.applyNewData(result.data.data.lishi)

			},
			async lists() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/paihang', {
					current1: this.current1,
					current2: this.current2,
				})
				console.log(2222, list.data.data);

				this.list2 = list.data.data.data.list
				// uni.hideLoading()
			},
			qiehuan(index) {
				console.log(index)
				this.current2 = index;
				this.lists()
			},
			showContent(index) {
				console.log(index)
				this.selectedContent = index;
				this.current1 = index;
				this.current2 = 0;
				this.lists()
			},
			changes(index) {
				console.log(index)
				this.current1 = index.indexs[0];
				this.current2 = 0;
				this.show = false;
				this.$forceUpdate()
				this.lists()
			},
		},


		mounted() {
			this.zhishu()
			this.lists()
			this.getList()
			this.collectlist()
			this.good_list()
			this.page = 1;
		},
		onShow() {


		},

		onLoad() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	view,
	text {
		box-sizing: border-box;
	}

	.list {
		padding: 0 0 10px;

		.titles {
			padding: 10px;

			uni-view {
				color: #fff;
			}
		}

		.item {
			padding: 10px;

			.t {
				font-size: 16px;
				// font-weight: 700;
				color: #fff;
			}

			.t1 {
				color: #ff1b45;
				// font-weight: 600;
			}

			.t1.die {
				color: #39b44c;
				// font-weight: 600;
			}

			.num {
				color: #999;
			}
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 50px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 50px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #333;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			// font-weight: 700;
			color: #f8ce9c;

			span {
				background: #f3c897;
			}
		}

		.active2 {
			font-size: 16px;
			// font-weight: 700;
			color: #aaa;

			span {
				// background: #f3c897;
			}
		}
	}
</style>