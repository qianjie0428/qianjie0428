<template>
	<view
		style="display: flex;align-items: center;justify-content: space-between; height:80rpx;">
			
			
		<view class="flex">
			<view>
				<image src="/static/hot.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
			</view>	
			<view  class="margin-left-5 bold">
				{{title}}
			</view>
		</view>
		
	
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: 'CustomTitle',
		props: {
			title: {
				type: String,
				default: 'TITLE'
			},
			// 左边图标url。有值视为需要
			img: {
				type: String,
				default: '',
			}
		},
	}
</script>

<style>
</style>