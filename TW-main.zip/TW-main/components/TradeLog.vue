<template>
	<view
		style="height: 90vh; overflow-y:scroll;">
		<view class="flex flex-b" style="background-color: #252525;padding: 10px 20px ;margin-top: 5px;color: #ddd;">
			<view style="font-size: 12px;flex: 20%;">名稱/股票代碼</view>
			<view style="font-size: 12px;flex: 20%;">申購價/申請量</view>
			<view style="font-size: 12px;flex: 15%;">成交額</view>
			<view style="font-size: 12px;">狀態</view> 
		</view>
		
		<view v-for="(item,index) in list" :key="index" style="">
			<view class="flex flex-b" style="margin-top: 5px;color: #ddd;">
				<view style="flex: 15%;margin-left: 5%">
					<view>{{item.goods.name}}</view>
					<view style="font-size: 10px;">{{item.goods.code}}</view>
				</view>
				<view style="flex: 20%;text-align: center;">
					<view style="font-size: 10px;">{{item.price}}</view>
					<view style="font-size: 10px;">{{item.apply_amount}} 股</view>
				</view>
				<view style="flex: 20%;text-align: center;color: #d3c997;font-size: 14px;">{{item.total}}</view>
				<view style="flex: 5%;font-size: 10px;">{{transStatus(item.status)}}</view>
			</view>
			<view style="padding: 8px 0px;">
				<view style="border-top: 1px #444 solid;"></view>
			</view>
			<!-- <view class="display quantity">
				<view class="display">
					<view style="color: #ccc;">購買完成</view>
					<view style="color: #fff;">{{item.goods.name}}</view>
				</view>
				<view class="display">
					<view style="color: #ccc;">購買價格</view>
					<view style="color: #f3c997;">{{item.price}}</view>
				</view>
			</view>
			<view class="display quantity">
				<view class="display">
					<view style="color: #ccc;">購買數量</view>
					<view style="color: #fff;">{{item.apply_amount}}</view>
				</view>
				<view class="display">
					<view style="color: #ccc;">購買金額</view>
					<view style="color: #f3c997;">{{item.total}}</view>
				</view>
			</view> -->
			<!-- <view>
				<view class="display">
					<view class="">槓桿</view>
					<view class="" style="text-align: right;">X{{item.ganggan}}</view>
				</view>
			</view> -->
			<!-- <view class="display">
				<view style="color: #ccc;">訂單號</view>
				<view class="color-white" style="text-align: right;">{{item.order_sn}}</view>
			</view>

			<view class="display">
				<view style="color: #ccc;">購買時間</view>
				<view class="color-white" style="text-align: right;">{{item.created_at}}</view>
			</view> -->
			
		</view>
	</view>
</template>

<script>
	export default {
		name: 'TradeLog',
		props: ['url', 'height'],
		data() {
			return {
				list: [],
			};
		},
		mounted(option) {
			this.getList();
		},
		methods: {
			async getList(e) {
				let result = await this.$http.post(`api/GoodsScramble/userApplyLog`, {})
				this.list = result.data.data
			},
			transStatus(admin_status){
								if(admin_status==1){
									return '申請中'
								}else if (admin_status==5){
									
									return '申購成功'
								}else if (admin_status==0){
									
									return '申購失败'
								}
								
							},
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>