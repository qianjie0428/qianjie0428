<!-- 用户基本信息 -->
<template>
	<view class="wode_bg" style="padding: 10px 0px;border-radius: 10px;" >
		<view style="display: flex;align-items: center;padding:0rpx 40rpx;">
			<!-- <view style="flex:20%">
				<image style="width: 80px;border-radius: 100%;" mode="widthFix" src="/static/applogo.png"></image>
			</view>
			<view style="flex:80%;padding-left: 10px;">
				<view style="font-size: 20px;text-align: left;font-weight: 700;color: #333;">
					{{info.real_name}}
				</view>
				<view style="font-size: 12px;text-align: left;font-weight: 700;color: #999;">
					{{info.p_mobile}}
				</view>
			</view> -->
		</view>
		<view class="flex">
			<view class="" style="padding: 0px 15px;">
				<view>資產總值
					<image :src="`/static/${yan_show?'zhengyan':'biyan' }.png`" mode="aspectFit"
						:style="$util.setImageSize(30)" @click="toggleAmount()" style="padding-left: 20rpx;"></image>
				</view>
				<view class="bold" style="color:#000;font-size: 32rpx;margin-top: 5px;">
					{{yan_show? $util.formatNumber(info.money*1 + info.frozen*1):hideAmount  }}
				</view>
			</view>
			
		</view>
		<!-- <view class="padding-15">
			<view>可用資金
			</view>
			<view class="bold" style="color:#000;font-size: 32rpx;margin-top: 5px;">
				{{yan_show? $util.formatNumber(info.money):hideAmount  }}
			</view>
		</view> -->
		
		
		<view style="padding: 20px 15px;">
		<view class="flex" style="border-radius:10px;">
			
			<view class="flex-1" style="">
				<view>可用資金
				</view>
				<view class="bold" style="color:#000;font-size: 32rpx;margin-top: 5px;">
					{{yan_show? $util.formatNumber(info.money):hideAmount  }}
				</view>
				<!-- <view>庫存資金
				</view>
				<view class="bold" style="color:#000;font-size: 32rpx;margin-top: 5px;">
					{{yan_show? $util.formatNumber(info.frozen):hideAmount  }}
				</view> -->
			</view>

			<view style="">
				<!-- <view>總損益 </view>
				<view style="color:#000;font-size: 32rpx;margin-top: 5px;">{{yan_show? $util.formatNumber(info.holdYingli):hideAmount  }}
				</view> -->
				<view>庫存資金
				</view>
				<view class="bold" style="color:#000;font-size: 32rpx;margin-top: 5px;">
					{{yan_show? $util.formatNumber(info.frozen):hideAmount  }}
				</view>
			</view>
		</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {
				yan_show: true,
				hideAmount: '****',
			};
		},
		methods: {
			toggleAmount() {
				this.yan_show = !this.yan_show;
			}
		}
	}
</script>

<style>

</style>