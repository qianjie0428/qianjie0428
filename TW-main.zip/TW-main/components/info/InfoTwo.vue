<template>
	<view>
		<view style="padding:0 20px;display: flex;flex-wrap: wrap;">
			<block v-for="(item,index) in productInfo" :key="index">
				<view style="flex:0 0 50%;">
					<view style="line-height: 1.6;padding:0 20rpx;margin: 16rpx;">
						<view style="color:#999;">{{item.label}}</view>
						<view style="color:#121212;">{{item.value}}</view>
					</view>
				</view>
			</block>
		</view>

		<view class="about">
			<view class="flex flex-b">
				<view class="t">기업개요</view>
				<view class="t1" @click="txt_show=false">더보기</view>
			</view>

			<view class="txt" :class="txt_show?'show':''" style="white-space:pre-wrap;">
				{{top2.description}}

				<view class="t1" @click="txt_show=true">
					간략히
				</view>
			</view>
		</view>
		<view class="xs">
			<view class="flex flex-b tb">
				<view class="flex flex-b flex-1 tabs">
					<view :class="info_two_ac==0?'active':''" @click="qh_info_two(0)">분기매출</view>
					<view :class="info_two_ac==1?'active':''" @click="qh_info_two(1)">연간매출</view>
				</view>

				<template v-if="info_two_ac==0&&top3 && top3.length>0 &&top3[0].report_year_month">
					<!-- <view>{{ top3[0]}}</view> -->
					<view class="flex-1 t-r t">기준 {{top3[0].report_year_month}}</view>
				</template>
				<template v-if="info_two_ac==1&&top33 && top33.length>0 &&top33[0].report_year_month">
					<!-- <view>{{ top33[0]}}</view> -->
					<view class="flex-1 t-r t">기준 {{top33[0].report_year_month}}</view>
				</template>

				<!-- <view class="flex-1 t-r t" v-if="">기준 {{top33[0].report_year_month}}</view> -->
			</view>
			<view class="nums" v-if="info_two_ac==0&&top3 && top3.length>0 " style="background-color: transparent;">
				<!-- <view class="t">전분기대비</view> -->
				<view class="flex flex-b">
					<view class="item">
						<view class="t1">최근 매출액</view>
						<view class="t2" :class="top3[0].fields[29].value/100000000>0?'':'die'">
							{{$util.formatNumber(top3[0].fields[29].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[42].value*1>0?'':'die'">
							{{(top3[0].fields[42].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item">
						<view class="t1">최근 영업이익</view>
						<view class="t2" :class="top3[0].fields[32].value/100000000>0?'':'die'">
							{{$util.formatNumber(top3[0].fields[32].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[81].value*1>0?'':'die'">
							{{(top3[0].fields[81].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item">
						<view class="t1">최근 순이익</view>
						<view class="t2" :class="top3[0].fields[36].value/100000000>0?'':'die'">
							{{$util.formatNumber(top3[0].fields[36].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top3[0].fields[83].value*1>0?'':'die'">
							{{(top3[0].fields[83].value).toFixed(2)}}%
						</view>
					</view>
				</view>
			</view>
			<view class="nums" v-if="info_two_ac==1&&top33 && top33.length>0 " style="background-color: transparent;">
				<!-- <view class="t">전분기대비</view> -->
				<view class="flex flex-b">
					<view class="item">
						<view class="t1">최근 매출액</view>
						<view class="t2" :class="top33[0].fields[29].value/100000000>0?'':'die'">
							{{$util.formatNumber(top33[0].fields[29].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[43].value*1>0?'':'die'">
							{{(top33[0].fields[43].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item">
						<!-- <view class="t1">최근 영업이익</view> -->
						<view class="t2" :class="top33[0].fields[32].value/100000000>0?'':'die'">
							{{$util.formatNumber(top33[0].fields[32].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[82].value*1>0?'':'die'">
							{{(top33[0].fields[82].value).toFixed(2)}}%
						</view>
					</view>
					<view class="item">
						<view class="t1">최근 순이익</view>
						<view class="t2" :class="top33[0].fields[36].value/100000000>0?'':'die'">
							{{$util.formatNumber(top33[0].fields[36].value/100000000,0)}}억
						</view>
						<view class="t3" :class="top33[0].fields[84].value*1>0?'':'die'">
							{{(top33[0].fields[84].value).toFixed(2)}}%
						</view>
					</view>
				</view>
			</view>
			<view class="chart-box">
				<view class="flex flex-b tb">
					<view class="flex flex-b flex-1 tabs">
						<view :class="zhexian_index==0?'active':''" @click="zhexian_act(0)">매출액</view>
						<view :class="zhexian_index==1?'active':''" @click="zhexian_act(1)">영업이익</view>
						<view :class="zhexian_index==2?'active':''" @click="zhexian_act(2)">순이익</view>
					</view>
				</view>
				<view id="main" class="chart">
					<!-- 折线图 -->
					<canvas canvas-id="zhexian" id="zhexian" class="charts" />
				</view>
			</view>
			<view>
				<view>
					<view class="flex flex-b top">
						<view class="t" style="color:#121212">투자자별 매매동향</view>
						<template v-if="top4!=''">
							<view class="t1">기준 {{top4.net_volume.dt}}</view>
						</template>
					</view>
					<view class="border pdd">
						<view class="t2">순매수량</view>
						<view style="display: flex;align-items: center;margin-top: 20rpx;">
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">개인</view>
								<view style="text-align: center;"
									:style="{color:top4.net_volume.net_vol_individual>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.net_volume.net_vol_individual)}}
								</view>
							</view>
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">기관</view>
								<view style="text-align: center;"
									:style="{color:top4.net_volume.net_vol_institutional>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.net_volume.net_vol_institutional)}}
								</view>
							</view>
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">외인</view>
								<view style="text-align: center;"
									:style="{color:top4.net_volume.net_vol_foreigner>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.net_volume.net_vol_foreigner)}}
								</view>
							</view>
						</view>
					</view>
					<view class="pdd">
						<view>누적순매수량</view>
						<view style="display: flex;align-items: center;margin-top: 20rpx;">
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">개인</view>
								<view style="text-align: center;"
									:style="{color:top4.cum_volume.cum_vol_individual>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.cum_volume.cum_vol_individual)}}
								</view>
							</view>
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">기관</view>
								<view style="text-align: center;"
									:style="{color:top4.cum_volume.cum_vol_institutional>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.cum_volume.cum_vol_institutional)}}
								</view>
							</view>
							<view style="flex:0 0 33.33%">
								<view style="text-align: center;">외인</view>
								<view style="text-align: center;"
									:style="{color:top4.cum_volume.cum_vol_foreigner>0?'#ff3636':'#18BFB4'}">
									{{$util.formatNumber(top4.cum_volume.cum_vol_foreigner)}}
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="list">

					<view class="mb20">
						<view class="flex flex-b titles">
							<view class="flex-1">날짜</view>
							<view class="flex-1 t-c">개인</view>
							<view class="flex-1 t-c">기관</view>
							<view class="flex-1 t-r">외인</view>
						</view>
						<view class="flex flex-b item" v-for="(item,index) in top5">
							<view class="flex-1 time" style="font-size: 24rpx;">{{item.dt?item.dt:''}}</view>
							<view class="flex-1 t-c red num-font" :class="item.net_vol_individual>0?'':'die'">
								{{$util.formatNumber(item.net_vol_individual)}}
							</view>
							<view class="flex-1 t-c red num-font" :class="item.net_vol_institutional>0?'':'die'">
								{{$util.formatNumber(item.net_vol_institutional)}}
							</view>
							<view class="flex-1 t-r red num-font" :class="item.net_vol_foreigner>0?'':'die'">
								{{$util.formatNumber(item.net_vol_foreigner)}}
							</view>
						</view>

					</view>


				</view>

				<view class="list mborder">
					<!-- <view class="flex flex-b tb">
						<view class="flex flex-b flex-1 tabs">
							<view class="active">자산비율</view>
							<view class="">매출구성</view>
						</view>
						<view class="flex-1"></view>
					</view> -->
					<view class="flex flex-b">
						<canvas canvas-id="huan1" id="huan1" class="charts" />
					</view>
				</view>
			</view>
			<view>
				<view class="top">
					<view class="t" style="margin-bottom: 16px;">공매도 거래량</view>
					<view class="flex flex-b" style="line-height: 1.6;">
						<view class="item">
							<view>
								<view class="t1" style="font-weight: 100;">공매도 거래량</view>
								<view class="t2">전체 거래량 대비</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view class="t3 num-font">{{top7[0].short_volume}}주</view>
								<view class="t4">{{top7[0].short_volume_weight}}%</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view class="t2">기준</view>
								<view class="t4" style="text-align: right;">{{top7[0].dt}}</view>
							</view>
						</view>
						<view class="item">
							<view>
								<view class="t1" style="font-weight: 100;">공매도 잔고</view>
								<view class="t2">시가총액 대비</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view class="t3 num-font">{{top7[1].short_volume}}주</view>
								<view class="t4">{{top7[1].short_volume_weight}}%</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view class="t2">기준</view>
								<view class="t4" style="text-align: right;">{{top7[1].dt}}</view>
							</view>
						</view>
					</view>
				</view>

			</view>
			<view data-v-3c1e211d="">
				<view data-v-3c1e211d="" class="flex flex-b top">
					<view data-v-3c1e211d="" class="t">업종 내 비교</view>
					<view data-v-3c1e211d="" class="t1">자동차부품 {{top8.count}} 개
						중</view>
				</view>
				<view data-v-3c1e211d="">
					<view data-v-3c1e211d="" class="title flex flex-b">
						<view data-v-3c1e211d="" class="flex-1"></view>
						<view data-v-3c1e211d="" class="flex-1 t-c">현 종목</view>
						<view data-v-3c1e211d="" class="flex-1 t-c">업종평균</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">업종 내
							순위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">평가금액</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red num-font" :class="top8.marketcap>0?'':'die'">
							{{top8.marketcap}}억
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red num-font" :class="top8.marketcap_avg>0?'':'die'">
							{{top8.marketcap_avg}} 억
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.marketcap_rank}}위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">순이익
							증가율</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.net_income_growth>0?'':'die'">
							{{top8.net_income_growth}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.net_income_growth_avg>0?'':'die'">
							{{top8.net_income_growth_avg}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.net_income_growth_rank}}위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">부채비율</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.debt_ratio>0?'':'die'">
							{{top8.debt_ratio}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.debt_ratio_avg>0?'':'die'">
							{{top8.debt_ratio_avg}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.debt_ratio_rank}}위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">PER</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.per>0?'':'die'">{{top8.per}}배
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.per_avg>0?'':'die'">
							{{top8.per_avg}}배
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.per_rank}}위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">PBR</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.pbr>0?'':'die'">{{top8.pbr}}배
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.pbr_avg>0?'':'die'">
							{{top8.pbr_avg}}배
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.pbr_rank}}위</view>
					</view>
					<view data-v-3c1e211d="" class="item flex flex-b">
						<view data-v-3c1e211d="" class="flex-1">ROE</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.roe>0?'':'die'">{{top8.roe}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-c red" :class="top8.roe_avg>0?'':'die'">
							{{top8.roe_avg}}%
						</view>
						<view data-v-3c1e211d="" class="flex-1 t-r">{{top8.roe_rank}}위</view>
					</view>
				</view>
			</view>
		</view>
	</view>

</template>

<script>
	import zhexian from '@/common/zhexian.js';
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: 'InfoTwo',
		components: {
			zhexian
		},
		props: ['code', 'productDetails'],
		data() {
			return {
				infoData: {},

				cWidth: 750,
				cHeight: 500,
				top1: {
					sharesout: 0,
					year_high: 0,
					marketcap: 0,
					foreigners_pie: 0,
					year_low: 0
				},
				top2: {},
				top3: [],
				top33: [],
				top4: {},
				top5: [],
				top7: [],
				top8: {},
				txt_show: true,
				info_two_ac: 0,
				zhexian_index: 0,
				zhexian_index_i: 29
			}
		},
		computed: {
			productInfo() {
				return [{
					label: '기업순위',
					value: `코스닥 ${this.infoData.marketcap_rank} 위`
				}, {
					label: '주식수',
					value: `${this.$util.formatNumber(this.infoData.sharesout)} 주`
				}, {
					label: '산업군',
					value: `${this.$util.formatNumber(this.infoData.sector)}`
				}, {
					label: '52주 최고',
					value: `${this.$util.formatNumber(this.infoData.year_high)}`
				}, {
					label: '평가금액',
					value: `${this.$util.formatNumber(this.infoData.marketcap)} 억`
				}, {
					label: '외국인비중',
					value: `${this.$util.formatNumber(this.infoData.foreigners_pie)}%`
				}, {
					label: '세부산업군',
					value: `${this.$util.formatNumber(this.infoData.industry)}`
				}, {
					label: '52주 최저',
					value: `${this.$util.formatNumber(this.infoData.year_low)}`
				}];
			}
		},
		methods: {
			qh_info_two(index) {
				this.info_two_ac = index;
				if (index == 0) {
					this.info_two()
				} else {
					this.info_two1()
				}
			},

			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "ring",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					fontSize: 13,
					fontColor: "#666666",
					dataLabel: true,
					dataPointShape: true,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: true,
						position: "bottom",
						lineHeight: 25,
						float: "left",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					// title: {
					//   name: "2,515억",
					//   fontSize: 15,
					//   color: "#666666",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					// subtitle: {
					//   name: "자산총계",
					//   fontSize: 25,
					//   color: "#7cb5ec",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					extra: {
						ring: {
							ringWidth: 30,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF",
							centerColor: "#FFFFFF",
							customRadius: 0,
							linearType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						}
					}
				});
			},
			async info_two() {
				uni.showLoading({
					mask: true
				})
				let list = await this.$http.post('api/product/info_two', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				uni.hideLoading()

				this.infoData = list.data.data[0].top1;
				this.top2 = list.data.data[0].top2
				this.top3 = list.data.data[0].top3
				this.top4 = list.data.data[0].top4
				this.top5 = list.data.data[0].top5
				this.top7 = list.data.data[0].top7
				this.top8 = list.data.data[0].top8

				this.zhexian()
				let res = {
					series: [{
						data: list.data.data[0].top6
					}]
				};
				this.drawCharts('huan1', res);

			},
			zhexian_act(index) {
				this.zhexian_index = index;

				if (index == 0) {
					this.zhexian_index_i = 29
				} else if (index == 1) {
					this.zhexian_index_i = 32
				} else if (index == 2) {
					this.zhexian_index_i = 36
				}

				this.zhexian()
			},
			zhexian() {
				// const zhexian_index_i = this.zhexian_index_i;
				let temp_top = [];

				if (this.info_two_ac == 0) {
					temp_top = this.top3;
				} else {
					temp_top = this.top33;
				}

				let res = {
					categories: temp_top.map(item => item.report_year_month),
					series: [{
						name: "",
						data: temp_top.map(item => item.fields[this.zhexian_index_i].value / 100000000),
					}]
				};
				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(zhexian.Charts(ctx, res, this.cWidth, this.cHeight))

			},
			async info_two1() {
				let list = await this.$http.post('api/product/info_two1', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				this.top33 = list.data.data[0].top3
				this.zhexian_act(0)
			},
		},

		mounted() {
			this.info_two()
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(750);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);

			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接

		},

		onLoad() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>
<style scoped>
	.charts {
		width: 750rpx;
		height: 500rpx;
	}
</style>
<style lang="scss">
	.info {
		padding: 0 16px 16px;

		uni-view {
			color: #666;
			line-height: 32px;
		}

		.t {
			color: #333;
		}

		.red {
			color: red;
		}

		.blue {
			color: #18BFB4;
		}
	}

	.about {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;
		padding: 16px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			color: #999;
		}

		.txt {
			margin-top: 16px;
			color: #333;
			line-height: 26px;
		}

		.txt.show {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
		}
	}

	.xs {
		padding: 16px 0;

		.tb {
			padding: 0 16px 10px;
		}

		.tabs {
			background: #f1f2f4;
			border-radius: 5px;
			height: 32px;
			padding: 0 5px;

			.t {
				font-size: 12px;
				color: #999;
			}

			.active {
				color: #18BFB4;
				background: #fff;
				border-radius: 3px;
			}

			uni-view {
				color: #121212;
				height: 26px;
				line-height: 26px;
				text-align: center;
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
			}
		}

		.nums {
			background: #FAFAFA;
			border-radius: 10px;
			padding: 5px;
			margin: 0 5px;
			text-align: center;

			.t {
				padding: 10px 0;
			}

			.item {
				background: #fff;
				border-radius: 8px;
				padding: 16px 0;
				width: 32%;

				.t1 {
					color: #121212;
				}

				.t2 {
					font-size: 21px;
					font-family: Roboto;
					font-weight: 700;
					color: #ff3636;
					margin: 10px 0;
				}

				.t3 {
					font-size: 19px;
					font-family: Roboto;
					font-weight: 400;
					color: #ff3636;
				}

				.die {
					color: #18BFB4;
				}
			}
		}

		.chart-box {
			padding: 16px 5px 10px;
			border-top: 5px solid #f0f2f5;
			border-bottom: 5px solid #f0f2f5;
			margin-top: 16px;
		}
	}

	.top {
		padding: 16px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			font-size: 12px;
			color: #999;
		}

		.item {
			background: #f1f2f4;
			border-radius: 10px;
			width: 42%;
			padding: 16px 10px;

			.t1 {
				font-size: 17px;
				font-weight: 700;
				color: #333;
			}

			.t2 {
				color: #999;
			}

			.t3 {
				font-size: 17px;
				font-weight: 700;
				color: #18BFB4;
				margin-right: 5px;
			}

			.t4 {
				color: #333;
			}

			.mtb {
				margin: 16px 0;
			}
		}
	}

	.cot {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;

		.tb {
			padding: 16px 16px 0;
		}
	}

	.border {
		border-bottom: 1px solid #dcdee0;
	}

	.pdd {
		padding: 16px 10px;

		.t2 {
			color: #333;
			font-size: 17px;
		}
	}

	.last {
		padding: 16px 0 0;

		uni-view {
			color: #333;
		}

		.die {
			color: #18BFB4;
		}

		span {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}
	}

	.list {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;
		padding: 16px 0;

		.tb {
			padding: 0 16px 16px;
		}

		.tabs {
			background: #f1f2f4;
			border-radius: 5px;
			height: 32px;
			padding: 0 5px;

			.active {
				color: #18BFB4;
				background: #fff;
				border-radius: 3px;
			}
		}

		.mb20 {
			margin-bottom: 10px;
		}

		.titles {
			padding: 10px;
			background: #f0f2f5;
		}

		.item {
			padding: 10px;

			.time {
				color: #333;
			}

			.red.die {
				color: #18BFB4;
			}

			.red {
				font-family: Roboto;
				font-weight: 700;
				color: #f72121;
			}
		}
	}

	.title {
		background: #f0f2f5;
		padding: 10px;
	}

	.item {
		padding: 10px;

		.red {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}

		uni-view {
			color: #333;
		}

		.red.die {
			color: #18BFB4;
		}
	}
</style>