<template>
	<view class="list" style="margin-top: 20px;">
		<view class="item flex flex-b" v-for="(item,index) in news" @click="open(item.link)">
			<!-- <view class="img">
				<image :src="item.image"></image>
			</view> -->
			<view class="flex-2">
				<view class="t el" style="color:#ccc">{{item.title}}</view>
				<view class="t1" style="text-align: right;">{{ $util.formatDate(item.publishAt * 1000, 'YYYY-MM-DD') }}

</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'InfoThree',
		components: {},
		props: ['code', 'productDetails'],
		data() {
			return {
				news: []
			}
		},
		mounted() {
			this.news_list()
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async news_list() {
				let list = await this.$http.post('api/product/news', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				this.news = list.data.data[0]
			},
		},
	}
</script>

<style lang="scss">
	.tab {
		padding: 0 10px 15px;

		.tab-item {
			background: #f1f2f4;
			border-radius: 5px;
			color: #999;
			height: 30px;
			line-height: 30px;
			text-align: center;
			width: 20%;
			margin-right: 10px;

		}
	}

	.tab-item.active {
		background: #e7f1f9;
		color: #014b8d;
	}

	.list {
		padding: 0 10px;

		.item {
			margin-bottom: 15px;

			.img {
				width: 120px;
				height: 80px;
				margin-right: 10px;
				border-radius: 5px;

				uni-image {
					width: 100%;
					height: 100%;
					border-radius: 5px;
				}
			}

			.t {
				color: #333;
			}

			.t1 {
				color: #999;
				margin-top: 10px;
			}
		}
	}

	.el {
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-box-orient: vertical;
		-webkit-line-clamp: 2;
	}
</style>