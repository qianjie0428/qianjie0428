<template>
	<view style="padding: 0px 5px;">
	<view class="btns_wrapper" >
		<view v-for="(item,index) in btns" :key="index" class="item" :style="{flex:`${col}%`}">
			<view @click="actionEvent(item.url,index,item.name)" class="icon margin-top-30">
				<image mode="aspectFit" :src="`/static/top${index+1}.png`" :style="$util.calcImageSize(55)"></image>
			</view>
			<text class="btn_name font-size-15" :style="{color:current==index?'#E4DFD7':'#E4DFD7'}">{{item.name}}</text>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns','col'],
		data() {
			return {
				current: -1
			};
		},
		methods: {
			actionEvent(url, index, name) {
				this.current = index;
				if(url.includes("/pages/service/service")){
					// uni.$u.toast('고객 서비스 매니저에 연락해주세요.');
					this.$util.linkCustomerService()
					return 
				}else if (url.includes('pages')) {
					uni.navigateTo({
						url: `${url}?tag=${name}`,
						fail() {
							uni.switchTab({
								url:`${url}?tag=${name}`
							})
						}
					})
					
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>