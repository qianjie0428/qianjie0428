<template>
	<view>
		<!-- <view
			style="border-radius:16rpx 0 7px 0px;padding:4px 10px;width: 70px;text-align: center;font-size: 13px;color: #fff;background-color: #38AA9A;">
			{{$lang.ALL_MSG}}
		</view> -->

		<EmptyData v-if="list.length<=0"></EmptyData>

		<block v-for="(item,index) in list" :key="index">
			<view style="padding: 5px 8px;">
			<view style="padding: 12rpx 10rpx;display: flex;align-items: center;border-radius: 10px;"
				
				@click="$u.route('/pages/productDetails/productDetails',{code:item.code});">

				<view style="flex: 6%;padding:10rpx 0;">
					
						<view :style="$util.setImageSize(60)"
							style="background-color:#18BFB4;text-align: center;line-height: 60rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;">
							{{item.name.slice(0,1)}}
						</view>
					
				</view>

				<view style="flex: 44%;padding-left: 10rpx;">
					<view class="color-white">{{item.name}}</view>
					<view style="font-size: 24rpx;color: #ccc;">{{item.code}}</view>
				</view>

				<view style="flex:30%;font-size: 16px;":style="{color:`${item.rate>0?'#e5b682':'#ff3636'}`}">
					{{$util.formatNumber(item.current_price*1)}}
				</view>

				<view style="flex:20%;" :style="{color:`${item.returns>0?'#e5b682':'#ff3636'}`}">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<image mode="aspectFit" :src="`/static/${item.rate>0?'up':'down'}.png`"
							:style="$util.setImageSize(20)"></image>
						<view>{{(1*item.rate).toFixed(2)}}%</view>
					</view>
				</view>

			</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		props: ['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>