<!-- header区域 -->
<template>
	<view style="display: flex;align-items: center;border-bottom: 1px solid #f1f1f1;padding:0 10px 6px 10px;">
		<view style="flex: 20%;">
			<image style="width: 24px; height: 24px;" mode="aspectFit" :src="`/static/${icon}.png`"></image>
		</view>
		<text
			style="display: block;color: #18BFB4;font-size: 38rpx;padding:0 10px;flex:50%;text-align: center;">{{title}}</text>
		<text @click="actionEvent()"
			style="display: block;color: #ffffff;font-size: 14px;padding:4px 10px;flex:20%;text-align: center;background-color:#18BFB4;border-radius: 16rpx;">거래내역</text>
	</view>
</template>

<script>
	export default {
		name: "TradeHeader",
		props: ["title", "icon"],
		data() {
			return {

			};
		},
		methods: {
			actionEvent() {
				this.$emit('action', '');
			}
		}
	}
</script>

<style>

</style>