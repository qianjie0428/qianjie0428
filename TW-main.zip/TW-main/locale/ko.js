// 底部导航组
const TABBAR = {
	TABBAR_HOME: "首頁",
	  TABBAR_FOLLOW: "最喜歡的專案",
	  TABBAR_MARKET: '最新消息',
	  TABBAR_TRADE: '交易',
	  TABBAR_ACCOUNT: '更多',
};

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "登入",
	  SIGN_UP: "註冊",
	  SIMGN_OUT: "登出",
	  GO_TO_SIGN_IN: '登入頁面',
	  USER_NAME: '電話號碼',
	  ENTER_USER_NAME:'請輸入您的電話號碼',
	  PASSWORD:'密碼',
	  ENTER_PASSWORD: '輸入您的密碼',
	  VERIFY_PASSWORD: '重新輸入密碼',
	  ENTER_VERIFY_PASSWORD: '重新輸入密碼',
	  INVITATION_CODE: '邀請專案代碼',
	  ENTER_INVITATION_CODE: '輸入邀請項目代碼',
	  TIP_PWD_NOEQUAL: '兩個密碼不符',
	  TIP_SUCCESS_SIGNIN: '登入完成',
	  TIP_SUCCESS_REGISTER: '註冊已完成。請登入',
	  TIP_SIGNIN_ING: '正在登入',
	  TIP_SIGNUP_ING: '正在註冊',
	  TIP_REMEMBER_PWD: '保持登入狀態',
	  API_TOKEN_EXPIRES: '登入狀態無效。請重新登入',
	  TIP_SIGN_OUT_SUCCESS: '註銷完成',
	  TIP_AGREE: '閱讀協議',
	  TIP_PRVITE_PACT:'隱私權協議',
	  TIP_CHECK_AGREE: '勾選此方塊即表示同意使用者隱私協定',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
		TIP_OLD_PWD:'請輸入您的舊密碼',
	  TIP_NEW_PWD:'請輸入新密碼',
	  TIP_NEW_PWD_VERIFY: '請重新輸入新密碼',
	  // 个人信息修改页面
	  PAGE_TITLE_AVATAR: '設定',
	  AVATAR_TIP_NICK_NAME: '請輸入您的姓名',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: '全名',
	  TIP_REAL_NAME: '請輸入姓名',
	  BANK_NAME: '銀行名稱',
	  TIP_BANK_NAME: '輸入或選擇開戶銀行',
	  BANK_CARD: '電話號碼',
	  TIP_BANK_CARD: '請輸入您的銀行卡號碼',
	  BTN_CHANGE_BANK_CARD: '確認',
	  BTN_BANK_SELECTED: '選擇銀行',
};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: '撤回',
	  WITHDRAW_AMOUNT: '我的資產',
	  WITHDRAW_TITLE: "提取資金",
	  TIP_AMOUNT_AVAIL:'可用',
	  WITHDRAW_WITH_AMOUNT: '提幣金額',
	  TIP_AMOUNT_WITHDRAW: '輸入提款金額',
	  WITHDRAW_PAY_PWD: '提幣密碼',
	  TIP_WITHDRAW_PWD: '電話號碼密碼',
	  WITHDRAWING_POST_TIP: '處理....',
	  // 提款說明
	  WITHDRAW_TIP_TEXT: [  
	      "1. 在出售目前持有的股票之前不能提取。为了提款，您需要在提款前验证您的真实姓名并验证您的账户。",  
	      "3. 提款交易可用时间：平日上午 09:00 至下午 15:00（周末和公众假期不可提款）。",  
	      "4. 请求提款时，最低金额为 10,000 韩元。",  
	      "5. 申请提现后，原则上当日存入指定提款账户。※ 付款将在最多 2 个工作天（48 小时）内完成。"  
	      // 注意：我移除了重复的条目，并合并了最后两条相似的信息  
	  ]
	  // WITHDRAW_TIP_TEXT:[`1. 在出售目前持有的股票之前不能提取。為了提款，您需要在提款前驗證您的真實姓名並驗證您的帳戶。`、`3.提款交易可用時間:平日上午 09:00 至下午 15:00（週末和公眾假期不可提款）`、`4.請求提款時，最低金額為 10,000 韓元。`、`5。申請提現後，原則上當日存入指定提款帳戶。 `、`※ 付款將在最多 2 個工作天（48 小時）內完成。`、`5。申請提現後，原則上當日存入指定提款帳戶。 `、`※ 付款將在最多 2 個工作天（48 小時）內完成。`
	  // ],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '存款',
	  DEPOSIT_TIP_DEPOSIT_AMOUNT: '輸入儲值金額',
	  DEPOSIT_TIP_LOW_AMOUNT: '最低儲值1000000',
	  DEPOSIT_POST_TIP: '處理......',
	  DEPOSIT_TIP_TITLE: '友情提示',
	  DEPOSIT_TIP_TEXT: '一、儲值時間:平日09:00~18:00，假日休息。感謝您選擇我們。為了確保您的資金安全，請確保您要轉帳的帳戶是我們平台上即時顯示的帳戶，每次您從非銀行帳戶轉帳時，請與我們的工作人員核實。應對因存款而產生的任何損失負責。',
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['已驗證[未驗證]', '已驗證[審核中]', '已驗證[審核失敗]'],
	  ACCOUNT_CHANGE_PWD: '更改登入密碼',
	  ACCOUNT_CHANGE_PAY_PWD: '更改交易密碼',
	  ACCOUNT_CARD_MANAGEMENT: '銀行帳戶關聯',
	  ACCOUNT_TRADE_LOG: '帳戶詳細資料',
	  ACCOUNT_SERVICE: '客戶服務',
	  ACCOUNT_AMOUNT_TOTAL: '總資產',
	  ACCOUNT_AMOUNT_AVAILABLE: '可用資金',
	  ACCOUNT_MORE_FEATURES: '更多功能',
	  ACCOUNT_COLD_AMOUNT: '資金凍結',
	  ACCOUNT_REPAY: '返回',
	  ACCOUNT_TOTAL_PROFIT: '總利潤'
};

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: '實名認證',
	  AUTH_TIP_ID_CARD: '請輸入正確的住戶登記號碼',
	  AUTH_TIP_CARD_F: '點選前面新增',
	  AUTH_TIP_CARD_B: '我是透過點擊背面添加的',
	  AUTH_ID_CARD: '居民登記卡',
	  AUTH_CARD_F: '居民登記卡正面',
	  AUTH_CARD_B: '居民登記卡背面',
	  AUTH_TIP_TEXT: '※如果您不是用戶，您在使用該服務時可能會處於不利地位。',
	// 认证结果
	AUTH_RESULT_PASS:'認證通過',
	  AUTH_RESULT_REVIEW:'等待審核',
	  AUTH_RESULT_REPOST:'請求重新考慮',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_TRADE: '儲值/提現交易',
	  TRADE_LOG_DEPOSIT: '存款詳情',
	  TRADE_LOG_WITHDRAW: '提款詳情',
	  TRADE_LOG_TIP_MODAL_TITLE: '您想取消提款請求嗎？',
	  TRADE_LOG_WITHDRAW_STATUS: ['審核中', '提現成功', '失敗', '已取消'],
	  LOG_TRADE_AMOUNT_AFTER: '餘額',
	  LOG_TRADE_AMOUNT_BEFORE: '交易前餘額',
	  LOG_TRADE_DW: '存款',
	  LOG_TRADE_CREATE_TIME: '日期時間',
	  LOG_TRADE_DESC: '規格',
	  LOG_TRADE_ORDER_SN: '訂單號碼',
	  LOG_TRADE_DW_DESC: '拒絕原因',
	  LOG_WITHDRAW_AMOUNT: '提款',
	  LOG_STATUS: '狀態',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TITLE:'投資結果',
	  TRADE_HOLD_LOG: '日誌',
	  TRADE_SELL_LOG: '銷售業績',
	  TRADE_TOTAL_BUY_AMOUNT: '總購買量',
	  TRADE_VALUATION_GAIN_LOSS: '估價收益/損失',
	  TRADE_VALUATION_GAIN_LOSS_AMOUNT: '總利潤',
	  TRADE_RATE_RESPONSE: '費率',
	  TRADE_TOTAL_GAIN: '總利潤',
	// 持仓数据明文
	TRADE_HOLD_LABEL_1ST: '股票名稱',
	  TRADE_HOLD_LABEL_2ND:'損益',
	  TRADE_HOLD_LABEL_3RD: '持有數量',
	  TRADE_HOLD_LABEL_4TH: '評估金額',
	  TRADE_HOLD_LABEL_5TH: '賣出價',
	  TRADE_HOLD_LABEL_6TH: '目前價格',
	  TRADE_HOLD_LABEL_7TH: '最新價格',
	// 卖出数据明文
	TRADE_SELL_LABEL_1ST: '股票名稱',
	  TRADE_SELL_LABEL_2ND: '估值獲利/虧損',
	  TRADE_SELL_LABEL_3RD: '持有數量',
	  TRADE_SELL_LABEL_4TH: '評估金額',
	  TRADE_SELL_LABEL_5TH: '賣出價',
	  TRADE_SELL_LABEL_6TH: '當前價格',
	  TRADE_SELL_LABEL_7TH: '最新價格',
	
	// 持仓与销售弹层数据明文
	TRADE_MODAL_BUY_TIME:'購買時間',
	  TRADE_MODAL_SELL_TIME:'賣出時間',
	  TRADE_MODAL_FLOAT_PROFIT:'當前損益',
	  TRADE_MODAL_PROFIT:'損益總額',
	  TRADE_MODAL_BUY_PRICE:'買入價',
	  TRADE_MODAL_BUY_QTY:'數量',
	  TRADE_MODAL_LEVER:'槓桿',
	  TRADE_MODAL_FEE:'費用',
	  TRADE_MODAL_BUY_AMOUNT:'總購買金額',
	  TRADE_MODAL_STOCK_CODE:'代碼',

	// 卖出的二次确认
	SELL_TIP: '您想確認銷售嗎？',
};

// AI交易
const TRADE_AI = {
	PAGE_TITLE_TRADE_AI: '人工智慧交易',
	  TRADE_AI_TABS: ['人工智慧交易', '交易歷史'],
	  TRADE_AI_AMOUNT: 'AI投資金額',
	  TRADE_AI_AMOUNT_TOTAL: 'AI總資產',
	  TRADE_AI_TRANSFER: ['申請', '提現'],
	  TRADE_AI_PROFIT: '人工智慧利潤',
	  TRADE_AI_LOG: ['待處理', '透過', '拒絕'],
	  TRADE_AI_CYCLE_TITLE: '選擇一個時期',
	  TRADE_AI_TRADE_VOL: '交易量',
	  TRADE_AI_BALANCE: '餘額',
	  TRADE_AI_TYPE: '交易類型',
	  TRADE_AI_CYCLE_DAY: '週期',
	  TRADE_AI_DEPOSIT_BTN: '存款',
	  TRADE_AI_ORDER_TABS: ['持有物品', '交易歷史'],
	  TRADE_AI_LIST_THEAD: ['股票名稱', '評估盈虧', '利潤率', '買入數量', '評估金額', '平均單價', '賣出價格'],
}

// 日内交易
const TRADE_DAY = {
	PAGE_TITLE_TRADE_DAY: '短期快速上漲的股票',
	  TRADE_DAY_TABS: ['點選股票', '申請狀態', '記錄'],
	  TRADE_DAY_BUY: '申請',
	  TRADE_DAY_TIP:'指南',
	  TRADE_DAY_TIP_TEXT: [  
	      '這是短期快速上漲股票的投資者當日買賣股票並根據交易利潤結算交易的交易技巧。',  
	      '投資者統一交易、結算股票價格。',  
	      '如果買入後出現獲利，會立即顯示在「日內交易股票」中，您可以選擇賣出獲利。',  
	      '為了保護快速上漲股票的利潤和保密性，購買期間不提供股票代碼和詳細信息。'  
	  ],
	  TRADE_DAY_BUY_AMOUNT: '金額',
	  TRADE_DAY_SUCCESS_AMOUNT: '已核准的金額',
	  TRADE_DAY_BUY_PRICE: '購買金額',
	  TRADE_DAY_ORDER_SN: '訂單編號',
	  TRADE_DAY_CREATE_TIME: '日期時間',
	  TRADE_DAY_ORDER_STATUS: '訂單狀態',
	  TRADE_DAY_MODAL_CONTENT: '您想提交訂單嗎？',
	  TRADE_DAY_TIP_INPUT_AMOUNT: '輸入金額',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '大宗交易',
	  TRADE_LARGE_TABS: ['商品清單', '交易記錄', ],
	  TRADE_LARGE_TAB1_TITLES: ['購買歷史', '分配數量'],
	  TRADE_LARGE_PRICE: '價格',
	  TRADE_LARGE_RATE: '成長率',
	  TEADE_LARGE_RATE_AMOUNT: '增量金額',
	  TRADE_LARGE_MIN_QTY: '最小購買數量',
	  TRADE_LARGE_MAX_QTY: '最大購買金額',
	  TRADE_LARGE_MIN_DAY: '最短持有天數',
	  TRADE_LARGE_ITEM_LABELS: ['價格', '成長率'],
	  TRADE_LARGE_ORDER_TITLE: '訂閱申請訂單',
	  TRADE_LARGE_BUY_AMOUNT: '買價',
	  TRADE_LARGE_TIP_BUY_COUNT: '輸入購買數量',
	  TRADE_LARGE_ORDER_AMOUNT: '購買金額',
	  TRADE_LARGE_TIP_BUY_PWD: '請輸入您的6位交易密碼',
	  TRADE_LARGE_LOG_FINISH: '購買完成',
	  TRADE_LARGE_LOG_PRICE: '購買價格',
	  TRADE_LARGE_LOG_NUM: '購買數量',
	  TRADE_LARGE_LOG_AMOUNT: '購買金額',
	  TRADE_LARGE_LOG_LEVER: '槓桿',
	  TRADE_LARGE_LOG_CREATE_TIME: '購買時間',
	  TRADE_LARGE_BUY_TOTAL_AMOUNT: '總購買金額',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO:'首次公開發行',
	  TRADE_IPO_TABS: ['產品清單','交易記錄','申購成功'],
	  TRADE_IPO_MODAL_TITLE: '公開發行申請',
	  TRADE_IPO_MODAL_CONTENT: '如果要申請認購請點選確定',
	  TADE_IPO_SUB_PRICE: '認購價格',
	  TRADE_IPO_PE_RATE: '本益比',
	  TRADE_IPO_SUB_CT: '申購時間',
	  TRADE_IPO_POST_QTY: '流通量',
	  TRADE_IPO_RAISE_MONEY: '籌集資金',
	  TRADE_IPO_LOG_LABELS: ['申購時間','申購價','市盈率','流通量'],
	  TRADE_IPO_SUCCESS_TITLE: 'IPO申購成功記錄',
	  TRADE_IPO_SUCCESS_APPLY_AMOUNT: '機構發行數量',
	  TRADE_IPO_SUCCESS_AMOUNT: '分配數量',
	  TRADE_IPO_SUCCESS_NUM_AMOUNT: 'IPO 金額',
	  TRADE_IPO_SUCCESS_ORDER_SN: '交易代碼',
	  TRADE_IPO_SUCCESS_CT: '交易日期',
	  TRADE_IPO_SUB: '訂閱',
	  TRADE_IPO_PUBLIC_PRICE: 'IPO 價格',
}

// 股权 交易
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: '股票交易',
	  TRADE_EQUITY_SURPLUS: '剩餘',
	  TRADE_EQUITY_PRICE: '申請價格',
	  TRADE_EQUITY_QTY: '申請數量',
	  TRADE_EQUITY_TOTAL: '申請總金額',
	  TRADE_EQUITY_SUCCESS_QTY: '成功數量',
	  TRADE_EQUITY_SUCCESS_TOTAL: '成功總數',
	  TRADE_EQUITY_SUB_AMOUNT: '認購金額',
	  TRADE_EQUITY_DEF_AMOUNT: '欠款金額',
	  TRADE_EQUITY_DEF_BTN: '贖回',
	  TRADE_EQUITY_DEF_AMOUNT_TIP: '輸入未償還金額',
	  TRADE_EQUITY_DEF_BTN_ALL:'全部',
};


// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '庫存詳情',
	// 股票最新数值
	STOCK_INFO_TITLES: ['市價', '前一日收盤價', '昂貴', '低價', '交易量', '交易金額'],
	// 股票详情 一级TABS
	STOCK_OVERVIEW_TABS: ['圖表', '庫存分析', '訊息'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['分', '天', '週', '月'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: '數量',
	  STOCK_BUY_TIP_QUANTITY: '請輸入數量',
	  STOCK_BUY_AMOUNT: '付款金額',
	  STOCK_BUY_FEE: '費用',
	  STOCK_BUY_CONFIRM: '確認購買',
	// 单股概览 概览信息
	STOCK_BASE_INFO: ['公司排名', '評估金額', '股數', '外資比例', '行業分組', '詳細行業分組', '52週最高價', '52週最低價'],
	  STOCK_KOSDAQ: '科斯達克', // '科斯达克', 
	// 概览 
	STOCK_COMPANY: '公司概況',
	  STOCK_SALES: '銷售',
	  STOCK_SALES_TABS:['季度銷售額','年度銷售'],
	// 销售额三块数据
	STOCK_SALES_LAST_SALES_AMOUNT: '最後銷售金額',
	  STOCK_SALES_LAST_SALES_PROFIT: '最後營業利潤',
	  STOCK_SALES_LAST_SALES_INCOME: '最後淨利',

	// 销售额折线上方的三个选项
	STOCK_SALES_KLINE_TABS: ['銷售額', '營業利潤', '淨利'],
	// 投资者交易趋势
	STOCK_TRADE_TREND_TITLE:'投資者的交易趨勢',
	  STOCK_TRADE_TREND_BUY_AMOUNT: ['淨買入數量', '累計淨買入數量'],
	  STOCK_TRADE_TREND_INFO_TITLE: ['個人', '機構', '外部'],
	  STOCK_TRADE_TREND_RECENT_TITLE: '近期交易趨勢',
	  STOCK_TRADE_TREND_RECENT_LABELS:['日期','個人','機構','外部'],
	// 饼图的title
	STOCK_TRADE_TREND_PIE_TITLE: '交易趨勢',
	  STOCK_TRADE_SELL_EMPTY_TITLE: '賣空量',
	// 卖空量两组数据的Title
	STOCK_TRADE_SELL_EMPTY_TITLE_BALANCE: '賣空餘額',
	  STOCK_TRADE_SELL_EMPTY_ITEM_DESC_1ST: '與總交易量相比',
	  STOCK_TRADE_SELL_EMPTY_ITEM_DESC_2ND: '與市值相比',

	// 行业内比较
	STOCK_INDUSTRY_TITLE: '產業內比較',
	  STOCK_INDUSTRY_DESC: '汽車零件',
	  STOCK_INDUSTRY_DESC_SUFFIX: '公共',
	  STOCK_INDUSTRY_DATA_TITLES: ['目前庫存', '產業平均'],
	  STOCK_INDUSTRY_DATA_LABELS: ['評估金額','淨利潤成長率','負債比率','PER','PBR','ROE'],
};

// 市场页面
const MARKET = {
	MARKET_TABS:['摘要','熱門商品','市場指標','市場問題'],
	// 市场概况:
	MARKET_OVERVIEW_SELF_TITLE:'國內商品',
	//国内、国外、虚拟货币
	MARKET_OVERVIEW_SELF_TABS: ["國內","海外","虛擬貨幣"],
	  MARKET_MORE_HOT_TITLE:'更多熱門商品',
	  MARKET_NEWS_TITLE:'市場問題',
	  MARKET_OVERVIEW_THEAD: ["上漲幅度","下跌幅度","新價格","交易量",'交易金額'],
	// 热门股票:
	MARKET_HOT_TABS:['漲幅','跌幅','報告價格','交易量頂部/底部','交易金額頂部/底部','國外淨買入','機構淨買入','新上市' , '賣空比例'],
	// 热门股票过滤
	MARKET_HOT_FILTER: ['同一天', '1 週', '1 個月', '3 個月', '6 個月'],
	  MARKET_HOT_THEAD: ['股票名稱','當前價格','波動率','當前指數'],
	// 市场指标
	MARKET_INDEX_TABS: ['指數','匯率','原料','虛擬貨幣'],
	  MARKET_NEWS_TABS: ['新聞', '市場', '經濟', '產業', '債券', '衍生性商品', '公司', '投資'],
	  MARKET_NEWS_TIP: '對於熱門商品，僅提供前100名的排名。 ',
};

// 首页中签弹层
const DIALOG_IPO_SUCCESS = {
	DIALOG_IPO_SUCCESS_TIP_TITLE: '恭喜',
	  DIALOG_IPO_SUCCESS_TIP_TEXT: '您已贏得公開發行認購',
	  DIALOG_IPO_SUCCESS_LABEL_QTY: '批次數量',
	  DIALOG_IPO_SUCCESS_LABEL_TOTAL: '一次性付款',
}

export default {
	TRANSLATE_TITLE: '選擇您的語言',
	  LAUNCH_TITLE:'線上股票交易應用程式',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_AI,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EQUITY,
	...STOCK_INFO,
	...MARKET,
	...DIALOG_IPO_SUCCESS,
	LEVER:'槓桿',
	  STOCK_ALL: '國內庫存',
	  STOCK_FOLLOW:'焦點',
	// 首页股票列表表头
	STOCK_THEAD: ['庫存','最新價格','波動性'],
	  PAGE_TITLE_NOTIFICATION: '折扣優惠',
	  PAGE_TITLE_SEARCH: '搜尋',
	  TIP_SEARCH: '輸入股票名稱/股票代號',
	  SEARCH_HISTORY: '搜尋紀錄',
	  SEARCH_CLEAR: '清除歷史記錄',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: '折扣交易',
	  TIP_POST_SUCCESS: '操作成功',
	  ABOUT_US:'關於我們',
	  CURRENCY_UNIT: '圓圈',
	  QUANTITY_UNIT: '狀態',
	  UNIT_BILION: '十億',
	  UNIT_POS: '向上',
	  UNIT_DAY: '天空',
	  MORE:'更多',
	  BRIEF:'簡要',
	  EMPTY_NOTIFIY: '沒有訊息',
	  EMPTY_DATA: '無記錄',
	  BTN_CONFIRM: '提交',
	  BTN_CANCEL: '取消',
	  BTN_SEND_SERVICE: '聯絡客服',
	  BTN_SERVICE: '客戶服務',
	  BTN_DETAIL: '詳細資料',
	  BTN_BUY: '購買',
	  BTN_SELL: '出售',
	  BTN_DETAIL_NOW: '立即查看',
	  STATUS_LOADING: '正在載入',
	  STATUS_SUBMIT: '正在提交',
	  STATUS_REQUEST: '資料檢索',
	  STATUS_HTTP_ERROR: '重試',
	  STATUS_UPLOAD: '正在上傳',
}