import subprocess
import time
import os
import requests
import base64
import threading
import urllib.parse
# 全局变量用于标记程序是否正在执行
is_running = False
import sys
# 活动列表
activity_map = {
    "com.vnpay.bidv/.ui.activities.results.SuccessActivity": "BIDV...",
    "com.vietinbank.ipay/.activity.SuccessActivity": "VTB...",
    "com.VCB/.ui.activities.result.TransactionResultActivity": "VCB...",
    "com.bank.vietnam.germany/.MainActivity":'ceshi...'
}

# 获取当前设备的最后一个活动页面
def get_current_activity(device_id):
    try:
        # 检查 adb 命令是否成功执行
        result = subprocess.check_output(
            ["adb", "-s", device_id, "shell", "dumpsys", "window"],
            encoding="utf-8",
            errors="ignore"
        )
        last_activity = None
        for line in result.splitlines():
            if "mCurrentFocus" in line or "mFocusedApp" in line:
                parts = line.split()
                for part in parts:
                    if "/" in part:
                        last_activity = part.strip("{}")

        return last_activity
    except subprocess.CalledProcessError as e:
        print(f"❌ 获取活动页面时出错: {e}")
        print(f"错误输出: {e.output}")
        return None
    except Exception as e:
        print(f"发生其他错误: {e}")
        return None

# 截图并保存到本地
def capture_screenshot(adb_path, device_id, screenshot_path):
    try:
        # 执行截图命令
        subprocess.check_output([adb_path, "-s", device_id, "shell", "screencap", "-p", "/sdcard/screenshot1.png"])

        # 将截图从设备复制到本地
        subprocess.check_output([adb_path, "-s", device_id, "pull", "/sdcard/screenshot1.png", screenshot_path])
        print('截图保存成功')
    except subprocess.CalledProcessError as e:
        print(f"截图失败: {e}")


# 上传截图到服务器
def upload_screenshot(image_path):
    url = 'https://bot.btcloud.shop/upload'
    with open(image_path, 'rb') as f:  # 使用 with 语句自动关闭文件
        files = {'file': f}
        try:
            response = requests.post(url, files=files)

            # 检查响应的状态码
            if response.status_code == 200:
                try:
                    response_data = response.json()
                    if response_data.get('message') == 'successfully':
                        return response_data['path']
                    else:
                        print(f"上传失败，响应数据: {response_data}")
                except ValueError as e:
                    print(f"解析响应时出错: {e}")
                    print(f"响应内容: {response.text}")
            else:
                print(f"请求失败，状态码: {response.status_code}, 响应内容: {response.text}")
        except Exception as e:
            print(f"上传失败: {e}")
    return None


# 发送请求到指定路径
def send_message_to_path(message_path, beizhu):
    try:
        print(message_path)
        print(beizhu)
        encoded_message = utf8_to_base64_and_urlencode(beizhu, message_path)
        print(encoded_message)

        url = f'https://bot.btcloud.shop/zhangdan?message={encoded_message}'
        print(url)

        response = requests.get(url)
        print('请求成功:', response.json())
    except Exception as e:
        print(f"请求失败: {e}")


# UTF-8 编码并转换为 Base64
def utf8_to_base64_and_urlencode(beizhu, message_path):
    try:
        # 拼接字符串
        combined_string = f"{beizhu}{message_path}"

        # 显式编码为 UTF-8 字节序列
        utf8_bytes = combined_string.encode('utf-8')

        # 使用标准 Base64 编码
        base64_encoded = base64.b64encode(utf8_bytes).decode('utf-8')  # 解码为 UTF-8 字符串

        # URL 编码
        url_encoded = urllib.parse.quote(base64_encoded)
        return url_encoded
    except Exception as e:
        print(f"编码过程中出错: {e}")
        return None


# 主函数: 定时获取活动并执行截图和上传
# 监听活动并进行截图和上传
def monitor_activity_and_capture(device_id, beizhu):
    global is_running

    if is_running:
        print("程序正在执行，跳过本次调用。")
        return

    is_running = True
    last_activity = None
    adb_path = "adb"
    screenshot_path = "screenshot1.png"

    try:
        while True:
            current_activity = get_current_activity(device_id)
            if current_activity and current_activity != last_activity:
                print(f"当前活动: {current_activity}")
                if current_activity in activity_map:
                    print(f"匹配到活动: {current_activity}")
                    beizhu = f"{activity_map[current_activity]}{beizhu}"
                    capture_screenshot(adb_path, device_id, screenshot_path)
                    upload_path = upload_screenshot(screenshot_path)
                    if upload_path:
                        send_message_to_path(upload_path, beizhu)
                last_activity = current_activity
            sys.stdout.flush()  # 强制刷新缓冲区
            time.sleep(1)
    except Exception as e:
        print(f"监听过程中出错: {e}")
    finally:
        is_running = False

# 使用 try-except 捕获异常
def run_in_thread(device_id, beizhu):
    try:
        monitor_activity_and_capture(device_id, beizhu)
    except Exception as e:
        print(f"线程执行过程中发生错误: {e}")




# device_id = "10.8.0.14:46183"
# beizhu = "d9e02a6f05fb7921..."  # 可替换为实际备注

# monitoring_thread = threading.Thread(target=monitor_activity_and_capture, args=(device_id, beizhu))
# monitoring_thread.start()

