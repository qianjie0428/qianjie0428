import socket
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

def scan_port(ip, port, stop_event):
    if stop_event.is_set():
        return None
    try:
        with socket.create_connection((ip, port), timeout=3):
            stop_event.set()
            return port
    except:
        return None

def scan_ports(ip, start_port=10000, end_port=65535, max_workers=10000):
    stop_event = threading.Event()
    ports = range(start_port, end_port + 1)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_port = {executor.submit(scan_port, ip, port, stop_event): port for port in ports}

        for future in as_completed(future_to_port):
            port = future_to_port[future]
            result = future.result()
            if result:
                print(f"{ip}:{result}", flush=True)
                stop_event.set()
                # 找到后立刻返回
                return f"{ip}:{result}"

    return None

if __name__ == "__main__":
    if len(sys.argv) >= 5:
        mode = sys.argv[1]
        wifi_ip = sys.argv[4]
        if mode == "saomiao":
            result = scan_ports(wifi_ip)
            if result:
                print(result, flush=True)
            else:
                print("未找到ADB服务", flush=True)
    else:
        print("使用方式: python main.py saomiao <android_id> <device_id> <wifi_ip>", flush=True)
