const { exec,spawn } = require("child_process");
const { app,dialog } = require("electron");
const logger = require("./logger.js");
const { showSingleInputBox } = require("./showInputBox.js");

const path = require('path');
const { autoTypeString } = require("./auto-type.js");
const { getDeviceConfig, setDeviceConfig,getCurrentActivity,zhangdan } = require("./config-utils.js");



const adbPath = "adb"; // 你可以修改为 getResourcePath('adb')，如果有动态路径需求

// **延迟函数**
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


const logMessage = (logWindow, message, level = "log-message", isPinned = false) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send(level, message, isPinned);
    }
};

const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout.trim());
            }
        });
    });
};




const AGRIjianting = async(logWindow, { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

    return new Promise((resolve, reject) => {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp; // 获取设备 ID

        // 判断是否是打包环境
        const isProduction = app.isPackaged;

        // 根据环境设置路径
        const scriptPath = isProduction
        ? path.resolve(__dirname, "../ziyuan/main.exe")  // 生产环境
        : path.join(__dirname, "/resources/ziyuan/main.exe");    

        logMessage(logWindow,"AGRI开始监听");
        console.log(scriptPath)
        // 运行可执行文件，并将 deviceId 作为参数传递给 main.exe
        const pythonProcess = spawn(scriptPath, ["agri", android_id, deviceId]);

        let outputData = "";
        let errorData = "";

        // 监听标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();
            logMessage(logWindow, `Python stdout: ${message}`);
            outputData += message + "\n";
        });

        // 监听标准错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            logMessage(logWindow, `Python stderr: ${errorMessage}`);
            errorData += errorMessage + "\n";
        });

        // 监听进程结束
        pythonProcess.on("close", (code) => {
            if (code === 0) {
                logMessage(logWindow, `密码监听成功跳转:\n${outputData}`);
                resolve(outputData.trim());
            } else {
                logMessage(logWindow, `密码监听失败:\n${errorData}`);
                reject(new Error(`密码监听失败 失败代码 ${code}: ${errorData}`));
            }
        });

        // 监听进程启动失败
        pythonProcess.on("error", (err) => {
            logMessage(logWindow, `密码监听失败: ${err.message}`);
            reject(new Error(`密码监听失败: ${err.message}`));
        });

    });
};


const AGRIlogin = async(logWindow, { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

    // 显示输入框
    const userInput = await showSingleInputBox({
        title: '请输入登录密码',
        message: '请输入内容',
    });

    if (!userInput) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    logMessage(`输入密码为: ${userInput}`);

    try {


        const config = getDeviceConfig(android_id);
        
        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;



        const startAppCommand = `${adbPath} -s ${deviceId} shell monkey -p com.vnpay.Agribank3g -c android.intent.category.LAUNCHER 1`;
        try {
            await execCommand(startAppCommand);
                logMessage(logWindow,'应用  已成功启动');
        } catch (error) {
            logMessage(logWindow,`启动应用失败: ${error.message}`);
            dialog.showErrorBox('错误', `启动应用失败: ${error.message}`); // 错误弹窗
            return;
        }

        await delay(3000); // 等待 5 秒


        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        logMessage(logWindow,'寻找成功 点击中');

        await delay(4000); // 等待 2 秒

        logMessage(logWindow,`进入登录页面 开始登录`);

        // 输入用户提供的文字
        // for (const char of userInput) {
        //     await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
        //     logMessage(logWindow,`输入字符 ${char} 成功`);
        // }


        const phoneParams = {
            screenWidth: androidWidth,
            screenHeight: androidHeight,
            navBarHeight: NavigationBarHeight
        };

        autoTypeString(logWindow,deviceId,userInput, phoneParams);

        logMessage(logWindow,'点击确认中,请稍后');
        await delay(2000); // 每次点击字符后延迟
        


        // 点击逻辑：从顶部40%到80%，每次增加5%，点击距离左侧10%的位置
        const x = Math.round(androidWidth * 0.1); // 距离左侧10%
        for (let percentage = 50; percentage <= 60; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击确认按键`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }


        logMessage(logWindow,'检测页面当前是否正常  等待6秒左右');
        await delay(6000); // 等待 2 秒


        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);

        if(activity!="com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.transfer.MenuTransferActivity"){
            logMessage(logWindow,`❌ 页面不正常' 当前${activity}`);
        }else{
            logMessage(logWindow,`当前页面检测正常,请点击【AGRI选择银行】按钮`,"log-info");
        }

    } catch (error) {
        console.error(`操作失败: ${error.message}`);
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};



const AGRIBank = async(logWindow, { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

   

    try {
        const config = getDeviceConfig(android_id);
        
        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;


        // 点击逻辑：从顶部40%到80%，每次增加5%，点击距离左侧10%的位置
        const x = Math.round(androidWidth * 0.3); // 距离左侧10%
        for (let percentage = 40; percentage <= 45; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击确认按键`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }


        logMessage(logWindow,'检测页面当前是否正常  等待6秒左右');
        await delay(6000); // 等待 2 秒


        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);
        if(activity!="com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.transfer.InterbankTransferActivity"){
            logMessage(logWindow,`❌ 页面不正常'}`);
        }else{
            logMessage(logWindow,`当前页面检测正常`);

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
            logMessage(logWindow,'寻找成功 弹出选择银行卡代表正常,选择后请点击【ARGI银行账号】<br>如果未弹出,请点击返回键，重复此操作',"log-warning");

            logMessage(logWindow,'选择银行卡必须<span style="color:red">搜索模式</span>  请勿用鼠标拖动选择',"log-critical");
        }

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};


const AGRIzhanghao = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

    // 显示输入框
    const zhanghao = await showSingleInputBox({
        title: '请输入转账账号',
        message: '请输入转账账号',
    });

    if (!zhanghao) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    logMessage(logWindow,'进入转账账号');

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');
        
        const pinpai=await execCommand(`adb -s ${deviceId}  shell getprop ro.product.brand`);
        logMessage(logWindow,`当前手机品牌${pinpai}`);
        // if(pinpai=="Redmi"){
        //     await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        //     logMessage(logWindow,'寻找页面按键中  请稍等');
        // }

        // 输入用户提供的文字
        for (const char of zhanghao) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }


        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);

        logMessage(logWindow,'选择银行后,当前步骤不会有任何弹窗,如果有弹窗代表操作错误,请联系主管进行修复或者纠正操作错误',"log-critical");

        logMessage(logWindow,`请点击【AGRI转账金额】`,"log-info");
            

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};

// **执行 BIDV 转账 3**
const AGRIMoney = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'AGRI转账金额');

    // 显示输入框
    const meony = await showSingleInputBox({
        title: '请输入转账金额',
        message: '请输入转账金额',
    });

    if (!meony) {
        console.error('未提供输入内容');
        logger.info('未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        logMessage(logWindow,'寻找 输入金额 输入框');

        logMessage(logWindow,`等待输入金额 2秒钟`);
        await delay(2000); 


        // 输入用户提供的文字
        for (const char of meony) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        logMessage(logWindow,'确认金额');
       
        await delay(2000); 


         // 点击逻辑：从顶部40%到80%，每次增加5%，点击距离左侧10%的位置
         const x = Math.round(androidWidth * 0.85); // 距离左侧10%
         for (let percentage = 80; percentage <= 90; percentage += 5) {
             const y = Math.round(androidHeight * (percentage / 100));
             logMessage(logWindow,`点击确认按键`);
             await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
         }


        

        logMessage(logWindow,'检测页面当前是否正常  等待6秒左右');
        await delay(6000); // 等待 2 秒


        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);
        if(activity!="com.vnpay.Agribank3g/com.vnpay.agribank3g.ui.activities.confirm.ConfirmActivity"){
            logMessage(logWindow,`❌ 页面不正常`,'log-critical');
        }else{
            logMessage(logWindow,`当前页面检测正常,开始寻找确认按键`,"log-info");

            const x = Math.round(androidWidth * 0.85); // 距离左侧10%
            for (let percentage = 70; percentage <= 90; percentage += 5) {
                const y = Math.round(androidHeight * (percentage / 100));
                logMessage(logWindow,`点击确认按键`);
                await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
            }
            
            logMessage(logWindow,`<span style='color:red'>如果操作无误,正常会有AGRI的logo显示,显示消失后</span>,请点击【AGRI验证码】`,"log-info");

        }
    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗

    }
};


// **执行 BIDV 转账 3**
const AGRIMima = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'AGRI转账密码');

    // 显示输入框
    const mima = await showSingleInputBox({
        title: '请输入转账密码',
        message: '请输入转账密码',
    });

    if (!mima) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        // 输入用户提供的文字
        for (const char of mima) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        logMessage(logWindow,`寻找确认按键,请等待3秒`,'log-warning');
        await delay(3000); // 等待 5 秒


        await delay(2000); // 等待 5 秒

        // 从顶部 80% 到 90%，每次增加 5%，点击距离左侧 50% 的位置
        const halfX = Math.round(androidWidth * 0.5); // 左边 50%
        for (let percentage = 80; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }

      
    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗

    }
};

module.exports = { AGRIlogin,AGRIBank,AGRIzhanghao,AGRIMoney,AGRIMima,AGRIjianting };
