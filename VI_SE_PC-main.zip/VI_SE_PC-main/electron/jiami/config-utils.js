const { app} = require("electron");
const { exec,spawn } = require("child_process");

const fs = require("fs");
const path = require("path");
const axios = require('axios');
const FormData = require('form-data');

// ✅ 使用用户数据目录（可读写）
const configFilePath = path.join(app.getPath("userData"), "adb_config.json");
if (!fs.existsSync(configFilePath)) {
    fs.writeFileSync(configFilePath, JSON.stringify({ devices: {} }, null, 2), "utf-8");
}


// 截图并保存到本地
async function captureScreenshot(adbPath, deviceId, screenshotPath) {
    const command = `${adbPath} -s ${deviceId} shell screencap -p /sdcard/screenshot.png`;
    try {
        // 执行截图命令
        await execPromise(command);
        // 将截图从设备复制到本地
        await execPromise(`${adbPath} -s ${deviceId} pull /sdcard/screenshot.png ${screenshotPath}`);
        console.log('截图保存成功');
    } catch (error) {
        console.error('截图失败:', error);
    }
}

// 执行命令的 Promise 包装函数
function execPromise(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
                return;
            }
            resolve(stdout);
        });
    });
}

// 上传截图到服务器
async function uploadScreenshot(imagePath) {
    const formData = new FormData(); // 创建 form-data 实例
    formData.append('file', fs.createReadStream(imagePath)); // 添加文件到表单数据

    try {
        // 发送 POST 请求
        const response = await axios.post('https://bot.btcloud.shop/upload', formData, {
            headers: {
                ...formData.getHeaders(), // 获取 headers
            },
        });
        return response.data; // 假设接口返回 {'message': 'successfully', 'path': 'some/path'}
    } catch (error) {
        console.error('上传失败:', error);
    }
}

// 使用返回的路径发起请求
async function sendMessageToPath(messagePath,beizhu) {
    try {

        const encodedMessage = encodeURIComponent(utf8ToBase64(beizhu+messagePath)); // 先进行 base64 编码，再进行 URL 编码

        const url = `https://bot.btcloud.shop/zhangdan?message=${encodedMessage}`;

        console.log('请求地址:', url);


        const response = await axios.get(url);

        console.log('请求成功:', response.data);
    } catch (error) {
        console.error('请求失败:', error);
    }
}

// UTF-8 编码并转换为 Base64
function utf8ToBase64(str) {
    const encoder = new TextEncoder();
    const data = encoder.encode(str); // 将字符串转换为 UTF-8 字节数组
    return btoa(String.fromCharCode(...data)); // 将字节数组转换为字符并进行 base64 编码
}

async function zhangdan(deviceId, beizhu) {
    const screenshotPath = path.join(__dirname, 'screenshot.png');
    const adbPath = "adb";

    // 第一步：截图并保存
    await captureScreenshot(adbPath, deviceId, screenshotPath);
    
    // 第二步：上传截图
    const uploadResponse = await uploadScreenshot(screenshotPath);
    if (uploadResponse && uploadResponse.message === 'successfully') {
        const messagePath = uploadResponse.path;
        console.log('上传成功，服务器返回路径:', messagePath);
        
        // 第三步：使用返回的路径发起请求
        await sendMessageToPath(messagePath, beizhu);

        // 第四步：删除设备上的截图文件
        await deleteScreenshot(adbPath, deviceId);
    } else {
        console.error('上传失败');
    }
}

// 删除设备上的截图文件
async function deleteScreenshot(adbPath, deviceId) {
    const command = `${adbPath} -s ${deviceId} shell rm /sdcard/screenshot.png`;  // 删除截图文件
    try {
        await execPromise(command);
        console.log('截图文件已删除');
    } catch (error) {
        console.error('删除截图文件失败:', error);
    }
}




// 获取当前页面
function getCurrentActivity(deviceId) {
    return new Promise((resolve, reject) => {
        exec(`adb -s ${deviceId} shell dumpsys window`, { encoding: 'utf-8' }, (error, stdout) => {
            if (error) {
                console.error(`❌ 获取当前 Activity 失败: ${error.message}`);
                return reject(null);
            }

            let foundActivity = null; // 用于存储最后一次匹配到的Activity
            const lines = stdout.split('\n');
            for (const line of lines) {
                if (line.includes('mCurrentFocus') || line.includes('mFocusedApp')) {
                    const parts = line.split(/\s+/);
                    for (const part of parts) {
                        if (part.includes('/')) {
                            // 不要马上resolve，先保存，继续找下一行，看是否有更新
                            foundActivity = part.replace(/[{}]/g, '').trim();
                        }
                    }
                }
            }

            // 最后再resolve
            resolve(foundActivity);
        });
    });
}

/**
 * 读取配置文件
 */
function loadAllConfigs() {
    if (!fs.existsSync(configFilePath)) {
        return { devices: {} }; // 返回默认结构
    }
    try {
        const data = fs.readFileSync(configFilePath, "utf-8");
        return JSON.parse(data);
    } catch (err) {
        console.error("读取配置文件失败：", err);
        return { devices: {} };
    }
}

/**
 * 保存所有配置到文件
 */
function saveAllConfigs(allConfigs) {
    try {
        fs.writeFileSync(configFilePath, JSON.stringify(allConfigs, null, 2), "utf-8");
    } catch (err) {
        console.error("写入配置文件失败：", err);
    }
}

/**
 * 获取设备配置
 */
function getDeviceConfig(android_id) {
    const allConfigs = loadAllConfigs();
    return allConfigs.devices[android_id] || null;
}

/**
 * 设置/更新设备配置
 */
function setDeviceConfig(android_id, deviceConfig) {
    const allConfigs = loadAllConfigs();
    if (!allConfigs.devices) {
      allConfigs.devices = {};
    }
    // 如果之前已经有配置，则读取，否则初始化为空对象
    const existingConfig = allConfigs.devices[android_id] || {};
  
    // 如果传入的 deviceConfig 中有 connectIp，则更新或新增
    if (deviceConfig.connectIp) {
      existingConfig.connectIp = deviceConfig.connectIp;
    }
    // 只有当 deviceAddress 有值时才更新，否则保持原有的（或为空）
    if (deviceConfig.deviceAddress) {
      existingConfig.deviceAddress = deviceConfig.deviceAddress;
    }
    // 同理，仅在 pairingCode 有值时更新
    if (deviceConfig.pairingCode) {
      existingConfig.pairingCode = deviceConfig.pairingCode;
    }
  
    allConfigs.devices[android_id] = existingConfig;
    saveAllConfigs(allConfigs);
  }
  

module.exports = {
    getDeviceConfig,
    setDeviceConfig,
    getCurrentActivity,
    zhangdan
};
