const { exec, spawn } = require('child_process');
const { dialog } = require('electron');

const { getDeviceConfig, setDeviceConfig } = require('./config-utils.js');
const { showInputBox } = require('./showInputBox.js');

require('dotenv').config();
const adbPath = "adb";

// 记录日志
const logMessage = (logWindow, message) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send("log-message", message);
    }
};


const clearMessage = (logWindow) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send("clear-message");
    }
};

/** 
 * 杀死所有 ADB 连接 
 * 这里使用 exec 调用 adb kill-server
 */
function killAllAdbConnections(callback) {
    exec("${adbPath} kill-server", (error) => {
        if (error) {
            console.error("❌ Failed to kill ADB server: ${error.message}");
        } else {
            console.log("✅ All ADB connections killed (kill-server).");
        }
        if (typeof callback === "function") callback();
    });
}


/**
 * 启动 scrcpy --max-size 800 --video-bit-rate 2M --max-fps 30 -s <connectIp>
 * 这样在多设备场景下可以精准连接目标设备
 */
function startScrcpy(logWindow, connectIp) {
    if (!connectIp) {
        logMessage(logWindow, "❌ 未提供 connectIp，无法指定设备");
        return;
    }
    logMessage(logWindow, `✅ 开始启动 scrcpy，多设备模式，目标设备: ${connectIp}`);

    const args = [
        "--no-audio",
        "--max-size", "600",
        "--video-bit-rate", "1M",
        "--max-fps", "10",
        "-s", connectIp  // ⭐ 关键：指定要连接的设备
    ];


    // 在 Windows 上用 cmd.exe /c scrcpy
    const proc = spawn("cmd.exe", ["/c", "scrcpy", ...args], { shell: true });

    proc.stdout.on("data", (data) => {
        logMessage(logWindow, `${data}`);
    });
    proc.stderr.on("data", (data) => {
        logMessage(logWindow, `${data}`);
    });
    proc.on("error", (error) => {
        logMessage(logWindow, `❌ scrcpy 运行失败: ${error.message}`);
    });
    proc.on("close", (code) => {
        if (code === 0) {
            logMessage(logWindow, `✅ scrcpy 正常退出`);
        } else {
            logMessage(logWindow, `❌ scrcpy 退出码: ${code}`);
        }
    });
}



/**
 * 运行 ADB Pair（先输入设备地址，再输入配对码）
 */
function runADBPair(logWindow, deviceAddress, pairingCode, connectIp, android_id, callback) {
    logMessage(logWindow, `🚀 运行配对命令`);

    const adbProcess = spawn("cmd.exe", ["/c", "adb", "pair", deviceAddress], {
        stdio: ["pipe", "inherit", "inherit"], // 允许写入标准输入
    });

    setTimeout(() => {
        logMessage(logWindow, `⌨️  发送配对码: ${pairingCode}`);
        adbProcess.stdin.write(pairingCode + "\n");
        adbProcess.stdin.end();
    }, 1000);

    adbProcess.on("close", (code) => {
        if (code === 0) {
            logMessage(logWindow, "✅ WIFI 配对成功，执行远程连接");
            adbConnect(logWindow, connectIp, android_id, (connectSuccess) => {
                if (connectSuccess) {
                    logMessage(logWindow, "✅ 设备连接成功，开始远程连接");
                    callback(true);  // ✅ 确保这里一定执行
                } else {
                    logMessage(logWindow, "❌ 设备连接失败");
                    callback(false);
                }
            });

        } else {
            logMessage(logWindow, "❌ WIFI 配对失败，错误码:" + code);
            dialog.showErrorBox("错误", "❌ WIFI 配对失败，错误码:" + code);

            callback(false);
        }
    });
}



/**
 * ADB 连接设备
 */
function adbConnect(logWindow, ipAndPort, android_id, callback) {
    logMessage(logWindow, `🔌 开始连接,请等待 ${ipAndPort}`);

    const adbProcess = spawn("adb", ["connect", ipAndPort], { shell: true });
    let adbOutput = "";

    adbProcess.stdout.on("data", (data) => {
        const output = data.toString().trim();
        adbOutput += output;
        // logMessage(logWindow, `📡 ADB 输出: ${output}`);
    });

    adbProcess.stderr.on("data", (data) => {
        logMessage(logWindow, `❌ WIFI 连接失败，返回信息: ${data}`);
        callback(false);
    });

    adbProcess.on("close", (code) => {
        // logMessage(logWindow, `🔍 ADB 连接结束，返回码: ${code}, 输出: ${adbOutput}`);

        // 解析 ADB 连接状态
        if (adbOutput.toLowerCase().includes("connected to")) {
            logMessage(logWindow, `✅ 设备 ${ipAndPort} 已连接`);

            // 确保 android_id 存在
            if (typeof android_id === "undefined") {
                logMessage(logWindow, "⚠️ android_id 未定义，可能导致配置信息存储失败");
            } else {
                logMessage(logWindow, `📡 存储设备信息: ${ipAndPort}`);

            }

            callback(true);  // ✅ 确保这里一定执行
        } else {
            logMessage(logWindow, `❌ WIFI 连接失败，返回信息: ${adbOutput}`);
            callback(false);
        }
    });
}



/**
 * 弹出输入框，用户输入设备信息
 */
function showFullPairingForm(logWindow, android_id, callback) {
    const config = getDeviceConfig(android_id) || {};

    showInputBox({
        title: "WIFI配对",
        messages: {
            deviceAddress: "【配对端口IP:端口】(例: 192.168.1.100:37000):",
            pairingCode: "【配对码】:",
            connectIp: "【连接IP:端口】(例: 192.168.1.100:5555):"
        },
        defaultValues: {
            deviceAddress: config.deviceAddress || "10.147.17.x:xxxxx",
            pairingCode: config.pairingCode || "",
            connectIp: config.connectIp || "10.147.17.x:xxxxx"
        }
    }).then((formData) => {
        if (!formData || Object.values(formData).every(value => value.trim() === "")) { // 🔥 确保输入不为空
            logMessage(logWindow, "❌ 关闭输入框，未输入任何内容");
            callback(false);
            return;
        }

        console.log("✅ 用户输入的内容:", formData); // ✅ 确保数据已传入



        const { deviceAddress, pairingCode, connectIp } = formData;

        logMessage(logWindow, `📡 用户输入:${deviceAddress} ${pairingCode} ${connectIp}`);

        setDeviceConfig(android_id, { deviceAddress, pairingCode, connectIp });


        if (!deviceAddress || !pairingCode || !connectIp) {
            logMessage(logWindow, "❌ 输入信息不完整，无法执行配对或连接");
            dialog.showErrorBox("错误", "请输入完整配对信息（设备地址、配对码、连接IP）");
            callback(false);
            return;
        }

        runADBPair(logWindow, deviceAddress, pairingCode, connectIp, android_id, (pairSuccess) => {
            if (!pairSuccess) {
                logMessage(logWindow, "❌ WIFI 配对失败");
                dialog.showErrorBox("错误", "❌ WIFI 配对失败");
                callback(false);
                return;
            }
            callback(true);
        });
    });

}

// 导出所有方法，供外部调用
module.exports = {
    adbConnect,
    showFullPairingForm,
    runADBPair,
    startScrcpy
};
