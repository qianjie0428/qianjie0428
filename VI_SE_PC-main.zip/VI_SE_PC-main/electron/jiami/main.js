const { app, BrowserWindow, ipcMain, dialog, screen, globalShortcut } = require('electron');
const path = require('path');
const { exec, spawn } = require('child_process');

const logger = require('./logger');

const { autoUpdater } = require('electron-updater');

const { showSingleInputBox } = require('./showInputBox.js');
const packageJson = require("./package.json"); // ✅ 读取 `package.json`
const { getDeviceConfig, setDeviceConfig, getCurrentActivity } = require("./config-utils.js");

const {
    adbConnect,
    showFullPairingForm,
    startScrcpy
  } = require("./adbManager");

require('dotenv').config();

const adbPath = "adb";
// const adbPath = getResourcePath('adb');

let mainWindow;

// 动态获取资源目录的路径
const resourcesPath = process.env.NODE_ENV === 'development'
    ? path.join(__dirname, 'resources', 'ziyuan') // 开发环境下使用源码目录
    : path.join(process.resourcesPath, 'ziyuan'); // 打包后使用 `resources` 目录

// 获取文件路径的函数
function getResourcePath(fileName) {
    return path.join(resourcesPath, fileName);
}

const calculateTapPosition = (
    x_ref, // 原设备上的任意点 X 坐标
    y_ref, // 原设备上的任意点 Y 坐标
    x1_ref, y1_ref, // 原设备的参考点 1
    x2_ref, y2_ref, // 原设备的参考点 2
    x1_actual, y1_actual, // 目标设备的参考点 1
    x2_actual, y2_actual // 目标设备的参考点 2
) => {
    // 计算宽度和高度比例
    const widthScale = (x2_actual - x1_actual) / (x2_ref - x1_ref);
    const heightScale = (y2_actual - y1_actual) / (y2_ref - y1_ref);

    // 计算偏移
    const xOffset = x1_actual - x1_ref * widthScale;
    const yOffset = y1_actual - y1_ref * heightScale;

    // 映射参考设备坐标到目标设备
    const x_actual = Math.round(x_ref * widthScale + xOffset);
    const y_actual = Math.round(y_ref * heightScale + yOffset);


    return { x: x_actual, y: y_actual };
};


const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout.trim());
            }
        });
    });
};


function initializeZeroTier() {
    const scriptPath = path.resolve(__dirname, getResourcePath("main.exe"));
    console.log(`运行 main.exe jiancha，路径: ${scriptPath}`);

    // 使用 `/c` 运行命令并在执行后自动关闭 cmd 窗口
    const cmdProcess = spawn("cmd.exe", ["/c", scriptPath, "jiancha"], {
        shell: true,
        detached: true, // 让子进程独立于主进程
        stdio: "ignore", // 避免 cmd 窗口阻塞
    });

    cmdProcess.unref(); // 让父进程不等待子进程

    joinZeroTierNetwork()
}


// 加入 ZeroTier 网络
function joinZeroTierNetwork() {
    const networkId = 'd5e5fb65378af3fd';
    const command = `zerotier-cli join ${networkId}`; // 加入指定的网络

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.log(`Failed to join ZeroTier network: ${error.message}`);
            return;
        }
        console.log(`Successfully joined network ${networkId}.`);
    });
}

const { closeAccessibility, openAccessibility, openScrcpy, superHeiping } = require("./adbOperations");
let logWindow;
// 创建窗口
function createWindow() {

    const appVersion = packageJson.version; // ✅ 获取版本号
    const name = packageJson.name;
    const url = packageJson.url;

    // 获取主屏幕的大小
    const { width: screenWidth, height: screenHeight } = screen.getPrimaryDisplay().workAreaSize;

    // 初始窗口大小
    let mainWidth = Math.floor(screenWidth * 0.60);  // 主窗口 70%
    let logWidth = Math.floor(screenWidth * 0.1);
    let height = Math.floor(screenHeight * 0.8);

    // 创建主窗口
    const mainWindow = new BrowserWindow({
        width: mainWidth,
        height: height,
        minWidth: 500, // 设定最小宽度，避免窗口过小
        minHeight: 400, // 设定最小高度
        title: `约炮远控 - v${appVersion}`, // ✅ 设置窗口标题
        resizable: true, // ✅ 允许调整窗口大小
        webPreferences: {
            contextIsolation: true,
            nodeIntegration: false,
            preload: path.join(__dirname, 'preload.js'),
        },
    });

    // ❌ 去掉顶部菜单
    mainWindow.setMenu(null);

    mainWindow.loadURL(url);

    mainWindow.webContents.once("did-finish-load", () => {
        mainWindow.setTitle(`约炮远控 - v${appVersion}`);
    });

    const mainBounds = mainWindow.getBounds();

    mainWindow.on('page-title-updated', (event) => {
        event.preventDefault(); // 阻止默认的 title 变化
        mainWindow.setTitle(`约炮远控 - v${appVersion}`); // 强制设置 title
    });

    // ✅ 注册全局快捷键（必须在 `whenReady` 之后）
    globalShortcut.register('CommandOrControl+Shift+M', () => {
        if (mainWindow) {
            mainWindow.webContents.toggleDevTools();
        }

    });

    // 监听滚轮缩放和快捷键刷新（推荐）
    mainWindow.webContents.on('before-input-event', (event, input) => {
        // 刷新快捷键支持
        if ((input.key === 'F5') || (input.control && input.key.toLowerCase() === 'r')) {
            mainWindow.reload();
            event.preventDefault();
        }
    });


    if (!logWindow || logWindow.isDestroyed()) {
        // 创建日志窗口
        logWindow = new BrowserWindow({
            width: logWidth,
            height: mainBounds.height - 10, // 让高度等于主窗口
            x: mainWindow.getBounds().x + mainWindow.getBounds().width, // 贴在主窗口右边
            y: mainWindow.getBounds().y, // 和主窗口对齐
            resizable: true,

            parent: mainWindow,       // ① 指定父窗口
            modal: false,            // ② 不阻塞主窗口
            show: false,             // 先不显示，等需要时再 show
            skipTaskbar: true,       // 不单独显示在任务栏

            minimizable: false,
            maximizable: false,
            alwaysOnTop: true,
            frame: false, // ✅ 去掉顶部菜单栏
            webPreferences: {
                contextIsolation: true,
                nodeIntegration: false,
                preload: path.join(__dirname, 'renderer.js') // ✅ 预加载 (不要用 renderer.js)
            },
        });

        logWindow.loadURL(`file://${path.join(__dirname, 'log.html')}`);



        // 监听主窗口移动，让 logWindow 跟随
        mainWindow.on('move', () => {
            const mainBounds = mainWindow.getBounds();
            if (logWindow) {
                logWindow.setBounds({
                    x: mainBounds.x + mainBounds.width, // 紧贴右边
                    y: mainBounds.y, // 和主窗口对齐
                    height: mainBounds.height - 10
                });
            }
        });

        // 监听主窗口调整大小，让 logWindow 跟随
        mainWindow.on('resize', () => {

            if (logWindow) {
                logWindow.setBounds({
                    x: mainBounds.x + mainBounds.width, // 紧贴右边
                    y: mainBounds.y, // 和主窗口对齐
                    height: mainBounds.height - 10
                });
            }
        });

        // 打开主窗口时，按需显示日志窗口
        mainWindow.on('ready-to-show', () => {
            mainWindow.show();
            logWindow.show();
        });

        mainWindow.on('focus', () => {
            if (logWindow && !logWindow.isDestroyed()) {
                logWindow.setAlwaysOnTop(false); // ✅ 取消置顶
            }
        });
        mainWindow.on('minimize', () => {
            if (logWindow && !logWindow.isDestroyed()) {
                logWindow.minimize();
            }
        });
        mainWindow.on('restore', () => {
            if (logWindow && !logWindow.isDestroyed()) {
                logWindow.restore();
            }
        });
        mainWindow.on('hide', () => {
            if (logWindow && !logWindow.isDestroyed()) {
                logWindow.hide();
            }
        });
        mainWindow.on('show', () => {
            if (logWindow && !logWindow.isDestroyed()) {
                logWindow.show();
            }
        });


    }

    mainWindow.on('before-quit', () => {

        killMainExe();
    });


    mainWindow.on('closed', () => {
        killMainExe();

        if (logWindow && !logWindow.isDestroyed()) {
            logWindow.close(); // ✅ 关闭日志窗口
        }
        mainWindow = null;
        logWindow = null;
    });

}


ipcMain.on('zoom-event', (event, { deltaY }) => {
    const webContents = event.sender;
    const currentZoom = webContents.getZoomFactor();
    const zoomFactor = deltaY < 0 ? 1.1 : 0.9;

    const newZoom = Math.min(Math.max(currentZoom * zoomFactor, 0.5), 3);
    webContents.setZoomFactor(newZoom);
});


function killMainExe() {
    exec('taskkill /F /IM main.exe', (error, stdout, stderr) => {
        if (error) {
            console.error(`❌ 关闭 main.exe 失败: ${error.message}`);
            return;
        }
        console.log("✅ main.exe 已成功关闭");
    });
}


// 记录日志
const logMessage = (message, level = "log-message", isPinned = false) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send(level, message, isPinned);
    } else {
        console.error("🚨 logWindow 未初始化或无效");
    }
};



const clearMessage = (logWindow) => {
    if (logWindow) {
        logWindow.webContents.send("clear-message");
    }
};


ipcMain.handle("close_accessibility", async (event, { android_id }) => {
    closeAccessibility(logWindow, android_id);
});

ipcMain.handle("open_accessibility", async (event, { android_id }) => {
    openAccessibility(logWindow, android_id);
});

ipcMain.handle("start-scrcpy", async (event, { android_id }) => {
    openScrcpy(logWindow, android_id);
});

ipcMain.handle("auto_link", async (event, { android_id, wifi_ip }) => {
    console.log("auto_link", wifi_ip);
    if (!wifi_ip || wifi_ip == "未连接zero或vpn") {
        logMessage("❌ 未连接zero或vpn 请检查网络连接或者点击【刷新】按钮！", "log-critical");
        return;
    }
    logMessage("✅ 开始自动连接设备");
    saomiao(android_id,wifi_ip);

    // openScrcpy(logWindow, android_id);
});


ipcMain.handle("super-heiping", async (event, { android_id }) => {
    superHeiping(logWindow, android_id);
});



ipcMain.handle("get_activity", async (event, { android_id }) => {

    const config = getDeviceConfig(android_id);

    if (!config || !config.connectIp) {
        logMessage("❌ 设备未找到，请检查配置！");
        return;
    }

    const deviceId = config.connectIp;


    const activity = await getCurrentActivity(deviceId);
    logMessage(`当前 Activity: ${activity}`, "log-critical");
});


const saomiao = async (android_id,wifi_ip) => {
    return new Promise((resolve, reject) => {
        const isProduction = app.isPackaged;
        const scriptPath = isProduction
            ? path.resolve(__dirname, "../ziyuan/main.exe")  // 生产环境
            : path.join(__dirname, "/resources/ziyuan/main.exe");

        console.log(scriptPath);

        // 运行可执行文件，并将参数传递给 main.exe
        const pythonProcess = spawn(scriptPath, ["saomiao", 1, 1, wifi_ip]);

        let outputData = "";
        let errorData = "";

        // 监听标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();

            // 定义一个正则表达式，匹配 IPv4 地址和端口号，例如 "192.168.1.100:5555"
            const ipPortRegex = /^(\d{1,3}\.){3}\d{1,3}:\d+$/;
            
            if (ipPortRegex.test(message)) {
                logMessage(`端口号: ${message}`);

                logMessage(`正在尝试链接设备: ${message}`);
                // 如果符合格式，就使用 message 更新 connectIp
                setDeviceConfig(android_id, { connectIp: message });
                
                logMessage(`请等待6秒等待设备上线`, "log-warning");
                logMessage(`如果连接成功后打不开屏幕,请直接点击旁边的【超级控制】`, "log-warning");
                // 延时 4 秒后再启动 scrcpy
                setTimeout(() => {
                    startScrcpy(logWindow, message);
                }, 6000);
            }


            outputData += message + "\n";
        });

        pythonProcess.on("close", (code) => {
            if (code === 0) {
                logMessage(`${outputData}`);
                logMessage(`扫描结束: 如果没有出现端口号 请重新点击，如果第二次也不行，请点击【超级远控】按钮 通过配对码进行连接`, "log-critical");

                resolve(outputData.trim());
            } else {
                logMessage(`${errorData}`);
                logMessage(`扫描失败: ${code}: ${errorData}`, "log-critical");
                reject(new Error(`失败代码 ${code}: ${errorData}`));
            }
        });

        // 监听标准错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            logMessage(`扫描失败: ${errorMessage}`);
            errorData += errorMessage + "\n";
        });


        // 监听进程启动失败
        pythonProcess.on("error", (err) => {
            reject(new Error(`扫描失败: ${err.message}`));
        });
    });
};


function checkForUpdates() {
    autoUpdater.checkForUpdatesAndNotify();  // 检查更新并自动通知
}

autoUpdater.checkForUpdates().then(updateCheckResult => {
    console.log(2222, updateCheckResult); // 检查是否返回更新信息
});
// 监听更新事件
autoUpdater.on('update-available', () => {
    dialog.showMessageBox({
        type: 'info',
        title: '更新提示',
        message: '检测到新版本，正在下载更新...',
        buttons: ['确定']
    });
});

autoUpdater.on('update-downloaded', () => {
    autoUpdater.quitAndInstall();
});

// 应用启动
app.whenReady().then(() => {
    initializeZeroTier();
    createWindow();
    checkForUpdates();

});

app.on('window-all-closed', () => {
    killMainExe();
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

// 捕获主进程的未捕获异常
process.on('uncaughtException', (error) => {
    console.log(`Uncaught Exception: ${error.stack || error}`)
});

// 捕获未处理的 Promise 拒绝
process.on('unhandledRejection', (reason) => {
    console.log(`Unhandled Rejection: ${reason}`);
});



ipcMain.handle('swipe', async (event, direction) => {
    console.log(`Received swipe ${direction} command`);
    swipe(direction);
});

ipcMain.handle('press-key', async (event, key) => {
    console.log(`Received press key ${key} command`);
    pressKey(key);
});

ipcMain.handle('tap', async (event, coordinates) => {
    const { x, y } = coordinates;
    console.log(`Received tap command at (${x}, ${y})`);
    tap(x, y);
});




function swipe(direction) {
    const adbPath = getResourcePath('adb');
    let command;

    switch (direction) {
        case 'left': // 左滑
            command = `${adbPath} shell input swipe 800 500 200 500`;
            break;
        case 'right': // 右滑
            command = `${adbPath} shell input swipe 200 500 800 500`;
            break;
        case 'up': // 上滑
            command = `${adbPath} shell input swipe 500 800 500 200`;
            break;
        case 'down': // 下滑
            command = `${adbPath} shell input swipe 500 200 500 800`;
            break;
        default:
            console.error('Invalid swipe direction.');
            return;
    }

    exec(command, (error) => {
        if (error) {
            console.error(`Swipe ${direction} failed: ${error.message}`);
            logMessage(`Swipe ${direction} failed: ${error.message}`);
        } else {
            console.log(`Swipe ${direction} executed successfully.`);
            logMessage(`Swipe ${direction} executed successfully.`);
        }
    });
}

function pressKey(key) {
    const adbPath = getResourcePath('adb');
    let keyCode;

    switch (key) {
        case 'home': // 主页键
            keyCode = 3;
            break;
        case 'recent': // 多任务键
            keyCode = 187;
            break;
        case 'back': // 返回键
            keyCode = 4;
            break;
        default:
            console.error('Invalid key type.');
            return;
    }

    exec(`${adbPath} shell input keyevent ${keyCode}`, (error) => {
        if (error) {
            console.error(`Press ${key} key failed: ${error.message}`);
        } else {
            console.log(`Press ${key} key executed successfully.`);
        }
    });
}

function tap(x, y) {
    const adbPath = getResourcePath('adb');
    exec(`${adbPath} shell input tap ${x} ${y}`, (error) => {
        if (error) {
            console.error(`Tap failed at (${x}, ${y}): ${error.message}`);
        } else {
            console.log(`Tap executed successfully at (${x}, ${y}).`);
        }
    });
}





const { openVCB, executeVCB2 } = require("./AAVCB.js");

ipcMain.handle("VCB", async (event, args) => {
    try {
        await openVCB(logWindow, args['android_id']);
        console.log("openVCB executed successfully");

        // First async function
        await jianting(args['android_id']);
        console.log("jianting executed successfully");




    } catch (error) {
        console.error("An error occurred:", error);
    }
});




ipcMain.handle("VCB2", async (event, { android_id, click_positions }) => {
    return executeVCB2(android_id, click_positions);
});



const { bidvLogin, bidvBank, bidvAccount, bidvMima, bidvMoney, bidvjianting } = require("./AABIDV.js");


ipcMain.handle("BIDV_jianting", async (event, args) => {
    await bidvjianting(logWindow, args);
});


ipcMain.handle("BIDV", async (event, args) => {
    await bidvLogin(logWindow, args);
});

ipcMain.handle("BIDV_zhuanzang", async (event, args) => {
    await bidvBank(logWindow, args);
});

ipcMain.handle("BIDV_zhuanzang1", async (event, args) => {
    await bidvAccount(logWindow, args);
});

ipcMain.handle("BIDV_zhuanzang2", async (event, args) => {
    await bidvMoney(logWindow, args);
});

ipcMain.handle("BIDV_zhuanzang3", async (event, args) => {
    await bidvMima(logWindow, args);
});




const { AGRIlogin, AGRIBank, AGRIzhanghao, AGRIMoney, AGRIMima, AGRIjianting } = require("./AAGRI.js");


ipcMain.handle("AGRI_jianting", async (event, args) => {
    await AGRIjianting(logWindow, args);
});


ipcMain.handle('AGRI', async (event, args) => {
    await AGRIlogin(logWindow, args);
});

ipcMain.handle('AGRI1', async (event, args) => {
    await AGRIBank(logWindow, args);
});


ipcMain.handle('AGRI2', async (event, args) => {
    await AGRIzhanghao(logWindow, args);
});


ipcMain.handle('AGRI3', async (event, args) => {
    await AGRIMoney(logWindow, args);
});

ipcMain.handle('AGRI4', async (event, args) => {
    await AGRIMima(logWindow, args);
});




const { vtbLogin, vtbEnterAmount, vtbEnterVerificationCode, executeVTB3 } = require("./AAVTB.js");
const { log } = require('console');

ipcMain.handle("VTB", async (event, args) => {
    await vtbLogin(logWindow, args);
});

ipcMain.handle("VTB1", async (event, args) => {
    await vtbEnterAmount(logWindow, 0, args);
});

ipcMain.handle("VTB11", async (event, args) => {
    await vtbEnterAmount(logWindow, 1, args);
});


ipcMain.handle("VTB2", async (event, args) => {
    await vtbEnterVerificationCode(logWindow, args);
});


ipcMain.handle("VTB3", async (event, args) => {
    await executeVTB3(logWindow, args);
});


const jianting = async (android_id) => {

    return new Promise((resolve, reject) => {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            config("❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp; // 获取设备 ID

        // 判断是否是打包环境
        const isProduction = app.isPackaged;

        // 根据环境设置路径
        const scriptPath = isProduction
            ? path.resolve(__dirname, "../ziyuan/main.exe")  // 生产环境
            : path.join(__dirname, "/resources/ziyuan/main.exe");

        console.log(scriptPath)
        // 运行可执行文件，并将 deviceId 作为参数传递给 main.exe
        const pythonProcess = spawn(scriptPath, ["jianting", android_id, deviceId]);

        let outputData = "";
        let errorData = "";

        // 监听标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();
            logMessage(`${message}`);
            outputData += message + "\n";
        });

        // 监听标准错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            logMessage(`${errorMessage}`);
            errorData += errorMessage + "\n";
        });

        // 监听进程结束
        pythonProcess.on("close", (code) => {
            if (code === 0) {
                logMessage(`${outputData}`);
                resolve(outputData.trim());
            } else {
                logMessage(`${errorData}`);
                reject(new Error(`失败代码 ${code}: ${errorData}`));
            }
        });

        // 监听进程启动失败
        pythonProcess.on("error", (err) => {
            logMessage(`失败: ${err.message}`);
            reject(new Error(`失败: ${err.message}`));
        });

    });
};