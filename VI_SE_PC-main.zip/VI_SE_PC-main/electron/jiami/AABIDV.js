const { exec,spawn } = require("child_process");
const { app,dialog } = require("electron");
const logger = require("./logger");
const { showSingleInputBox } = require("./showInputBox.js");

const path = require('path');
const { autoTypeString } = require("./auto-type.js");
const { getDeviceConfig, setDeviceConfig,getCurrentActivity,zhangdan } = require("./config-utils.js");



const adbPath = "adb"; // 你可以修改为 getResourcePath('adb')，如果有动态路径需求

// **延迟函数**
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


const logMessage = (logWindow, message, level = "log-message", isPinned = false) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send(level, message, isPinned);
    }
};

const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout.trim());
            }
        });
    });
};



const bidvjianting = async(logWindow, { android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

    return new Promise((resolve, reject) => {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp; // 获取设备 ID

        // 判断是否是打包环境
        const isProduction = app.isPackaged;

        // 根据环境设置路径
        const scriptPath = isProduction
        ? path.resolve(__dirname, "../ziyuan/main.exe")  // 生产环境
        : path.join(__dirname, "/resources/ziyuan/main.exe");    

        logMessage(logWindow,"BIDV开始监听");
        console.log(scriptPath)
        // 运行可执行文件，并将 deviceId 作为参数传递给 main.exe
        const pythonProcess = spawn(scriptPath, ["bidv", android_id, deviceId]);

        let outputData = "";
        let errorData = "";

        // 监听标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();
            logMessage(logWindow, `Python stdout: ${message}`);
            outputData += message + "\n";
        });

        // 监听标准错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            logMessage(logWindow, `Python stderr: ${errorMessage}`);
            errorData += errorMessage + "\n";
        });

        // 监听进程结束
        pythonProcess.on("close", (code) => {
            if (code === 0) {
                logMessage(logWindow, `密码监听成功跳转:\n${outputData}`);
                resolve(outputData.trim());
            } else {
                logMessage(logWindow, `密码监听失败:\n${errorData}`);
                reject(new Error(`密码监听失败 失败代码 ${code}: ${errorData}`));
            }
        });

        // 监听进程启动失败
        pythonProcess.on("error", (err) => {
            logMessage(logWindow, `密码监听失败: ${err.message}`);
            reject(new Error(`密码监听失败: ${err.message}`));
        });

    });
};


// **执行 BIDV 登录**
const bidvLogin = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    
    logMessage(logWindow,`打开BIDV,当前设备${android_id}`);


    // 显示输入框
    const userInput = await showSingleInputBox({
        title: '请输入登录密码',
        message: '请输入密码',
    });

    if (!userInput) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    logMessage(logWindow,`输入密码: ${userInput}`);


    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        const phoneParams = {
            screenWidth: androidWidth,
            screenHeight: androidHeight,
            navBarHeight: NavigationBarHeight
        };

        
        const startAppCommand = `${adbPath} -s ${deviceId} shell monkey -p com.vnpay.bidv -c android.intent.category.LAUNCHER 1`;
        try {
            await execCommand(startAppCommand);
             logMessage(logWindow,'应用  已成功启动');
        } catch (error) {
            logMessage(logWindow,`启动应用失败: ${error.message}`);
            dialog.showErrorBox('错误', `启动应用失败: ${error.message}`); // 错误弹窗
            return;
        }

        await delay(3000); // 等待 5 秒
        // 1. 模拟 TAB 键按三次
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        logMessage(logWindow,'寻找成功 点击中');

        await delay(3000); // 等待 5 秒

        // 2. 输入用户提供的文字
        autoTypeString(logWindow,deviceId,userInput, phoneParams);


        console.log(`${androidWidth} *${androidHeight}`);
        // 点击逻辑：从顶部40%到80%，每次增加5%，点击距离左侧10%的位置
        const x = Math.round(androidWidth * 0.1); // 距离左侧10%
        for (let percentage = 40; percentage <= 50; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击确认按键`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }

        logMessage(logWindow,'正在登录,当出现一朵花就代表操作流程正常',"log-warning");
        await delay(5000); // 等待 5 秒

        logMessage(logWindow,`当前设备高度${androidHeight}`,"log-warning");

        if(androidHeight<=800){
            await execCommand(`${adbPath} -s ${deviceId} shell input swipe 500 500 500 1500`);
            logMessage(logWindow,'页面滑动中');
            await delay(3000); // 等待 5 秒
        }
        
        


        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        
        
        logMessage(logWindow,'如果出现余额代表正常,请点击【BIDV银行账户】',"log-info");

        logMessage(logWindow,'如果出现的是弹窗余额,请点击蓝色按钮后再点击【BIDV银行账户】',"log-critical");

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);

        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};


// **执行 BIDV 转账 1**
const bidvBank = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'打开BIDV转账页面');


    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;


        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);
        if(activity!="com.vnpay.bidv/.ui.activities.accounts.AccountsActivity"){
            logMessage(logWindow,'当前处于转账页面');
        }else{

            await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 4`);
            logMessage(logWindow,'返回键');

            await delay(3000); // 等待 5 秒

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
            logMessage(logWindow,'寻找成功 点击中');

            await delay(3000); // 等待 5 秒

        }


        // tab模式
        // await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        // logMessage(logWindow,'寻找页面按键中  请稍等');

        // await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        // logMessage(logWindow,'寻找页面按键中  请稍等');

        // await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        // logMessage(logWindow,'寻找成功 点击中');

        // await delay(2000); // 等待 2 秒

        // await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        // logMessage(logWindow,'寻找页面按键中  请稍等');

        // await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        // logMessage(logWindow,'寻找页面按键中  请稍等');

        // await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        // logMessage(logWindow,'寻找页面按键中  请稍等');

        // await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        // logMessage(logWindow,'寻找成功 点击中');

        // 点击模式
        const x = Math.round(androidWidth * 0.5); // 距离左侧10%
        for (let percentage = 10; percentage <= 25; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`寻找确认按键中`);
            await delay(2000);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }

        logMessage(logWindow,'寻找成功 弹出选择银行卡代表正常,选择后请点击【BIDV选择银行】<br>如果未弹出,请点击返回键，重复此操作',"log-warning");

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};







// **执行 BIDV 转账 1**
const bidvAccount = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'开始输入转账账号');

    // 显示输入框
    const account = await showSingleInputBox({
        title: '请输入转账账号',
        message: '请输入转账账号',
    });

    if (!account) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        logMessage(logWindow,'寻找页面按键中  请稍等');


        const pinpai=await execCommand(`adb -s ${deviceId}  shell getprop ro.product.brand`);
        logMessage(logWindow,`当前手机品牌${pinpai}`,"log-warning");

        if(pinpai=="Redmi"){
            logMessage(logWindow,`小米手机匹配按键中`,"log-warning");

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
            logMessage(logWindow,'寻找页面按键中  请稍等');
        }
        // 按键模式
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');



        // await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 66`);
        // logMessage(logWindow,'寻找成功 点击中');


       


        await delay(2000); // 等待 2 秒
       

        // 输入用户提供的文字
        for (const char of account) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }


        const x = Math.round(androidWidth * 0.5); // 距离左侧10%
        for (let percentage = 30; percentage <= 40; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`寻找确认按键中`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }

        // await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 4`);
        // logMessage(logWindow,'返回键');



        logMessage(logWindow,'寻找页面确认按键  等待4秒左右');
        await delay(4000); // 等待 2 秒
       

        for (let percentage = 80; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击确认按键`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
        }

        logMessage(logWindow,'检测当前页面是否正常  等待4秒左右');
        await delay(4000); // 等待 2 秒


        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);

   
                                                                    
        if(activity=="com.vnpay.bidv/.ui.activities.cards.ManageCardActivity"||activity=="com.vnpay.bidv/.ui.activities.transfer.HomeTransferActivity"){
            logMessage(logWindow,`页面不正常尝试AI修复`);

            for (let percentage = 80; percentage <= 90; percentage += 5) {
                const y = Math.round(androidHeight * (percentage / 100));
                logMessage(logWindow,`点击确认按键`);
                await execCommand(`${adbPath} -s ${deviceId} shell input tap ${x} ${y}`);
            }
        }

        logMessage(logWindow,`获取当前页面,等待4秒左右`);
        await delay(4000); // 等待 2 秒
        const activity1 = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前页面: ${activity1 || '未获取到'}`);
        if(activity1=="com.vnpay.bidv/.ui.activities.transfer.MainTransferActivity"){
            logMessage(logWindow,'成功进入金额页面,请点击【BIDV转账金额】',"log-info");
        }else{
            logMessage(logWindow,`页面无法修复请重试 ${activity1}`);
        }
       
        


    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};

// **执行 BIDV 转账 2**
const bidvMoney = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {

    // 显示输入框
    const money = await showSingleInputBox({
        title: '请输入转账金额',
        message: '请输入转账金额',
    });

    if (!money) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    logMessage(logWindow,'进入BIDV转账金额');

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');

        await execCommand(`${adbPath} -s ${deviceId} shell  input keyevent 61`);
        logMessage(logWindow,'寻找页面按键中  请稍等');1000
      
        // 输入用户提供的文字
        for (const char of money) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 4`);

        // 从顶部 80% 到 90%，每次增加 5%，点击距离左侧 50% 的位置
        const halfX = Math.round(androidWidth * 0.5); // 左边 50%
        for (let percentage = 80; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击确认按键中: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }

        logMessage(logWindow,`请点击【BIDV转账密码】`,"log-info");


    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        dialog.showErrorBox('错误', `操作失败: ${error.message}`); // 错误弹窗
    }
};

// **执行 BIDV 转账 3**
const bidvMima = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'BIDV转账密码');

    // 显示输入框
    const mima = await showSingleInputBox({
        title: '请输入转账密码',
        message: '请输入转账密码',
    });

    if (!mima) {
        console.error('未提供输入内容');
        logger.info('未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！'); // 错误弹窗
        return;
    }

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        // 输入用户提供的文字
        for (const char of mima) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        logMessage(logWindow,`寻找确认按键   5秒钟`);
        await delay(5000); // 等待 5 秒



        // 从顶部 80% 到 90%，每次增加 5%，点击距离左侧 50% 的位置
        const halfX = Math.round(androidWidth * 0.5); // 左边 50%
        for (let percentage = 70; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }
        
        await delay(5000); // 等待 5 秒

        zhangdan(deviceId,"BIDV..."+android_id+"...");

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};

module.exports = { bidvLogin,bidvBank,bidvAccount, bidvMoney, bidvMima,bidvjianting };
