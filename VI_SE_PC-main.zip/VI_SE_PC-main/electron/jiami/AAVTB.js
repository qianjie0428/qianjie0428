const { exec, spawn } = require('child_process');
const path = require('path');
const { app,dialog } = require("electron");
const logger = require("./logger.js");

const { showSingleInputBox } = require("./showInputBox.js");
const { autoTypeString } = require("./auto-type.js");
const { getDeviceConfig, setDeviceConfig,getCurrentActivity,zhangdan } = require("./config-utils.js");



const adbPath = "adb"; // 确保你的 ADB 路径正确

// **延迟函数**
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const execCommand = async (command, logger) => {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout.trim());
            }
        });
    });
};

const logMessage = (logWindow, message, level = "log-message", isPinned = false) => {
    if (logWindow && logWindow.webContents) {
        logWindow.webContents.send(level, message, isPinned);
    }
};



// **执行 Python 脚本 VTB3**
const executeVTB3 = async(logWindow, { android_id }) => {
    // 先打印一下收到的参数，便于调试
    console.log(`VTB3 Received android_id: ${android_id}`);

    return new Promise((resolve, reject) => {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp; // 获取设备 ID
        // 判断是否是打包环境
        const isProduction = app.isPackaged;
        
        const scriptPath = isProduction
                ? path.resolve(__dirname, "../ziyuan/main.exe")  // 生产环境
                : path.join(__dirname, "/resources/ziyuan/main.exe");    

        logMessage(logWindow,"开始监听");
        // 运行可执行文件，并将 deviceId 作为参数传递给 main.exe
        const pythonProcess = spawn(scriptPath, ["vtb", android_id, deviceId]);

        let outputData = "";
        let errorData = "";

        // 监听标准输出
        pythonProcess.stdout.on("data", (data) => {
            const message = data.toString().trim();
            logMessage(logWindow, `Python stdout: ${message}`);
            outputData += message + "\n";
        });

        // 监听标准错误输出
        pythonProcess.stderr.on("data", (data) => {
            const errorMessage = data.toString().trim();
            logMessage(logWindow, `Python stderr: ${errorMessage}`);
            errorData += errorMessage + "\n";
        });

        // 监听进程结束
        pythonProcess.on("close", (code) => {
            if (code === 0) {
                logMessage(logWindow, `密码监听成功跳转:\n${outputData}`);
                resolve(outputData.trim());
            } else {
                logMessage(logWindow, `密码监听失败:\n${errorData}`);
                reject(new Error(`密码监听失败 失败代码 ${code}: ${errorData}`));
            }
        });

        // 监听进程启动失败
        pythonProcess.on("error", (err) => {
            logMessage(logWindow, `密码监听失败: ${err.message}`);
            reject(new Error(`密码监听失败: ${err.message}`));
        });

    });
};

// **VTB 登录**
const vtbLogin = async (logWindow,{ android_id,androidWidth, androidHeight, StatusBarHeight, NavigationBarHeight }) => {
    logMessage(logWindow,'VTB登录');

    // 显示输入框
    const userInput = await showSingleInputBox({
        title: '请输入登录内容',
        message: '请输入内容',
    });

    if (!userInput) {
        logMessage(logWindow,'未提供输入内容');
    
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    logMessage(logWindow,`输入内容: ${userInput}`);
 
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);

        await delay(2000); // 等待 2 秒

        const phoneParams = {
            screenWidth: androidWidth,
            screenHeight: androidHeight,
            navBarHeight: NavigationBarHeight
        };


        autoTypeString(logWindow,deviceId,userInput, phoneParams);

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.1); // 左边 50%

        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 66`);

        logMessage(logWindow,`成功跳转页面后,点击【Chuyển tiền】,选择银行,输入卡号,点击确定后,再点击【VTB转账金额】`,"log-info");

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
        
    }
};

// **VTB 输入金额**
const vtbEnterAmount = async (logWindow,more,{ android_id,androidWidth, androidHeight }) => {

    // 显示输入框
    const money = await showSingleInputBox({
        title: '请输入转账金额',
        message: '请输入内容',
    });

    if (!money) {
     
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }


    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        if(more==1){
            logMessage(logWindow,'转账金额2模式',"log-warning");

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 61`);
        }
        await delay(2000); // 等待 2 秒

        // 2. 输入用户提供的文字
        for (const char of money) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.5); // 左边 50%
        const y = Math.round(androidHeight * 0.2);
        // await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);

        // for (let percentage = 10; percentage <= 20; percentage += 5) {
        //     const y = Math.round(androidHeight * (percentage / 100));
        //     console.log(`点击坐标: (${halfX}, ${y})`);
        //     await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        // }
        await execCommand(`${adbPath}  -s ${deviceId} shell input keyevent 4`);




        await delay(2000); // 等待 2 秒

        for (let percentage = 70; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            console.log(`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }


        logMessage(logWindow, "检测当前页面是否正常，知否进入");
        await delay(4000);
        
        const activity = await getCurrentActivity(deviceId);
        logMessage(logWindow,`当前 Activity: ${activity || '未获取到'}`);
        if(activity=="com.vietinbank.ipay/.activity.finances.transfers.InitTransferActivity"){
            logMessage(logWindow,'❌ 当前仍处于转账页面，当前转账按钮不生效，请点击【返回键】重新进入，点击【VTB转账金额2】按钮',"log-critical");

            await execCommand(`${adbPath} -s ${deviceId} shell input keyevent 4`);

        }else{
            if(activity=="com.vietinbank.ipay/com.vnpay.ekyc.ui.activity.EKYCFacePayActivity"){
                logMessage(logWindow,'当前处于人脸识别页面,请进行人脸识别',"log-warning");
            }
        }

        logMessage(logWindow,'人脸识别后,如果没有转账密码,点击【VTB转账密码】则随便输入即可',"log-warning");
        // com.vietinbank.ipay/.activity.finances.transfers.InitTransferActivity
    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};

// **VTB 输入验证码**
const vtbEnterVerificationCode = async (logWindow,{ android_id, androidWidth, androidHeight }) => {
    // 显示输入框
    const yzm = await showSingleInputBox({
        title: '请输入验证码',
        message: '请输入内容',
    });

    if (!yzm) {
        logMessage(logWindow,'未提供输入内容');
        dialog.showErrorBox('错误', '未提供输入内容，请重新操作！');
        return;
    }

    logMessage(logWindow,`输入内容: ${yzm}`);

    try {

        const config = getDeviceConfig(android_id);

        if (!config || !config.connectIp) {
            logMessage(logWindow, "❌ 设备未找到，请检查配置！");
            return;
        }

        const deviceId = config.connectIp;

        // 2. 输入用户提供的文字
        for (const char of yzm) {
            await execCommand(`${adbPath} -s ${deviceId} shell input text ${char}`);
            logMessage(logWindow,`输入字符 ${char} 成功`);
        }

        await delay(2000); // 等待 2 秒

        const halfX = Math.round(androidWidth * 0.5); // 左边 50%

        for (let percentage = 70; percentage <= 90; percentage += 5) {
            const y = Math.round(androidHeight * (percentage / 100));
            logMessage(logWindow,`点击坐标: (${halfX}, ${y})`);
            await execCommand(`${adbPath} -s ${deviceId} shell input tap ${halfX} ${y}`);
        }

        await delay(5000); // 等待 5 秒
        zhangdan(deviceId,"VTB..."+android_id+"...");

    } catch (error) {
        logMessage(logWindow,`操作失败: ${error.message}`);
    }
};

module.exports = { vtbLogin, vtbEnterAmount, vtbEnterVerificationCode,executeVTB3 };
