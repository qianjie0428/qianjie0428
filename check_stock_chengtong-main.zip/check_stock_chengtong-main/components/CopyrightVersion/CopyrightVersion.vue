<template>
	<view style="display: flex;align-items: center;justify-content: center;" :style="{color:color}">
		<view>{{copyright}}</view>
		<view style="padding-left: 40px;">{{version}}</view>
	</view>
</template>

<script>
	export default {
		name: "CopyrightVersion",
		props: {
			color: {
				type: String,
				default: '',
			}
		},
		computed: {
			copyright() {
				return this.$APP_NAME + ` © ` + this.$fmt.setToYear()
			},
			version() {
				return this.$fmt.fmtText(this.$msg.COMMON_VERSION) + ` ` + this.$VERSION
			},
		},
		beforeMount() {},
	}
</script>

<style>

</style>