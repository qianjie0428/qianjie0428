<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');
			uni.hideTabBar();
		},
		onShow: function() {
			console.log('App Show');
			uni.hideTabBar();
		},
		onHide: function() {
			console.log('App Hide');
			uni.hideTabBar();
		}
	}
</script>

<style lang="scss">
	@import "@/node_modules/uview-ui/index.scss";
	@import "@/common/animate.css";
	@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@100..900&display=swap');
	@import "@/common/style.css";
	@import "@/common/rc.css";
	// @media screen and (max-device-width:375px) {
	// 	page {
	// 		width: 100vw;
	// 	}
	// }

	// @media screen and (min-device-width:376px) and (max-device-width:750px) {
	// 	page {
	// 		width: 100vw;
	// 		margin: 0 auto;
	// 	}
	// }

	// @media screen and (min-device-width:751px) {
	// 	page {
	// 		width: 750px;
	// 		margin: 0 auto;
	// 	}
	// }

	* {
		font-family: "Noto Sans SC", "Roboto", Arial, sans-serif;
		font-optical-sizing: auto;
		font-style: normal;
		box-sizing: border-box;
	}
</style>