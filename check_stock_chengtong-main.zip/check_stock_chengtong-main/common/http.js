import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import md5 from '@/common/md5.min.js';
import { translate } from '@/localize/index.js';
import { Msg, } from '@/localize/index.js';

import * as mock from '@/common/mock.js';
import fmt from '../format';


// 测速的 api域名组。
export const APIS = [
	{ url: `api.cggerstop.top`, name: "上海移动", },
	{ url: `api.lgpstock.top`, name: "广州电信" },
	{ url: `api.germanystock.top`, name: "北京联通" }
];

// 测试API域名的响应时间
export const testAPI = async (val) => {
	const startTime = Date.now();
	const response = await uni.request({
		url: `https://${val.url}/api/app/config`,
		method: 'HEAD'
	});
	const [err, res] = response;
	console.log(`testAPI:`, err, res);
	if (res) {
		const duration = Date.now() - startTime; // 计算时间
		return { url: val.url, name: val.name, duration }
	}
	// 失败返回无限大
	if (err) return { url: val.url, name: val.name, duration: Infinity }
}

// 批量测试所有API域名
export const testAPIS = async () => {
	const apiTests = await APIS.map(v => testAPI(v));
	const apiResult = await Promise.all(apiTests); // 等待所有测试完成
	console.log(`testAPIS:`, apiTests, apiResult);

	const temp = apiResult.filter(v => v.duration != Infinity);
	const tempBest = temp.reduce((prev, current) =>
		(prev.duration < current.duration) ? prev : current);

	const bestAPI = getCurHost().length > 0 ? temp.filter(v => v.url === getCurHost())[0] : tempBest;
	setCurHost(bestAPI.url);
	console.log(bestAPI)
	return {
		results: temp.sort((a, b) => a.duration - b.duration),
		best: bestAPI,
	};
}

// 设置当前API域名
export const setCurHost = (val = '') => {
	uni.setStorageSync('host', val);
}
// 获取当前API域名
export const getCurHost = () => {
	return uni.getStorageSync('host');
}

// export const HOST = `api.capitalgrou.top`.trim();
// export const HOST = `api.jxwqstop.top`.trim();
// export const HOST = `api.germanystock.top`.trim();
// export const HOST = getCurHost();

export const BASE_URL = () => { return `https://${getCurHost()}`.trim() };
// export const WS_COIN_URL = `wss://ws.bxcoinws.top/ws`; // coin
export const WS_OTHER_URL = () => { return `wss://${getCurHost()}/zonghe`.trim() }; // 币

const CODE = "Qwd3N5yp";

// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;
		return true;
	} catch (err) {
		throw err
	}
}

export async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();
	if (!result) {
		return {
			message: translate(Msg.API_NETWORKNO)
		};
	} else {
		// console.log('url:', url, 'params:', params);
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": uni.getStorageSync('locale') || 'en', // 'zh-Hans'
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();
		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);
		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL()}/${url}?sign=${mdd}&t=${time}`;
		try {
			const response = await uni.request({
				url: `${fmtAPIURL}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});
			uni.hideLoading();
			const [err, res] = response;
			console.log('err:', err, 'res:', res);

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					uni.removeStorageSync('token'); // 只移除token的缓存
					uni.showToast({
						title: translate(Msg.API_TOKEN_EXPIRES),
						icon: 'none'
					})
					setTimeout(() => {
						linkTo.signIn();
					}, 1000);
					return null;
				}
				// console.log('res:', res);
				// console.log('res.data:', res.data);
				if (res.data) {
					// console.log('res.data:', res.data);
					if (res.data.code == 0) {
						// console.log('res.data.data:', res.data.data);
						return res.data.data || null;

					} else {
						uni.showToast({
							title: !res.data.message ? res.message : res.data.message,
							icon: 'none'
						})
						return null;
					}
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: err.errMsg || translate(Msg.API_HTTP_ERROR),
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
export const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

export const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}


// 图片上传
export async function uploadImage(val) {
	// console.log(val)
	uni.showLoading({
		title: translate(Msg.API_UPLOAD),
	})
	let Request = "Qwd3N5yp"
	let time = parseInt(new Date().getTime() / 1000)
	let str_url = ("/api/app/upload").toLowerCase()
	let mdd = md5("XPFXMedS" + Request + str_url + time);

	const result = await uni.uploadFile({
		url: BASE_URL() + '/api/app/upload?t=' + time + "&sign=" + mdd,
		filePath: val,
		name: 'file',
	});
	// console.log('result:', result);
	uni.hideLoading();
	if (result[1].statusCode == 200) {
		const temp = JSON.parse(result[1].data);
		// console.log('temp:', temp);
		// this.obverseUrl = temp[0].url;
		return temp[0].url;
	} else {
		return null;
	}
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
});

// 获取配置
export const getConfig = async () => {
	const result = await get(`api/app/config`);
	console.log(`config result:`, result);
	return result.reduce((map, item) => {
		map.set(item.key, item.value);
		return map;
	}, new Map());
}

// 完整账户信息
export const getAccount = async () => {
	const result = await get(`api/user/info`);
	if (!result) return false;
	return result;
}

// 精简账户信息
export const getAccountFast = async () => {
	const result = await get(`api/user/fastInfo`);
	if (!result) return false;
	return result;
}

//  热点资讯
export const getNews = async (val = 0) => {
	const result = await get(`api/goods/get_news`, {
		current: val
	});
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(v => {
		return {
			title: v.title,
			url: v.url,
			dt: v.created_at,
			pic: v.pic,
			origin: ``, // 21世纪经济报道
			read: v.count_read * 1 || 0,
		}
	});
};


export const getGoodsList = async (gpindex = '', count = 0, data = {}) => {
	const result = await get(`api/goods/list`, {
		gp_index: constants.GPINDEX[gpindex],
		...data,
	});
	if (!result) return null;
	// console.log(result, fmt.getLgre(gpindex));
	const temp = result.length <= 0 ? [] : result.map(v => {
		return {
			gid: v.gid,
			name: v.name,
			code: v.code,
			price: v.current_price * 1 || 0,
			rate: v.rate * 1 || 0,
			rateNum: v.rate_num * 1 || 0,
			amount: v.cj_amount * 1 || 0,
			amount1: v.trans_amount * 1 || 0,
			amount2: 0,
			lgre: fmt.getLgre(constants.GPINDEX[gpindex]),
			line: count > 0,
			totalRate: 0,
			online: ``,
		}
	});
	if (!count || count <= 0) return temp;
	return temp.length > 0 && temp.length <= count ? temp : temp.slice(0, count);
}

// 业绩大全
export const getPERMarket = async () => {
	const result = await get(`api/app/market_list`);
	if (!result) return null;
	// console.log(result);
	return Object.entries(result).map(([key, value]) => ({ key: value, value: key }));
}

export const getPERQuarter = async () => {
	const result = await get(`api/app/jidu_list`);
	if (!result) return null;
	// console.log(result);
	return Object.entries(result).map(([key, value]) => ({ key: value, value: key }));
}

export const getPERType = async () => {
	const result = await get(`api/app/yj_sort`);
	if (!result) return null;
	// console.log(result);
	return Object.entries(result).map(([key, value]) => ({ key: value, value: key }));
}

export const getPERList = async (url, data) => {
	console.log(data);
	const result = await get(url, data);
	if (!result) return null;
	console.log(result);
	return result.map(v => {
		return {
			code: v.code,
			name: v.name,
			type: v.predict_type || '',
			rateLow: v.low_rate,
			rateUp: v.up_rate,
			dt: v.date,
			total: v.yingli_total / 100000000 || 0,
			subDT: v.yuyue_date || '',
			// stockType: v.stock_type || '',
			market: v.market || '',
		}
	})
}

export const getStockDetail = async (symbol, gid, line) => {
	uni.showLoading({
		title: Msg.API_REQUEST_DATA,
	})
	const result = await get(`api/product/info`, {
		code: symbol,
		gid: gid,
		time_index: line
	});
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? null :
		!result[0].gid ? null : result[0];
}

// 获取当前crypto kline历史数据
export const getKlineData = async (symbol, line, type) => {
	const result = await get(`api/product/lishi`, {
		code: symbol,
		ac_time: line,
		project_type_id: type,
	})
	if (!result) return false;
	// result.forEach(item => {
	// 	item.volume = item.vol || 0;
	// })
	return result;
}

// ===================================================

export const getIPOAlert = async () => {
	const result = await get(`api/goods-shengou/tanchuang`);
	if (!result) return false;
	console.log(result);
	if (result.length <= 0) return null;
	return {
		code: result[0].goods.code, // BAKAB
		name: result[0].goods.name, // Ambalaj
		success: result[0].success, // 100
		price: result[0].price, // 100
		total: result[0].success_num_amount, // success_num_amount
	}
}



export const getDepositRecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/recharge`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc_type,
			sn: item.order_sn,
			// reason:item.reason,
			status: item.status,
			// 以下为接口中本不含有的字段
			after: item.after * 1 || 0,
			type: `银联`,

		}
	});
}

export const getWithdrawRecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/withdraw`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc_type,
			sn: item.order_sn,
			reason: item.reason,
			status: item.status,
			id: item.id,
			// 以下为接口中本不含有的字段
			after: item.after * 1 || 0,
			type: `银联`,
		}
	});
}

export const getWithdrawCancel = async (val) => {
	uni.showLoading({
		title: translate(Msg.API_SUBMITING),
	});
	const result = await post(`api/app/qx`, {
		id: val
	});
	if (!result) return false;
	console.log(result);
	return result;
}

export const getSearch = async (keyword = '', type) => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/product/list`, {
		key: keyword,
		page: 1,
		limit: 30,
		gp_index: type
	});
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(item => {
		if (item.gid && item.gid > 0) {
			return {
				id: item.gid,
				logo: item.logo || '',
				name: item.name || '',
				code: item.code || '',
				price: item.current_price || 0,
				rate: item.rate || 0,
				rateNum: item.rate_num || 0,
				type_id: item.project_type_id || 0,
			}
		}
	});
}

export const getTrack = async (val = 0) => {
	const result = await get(`api/user/collect_list`, {
		current: val
	});
	if (!result) return false;
	return result.list.map(item => {
		return {
			logo: item.goods.logo,
			name: item.goods.name,
			code: item.goods.code,
			price: item.goods.current_price * 1 || 0,
			rate: item.goods.rate * 1 || 0,
			rateNum: item.goods.rate_num || 0,
		}
	});
}

// =========================================
//       以下是模拟数据, 需联调接口数据
// ==========================================

// home 理财速递
export const getFinanceNews = async () => {
	const result = await mock.getFinanceNews();
	if (!result) return false;
	console.log(result);
	return result;
}

// 首页曲线图数据
export const getHomeCurves = async () => {
	const result = await mock.getHomeCurves();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 指数 市场概述
export const getKPIDashboardDetail = async () => {
	const result = await mock.getKPIDashboardDetail();
	if (!result) return false;
	console.log(result);
	return result;
}


// 市场 沪深 全市场
export const getHSALL = async () => {
	const result = await mock.getHSALL();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 顶部数据
export const getHSBest = async () => {
	const result = await mock.getHSBest();
	if (!result) return false;
	console.log(result);
	return result;
}

// 交易页面 最新数据
export const getLatests = async (val = '') => {
	console.log(val);
	const result = await mock.getLatests();
	if (!result) return false;
	console.log(result);
	return result;
}
// export const getRanking = async (val = '') => {
// 	console.log(val);
// 	const result = await mock.getRanking();
// 	if (!result) return false;
// 	console.log(result);
// 	return result;
// }

// // 资金流向
// export const getDashboard = async () => {
// 	const result = await mock.getDashboard();
// 	if (!result) return false;
// 	console.log(result);
// 	return result;
// }

// 次新股
export const getRecent = async () => {
	const result = await mock.getRecent();
	if (!result) return false;
	console.log(result);
	return result;
}

// // 大盘风向
// export const getTrend = async () => {
// 	const result = await mock.getTrend();
// 	if (!result) return false;
// 	console.log(result);
// 	return result;
// }

// 仅麒麟研报
export const getReport = async () => {
	const result = await mock.getReport();
	if (!result) return false;
	console.log(result);
	return result;
}

// 仅麒麟榜单 最佳&精英 (传参选中年份)
export const getReporeRanking = async (val = '') => {
	const result = await mock.getReporeRanking();
	if (!result) return false;
	console.log(result);
	return result;
}
// 仅麒麟研报 未来之星 (传参选中年份)
export const getReportStar = async (val = '') => {
	const result = await mock.getReportStar();
	if (!result) return false;
	console.log(result);
	return result;
}

// 持仓 投资收益
export const getROI = async () => {
	const result = await mock.getROI();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 资金流向
export const getFundFlow = async () => {
	const result = await mock.getFundFlow();
	if (!result) return false;
	console.log(result);
	return result;
}

// 市场 沪深 涨幅分布详情数据
// export const getPMDDetail = async () => {
// 	const result = await mock.getPMDDetail();
// 	if (!result) return false;
// 	console.log(result);
// 	return result;
// }


// 市场通用页面列表数据
export const getMarketCommons = async (val = '') => {
	console.log(val);
	// 此处需根据传入的api，处理不同的接口请求，并将数据格式化为统一格式渲染
	const result = await mock.getMarketCommons();
	if (!result) return false;
	console.log(result);
	return result;
}









export const getGoodsTop = async (val = 0) => {
	const result = await get(`api/goods/top1`, {
		// current1: this.current1,
		// stockid: this.klineindex , stockId: 141,
	});
	console.log(result);
	return result;
	// this.top1 = result.top1 // 三个数据
	// this.article = result.article; // 8个新闻
	// this.industryList = result.bottom; // 16条数据
}



export const getStocks = async (val = 0) => {
	const result = await get(`api/goods/top1`, {
		// current: 0,
		gp_index: val,
	});
	if (!result) return false;
	const temp = result.top1.length <= 0 ? [] : result.top1.filter(item => item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.name,
			code: item.code,
			rate: item.rate * 1 || 0,
			price: item.current_price * 1 || 0,
			rateNum: item.rate_num * 1 || 0,
			type: item.project_type_id,
		}
	});
};

export const getPaiHang = async (val = 0) => {
	const result = await get(`api/goods/paihang`, {
		gp_index: val
	});
	console.log(result);
	if (!result) return false;
	const temp = result.length <= 0 ? [] : result.filter(item => item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.name,
			code: item.code,
			rate: item.rate * 1 || 0,
			price: item.current_price * 1 || 0,
			rateNum: item.rate_num * 1 || 0,
			type: item.project_type_id,
		}
	});
}

export const getMarketKPI = async (val = 0) => {
	const result = await get(`api/goods/zhibiao`, {
		current: val
	});
	if (!result) return false;
	const temp = Object.values(result).length <= 0 ? [] : Object.values(result).filter(item => item.gid > 0);
	return temp.map(item => {
		return {
			logo: item.logo,
			name: item.ko_name,
			code: item.code,
			price: item.close * 1 || 0,
			rate: item.returns * 1 || 0,
			follow: item.sc,
			gid: item.gid,
			close: item.close,
		}
	});
}



// export const getFuture = async (val = 0) => {
// 	const result = await get(`api/goods/zhibiao`, {
// 		current: val
// 	});
// 	if (!result) return false;
// 	return result;
// }



// export const getCurrency = async (val = 0) => {
// 	const result = await get(`api/goods/zhibiao`, {
// 		current: val
// 	});
// 	if (!result) return false;
// }

export const getNotifys = async (val = 0) => {
	// uni.showLoading({
	// 	title: format.text(i18n.t('api.requestData')),
	// });

	// const result =
	return [];
}

export const getFlowTrade = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/user/finance`);
	if (!result) return false;
	return result.length <= 0 ? [] : result.map(item => {
		return {
			after: item.after * 1 || 0,
			before: item.before * 1 || 0,
			money: item.money * 1 || 0,
			dt: item.created_at,
			desc: item.desc,
		}
	});
}



export const getAIApplys = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/rinei/sq-list`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			status: item.status,
			statusTxt: item.zt,
			money: item.money * 1 || 0,
			success: item.success * 1 || 0,
			dt: item.created_at,
			sn: item.ordersn,
		}
	});
}

export const getAISuccess = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/rinei/order-list`);
	if (!result) return false;
	console.log(result);
	return result.length <= 0 ? [] : result.map(item => {
		return {
			status: item.status,
			statusTxt: item.zt, // translate(Msg.COMMON_SUCCESS)
			price: item.price * 1 || 0,
			money: item.money * 1 || 0,
			success: item.success * 1 || 0,
			dt: item.created_at,
			sn: item.ordersn,
		}
	});
}

export const getEAGoods = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/jijin/list`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.jj_list.filter(item => item.id && item.id > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			id: item.id,
			name: item.name,
			minAmount: item.min_price * 1 || 0,
			fudu: item.fudu * 1 || 0,
			syl: item.syl * 1 || 0,
			days: item.zhouqi * 1 || 0,
		}
	});
}

export const getEARecord = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/jijin/list`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.order.filter(item => item.id && item.id > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			id: item.id,
			name: item.goodname,
			price: item.price * 1 || 0,
			fudu: item.fudu * 1 || 0,
			syl: item.syl * 1 || 0,
			days: item.zhouqi * 1 || 0,
			sdt: item.time || '',
			edt: item.endtime || '',
			fee: item.shouxu_fee || 0,
		}
	});
}

export const getScrambleGoods = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	// api/goods-scramble/calendar
	const result = await get(`api/goods-scramble/calendar`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	// return !temp || temp.length <= 0 ? [] : temp.map(item => {
	// 	return {
	// 		name: item.goods.name,
	// 		code: item.goods.code,
	// 		id: item.id,
	// 		price: item.price * 1 || 0,
	// 		issuanceAmount: item.fa_amount * 1 || 0,
	// 		type: item.goods.project_type_id,
	// 	}
	// });
	return [{
		id: 1,
		name: `巨轮智能`,
		code: `sz002031`,
		price: 44378.43,
		rate: 36.79,
		rateNum: 153.79,
		dt: `2024-01-20`,
		type: 1
	}, {
		id: 1,
		name: `巨轮智能`,
		code: `sz002031`,
		price: 44378.43,
		rate: -36.79,
		rateNum: 153.79,
		dt: `2024-01-20`,
		type: 1
	}];
}


export const getScrambleApplys = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goodsscramble/userApplyLog`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			id: item.id,
			price: item.scramble.price || 0,
			applyAmount: item.apply_amount * 1 || 0,
			success: item.success * 1 || 0,
			total: item.total * 1 || 0,
			sn: item.order_sn,
			dt: item.created_at,
			type: item.goods.project_type_id,
		}
	});
}

export const getScrambleSuccess = async () => {
	uni.showLoading({
		title: translate(Msg.API_REQUEST_DATA),
	})
	const result = await get(`api/goods-shengou/user-success-log`);
	if (!result) return false;
	console.log(result);
	const temp = !result || result.filter(item => item.gid && item.gid > 0);
	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			name: item.goods.name,
			code: item.goods.code,
			id: item.id,
			price: item.price * 1 || 0,
			applyAmount: item.apply_amount * 1 || 0,
			winning: item.success_num_amount * 1 || 0,
			success: item.success * 1 || 0,
			sn: item.order_sn,
			dt: item.created_at,
			type: item.goods.project_type_id,
		}
	});
}