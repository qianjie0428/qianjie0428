// constants.js 常量。 全局唯一硬编码
// use  $C.DARK or Vue.prototype.$C

// market/index  api/goods/list 所需
export const GPINDEX = {
	// rise: 1, // 涨幅
	// fall: 2, // 跌幅
	// inflow: 3, // 主力净流入
	// vol: 4, // 成交额

	sa: 1, // 深A股
	ha: 2, // 沪A股
	hk: 3, // 港股
	us: 4, // 美股
	hkindi: 5, // 港指
	usindi: 6, // 美指
	future: 7, // 美股期货
	hsjblock: 8, // 沪深京板块
	hsetfh: 9, // 沪深通ETF(沪股)
	hsetfs: 10, // 沪深通ETF(深股)
	gem: 11, // 创业板
	stb: 12, // 科创板
	hsindi: 13, // 沪深指
	iporecent: 14, // 次新股
	usetf: 13, // 美股ETF
	usblock: 14, // 美股板块
};

export const KEY_RISE = `rise`;
export const KEY_FALL = `fall`;
export const KEY_INFLOW = `inflow`;
export const KEY_VOL = `vol`;


export const US_GPINDEX = [3, 4, 5, 6, 7];
// export const HK_GPINDEX = [3, 5];

export const KEY_SA = `sa`; // 深A股
export const KEY_HA = `ha`; // 沪A股
export const KEY_HS = `hs`; // 滬深
export const KEY_INDI = `indi`; // 指數
export const KEY_HK = `hk`; // 港股
export const KEY_US = `us`; // 美股
export const KEY_HK_INDI = `hkindi`; // 港指
export const KEY_US_INDI = `usindi`; // 美指
export const KEY_FUTURE = `future`;
export const KEY_HSJ_BLOCK = `hsjblock`; // 沪深京板块
export const KEY_HSETF_H = `hsetfh`; // 沪深通ETF(沪股)
export const KEY_HSETF_S = `hsetfs`; // 沪深通ETF(深股)
export const KEY_GEM = `gem`; // 创业板
export const KEY_STB = `stb`; // 科创板
export const KEY_HS_INDI = `hsindi`; // 沪深指
export const KEY_IPO_RECENT = `iporecent`; // 次新股
export const KEY_US_ETF = `usetf`; // 美股ETF
export const KEY_US_BLOCK = `usblock`; // 美股板块
export const KEY_ALL = `all`; // 全市场

// position tabs
export const KEY_ROI = `roi`;
export const KEY_HOLD = `hold`;
export const KEY_RECORD = `record`;

export const KEY_GOODS = `goods`;
export const KEY_APPLY = `apply`;
export const KEY_SUCCESS = `success`;



export const KEY_MARKET_ALL = `all`;


export const KEY_US_PLATE = `plate`;

// 默认 语言
export const DEF_LANG = 'English';

export const KEY_LEFT = `left`;
export const KEY_RIGHT = `right`;

// 明文格式化模式 
// 标题或重要标签 每个单词首字母大写 （Title Case）
export const TITLE_CASE = "title";
// 一般描述文本 首个单词首字母大写 （Sentence Case）
export const SENTENCE_CASE = "sentence";

// 项目header的多种布局模式
export const HEADER_1 = `first`;
export const HEADER_2 = `second`;
export const HEADER_3 = `third`;

export const KEY_HOME = `home`;
export const KEY_MARKET = "market";
export const KEY_TRADE = `trade`;
export const KEY_POSITION = `position`;
export const KEY_ACCOUNT = `account`;

export const KEY_TAB_REPORT = `report`;
export const KEY_TAB_REPORTS = `reports`;
export const KEY_REPORT_TAB_BEST = `best`;
export const KEY_REPORT_TAB_ELITE = `elite`;
export const KEY_REPORT_TAB_STAR = `star`;

export const KEY_PER_TAB_HOME = `home`;
export const KEY_PER_TAB_FCST = `fcst`;
export const KEY_PER_TAB_QR = `qr`;
export const KEY_PER_TAB_PEND = `pend`;
export const KEY_PER_TAB_RELEASED = `Released`;
export const KEY_PER_HOME_ALL = `all`;
export const KEY_PER_HOME_TRACK = `track`;
export const KEY_PER_HOME_CPU = `cpu`;
export const KEY_PER_HOME_BJE = `bjexchange`;
export const KEY_PER_HOME_GEM = `gem`;
export const KEY_PER_HOME_ST = `st`;

// market key
export const KEY_INDEX = `index`;
export const KEY_RISELOSS = `riseloss`;
export const KEY_TRACK = `track`;

export const KEY_CURRENCY = `currency`;


export const KEY_DEPOSIT = `deposit`;
export const KEY_WITHDRAW = `withdraw`;


export const KEY_AUTH = `auth`;
export const KEY_BANK = `bank`;
export const KEY_PWD = `pwd`;
export const KEY_PAY = `pay`;
export const KEY_FLOW = `flow`;