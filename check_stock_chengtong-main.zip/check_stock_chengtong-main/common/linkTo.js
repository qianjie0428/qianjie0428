import * as constants from '@/common/constants.js';
import {
	checkToken
} from '@/common/util.js';

// 页面URL 以及跳转函数
export const PAGES = `/pages/`; // pages 部分

export const LAUNCH = `launch/index`; // 启动页
export const SERVICE = `service`; // 内联客服所需

// ============================================
export const SEARCH = `search/index`;
export const POSITION = `position/index`; // 持仓
export const FINANCIALS = `financials/index`; // 理财
export const ASSETS = `assets/index`; // 资产
export const TRADE_AI = `trade/ai/index`; // AI交易
export const TRADE_EA = `trade/ea/index`; // 基金
export const STOCK_INDEX = `stock/index`;

/**
 * @function 鉴权跳转
 * @description 用于设置需要检查token的跳转，如onShow，linkTo
 */
export const isAuth = () => {
	if (!checkToken()) {
		signIn();
		// return false;
	} else {
		return true;
	}
};

export const HOME = `launch/webview`; // 主页
export const home = () => {
	if (!isAuth()) return false;
	uni.reLaunch({
		url: PAGES + HOME,
	})
};

export const SIGN_IN = `signIn/index`; // 登入
export const signIn = () => {
	uni.reLaunch({
		url: PAGES + SIGN_IN
	})
};

export const SIGN_UP = `signUp/index`; // 登入
export const signUp = () => {
	uni.reLaunch({
		url: PAGES + SIGN_UP
	})
};

export const TERMS = `settings/terms`; // 用户隐私协议
export const terms = () => {
	uni.navigateTo({
		url: PAGES + TERMS,
	})
}

export const NOTIFY = `settings/notify`; // 消息通知
export const notify = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + NOTIFY,
	})
}

export const SETTINGS = `settings/index`; // 个人中心
export const settings = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SETTINGS,
	})
}

export const FEATURES = `features/index`;
export const features = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + FEATURES,
	})
}

export const MARKET = `markets/index`;
export const markets = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + MARKET,
	})
}

export const NEWS_HOT = `markets/news`;
export const newsHot = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + NEWS_HOT,
	})
}

export const TREND = `markets/trend`;
export const trend = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + TREND,
	})
}

export const DATA_CENTER = `markets/dataCenter`;
export const dataCenter = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + DATA_CENTER,
	})
}

export const AH_COMPARE = `markets/ahcompare`;
export const ahCompare = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + AH_COMPARE,
	})
}

export const DASHBOARD = `markets/dashboard`;
export const dashboard = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + DASHBOARD,
	})
}

export const LONGHU = `markets/longhu`;
export const longhu = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + LONGHU,
	})
}

export const REPORT = `markets/report`;
export const report = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + REPORT,
	})
}

export const PERFORMANCE = `markets/performance`;
export const performance = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PERFORMANCE,
	})
}

export const HSETF = `markets/hsetf`;
export const hsetf = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + HSETF,
	})
}

export const IPORECENT = `markets/iporecent`;
export const iporecent = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + IPORECENT,
	})
}

export const MARKET_COMMON = `markets/common`;
export const marketCommon = (val = '') => {
	console.log(val);
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + MARKET_COMMON + `?tag=${val}`,
	})
}

export const TRADE = `trade/index`;
export const trade = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + TRADE,
	})
}

export const BLOCK = `trade/block/index`;
export const block = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + BLOCK,
	})
}

export const BLOCK_RECORD = `trade/block/record`;
export const blockRecord = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + BLOCK_RECORD,
	})
}

export const IPO = `trade/ipo/index`;
export const ipo = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + IPO,
	})
}

export const IPO_DETAIL = `trade/ipo/detail`;
export const ipoDetail = (val = '') => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + IPO_DETAIL + `?id=${val}`
	})
}

export const IPO_RECORD = `trade/ipo/record`;
export const ipoRecord = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + IPO_RECORD,
	})
}

export const SCRAMBLE = `trade/scramble/index`;
export const scramble = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SCRAMBLE,
	})
}

export const SCRAMBLE_DETAIL = `trade/scramble/detail`;
export const scrambleDetail = (val = '') => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SCRAMBLE_DETAIL + `?id=${val}`,
	})
}

export const SCRAMBLE_RECORD = `trade/scramble/record`;
export const scrambleRecord = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SCRAMBLE_RECORD,
	})
}







export const search = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + SEARCH,
	})
}

export const stockDetail = (symbol, gid, tag = '') => {
	if (!isAuth()) return false;
	tag = tag != '' ? `&tag=${tag}` : '';
	uni.navigateTo({
		url: PAGES + STOCK_INDEX + `?symbol=${symbol}&gid=${gid}${tag}`,
	})
}

export const position = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + POSITION,
	})
}

export const openNews = (val) => {
	window.open(val)
}


export const ai = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + TRADE_AI,
	})
}

export const ea = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + TRADE_EA,
	})
}


export const DEPOSIT = `assets/deposit`; // 充值
export const deposit = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + DEPOSIT,
	})
}

export const WITHDRAW = `assets/withdraw`; // 提现
export const withdraw = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + WITHDRAW,
	})
}

export const AUTH = `settings/auth`;
export const auth = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + AUTH,
	})
}

export const BANK = `settings/bank`;
export const bank = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + BANK,
	})
}

export const PASSWORD = `settings/password`;
export const pwd = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PASSWORD,
	})
}
export const pwdPay = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PASSWORD + `?tag=pay`,
	})
}

export const FLOW = `settings/flow`;
export const flow = (val = '') => {
	console.log(val);
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + FLOW + `?tag=${val}`,
	})
}

export const ABOUT = `settings/about`;
export const about = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + ABOUT,
	})
}

export const PROFILE = `settings/profile`;
export const profile = () => {
	if (!isAuth()) return false;
	uni.navigateTo({
		url: PAGES + PROFILE,
	})
}