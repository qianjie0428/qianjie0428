import CryptoJS from "crypto-js";

// **必须是 16/32 字节的密钥 & IV**
const SECRET_KEY = CryptoJS.enc.Utf8.parse("1234567890123456"); // 16字节密钥
const SECRET_IV = CryptoJS.enc.Utf8.parse("1234567890123456");  // 16字节 IV

// **AES 加密**
export function encrypt(text) {
    if (!text) return "";

    const encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(text), SECRET_KEY, {
        iv: SECRET_IV,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });

    return encrypted.toString();  // Base64 输出
}

// **AES 解密**
export function decrypt(encryptedText) {
    if (!encryptedText) return "";

    const decrypted = CryptoJS.AES.decrypt(encryptedText, SECRET_KEY, {
        iv: SECRET_IV,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });

    return CryptoJS.enc.Utf8.stringify(decrypted); // **正确转换回字符串**
}
