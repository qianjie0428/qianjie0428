import Vue from 'vue';
import App from './App';
import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import * as theme from '@/common/theme.js';
import * as util from '@/common/util.js';
import * as http from '@/common/http.js';
import uView from "@/node_modules/uview-ui";
import fmt from '@/format/index.js';

import {
	translate
} from '@/localize/index.js';

Vue.use(uView);

Vue.config.productionTip = false;

Vue.prototype.$C = constants; // 常量
Vue.prototype.$linkTo = linkTo; // 跳转
Vue.prototype.$util = util; // 工具类
Vue.prototype.$http = http; // http api
Vue.prototype.$fmt = fmt; // 格式化
Vue.prototype.$msg = null;
Vue.prototype.$t = translate;
Vue.prototype.$theme = theme;
// 全局设置金额小数点保留位数
Vue.prototype.$decimal = 2;
// 全局设置率值小数点保留位数
Vue.prototype.$rate = 2;
// 默认的代码，用于部分金额格式化的依据
Vue.prototype.$DEF_LGRE = `zh-CN`;

App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()

// 初始化设置
util.initialize();

