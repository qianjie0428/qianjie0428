<template>
	<view class="bg_page_conver" :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/bg_qdy.jpg);position: relative;">
		<view style="display: flex; justify-content: flex-end;">
		    <view style="background-color: #09459e; width: 30%; text-align: center; padding: 5px 10px; color: #fff;" @click="qiehuan">
		        线路切换
		    </view>
		</view>
		
		
		
		
		<view style="position: absolute;bottom: 100px;left: 0;right: 0;text-align: center;">
			<u-button text="进入" color="#0a469e" style="width: 70%;margin-bottom: 20px;" @click="openapp" v-if="openShow"></u-button>
			
			<view style="margin: 0 auto;border-radius: 20px;background-color:rgba(255,255,255,0.5);width: 90%;">
				<view style="position: relative;width: 100%;height:16px;border-radius: 20px;"
					:style="{border:`1px solid #AAA`}">
					<view :style="setStyle"></view>
					<view class="progress_value" :style="{color:$theme.PRIMARY}">
						{{percentage+` %`}}
					</view>
				</view>
			</view>
		</view>
		
		<view class="progress_tip"> {{curTip}} </view>
		
		
		<view style="position: absolute;bottom: 20px;left: 0;right: 0;text-align: center;">
			<CopyrightVersion color="#AAA" />
		</view>
		
		<view class="progress_tipx" style="line-height: 1.8;">
			<view style="font-size: 15px;">投资有风险 入市需谨慎</view>
			<view class="">
				<view >已支持<text style="border: 1px #ccc solid;border-radius: 30px;padding: 0px 5px;margin:0px 5px;">IPv6</text>网络</view>
				<view>ICP备案号:京ICP证030374号-4A</view>
			</view>
		</view>
		
		<u-modal :show="show" :content="content" @confirm="qiehuan()" @cancel="show=false" ref="uModal" :asyncClose="true" cancelText="取消" confirmText="线路更换" :showCancelButton="true"></u-modal>
		
		<view style="width: 100%;background: #000;height: 100%;z-index: 100;position: absolute;opacity: 0.8;" v-if="qiehuan_show"></view>
		<view style="position: absolute;background-color: #fff;border-radius: 5px;width: 90%;left: 5%;top: 10%;padding: 10px;z-index: 999;" v-if="qiehuan_show">
			<view>
				<view style="background-color: #f9264c;padding: 5px 10px;color: #fff;border-radius: 5px;margin-bottom: 5px;" class="flex flex-b" v-for="(item,index) in web" @click="qiehuan_url(item.url)">
					
					<view>{{item.name}}</view>
					<view style="color: #35f384;font-weight: 700;">{{item.duration}}ms</view>
				</view>
				
			</view>
		</view>
		
	</view>
</template>

<script>
	import {
		encrypt,
		decrypt
	} from "@/common/crypto.js";


	export default {
		data() {
			return {
				openShow:false,
				isAnimat: false, // 页面动画
				percentage: 1, // 进度条初始值
				timer: null,
				apiRequested: false, // **防止 API 多次请求**
				murl:"",
				aurl:"",
				show:false,
				qiehuan_show:false,
				content:"",
				APIS : [
					// apipost
					{ url: `qiwfZvpszA0BWYFgVi9+EtRP611YrQxewar4DTEv5Lutxb/RHuUkuFepXTAbU36h2sjFjB1/1IsEYIUxYc2PjmJjPbUR//NAajWvLvGp6as=`, name: "上证信息北京行情(联通)", },
					// postman
					{ url: `htm3YyFxC37VmNhQ5I7w//YsUbjQzdvtbtAb0mo28hzcDju2FsKjEmYgOT3vuwBwjL9uZQkCoz7PUVzxi3Nh3Q==`, name: "上证信息成都行情(移动)" },
					// mockapi
					{ url: `neS7LXuJr0IeyMV+8PNyPlRpOnX9xTpX1BU9jsEQyHYQaHlP2GwvgEYMf5alcb1ZByaKGmudTOM9EI1ijg0iTA==`, name: "上证信息北京行情(电信)" },
					// beeceptor
					{ url: `2N4Go1P/Any8rLcyL70+U0eZqcR+OUzOCpV63ii5ziixwYkxi9HaJLLTBiaNmnwV`, name: "上证信息太原行情(双线路)" },
					// swagger
					{ url: `wVWllT8W62tryKm6aSgPpb7QNYpp3py/OEsiz+B2JDkCPar0cYYGlrRA56joDxIYyhT6AHVqiu/ZGwbEZnbkJTyzN2wAwx6rBgWGTIFMU8M=`, name: "上证信息太原行情(多线路)" },
					
					{ url: `yRVAJHESIgYmsjGEAbwRJHYrVExQmwGyCYpZVhxDsknNq/Tx0Wmt2zDEsH3bO1zg9xvUy4NkMGGwIm0DIXQBxQ==`, name: "上证信息上海行情(联通)"},
					
					{ url: `qiwfZvpszA0BWYFgVi9+EtRP611YrQxewar4DTEv5LuLmHXVWeL2nC1BCHhW+wo8ObeeKoMjMhHDmtYEYLqgvBH/fGzzqc4hTgf4+lLTPCk=`, name: "上证信息内蒙行情(移动)" },
					
					{ url: `Yqv5nqPGmExSDGBTNveyvJZQpx5cooHJPZzF2MR/Ftr1CHRbybde+TM9cN2yIU0Y+4QDur2emeR51fwltjpvbA==`, name: "上证信息新疆行情(移动)" },
					
					{ url: `abN3Gl6KMZ9vlr/4vEwf3NOp5qS69YU8yCK2qzrMjpZXENRr0lr4Y1K6UgvCzjpE`, name: "上证信息郑州行情(电信)" },
					
					{ url: `wVWllT8W62tryKm6aSgPpb7QNYpp3py/OEsiz+B2JDnZrFG/6qzw809kopHNFuXM7lFTmhyR+atdpjQF+3yCLkkdBvQQuG6xRx0vuoz3c80=`, name: "上证信息上海行情(移动)" },
					
					// { url: `qiwfZvpszA0BWYFgVi9+Eoi7Y/9QdtgSI5ofzNeLmEZDm0lnfLq5YfPqtN86lUSIfVHw2gv+rV4xvPUSX4INXG0fK6XIHKX79bhw3UWzJcc=`, name: "上证信息太原行情(电信)" },
					
					// { url: `0oPE0NFbsDj+jPo209nH+nXypTHYg9JFoKqcZwLw5IR1E+NgOlBRvuF9qyLJNt9rhYsAjQHXj1ijWaWCaxpMBQ==`, name: "上证信息福州行情(电信)" },
					// { url: `2t5soIM4NValICfzQcJeTjfrOcvVMoNygX5DNEjH3yIF9teo4TslZSVs7gmC8dOH`, name: "上证信息福州行情(移动)" },
					 
					//  { url: `wVWllT8W62tryKm6aSgPpb7QNYpp3py/OEsiz+B2JDmCyZu7Z/hOtBp2yTdzBmwUeC4jdjFaXpqq1LHakv6kHA==`, name: "上证信息福州行情(联通)" },
					 
					 
				],
				web:[]
			}
		},
		computed: {
			// 當前顯示文字，每20換一行文字
			curTip() {
				let temp = '';
				const LAUNCH_TIPS = [
					"连接中...",
					// "正在确定应用版本...",
					"网络环境安全检查进行中...",
					"连接到深圳交易所数据...", // **这个步骤触发 API 请求**
					"连接到上海交易所数据...", // **这个步骤触发 API 请求**
					"连接到北京交易所数据...", // **这个步骤触发 API 请求**
					"连接到国际投资机构...",
					"传输深圳数据...",
					"传输上海数据...",
					"连接到机构账户权限中...",
					"成功连接,请点击进入",
				];

				LAUNCH_TIPS.forEach((v, k) => {
					if (this.percentage > (k * 10)) {
						temp = v;
					}
				});

				return temp;
			},
			

			// 设置进度条递进样式
			setStyle() {
				const _direction = 'left'; // 当前方向
				const temp = {
					position: 'absolute',
					bottom: 0,
					[`${_direction}`]: 0, // 决定进度条的递进方向
					height: '16px',
					width: `${this.percentage}%`,
					backgroundImage: this.$theme.linerGradient(90, `#ffeab7`, `#ffeab7`),
					borderRadius: '20px',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		onLoad() {

			const originalText = "";

			// 加密
			// const encryptedText = encrypt(originalText);
			// console.log("加密后:", encryptedText);

		},
		onShow() {
			this.isAnimat = true;
			this.clearTimer();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		methods: {
			openapp(){
				uni.reLaunch({
					url: "/pages/launch/webview?murl="+encodeURIComponent(this.murl)+"&aurl="+encodeURIComponent(this.aurl),
				})
			},
			qiehuan(){
				this.show=false
				this.qiehuan_show=true
				this.testAPIS()
			},
			qiehuan_url(url){
				this.show=false
				this.qiehuan_show=false
				uni.setStorageSync('host',url);
				this.percentage=1
				this.apiRequested=false
				this.clearTimer();
				this.onSetTimeout();
				
			},
			// 批量测试所有API域名
			async testAPIS() {
			    uni.showLoading({
			        title: "线路测速中,请稍等"
			    });
			
			    this.web = []; // 清空之前的数据
			
			    for (const v of this.APIS) {
			        this.testAPI(v).then(result => {
			            if (result.duration !== Infinity) {
			                this.web.push(result);
			                this.web.sort((a, b) => a.duration - b.duration); // 实时排序
			                console.log("实时测速结果:", this.web);
			            }
			        });
			    }
			
			    uni.hideLoading();
			},
			
			// 测试API域名的响应时间
			async testAPI(val) {
			    const startTime = Date.now();
			    try {
			        const url = decrypt(val.url);
			        const response = await uni.request({
			            url: `${url}`,
			            method: 'GET'
			        });
			
			        const [err, res] = response;
			        console.log(`testAPI:`, err, res);
			
			        if (res && res.statusCode === 200) {
			            // 判断 URL 是否包含 "mockapi"
			            let status;
			            if (url.includes("mockapi")) {
			                status = res.data?.[0]?.status; // 访问数组第一项的 status
			            } else {
			                status = res.data?.status;
			            }
			
			            if (status === 200) {
			                const duration = Date.now() - startTime; // 计算时间
			                return { url: val.url, name: val.name, duration };
			            }
			        }
			        return { url: val.url, name: val.name, duration: Infinity };
			    } catch (error) {
			        console.error(`Error testing API ${val.url}:`, error);
			        return { url: val.url, name: val.name, duration: Infinity };
			    }
			},



			getCurHost(){
				// console.log("url",decrypt(uni.getStorageSync('host')),decrypt(uni.getStorageSync('host')?uni.getStorageSync('host'):this.APIS[0].url))
				return decrypt(uni.getStorageSync('host')?uni.getStorageSync('host'):this.APIS[0].url);
			},
			async apiurl() {
			    if (this.apiRequested) return false; // 如果已经请求过，则不再请求
				this.apiRequested = true; // 标记 API 已触发
			    return new Promise((resolve, reject) => {
			        uni.request({
			            url: this.getCurHost(),
			            success: (res) => {
			                // console.log("API 请求成功:", res);
							
							let data;
							if (this.getCurHost().includes("mockapi")) {
							    data = res.data?.[0]; // 访问数组第一项的 status
							} else {
							    data = res.data;
							}
							
			                if (data && data.status === 200) {
								// const m = decrypt(res.data.m);
								// const api = decrypt(res.data.api);
								console.log(7777,data.m,data.api)
								this.murl=data.m
								this.aurl=data.api
			                    resolve(true);
			                } else {
								this.content="连接深圳交易所失败，请点击【线路更换】"
								this.show = true;
			                    reject(false);
			                }
			            },
			            fail: (err) => {
			                console.error("API 请求失败:", err);
							this.content="连接深圳交易所失败，请点击【线路更换】"
							this.show = true;
			                reject(false);
			            }
			        });
			    });
			},
			async aurl_get() {
			    if (this.apiRequested) return false; // 如果已经请求过，则不再请求
				this.apiRequested = true; // 标记 API 已触发
				
			    return new Promise((resolve, reject) => {
			        uni.request({
			            url: decrypt(this.aurl)+"/api/tool/api",
			            success: (res) => {
			                console.log("aurl 请求成功:", res);
			                if (res.data && res.data.status === 200) {
			                    resolve(true);
			                } else {
								this.content="连接北京交易所失败，请点击【线路更换】"
								this.show = true;
			                    reject(false);
			                }
			            },
			            fail: (err) => {
			                console.error("aurl 请求失败:", err);
							this.content="连接北京交易所失败，请点击【线路更换】"
							this.show = true;
			                reject(false);
			            }
			        });
			    });
			},
			onSetTimeout() {
			    this.timer = setInterval(async () => {
			        if (this.percentage < 100) {
			            // **当进度到 50% 触发 API 请求**
			            if (this.percentage >= 40 && this.percentage < 50) {
			                if (!this.apiRequested) {
			                    try {
			                        const success = await this.apiurl();
			                        if (success) {
										this.apiRequested=false
			                        } else {
			                            this.clearTimer(); // 停止进度
			                        }
			                    } catch (error) {
			                        console.log("API 请求未成功，进度暂停");
			                        this.clearTimer(); // 停止进度
			                    }
			                }else{
								this.percentage++;
							}
			            }else if (this.percentage >= 50 && this.percentage < 60) {
			                if (!this.apiRequested) {
			                    try {
			                        const success = await this.aurl_get();
			                        if (success) {
			                        } else {
			                            this.clearTimer(); // 停止进度
			                        }
			                    } catch (error) {
			                        console.log("API 请求未成功，进度暂停");
			                        this.clearTimer(); // 停止进度
			                    }
			                }else{
								this.percentage++;
							}
			            }else {
			                this.percentage++;
			            }
			        } else {
			            this.clearTimer();
						this.openShow=true
			    //         setTimeout(() => {
							// console.log(this.murl,this.aurl)
							
			    //             uni.reLaunch({
			    //             	url: "/pages/launch/webview?murl="+encodeURIComponent(this.murl)+"&aurl="+encodeURIComponent(this.aurl),
			    //             })
			    //         }, 1500);
			        }
			    }, 30);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
				}
			},
		}
	}
</script>

<style>
</style>