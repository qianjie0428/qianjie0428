<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="page_header">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.STOCK_TITLE+`(${symbol})`)" />

		<view class="right_in" style="padding:16px 8px 60px 8px;">
			<template v-if="detail">
				<view class="card_dark" style="padding: 20px;margin:0;background-color: #FFF;">
					<view style="display: flex;align-items: center;">
						<!-- <CustomLogo :logo="detail.logo" :name="detail.name"></CustomLogo> -->
						<view style="line-height: 1.4;font-size: 32rpx;font-weight: 700;">
							{{detail.name}}<text style="font-size: 25rpx;padding-left: 10px;font-weight: 300;"
								:style="{color:$theme.LOG_LABEL}">({{detail.gid}})</text>
						</view>
						<view style="margin-left: auto;">
							<image :src="`/static/star_light${detail.is_collected?``:`_un`}.svg`" mode="aspectFit"
								:style="$theme.setImageSize(16)" @click.stop="handleTrack(detail.gid)"></image>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;">
						<view style="flex:1;">
							<view> {{$t($msg.STOCK_PRICE)}} </view>
							<view style=" font-size: 32rpx;" :style="{color:$theme.setRiseFall(detail.rate)}">
								{{$fmt.amount(detail.current_price,$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}}
							</view>
						</view>
						<view style="flex:1;text-align: center;">
							<view> {{$t($msg.STOCK_RATE)}} </view>
							<view style="font-size: 32rpx;" :style="{color:$theme.setRiseFall(detail.rate)}">
								{{$fmt.percent(Math.abs(detail.rate))}}
							</view>
						</view>
						<view style="flex:1;text-align: right;">
							<view> {{$t($msg.STOCK_RATE_NUM)}} </view>
							<view style="font-size: 32rpx;" :style="{color:$theme.setRiseFall(detail.rate_num)}">
								{{$fmt.amount(Math.abs(detail.rate_num),$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}}
							</view>
						</view>
					</view>
					<template v-if="detail.open">
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 6px;font-size: 14px;border-top: 1px solid #F3F3F3;margin-top: 6px;">
							<view style="flex:1;">
								<view style="font-size: 12px;color: #CCC;"> {{$t($msg.COMMON_OPEN)}} </view>
								<view> {{$fmt.amount(detail.open,$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}} </view>
							</view>
							<view style="flex:1;text-align: center;">
								<view style="font-size: 12px;color: #CCC;"> {{$t($msg.COMMON_CLOSE)}} </view>
								<view> {{$fmt.amount(Math.abs(detail.close,$fmt.getLgre($C.GPINDEX[detail.project_type_id])))}}
								</view>
							</view>
							<view style="flex:1;text-align: center;">
								<view style="font-size: 12px;color: #CCC;"> {{$t($msg.COMMON_HIGH)}} </view>
								<view> {{$fmt.amount(Math.abs(detail.high,$fmt.getLgre($C.GPINDEX[detail.project_type_id])))}} </view>
							</view>
							<view style="flex:1;text-align: right;">
								<view style="font-size: 12px;color: #CCC;"> {{$t($msg.COMMON_LOW)}} </view>
								<view> {{$fmt.amount(Math.abs(detail.low,$fmt.getLgre($C.GPINDEX[detail.project_type_id])))}} </view>
							</view>
						</view>
					</template>
				</view>
			</template>

			<view style="margin:20px 0 0 0;">
				<view class="flex_row_between" style="padding:14px 50px;background-color: #FFF;border-radius: 2px;">
					<block v-for="(v,k) in times" :key="k">
						<view @click="changeTimes(k)">
							<view style="text-align: center;">
								<text style="padding-bottom: 4px;display: inline-block;min-width: 32px;"
									:style="setStyle(curKline===k)">{{v}}</text>
							</view>
						</view>
					</block>
				</view>
				<view style="margin-top: 10px;"></view>
				<view id="kline-stock"
					style="width: 100%;height:560rpx;background-color: #FFF;border-radius: 6px;padding-top: 10px;"> </view>
			</view>

			<view style="width: 100%;margin:21.5px auto;">
				<BtnLock :isDisabled="islock" @click="showBuy" className="btn_submit">
					<text>{{$t($msg.COMMON_BUY)}}</text>
				</BtnLock>
			</view>
		</view>

		<!-- buy modal -->
		<template v-if="showBuyModal">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_bottom bottom_in" style="background-color:#FFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #F0D6A3;background-color: #FFF;border-radius: 6px 6px 0 0;line-height: 2.4;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							{{$t($msg.STOCK_ORDERS_TITLE)}}
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit" style="margin-left: auto;padding-right: 6px;"
							:style="$theme.setImageSize(20)" @click.top="modalClose()"></image>
					</view>
					<view style="padding:12px 16px 40px 16px;">
						<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
							购买数量
						</view>
						<view class="form_input" style="margin-bottom: 15px;">
							<input v-model="qty" type="number" 
								placeholder-class="placeholder"></input>
							<template v-if="qty && qty.length > 0">
								<image src="/static/del.svg" mode="aspectFit" @click="qty=''"></image>
							</template>
						</view>
						<Balance :balance="!user?'': $fmt.amount(user.money)"  style="font-size: 14px;"/>
							
						<view class="flex" style="align-items: center;padding-top: 6px;">
							<view style="font-size: 13px;">购买金额 : </view>
							<view style="margin-left: 5px;font-size: 13px;" :style="{color:$theme.PRIMARY}">
								{{$fmt.amount(total,$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}}
							</view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content:  space-between;padding-top: 6px;">
							<view>{{$t($msg.STOCK_FREEZE)+`:`}} </view>
							<view style="padding:0 0 0 12px;">
								{{$fmt.amount(feeRate,$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}}
							</view>
						</view> -->
						<view style="width: 100%;margin:21.5px auto;">
							<BtnLock :isDisabled="islock" @click="handleBuy" className="btn_submit">
								<text>{{$t($msg.COMMON_BUY)}}</text>
							</BtnLock>
						</view>
					</view>
				</view>
			</view>
		</template>
		<template v-if="showAsk">
			<view class="overlay" style="background-color: rgba(0,0,0,0.75);z-index: 15;" @click="showAsk=false"></view>
			<view class="modal_wrapper_center" style="background-color: #FFF;">
				<view style="line-height: 2.4;font-size: 18px;font-weight: 500;text-align: center;">
					{{$t($msg.STOCK_ORDERS_TITLE + $msg.COMMON_CONFIRM)}}
				</view>
				<view style="font-size: 14px;font-weight: 500;padding:0 12px;">
					{{detail.name}} <text style="padding-left: 12px;font-size: 11px;font-weight: 300;"
						:style="{color:$theme.FLAT}">({{detail.code}})</text>
				</view>
				<view style="display: flex;align-items: center;padding:6px 12px;">
					{{$t($msg.COMMON_BUY+$msg.UNIT_SHARES)}}:
					<view>
						<text style="font-size: 14px;font-weight: 500;margin-left: 10px;" :style="{color:$theme.PRIMARY}">
							{{$fmt.numer(qty)}}</text>
						<!-- <text style="font-size: 11px;font-weight: 100;padding-left: 4px;"
							:style="{color:$theme.FLAT}">{{$t($msg.UNIT_SHARES)}}</text> -->
					</view>
				</view>
				<view class="flex" style="align-items: center;padding: 0px 12px;">
					<view style="font-size: 14px;">购买金额 : </view>
					<view style="margin-left: 5px;font-size: 14px;" :style="{color:$theme.PRIMARY}">
						{{$fmt.amount(total,$fmt.getLgre($C.GPINDEX[detail.project_type_id]))}}
					</view>
				</view>
				
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 3;margin-top: 8px;border-top: 0.1px solid #EEE;">
					<view style="flex: 1;text-align: center;border-right: 0.1px solid #EEE;font-size: 16px;" @click="cancel()">
						{{$t($msg.COMMON_CANCEL)}}
					</view>
					<view style="flex: 1;text-align: center;font-size: 16px;" :style="{color:$theme.PRIMARY}" @click="comfirm()">
						{{$t($msg.COMMON_CONFIRM)}}
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import { init, dispose } from '@/common/klinecharts.min.js';
	import {
		getTimeZone
	} from '@/localize/index.js';
	// 简易的日期格式化示例函数
	function formatTimestamp(timestamp, format = 'YYYY-MM-DD') {
	  const date = new Date(timestamp)
	  const year = date.getFullYear()
	  const month = String(date.getMonth() + 1).padStart(2, '0')
	  const day = String(date.getDate()).padStart(2, '0')
	  const hour = String(date.getHours()).padStart(2, '0')
	  const minute = String(date.getMinutes()).padStart(2, '0')
	  const second = String(date.getSeconds()).padStart(2, '0')
	
	  // 这里根据自己的需求拼接即可
	  // 如果需要更强的日期处理，可以引入 dayjs/moment 等库
	  // 并在这里直接 return dayjs(timestamp).format(format)
	  return `${year}-${month}-${day}`
	}
	
	
	
	export default {
		data() {
			return {
				isAnimat: false,
				symbol: '',
				gid: '',
				curKline: 0,
				detail: null,
				times: [ this.$msg.COMMON_DAY, this.$msg.COMMON_WEEK, this.$msg.COMMON_MONTH],
				wsClient: null, // websocket
				isConnected: false, // ws是否连接
				chart: null, // 当前kline实例
				chartData: [],
				showBuyModal: false,
				qty: '',
				user: null,
				fee: 1,
				showAsk: false,
				askInfo: null,
				timer: null,
				islock: false,
			}
		},
		computed: {
			total() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.current_price, this.$decimal)
			},
			feeRate() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.current_price * this.fee, this.$decimal)
			}
		},
		onLoad(opt) {
			this.symbol = opt.symbol || this.symbol;
			this.showBuyModal = opt.tag == 'buy';
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getStockDetail();
			
			
		},
		onReady() {
			this.chart = init("kline-stock");
			if (this.chart) {
				this.chart.setLocale("zh-CN")
				
				
				// 设置样式，重点是 xAxis.tickText
				 this.chart.setCustomApi({
				         formatDate: (dateFormat, timestamp) => {
				           // klinecharts 会把要使用的"格式字符串"(dateFormat)和时间戳(timestamp)传过来
				           // 你可以根据实际需求进行解析或忽略 dateFormat
				           return formatTimestamp(timestamp)
				         }
				       });
					   
				this.chart.setStyles({
				    candle: {
				        bar: {
				            upColor: '#f92855',   // **阳线颜色（A股习惯：红色）**
				            downColor: '#2dc08e', // **阴线颜色（A股习惯：绿色）**
				            noChangeColor: '#888888', // **不变K线颜色**
							upBorderColor: '#f92855',
							downBorderColor: '#2dc08e',
				        },
						
				    }
				});

				
				// this.chart.setTimezone('Asia/Shanghai')
				
				console.log(this.chart);
					
				this.chart.setTimezone(getTimeZone());
				this.chart.setPriceVolumePrecision(this.$decimal, 0);
			}
		},
		onHide() {
			this.isAnimat = false;
			this.clearSomething();
			this.chart = null;
			if (this.wsClient) this.disconnect();
		},
		deactivated() {
			this.clearSomething();
			this.chart = null;
			if (this.wsClient) this.disconnect();
		},
		onUnload() {
			this.clearSomething();
			this.chart = null;
			if (this.wsClient) this.disconnect();
		},
		onPullDownRefresh() {
			if (this.wsClient) this.disconnect();
			this.chart = null;
			this.getStockDetail();
			this.changeTimes(this.curKline);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 格式化时间
			formatTime(timestamp) {
			  // 假设你的数据里是毫秒级的时间戳
			  const date = new Date(timestamp)
			  const year = date.getFullYear()
			  const month = String(date.getMonth() + 1).padStart(2, '0')
			  const day = String(date.getDate()).padStart(2, '0')
			  const hour = String(date.getHours()).padStart(2, '0')
			  const minute = String(date.getMinutes()).padStart(2, '0')
			  return `${year}-${month}-${day}`
			},
			setStyle(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.BLACK_70,
					fontWeight: val ? `700` : `500`,
					borderBottom: `3px solid ${val ?this.$theme.PRIMARY:this.$theme.TRANSPARENT}`
				}
			},
			// 停止并清理数据
			clearSomething() {
				if (this.chart) this.chart.clearData();
				dispose("kline-stock");
				this.clearTimer();
			},

			// info 数据
			async getStockDetail() {
				this.detail = await this.$http.getStockDetail(this.symbol, this.curKline);
				if (this.detail && this.detail.project_type_id) {
					console.log(`info:`, this.detail);
					this.getKlineData();
					if (!this.timer) this.onSetTimeout();

					if (this.wsClient) this.disconnect();
					// // 如果没有启动ws ，则启动ws 。全程断线重连，更新info数据
					// if (!this.wsClient) this.initWebSocket();
				}
				this.gid = result[0].gid;
			},
			
			async handleTrack() {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid:this.detail.gid,
				});
					
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: result.message,
					icon: 'none'
				});
				if (this.wsClient) this.disconnect();
				this.getStockDetail();
			},

			// 时轴切换
			async changeTimes(val) {
				this.chartData = null;
				console.log(`?`, this.chartData);
				this.clearSomething();
				this.chart = init("kline-stock");
				this.chart.setLocale("zh-CN")
				
				
				// 设置样式，重点是 xAxis.tickText
				 this.chart.setCustomApi({
				         formatDate: (dateFormat, timestamp) => {
				           // klinecharts 会把要使用的"格式字符串"(dateFormat)和时间戳(timestamp)传过来
				           // 你可以根据实际需求进行解析或忽略 dateFormat
				           return formatTimestamp(timestamp)
				         }
				       });
				this.chart.setStyles({
				    candle: {
				        bar: {
				            upColor: '#f92855',   // **阳线颜色（A股习惯：红色）**
				            downColor: '#2dc08e', // **阴线颜色（A股习惯：绿色）**
				            noChangeColor: '#888888', // **不变K线颜色**
							upBorderColor: '#f92855',
							downBorderColor: '#2dc08e',
				        },
						
				    }
				});
				
				
				this.chart.setTimezone(getTimeZone());
				this.chart.setPriceVolumePrecision(this.$decimal, 0);

				this.curKline = val;
				this.getKlineData();
				if (!this.timer) this.onSetTimeout();
			},
			async showBuy() {
				this.showBuyModal = true;
				this.user = await this.$http.getAccount();
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') * 1;
			},
			modalClose() {
				this.showBuyModal = false;
				this.qty = '';
			},
			async handleBuy() {
				if (!this.qty || this.qty * 1 <= 0) {
					uni.showToast({
						title: this.$t(this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES),
						icon: 'none'
					});
					return false;
				}
				this.showAsk = true;
			},
			cancel() {
				this.showAsk = false;
			},
			async comfirm() {
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.qty,
					gid: this.detail.gid,
					price: this.detail.current_price,
					// ganggan: this.curLever,
				});
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				});
				setTimeout(() => {
					this.cancel();
					this.modalClose();
					this.$linkTo.position();
				}, 1000)
			},

			async getKlineData() {
				console.log(this.detail);
				this.chartData = await this.$http.getKlineData(this.detail.code, this.curKline, this.detail.project_type_id);
				console.log(this.chartData);
				if (this.chart && this.chartData && this.chartData.length > 0) {
					
					if (this.chart) this.chart.clearData();
					this.chart.applyNewData(this.chartData);
					// 获取图标上的数据
					const dataList = this.chart.getDataList();
					// 数据数组的最后一个元素
					const lastData = dataList[dataList.length - 1];
					console.log(`lastData:`, lastData);
					this.detail.current_price = lastData.close;
				}
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					this.getKlineData();
					this.getStockDetail();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			// 初始化webSocket
			initWebSocket() {
				if (this.wsClient) this.disconnect();
				this.wsClient = uni.connectSocket({
					url: this.$http.WS_OTHER_URL(),
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});

				console.log(`socket:`, this.wsClient);
				this.wsClient.onOpen((res) => {
					console.info("socket onOpen:", res);
					this.isConnected = true; // 已连接
				});
				this.wsClient.onClose((res) => {
					// code:1000(手动关闭) 1006(异常关闭) 
					console.log(`onClose:`, res);
					this.isConnected = false;
					if (res.code !== 1000) {
						this.reconnectWebSocket();
					}
				});
				this.wsClient.onError((err) => {
					console.log(`onError:`, err);
					this.isConnected = false;
					this.reconnectWebSocket();
				});
				this.wsClient.onMessage((res) => {
					const data = JSON.parse(res.data);
					if (this.detail && this.detail.pid == data.pid) {
						console.log(data);
						console.log(`last_numeric:`, data.last_numeric);
						this.detail.current_price = data.last_numeric;
						this.detail.rate = data.pcp || 0;
						this.detail.rate_num = data.pc || 0;
						if (this.chart && this.chartData) {
							// 获取图标上的数据
							const dataList = this.chart.getDataList();
							// 数据数组的最后一个元素
							const lastData = dataList[dataList.length - 1];
							console.log(`lastData:`, lastData);
							// 建新数据
							const newData = {
								...lastData
							}
							newData.close = data.last_numeric;
							// newData.high = data.high;
							// newData.low = data.low;
							// // newData.volume = data.vol;
							// newData.open = data.high;
							// 当前ws时间戳 - 最后一个元素时间戳，>指定秒数，追加一根蜡烛
							if (data.timestamp * 1000 - newData.timestamp > 60000)
								newData.timestamp = data.timestamp * 1000;
							this.chart.updateData(newData);
							// this.detail.open = newData.open;
							// this.detail.close = newData.close;
							// this.detail.high = newData.high;
							// this.detail.low = newData.low;
						}
					}
				});
			},
			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				// if (this.isConnected) return;
				// console.log(`reconnect!`, this.isConnected);
				// this.wsClient = null;
				// console.log(`reconnect! socket:`, this.wsClient);
				// this.initWebSocket();
			},

			// 关闭 websocket链接
			disconnect() {
				if (this.wsClient) {
					this.wsClient.close();
					this.wsClient = null;
					this.isConnected = false;
				}
			},
		}
	}
</script>

<style>
</style>