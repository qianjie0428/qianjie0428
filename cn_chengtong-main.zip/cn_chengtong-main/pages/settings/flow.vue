<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" title="资金记录" :dir="$C.KEY_RIGHT" />

		<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 15px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @click="changeTab(v.key)">
					<view style="padding-bottom: 6px;font-size: 15px;" :style="setStyle(curKey===v.key)">
						{{v.name}}
					</view>
					<view style="width: 28px;height: 4px; margin:0 auto; border-radius:2px 0 2px 0;"
						:style="{ backgroundColor:curKey===v.key?$theme.PRIMARY : $theme.TRANSPARENT }">
					</view>
				</view>
			</block>
		</view>

		<view :class="$theme.random(curIndex)+`_in`" style="padding:20px 20px 60px 20px;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<!-- <template v-if="curKey===$C.KEY_TRADE">
					<RecordTrade :list="list" />
				</template> -->
				<template v-if="curKey===$C.KEY_DEPOSIT">
					<RecordDeposit :list="list" />
				</template>
				<template v-if="curKey===$C.KEY_WITHDRAW">
					<RecordWithdraw :list="list" @action="refresh" />
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import RecordTrade from './components/RecordTrade.vue';
	import RecordDeposit from './components/RecordDeposit.vue';
	import RecordWithdraw from './components/RecordWithdraw.vue';
	export default {
		components: {
			RecordTrade,
			RecordDeposit,
			RecordWithdraw,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curKey: null,
				tabs: ext.flowTabs(),
				list: null,
				statusLabels: [`审核中`, `成功`, `失败`, `拒绝`],
			}
		},
		computed: {
			curIndex() {
				const tem = this.tabs.findIndex(v => v.key === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curKey = opt.tag || this.curKey;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.tabs[0].key;
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			setStyle(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.BLACK_70,
					fontWeight: val ? `700` : `500`
				}
			},
			changeTab(val) {
				this.list = null;
				this.curKey = val;
				console.log("curKeay===",val);
				// if (this.curKey === this.$C.KEY_TRADE) this.getFlowTrade();
				if (this.curKey === this.$C.KEY_DEPOSIT) this.getDepositRecord();
				if (this.curKey === this.$C.KEY_WITHDRAW) this.getWithdrawRecord();
			},
			refresh(val) {
				this.changeTab(this.curKey);
			},
			async getFlowTrade() {
				this.list = await this.$http.getFlowTrade();
			},
			async getDepositRecord() {
				const result = await this.$http.getDepositRecord();
				// this.list = [...result].map((v, k) => {
				// 	v.status = k;
				// 	return {
				// 		...v,
				// 		statusLabel: this.statusLabels[v.status]
				// 	}
				// })
				this.list = result
				
			},
			async getWithdrawRecord() {
				const result = await this.$http.getWithdrawRecord();
				// this.list = [...result].map((v, k) => {
				// 	v.status = k;
				// 	return {
				// 		...v,
				// 		statusLabel: this.statusLabels[v.status]
				// 	}
				// })
				this.list = result
			}
		}
	}
</script>

<style>
</style>