<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<!-- <CommonHeader :layout="$C.HEADER_1" :title="$t($msg.AUTH_TITLE)" /> -->

		<header class="common_head" style="padding-top: 10px;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back" @click="$u.route({url:'/pages/settings/index'});"></image>
			<view class="dynamic_title slide_in_left">实名认证</view>
		</header>

		<view class="right_in" style="padding:20px 20px 100px 20px;">
			<view class="form_label"> {{$t($msg.REAL_NAME)}} </view>
			<view class="form_input">
				<input v-model="realName" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.REAL_NAME)"
					placeholder-class="placeholder"></input>
				<template v-if="realName && realName.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="realName=''"></image>
				</template>
			</view>

			<view class="form_label" style="margin-top: 12px;">
				{{$t($msg.AUTH_ID)}}
			</view>
			<view class="form_input">
				<input v-model="cardID" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.AUTH_ID)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)" @click="toggleMask()"></image>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.AUTH_FRONT)}} </view>

			<view @click="selectImg('front')"
				style="display: flex;align-items: center;justify-content: center;padding: 6px;border-radius: 8rpx;border: 1px solid #EAEAEA;background-color: #FCFDFF;">
				<template v-if="!frontURL">
					<view
						style="margin:20rpx;width:280px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
						<image src="/static/carmera.svg" mode="aspectFit" :style="$theme.setImageSize(96)">
						</image>
					</view>
				</template>
				<template v-else>
					<image :src="frontURL" style="margin:20rpx;width:280px;height:120px;">
					</image>
				</template>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.AUTH_BACK)}} </view>

			<view @click="selectImg('back')"
				style="display: flex;align-items: center;justify-content: center;padding: 6px;border-radius: 8rpx;border: 1px solid #EAEAEA;background-color: #FCFDFF;">
				<template v-if="!backURL">
					<view
						style="margin:20rpx;width:280px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
						<image src="/static/carmera.svg" mode="aspectFit" :style="$theme.setImageSize(96)">
						</image>
					</view>
				</template>
				<template v-else>
					<image :src="backURL" style="margin:20rpx;width:280px;height:120px;">
					</image>
				</template>
			</view>

			<view class="form_label" style="margin-top: 16px;">
				{{$t($msg.AUTH_TITLE+ $msg.COMMON_RULE)}}
			</view>
			<block v-for="(v,k) in tips" :key="k">
				<view style="color:#6D6D6D;font-size: 12px;padding-bottom: 4px;">{{`・`+ v}}</view>
			</block>
		</view>
		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
				{{$t($msg.COMMON_SUBMIT)}}
			</BtnLock>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				realName: '',
				cardID: '',
				frontURL: null,
				backURL: null,
				tips: ext.authTips(),
				islock: false,
			}
		},
		computed: {},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 缓存表单，否则输入框值会消失
			setStorage() {
				uni.setStorageSync('real', this.realName);
				uni.setStorageSync('card', this.cardID);
				uni.setStorageSync('front', this.frontURL);
				uni.setStorageSync('back', this.backURL);
			},
			getStorage() {
				this.realName = uni.getStorageSync('real');
				this.cardID = uni.getStorageSync('card');
				this.frontURL = uni.getStorageSync('front') || this.frontURL;
				this.backURL = uni.getStorageSync('back') || this.backURL;
			},

			async getAccount() {
				const result = await this.$http.getAccount();
				this.realName = result.real_name || '';
				this.cardID = result.idno || '';
				this.frontURL = result.front_image || '';
				this.backURL = result.back_image || '';
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.realName,
						this.$msg.COMMON_ENTER + this.$msg.REAL_NAME)) return false;
				if (!this.$util.checkField(this.cardID,
						this.$msg.COMMON_ENTER + this.$msg.AUTH_ID)) return false;
				if (!this.$util.checkField(this.frontURL,
						this.$msg.COMMON_UPLOAD + this.$msg.AUTH_FRONT)) return false;

				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName.trim(),
					idno: this.cardID.trim(),
					front_image: this.frontURL.trim() || '',
					back_image: this.backURL.trim() || '',
				});
				if (!result) {
					this.islock = false;
					return false;
				}
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.settings();
					this.islock = false;
				}, 1000);
			},
			// 点击上传
			async selectImg(val) {
				this.setStorage();
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				// console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				// console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				// console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.getStorage();
				if (val == 'front') {
					this.frontURL = reultURL;
					console.log(`frontURL:`, this.frontURL);
				}
				if (val == 'back') {
					this.backURL = reultURL;
					console.log(`backURL:`, this.backURL);
				}
			},
		}
	}
</script>

<style>
	header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20px 16px 0 16px;
		// position: relative;
		// overflow: hidden;
	}
	.dynamic_title {
		flex: 1;
		text-align: center;
		position: relative;
		color: #FFF;
		font-size: 32rpx;
	}
	
	.dynamic_data {
		flex: 1;
		text-align: center;
		position: relative;
	}
</style>