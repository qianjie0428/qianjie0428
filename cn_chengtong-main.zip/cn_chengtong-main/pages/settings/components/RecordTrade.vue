<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view class="record_tr" :style="{paddingTop: k==0?``:`6px`}">
					<view>{{$t($msg.FLOW_TRADE_AFTER)}}</view>
					<view>{{$fmt.amount(v.after)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.FLOW_TRADE_BEFORE)}}</view>
					<view>{{$fmt.amount(v.before)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.FLOW_MONEY)}}</view>
					<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.money)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.COMMON_DT)}}</view>
					<view>{{v.dt}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.COMMON_DESC)}}</view>
				</view>
				<view class="record_tr">
					<view></view>
					<view style="text-align: right;color: #888;">{{v.desc}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'RecordTrade',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>