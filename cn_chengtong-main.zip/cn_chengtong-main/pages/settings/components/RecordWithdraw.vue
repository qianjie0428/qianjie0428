<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view style="margin-bottom: 10px;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_10}`}">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>提款金额</view>
						<view style="font-weight:700;">{{$fmt.amount(v.money)}}</view>
					</view>
					<view style="text-align: right;">
						<view>提款后余额</view>
						<view style="font-weight:700;">{{$fmt.amount(v.after)}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>途径</view>
						<view style="font-weight:700;">{{v.type}}</view>
					</view>
					<view style="text-align: right;">
						<view>申请时间</view>
						<view style="font-weight:700;">{{v.dt}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>订单号</view>
						<view style="font-weight:700;">{{v.sn}}</view>
					</view>
					<view style="margin-left: auto;">
						<template v-if="v.status==1">
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
								
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[v.status]}}
							</view>
						</template>
						<template v-else-if="v.status==0">
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }"
								@click="handleCancel(v.id)">
								{{$t($msg.COMMON_CANCEL)}}
							</view>
						</template>
						<template v-else-if="v.status==2">
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;" :style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[v.status]}}
							</view>
						</template>
						<template v-else>
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[v.status]}}
							</view>
						</template>
					</view>
				</view>
				<view style="display: flex;align-items: center;padding-bottom: 20px;">
					<view style="text-align: right;" :style="{color:[$theme.BTN_UNLOCK,$theme.RISE][v.status]}">
						{{$t(v.desc)}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.FLOW_REASON)}}</view>
					<view style="color: #121212;">{{v.reason}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'RecordWithdraw',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				statusLabels: [`审核中`, `提现成功`, `提现失败`,'取消提现']
			}
		},
		methods: {
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$t(this.$msg.FLOW_MODAL_TITLE),
					cancelText: this.$t(this.$msg.COMMON_CANCEL),
					confirmText: this.$t(this.$msg.COMMON_CONFIRM),
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},

			async cancelWithdraw(id) {
				const result = await this.$http.getWithdrawCancel(id);
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				setTimeout(() => {
					this.$emit('action', 1);
				}, 1500);
			},
		}
	}
</script>

<style>
</style>