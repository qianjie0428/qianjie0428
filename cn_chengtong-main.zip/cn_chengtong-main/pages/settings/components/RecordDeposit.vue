<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view style="margin-bottom: 10px;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_10}`}">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>汇款金额</view>
						<view style="font-weight:700;">{{$fmt.amount(v.money)}}</view>
					</view>
					<view style="text-align: right;">
						<view>汇款后余额</view>
						<view style="font-weight:700;">{{$fmt.amount(v.after)}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>途径</view>
						<view style="font-weight:700;">{{v.type}}</view>
					</view>
					<view style="text-align: right;">
						<view>申请时间</view>
						<view style="font-weight:700;">{{v.dt}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
					<view>
						<view>订单号</view>
						<view style="font-weight:700;">{{v.sn}}</view>
					</view>
					<view style="margin-left: auto;">
						<template v-if="v.status==0">
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
							
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[0]}}
							</view>
						</template>
						<template v-else-if="v.status==1">
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[1]}}
							</view>
						</template>
						<template v-else>
							<view style="text-align: center;padding:4px 16px;border-radius: 2px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.flowStatus[v.status],15), color:$theme.flowStatus[v.status] }">
								{{statusLabels[2]}}
							</view>
						</template>
						
					</view>
				</view>
				<view style="display: flex;align-items: center;padding-bottom: 10px;">
<!-- 					<view style="text-align: right;" :style="{color:$theme.flowStatus[v.status]}">
						{{$t(v.desc)}}
					</view> -->
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "RecordDeposit",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				statusLabels: [`审核中`, `充值成功`, `充值失败`]
			}
		}
	}
</script>

<style>
</style>