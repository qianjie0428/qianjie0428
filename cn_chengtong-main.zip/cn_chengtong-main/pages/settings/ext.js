import * as linkTo from '@/common/linkTo.js';
import * as util from '@/common/util.js';
import * as constants from '@/common/constants.js';
import * as theme from '@/common/theme.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const auth = () => {
	return [
		translate(Msg.COMMON_UNREAL),
		translate(Msg.COMMON_REAL),
	]
}

export const setBtns = () => {
	return [{
		key: constants.KEY_AUTH,
		name: `实名认证`,
		icon: `auth`,
		action: linkTo.auth,
	}, {
		key: constants.KEY_BANK,
		name: `银行卡管理`,
		icon: `bank`,
		action: linkTo.bank,
	}, {
		key: constants.KEY_FLOW,
		name: `资金记录`,
		icon: `record_flow`,
		action: () => {
			linkTo.flow()
		},
	}, {
		key: constants.KEY_PWD,
		name: translate(Msg.SET_PWD_TITLE),
		icon: `pwd`,
		action: linkTo.pwd,
	}, {
		key: constants.KEY_PWD,
		name: `关于我们`,
		icon: `about`,
		action: linkTo.about,
	}, 
	// {
	// 	key: constants.KEY_PWD,
	// 	name: `在线反馈`,
	// 	icon: `service`,
	// 	action: util.linkCustomerService,
	// },
	]
}

export const otherBtns = () => {
	return [{
		name: translate(Msg.MENU_LONGHU),
		icon: `menu_longhu`,
		action: linkTo.longhu
	}, {
		name: translate(Msg.MENU_TREND),
		icon: `menu_trend`,
		action: linkTo.trend
	}, {
		name: translate(Msg.MENU_DASHBOARD),
		icon: `menu_dashboard`,
		action: linkTo.dashboard
	}, {
		name: translate(Msg.MENU_REPORT),
		icon: `menu_report`,
		action: linkTo.report
	}, {
		name: translate(Msg.MENU_DATA),
		icon: `menu_data`,
		action: linkTo.dataCenter
	}]
}

export const authTips = () => {
	return [
		translate(Msg.AUTH_TIP0),
		translate(Msg.AUTH_TIP1),
		translate(Msg.AUTH_TIP2),
	]
}

export const flowTabs = () => {
	return [
		// 	{
		// 	key: constants.KEY_TRADE,
		// 	name: translate(Msg.FLOW_TRADE),
		// },
		{
			key: constants.KEY_DEPOSIT,
			name: translate(Msg.FLOW_DEPOSIT),
		}, {
			key: constants.KEY_WITHDRAW,
			name: translate(Msg.FLOW_WITHDRAW),
		}
	]
}