<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.BANK_TTILE)" />

		<view class="left_in" style="padding:20px 20px 100px 20px;">
			<view class="form_label"> {{$t($msg.REAL_NAME)}} </view>
			<view class="form_input">
				<image src="/static/real-name.svg" mode="aspectFit"></image>
				<input v-model="realName" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.REAL_NAME)"
					placeholder-class="placeholder"></input>
				<template v-if="realName && realName.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="realName=''"></image>
				</template>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.BANK_NAME)}} </view>
			<view class="form_input">
				<image src="/static/real-name.svg" mode="aspectFit"></image>
				<input v-model="bankName" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.BANK_NAME)"
					placeholder-class="placeholder"></input>
				<template v-if="bankName && bankName.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="bankName=''"></image>
				</template>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.BANK_ID)}} </view>
			<view class="form_input">
				<image src="/static/id-card.svg" mode="aspectFit"></image>
				<input v-model="cardSN" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.BANK_ID)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>
			
			<view class="form_label" style="margin-top: 16px;"> 提款密码 </view>
			<view class="form_input">
				<image src="/static/id-card.svg" mode="aspectFit"></image>
				<input v-model="password" :password="isMask" maxlength="6" placeholder="请输入密码"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>
		</view>
		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
				{{$t($msg.COMMON_SUBMIT)}}
			</BtnLock>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				realName: '',
				bankName: '',
				cardSN: '',
				password:'',
				islock: false,
			}
		},
		computed: {},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async getAccount() {
				const result = await this.$http.getAccount();
				console.log(2222,result)
				if (result.is_check==-1||result.is_check==2) this.$linkTo.auth();
				if (result.bank_card_info) {
					this.realName = result.bank_card_info.realname || '';
					this.bankName = result.bank_card_info.bank_name || '';
					this.cardSN = result.bank_card_info.card_sn || '';
				}
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.realName,
						this.$msg.COMMON_ENTER + this.$msg.REAL_NAME)) return false;
				if (!this.$util.checkField(this.bankName,
						this.$msg.COMMON_ENTER + this.$msg.BANK_NAME)) return false;
				if (!this.$util.checkField(this.cardSN,
						this.$msg.COMMON_ENTER + this.$msg.BANK_ID)) return false;
				if (this.password.length < 6) {
				  uni.$u.toast('密码必须至少6位');
				  return false; 
				}
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.realName.trim(),
					bank_name: this.bankName.trim(),
					card_sn: this.cardSN.trim(),
					password:this.password.trim(),
				})
				if (!result) {
					this.islock = false;
					return false;
				}
				console.log('result:', result);
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success',
				});
				setTimeout(() => {
					this.islock = false;
					this.$linkTo.settings();
				}, 1000)
			},
		}
	}
</script>

<style>
</style>