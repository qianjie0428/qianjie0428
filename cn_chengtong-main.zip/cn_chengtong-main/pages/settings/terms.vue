<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="setTitle" :msg="isShow" />
		<view class="right_in" style="padding:0 32rpx 60rpx 32rpx;overflow-y: auto;max-height: 80vh;margin-top: 48rpx;">
			<template v-if="!detail">
				<view style="display: flex;align-items: center;justify-content: center;padding: 6vh 0 1vh 0;">
					<image src="/static/launch_icon.png" mode="heightFix"></image>
				</view>
				<view style="text-align: center;" :style="{color:$theme.TXT_UNACT}">
					{{$t($msg.COMMON_EMPTY_DATA)}}
				</view>
			</template>
			<template v-else>
				<view :style="{color:$theme.BLACK_70}" v-html="detail.content"></view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				detail: null
			}
		},
		computed: {
			setTitle() {
				const temp = this.$t(this.$msg.SIGN_TERMS);
				return !this.detail ? temp : this.detail.title;
			},
			isShow() {
				return this.$util.checkToken() ? true : false;
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.$util.checkToken()) this.$linkTo.isAuth();
			this.getDetail();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getDetail();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getDetail() {
				uni.showLoading({
					title: this.$t(this.$msg.API_REQUEST_DATA),
				});
				const result = await this.$http.get(`api/article/privacy`);
				if (!result) return false;
				this.detail = {
					title: result.title,
					content: result.content,
				}
			}
		}
	}
</script>

<style>
</style>