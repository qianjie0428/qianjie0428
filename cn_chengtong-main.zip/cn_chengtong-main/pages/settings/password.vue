<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.SET_PWD_TITLE)" />

		<view class="right_in" style="padding:20px 20px 100px 20px;">
			<view class="form_label">{{$t($msg.SET_PWD_OLD)}} </view>
			<view class="form_input">
				<image src="/static/pwd_old.svg" mode="aspectFit"></image>
				<input v-model="oldPwd" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.SET_PWD_OLD)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>
			<!-- @click="$util.linkCustomerService()" -->
			<view style="font-size: 11px;text-align: right;padding-top: 4px;">
				{{$t($msg.SIGN_FORGOT)}} <text
					style="color:#08459E;padding:0 4px;">{{$t($msg.COMMON_CONTACT_SERVICE)}}</text>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.SET_PWD_NEW)}} </view>
			<view class="form_input">
				<image src="/static/pwd_new.svg" mode="aspectFit"></image>
				<input v-model="newPwd" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.SET_PWD_NEW)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>

			<view class="form_label" style="margin-top: 16px;"> {{$t($msg.SET_PWD_CONFIM)}} </view>
			<view class="form_input">
				<image src="/static/pwd_new.svg" mode="aspectFit"></image>
				<input v-model="confimPwd" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.SET_PWD_CONFIM)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>
		</view>

		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
				{{$t($msg.COMMON_SUBMIT)}}
			</BtnLock>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: false,
				oldPwd: "",
				newPwd: "",
				confimPwd: "",
				isPay: false,
				islock: false,
			}
		},
		onLoad(opt) {
			// console.log(opt);
			this.isPay = opt.tag || this.isPay;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		methods: {

			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.oldPwd,
						this.$msg.COMMON_ENTER + this.$msg.SET_PWD_OLD)) return false;
				if (!this.$util.checkField(this.newPwd,
						this.$msg.COMMON_ENTER + this.$msg.SET_PWD_NEW)) return false;
				if (!this.$util.checkField(this.confimPwd,
						this.$msg.COMMON_ENTER + this.$msg.SET_PWD_CONFIM)) return false;
				if (this.newPwd != this.confimPwd) {
					uni.showToast({
						title: this.$t(this.$msg.TIP_PWDDIFF),
						icon: 'none'
					});
					return false;
				}
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const temp = this.pay ? `updatePayPassword` : `updateLoginPassword`
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPwd.trim(),
					newpass: this.newPwd.trim(),
					confirmpass: this.confimPwd.trim(),
				});
				console.log(result);
				if (!result) {
					this.islock = false;
					return false;
				}
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.settings();
					this.islock = false;
				}, 1000)
			},
		}
	}
</script>

<style>
</style>