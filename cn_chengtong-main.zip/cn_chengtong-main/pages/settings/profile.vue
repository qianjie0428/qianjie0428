<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.EDIT_PROFILE)" />

		<view class="right_in" style="padding:20px 20px 100px 20px;">
			<view class="form_label"> {{$t($msg.NICK_NAME)}} </view>
			<view class="form_input">
				<image src="/static/real-name.svg" mode="aspectFit"></image>
				<input v-model="nickName" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.NICK_NAME)"
					placeholder-class="placeholder"></input>
				<template v-if="nickName && nickName.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="nickName=''"></image>
				</template>
			</view>
			<view class="form_label" style="padding-top: 16px;"> {{$t($msg.COMMON_UPLOAD+$msg.COMMON_AVATAR)}} </view>

			<view @click="selectImg('front')"
				style="display: flex;align-items: center;justify-content: center;padding: 6px;border-radius: 8rpx;border: 1px solid #EAEAEA;background-color: #FCFDFF;">
				<template v-if="!frontURL">
					<view
						style="margin:20rpx;width:280px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
						<image src="/static/carmera.svg" mode="aspectFit" :style="$theme.setImageSize(96)">
						</image>
					</view>
				</template>
				<template v-else>
					<image :src="frontURL" style="margin:20rpx;width:160px;height:160px;">
					</image>
				</template>
			</view>
		</view>
		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
				{{$t($msg.COMMON_SUBMIT)}}
			</BtnLock>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				nickName: '',
				frontURL: null,
				islock: false,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			setStorage() {
				uni.setStorageSync('nick', this.nickName);
				uni.setStorageSync('front', this.frontURL);
			},
			getStorage() {
				this.nickName = uni.getStorageSync('nick');
				this.frontURL = uni.getStorageSync('front') || this.frontURL;
			},

			async getAccount() {
				const result = await this.$http.getAccount();
				this.nickName = result.nick_name || '';
				this.frontURL = result.avatar || '';
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.nickName,
						this.$msg.COMMON_ENTER + this.$msg.NICK_NAME)) return false;
				if (!this.$util.checkField(this.frontURL,
						this.$msg.COMMON_UPLOAD + this.$msg.COMMON_AVATAR)) return false;

				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/user/updateAvatar`, {
					nickname: this.nickName.trim(),
					avatar: this.frontURL.trim() || '',
				});
				if (!result) {
					this.islock = false;
					return false;
				}
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.settings();
					this.islock = false;
				}, 1000);
			},
			// 点击上传
			async selectImg(val) {
				this.setStorage();
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.getStorage();
				if (val == 'front') {
					this.frontURL = reultURL;
					console.log(`frontURL:`, this.frontURL);
				}
			},
		}
	}
</script>

<style>
</style>