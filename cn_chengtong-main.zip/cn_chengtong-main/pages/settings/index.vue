<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="setting_head">
		<header style="display: flex;align-items: center;background: none;width: 100%;padding: 24px 16px 10px 10px;">
			<!-- <view style="flex:1;display: flex;align-items: center;gap:4px;color:#FFF;" @click="qiehuan">
				
				<view>切换线路</view>
				<text :style="{color:$theme.setDuration(100)}">88ms</text>
				<image src="/static/arrow_down_fff.svg" mode="aspectFit" :style="$theme.setImageSize(8)" >
				</image>
			</view> -->

			<view style="margin-left: auto;">
				<view style="border-radius: 18px;padding:6px 12px;display: flex;align-items: center;min-width: 100px;"
					:style="{backgroundColor:$theme.convertRGBA(`#FFFFFF`,30)}">
					<!-- <image src="/static/search.svg" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
					<view style="padding-left: 12px;" :style="{color:$theme.convertRGBA(`#FFFFFF`,70)}">
						{{$t($msg.COMMON_SEARCH)}}
					</view> -->
				</view>
			</view>
			<!-- <image src="/static/kefu.svg" mode="aspectFit" :style="$theme.setImageSize(32)"></image> -->
		</header>
		
		<view style="width: 100%;background: #000;height: 100%;z-index: 998;position: absolute;opacity: 0.8;" v-if="qiehuan_show"></view>
		<view style="position: absolute;background-color: #fff;border-radius: 5px;width: 90%;left: 5%;top: 10%;padding: 10px;z-index: 999;" v-if="qiehuan_show">
			<view>
				<view style="background-color: #f9264c;padding: 5px 10px;color: #fff;border-radius: 5px;margin-bottom: 5px;" class="flex flex-b" v-for="(item,index) in web" @click="qiehuan_url(item.url)">
					
					<view>{{item.name}}</view>
					<view style="color: #35f384;font-weight: 700;">{{item.duration}}ms</view>
				</view>
				
			</view>
		</view>
		
		
		<view class="left_in">
			<view style="display: flex;align-items: center;padding:0 20px;" @click="$linkTo.profile()">
				<image :src='!user||!user.avatar?`/static/logo1.png`:$util.setLogo(user.avatar)' mode="scaleToFill"
					:style="$theme.setImageSize(64)" style="border-radius: 100%;"></image>
				<view style="flex:1;color: #FFF;">
					<view style="padding-left: 12px;font-size: 16px;font-weight: 700;text-transform:uppercase;">
						{{!user?'': user.name}}
					</view>
					<view style="padding-left: 12px;">{{!user?'':user.mobile}}</view>
				</view>
			</view>

			<AssetsCard :info="userAssets" />

			<view
				style="display: flex;align-items: center;justify-content: space-around;gap:20px; padding:0 20px;font-size: 15px;height: 40px;line-height: 40px;margin-top: 10px;">
				<view
					style="border-radius: 22px;background-color: #FFEEEE;flex:1;display: flex;align-items: center;justify-content: center;"
					@click="$linkTo.deposit()">
					<image src="/static/setting_withdraw.svg" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
					<text style="padding-left: 12px;" :style="{color:$theme.PRIMARY}">银证转入</text>
				</view>
				<view @click="$linkTo.withdraw()"
					style="background-color: #EE1515;border-radius: 22px;flex:1;display: flex;align-items: center;justify-content: center;">
					<image src="/static/setting_deposit.svg" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
					<text style="color:#FFFFFF;padding-left: 12px;">银证转出</text>
				</view>
			</view>

			<view class="btns" style="padding: 20px;">
				<block v-for="(v,k) in otherBtns" :key="k">
					<view class="item" @click="v.action">
						<image mode="aspectFit" :src="`/static/menu/${v.icon}.svg`" :style="$theme.setImageSize(24)">
						</image>
						<view style="font-size: 13px;margin-top: 4px;text-align: center;font-weight: 500;">{{v.name}}
						</view>
					</view>
				</block>
			</view>

			<view style="padding:20px;background-color: #FFFFFF;border-radius: 20px 20px 0 0;min-height: 60vh;">
				<!-- <view @click="openLgre()"
					style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 2.4;">
					<view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view>
					<view style="padding-left: 12px;color: #6D6D6D;flex:1;">{{$t($msg.LGRE_TITLE)}}</view>
					<view style="font-size: 14px;font-weight: 500;" :style="{color:$theme.PRIMARY}">
						{{curLang}}
					</view>
				</view> -->

				<block v-for="(v,k) in setBtns" :key="k">
					<view @click="v.action"
						style="display: flex;align-items: center;border-bottom: 0.5px solid #C0C0C03A;line-height: 3.2;font-size: 13px;"
						:style="{borderBottom:`${k<setBtns.length-1?`0.5`:`0`} solid #C0C0C03A`}">
						<!-- <view style="width: 6px;height: 6px;background-color: #659FFB;border-radius: 100%;"></view> -->
						<image mode="aspectFit" :src="`/static/setting_${v.icon}.svg`" :style="$theme.setImageSize(20)">
						</image>
						<view style="padding-left: 12px;flex:1;" :style="{color:$theme.BLACK_70}">{{v.name}}</view>
						<template v-if="v.key ===$C.KEY_AUTH">
							<view style="font-size: 12px;padding-right: 12px;"
								:style="{color:$theme.setRiseFall(!user?-1: user.isCheck)}">
								{{setAuth(!user?-1: user.isCheck)}}
							</view>
						</template>
						<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
						</image>
					</view>
				</block>
				<view style="border-radius: 22px;text-align: center;line-height: 3.6;width: 60%;margin: 20px auto;"
					:style="{backgroundColor:$theme.convertRGBA(`#EE1515`,10),color:$theme.BLACK_30}" @click="$util.signOut()">
					退出登录
				</view>
				<view style="height: 40px;"></view>
			</view>
		</view>

		<FooterSmall :actKey="$C.KEY_ACCOUNT"></FooterSmall>

		<!-- <u-picker :show="showLang" :columns="[lgres]" @change="chooseLgre" @cancel="showLang=false"
			@confirm="confirmLgre" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="lang"
			visibleItemCount="9"></u-picker> -->

		<template v-if="showLine">
			<u-picker :show="showLine" :columns="[setApiResults]" @change="chooseLine" @cancel="showLine=false"
				@confirm="confirmLine" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
				:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
				visibleItemCount="9"></u-picker>
		</template>
	</view>
</template>

<script>
	import {
		encrypt,
		decrypt
	} from "@/common/crypto.js";
	import * as ext from './ext.js';
	// import {
	// 	lgre,
	// 	getLang,
	// 	setLgre
	// } from '@/localize/index.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				user: null,
				setBtns: ext.setBtns(),
				otherBtns: ext.otherBtns(),
				userAssets: null,

				apiResults: null, // 测速结果组
				curAPI: null, // 当前线路
				showLine: false, //
				
				apiRequested: false, // **防止 API 多次请求**
				murl:"",
				aurl:"",
				show:false,
				qiehuan_show:false,
				content:"",
				APIS : [
					{ url: `0ESwiu01MXLxh6XZHIsrhM5PV0mbfcUlqNqg1ZcapZA=`, name: "上证信息北京行情(联通)", },
					{ url: `MosO3zjPc3nTU3l9T438MrWX1weApQ66Gl+U1HenLNE=`, name: "上证信息成都行情(移动)" },
				],
				web:[]
				
			}
		},
		computed: {
			setApiResults() {
				if (this.apiResults && this.apiResults.length > 0) {
					return this.apiResults.map(v => { return { ...v, label: `${v.name} - ${v.duration}ms` } })
				}
			}
			// curLang() {
			// 	console.log(getLang());
			// 	return getLang();
			// },
			// lgres() {
			// 	return Object.values(lgre)
			// },
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			qiehuan(){
				this.show=false
				this.qiehuan_show=true
				this.testAPIS()
			},
			qiehuan_url(url){
				this.show=false
				this.qiehuan_show=false
				uni.setStorageSync('host',url);
				this.percentage=1
				this.apiRequested=false
				this.getAccount();
			},
			// 批量测试所有API域名
			async testAPIS(){
				uni.showLoading({
					title:"线路测速中,请稍等"
				})
				const apiTests = await this.APIS.map(v => this.testAPI(v));
				const apiResult = await Promise.all(apiTests); // 等待所有测试完成
				console.log(`testAPIS:`, apiTests, apiResult);
			
				const temp = apiResult.filter(v => v.duration != Infinity);
			
				console.log(3333,temp.sort((a, b) => a.duration - b.duration))
				this.web= temp.sort((a, b) => a.duration - b.duration)
				uni.hideLoading()
			},
			// 测试API域名的响应时间
			async testAPI(val) {
			    const startTime = Date.now();
			    try {
			        const url = decrypt(val.url);
			        const response = await uni.request({
			            url: `${url}/api/tool/api`,
			            method: 'GET'
			        });
			
			        const [err, res] = response;
			        console.log(`testAPI:`, err, res);
			
			        if (res && res.statusCode === 200) {
			            // 判断 URL 是否包含 "mockapi"
			            let status;
			            if (url.includes("mockapi")) {
			                status = res.data?.[0]?.status; // 访问数组第一项的 status
			            } else {
			                status = res.data?.status;
			            }
			
			            if (status === 200) {
			                const duration = Date.now() - startTime; // 计算时间
			                return { url: val.url, name: val.name, duration };
			            }
			        }
			        return { url: val.url, name: val.name, duration: Infinity };
			    } catch (error) {
			        console.error(`Error testing API ${val.url}:`, error);
			        return { url: val.url, name: val.name, duration: Infinity };
			    }
			},
			setAuth(val) {
				const temp = val == 1 ? 0 : -1;
				return ext.auth()[temp + 1];
			},
			async getAccount() {
				const result = await this.$http.getAccount();
				this.user = {
					avatar: result.avatar || null,
					mobile: result.mobile || '',
					name: result.nick_name || '',
					isCheck: result.is_check || -1,
				}
				this.userAssets = {
					totalZichan: result.totalZichan,
					money: result.money,
					floatPL: result.holdYingli,
				}
			},

			openLine() { this.showLine = true },
			chooseLine(e) { console.log(`chooseLine e:`, e); },
			confirmLine(e) {
				console.log(`confirmLine e:`, e);
				this.showLine = false;
				this.curAPI = e.value[0];
				// 替换api域名
				this.$http.setCurHost(this.curAPI.url);
				this.$forceUpdate();
				this.$linkTo.settings();
			},
			// openLgre() {
			// 	this.showLang = true;
			// },
			// chooseLgre(e) {
			// 	console.log(`changeMode e:`, e);
			// },
			// confirmLgre(e) {
			// 	console.log(`confirmMode e:`, e);
			// 	this.showLang = false;
			// 	setLgre(e.value[0].code);
			// 	this.$forceUpdate();
			// 	window.location.reload();
			// },
		}
	}
</script>

<style>
</style>