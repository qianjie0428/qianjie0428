<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.FEATURES_TITLE)">
			<image src="/static/home.svg" mode="aspectFit" :style="$theme.setImageSize(32)" @click="$linkTo.home()"
				style="padding-right: 16px;">
			</image>
		</CommonHeader>
		<view class="right_in" style="padding:28px 16px;">
			<view class="btns">
				<block v-for="(v,k) in btns" :key="k">
					<view class="item" style="width: 25%;" @click="v.action">
						<image mode="aspectFit" :src="`/static/menu/${v.icon}.svg`" :style="$theme.setImageSize(30)"
							style=""></image>
						<text class="text-center"
							style="font-size: 14px;margin-top: 8px;padding-bottom: 16px;">{{v.name}}</text>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				btns: ext.btns(),
			}
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
			this.$linkTo.isAuth();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		methods: {}
	}
</script>

<style>
</style>