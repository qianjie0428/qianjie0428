<template>
	<view class="bg_page_conver" :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/bg_qdy.jpg);background-size: contain;background-size: 100% 100%;background-repeat: no-repeat;">
		
		<view class="progress_tipx" style="line-height: 1.8;">
			<view style="font-size: 15px;">投资有风险 入市需谨慎</view>
			<view class="">
				<view >已支持<text style="border: 1px #ccc solid;border-radius: 30px;padding: 0px 5px;margin:0px 5px;">IPv6</text>网络</view>
				<view>ICP备案号:京ICP证030374号-4A</view>
			</view>
		</view>

		<view style="position: absolute;bottom: 100px;left: 0;right: 0;text-align: center;">
			<view style="margin: 0 auto;border-radius: 20px;background-color:rgba(255,255,255,0.5);width: 90%;">
				<view style="position: relative;width: 100%;height:16px;border-radius: 20px;"
					:style="{border:`1px solid #AAA`}">
					<view :style="setStyle"></view>
					<view class="progress_value" style="color: #fff;">
						{{percentage+` %`}}
					</view>
				</view>
			</view>
		</view>

		<view class="progress_tip"> {{curTip}} </view>

		<view style="position: absolute;bottom: 20px;left: 0;right: 0;text-align: center;">
			<CopyrightVersion color="#AAA" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},
		computed: {
			// 當前顯示文字，每20換一行文字
			curTip() {
				let temp = '';
				this.$msg.LAUNCH_TIPS.forEach((v, k) => {
					if (this.percentage > (k * 20)) temp = v;
				});
				return temp;
			},

			// 设置进度条递进样式
			setStyle() {
				const _direction = 'left'; // 当前方向
				const temp = {
					position: 'absolute',
					bottom: 0,
					[`${_direction}`]: 0, // 决定进度条的递进方向
					height: '16px',
					width: `${this.percentage}%`,
					backgroundImage: this.$theme.linerGradient(90, `#ff0e22`, `#ff0e22`),
					borderRadius: '20px',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		onLoad() {
			this.clearTimer();
			this.onSetTimeout();
		},
		onShow() {
			this.isAnimat = true;
			this.clearTimer();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					if (this.percentage < 100) this.percentage++;
					else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							this.$linkTo.home();
						}, 1500);
					}
				}, 30);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
				}
			},
		}
	}
</script>

<style>
</style>