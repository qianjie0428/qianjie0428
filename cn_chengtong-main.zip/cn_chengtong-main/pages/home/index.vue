<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="home_bg">
		<template v-if="setUser">
			<CommonHeader :layout="$C.HEADER_3" :dir="$C.KEY_RIGHT" :total="setUser.totalPL" :hold="setUser.holdPL"
				:avatar="setUser.avatar" />
		</template>
		<view class="home_btns_bg">
			<view class="btns">
				<block v-for="(v,k) in btns" :key="k">
					<view class="item" @click="v.action">
						<image mode="aspectFit" :src="`/static/home/btn_${k}.png`" :style="$theme.setImageSize(32)">
						</image>
						<view style="font-size: 14px;margin-top: 4px;text-align: center;font-weight: 500;"
							:style="{color:$theme.BLACK_70, paddingBottom:k<5 ?'16px':''}">{{v.name}}</view>
					</view>
				</block>
			</view>
			<!-- <view style="text-align: center;padding-top: 12px;">
				<image src="/static/home/banner.png" mode="aspectFit" :style="$theme.setImageSize(360,100)"></image>
			</view> -->
			<template>
				<view style="margin-top: 20px;">
					<u-swiper :list="list2" keyName="image" interval="4000"  showTitle :autoplay="true" imgMode="heightFix" height="120" circular></u-swiper>
				</view>
			</template>
		</view>

		<!-- <view class="home_line_wrapper">
			<template v-if="homeCurves && homeCurves.length>0">
				<HomeCurves :list="homeCurves" />
			</template>
		</view> -->

		<view class="home_wealth_bg" style="margin-top: 10px;padding:16px;">
			<view style="font-size: 16px;font-weight: 700;">
				<text :style="{color:$theme.PRIMARY,borderBottom:`3px solid ${$theme.PRIMARY}`}">理财</text>
				<text :style="{color:$theme.BLACK_70}">速递</text>
			</view>
			<!-- finances -->
			<block v-for="(v,k) in setNews" :key="k">
				<view style="display: flex;align-items: center;padding-top: 12px;font-size: 12px;">
					<text style="border-radius: 2px;text-align: center;padding:0 2px;width: 48px;"
						:style="{color:$theme.PRIMARY,border:`0.1px solid ${$theme.PRIMARY}`}">新发</text>
					<text class="ellipsis" style="flex:1; padding-left: 4px;color:#999;">{{v.title}}</text>
				</view>
			</block>
		</view>

		<view class="home_news_btn">
			<block v-for="(v,k) in tabs" :key="k">
				<view class="item" @click="v.action">
					<image mode="aspectFit" :src="`/static/home/icon_${k}.png`" :style="$theme.setImageSize(32)"
						style=""></image>
					<text class="text-center" style="margin-top: 4px;">{{v.name}}</text>
				</view>
			</block>
		</view>

		<view class="home_news_tabs">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;padding:0;" @touchmove.stop>
				<view style="display: flex;margin:0 4px;">
					<block v-for="(v,k) in $msg.NEWS_TABS" :key='k'>
						<view style="font-size: 15px;padding-right: 12px;" @click="changeTab(k)">
							<view style="padding-bottom: 12px;"
								:style="{ color:curTab==k?$theme.PRIMARY : $theme.TXT_UNACT }">{{v}}
							</view>
							<view style="width: 28px;height: 3px; margin:0 auto; border-radius: 24px;"
								:style="{ backgroundColor:curTab==k?$theme.PRIMARY : $theme.TRANSPARENT }">
							</view>
						</view>
					</block>
				</view>
			</scroll-view>
		</view>

		<template v-if="!news || news.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in news.slice(0,100)" :key="k">
				<view class="news_item" @click="$linkTo.openNews(v.url)">
					<!-- <image :src="v.pic" mode="scaleToFill" :style="$theme.setImageSize(60)" style="border-radius: 6px;">
					</image> -->
					<view style="flex:1;display: flex;flex-direction: column;justify-content: space-between;">
						<view style="font-size: 13px;"><text>{{v.title}}</text> </view>
						<view style="flex:0 0 auto;display: flex;justify-content: flex-end;font-size: 12px;"
							:style="{color:$theme.TXT_UNACT}">
							<!-- <view>{{v.origin}}</view>
							<view>{{$fmt.quantity(v.read)+` `+$t($msg.COMMON_READ)}}</view> -->
							<view>{{v.dt}}</view>
						</view>
					</view>
				</view>
			</block>
		</template>

		<view style="text-align: center;line-height: 1.6;" :style="{color:$theme.TXT_UNACT}">{{$t($msg.COMMON_100)}}
		</view>
		
		<template v-if="showIPO && detail">
			<view class="overlay" style="background-color: rgba(0,0,0,0.5);" @click="showIPO=false"></view>
			<view class="modal_wrapper_center" style="background-color: #fff;">
				<view class="card_dark" style="padding: 20px;margin:0;">
					<view class="" style="color: #000;background-size:40%;">
						<!-- <view style="text-align: center;font-size: 16px;font-weight: 900;">
							新股
						</view> -->
						<view style="text-align: center;font-size: 16px;font-weight: 300;margin-top: 20px;">
							 恭喜您中签新股！
						</view>
						<view style="font-size: 32rpx;font-weight: 700;padding:20px 0;">
							<text style="">
								{{detail.name}}
							</text>
							({{detail.code}})
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>中签数量:</view>
							<text style="font-weight: 900;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.quantity(detail.success)}}</text>
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>申购价格:</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.amount(detail.price,$CUR_LGRE,$util.isUS(detail.type))}}</text>
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>中签金额:</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.amount(detail.total,$CUR_LGRE,$util.isUS(detail.type))}}</text>
						</view>
						<!-- <view style="font-size: 12px;text-align: left;padding: 24px 0;">{{$t($msg.IPO_SUCCESS_TIP)}}
						</view> -->
						<view style="padding: 10px;">
							<view class="btn_signIn" style="background-color: #ff3636;padding: 10px;text-align: center;color: #fff;border-radius: 5px;" @click="showIPO=false">{{$t($msg.IPO_SUCCESS_CLOSE)}}</view>
						</view>
						
					</view>
				</view>
			</view>
		</template>
		
		<template v-if="showPS && detail">
			<view class="overlay" style="background-color: rgba(0,0,0,0.5);" @click="showPS=false"></view>
			<view class="modal_wrapper_center" style="background-color: #fff;">
				<view class="card_dark" style="padding: 20px;margin:0;">
					<view class="" style="color: #000;background-size:40%;">
						<!-- <view style="text-align: center;font-size: 16px;font-weight: 900;">
							配售
						</view> -->
						<view style="text-align: center;font-size: 16px;font-weight: 300;margin-top: 20px;">
							 恭喜您配售成功！
						</view>
						<view style="font-size: 32rpx;font-weight: 700;padding:20px 0;">
							<text style="">
								{{detail.name}}
							</text>
							({{detail.code}})
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>配售数量:</view>
							<text style="font-weight: 900;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.quantity(detail.success)}}</text>
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>配售价格:</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.amount(detail.price,$CUR_LGRE,$util.isUS(detail.type))}}</text>
						</view>
						<view style="padding: 10px 0;display: flex;align-items: center;padding:10px 0;">
							<view>配售金额:</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 18px;padding-left: 20px;">
								{{$fmt.amount(detail.success*detail.price)}}</text>
						</view>
						<!-- <view style="font-size: 12px;text-align: left;padding: 24px 0;">{{$t($msg.IPO_SUCCESS_TIP)}}
						</view> -->
						<view style="padding: 10px;">
							<view class="btn_signIn" style="background-color: #ff3636;padding: 10px;text-align: center;color: #fff;border-radius: 5px;" @click="showPS=false">{{$t($msg.IPO_SUCCESS_CLOSE)}}</view>
						</view>
						
					</view>
				</view>
			</view>
		</template>

		<view style="height: 100px;"></view>

		<FooterSmall :actKey="$C.KEY_HOME"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import HomeCurves from './components/HomeCurves.vue';
	export default {
		components: {
			HomeCurves
		},
		data() {
			return {
				isAnimat: false,
				btns: ext.btns(),
				tabs: ext.tabs(),
				// newsTabs: ext.newsTabs(),
				curTab: 0,
				user: {
					'totalPL': "--",
					'holdPL': "--",
					'avatar': "--",
					'total': "--",
					'hold': "--"
				},
				news: null,
				showIPO: false,
				showPS: false,
				finances: null,
				homeCurves: null,
				list2: [{
						image: "/static/lbt_1.png",
						// title: "昨夜星辰昨夜风，画楼西畔桂堂东",
					},
					{
						image: "/static/lbt_2.png",
						// title: "身无彩凤双飞翼，心有灵犀一点通",
					},
					{
						image: "/static/lbt_3.jpg",
						// title: "谁念西风独自凉，萧萧黄叶闭疏窗，沉思往事立残阳",
					},
				],
			}
		},
		computed: {
			setUser() {
				if (this.user) {
					return {
						totalPL: this.user.money * 1,
						holdPL: this.user.holdYingli * 1 || "--",
						avatar: this.user.avatar || '',
					}
				}
			},
			setNews() {
				if (!this.news || this.news.length <= 0) return [];
				return this.news.length <= 2 ? this.news : this.news.slice(0, 2);
			}
		},
		onLoad(op) {
			if (op.aurl) {
				uni.setStorageSync('host', op.aurl)
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			const token=uni.getStorageSync('token')
			if(token){
				this.getIPOAlert();
				this.getPSAlert();
			}
			
			this.isAnimat = true;
			this.finances = await this.$http.getFinanceNews();
			this.user = await this.$http.getAccount();
			this.homeCurves = await this.$http.getHomeCurves();
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.finances = await this.$http.getFinanceNews();
			this.user = await this.$http.getAccount();
			this.changeTab(this.curTab);
			this.homeCurves = null;
			this.homeCurves = await this.$http.getHomeCurves();
			uni.stopPullDownRefresh();
		},
		methods: {
			getCurHost() {
				console.log("url", decrypt(uni.getStorageSync('host')), decrypt(uni.getStorageSync('host') ? uni
					.getStorageSync('host') : this.APIS[0].url))
				return decrypt(uni.getStorageSync('host') ? uni.getStorageSync('host') : this.APIS[0].url);
			},
			changeTab(v) {
				this.curTab = v;
				this.getNews();
			},
			async getIPOAlert() {
				this.detail = await this.$http.getIPOAlert();
				if (this.detail) this.showIPO = true;
			},
			
			async getPSAlert() {
				this.detail = await this.$http.getPSAlert();
				if (this.detail) this.showPS = true;
			},
			
			async getNews() {
				let current = 10;
				switch (this.curTab) {
					case 0:
						current = 0;
						break;
					case 1:
						current = 1;
						break;
					case 2:
						current = 10;
						break;
					case 3:
						current = 3;
						break;
					case 4:
						current = 11;
						break;
				}
				this.news = await this.$http.getNews(current) || this.news;
			},
		}
	}
</script>

<style>
</style>