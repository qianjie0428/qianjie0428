import * as linkTo from '@/common/linkTo.js';
import * as util from '@/common/util.js';
import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return [{
		name: `行情`,
		action: linkTo.markets
	}, {
		name: `次新股`,
		action: linkTo.iporecent
	}, {
		name: translate(Msg.MENU_REPORT),
		action: linkTo.report
	}, {
		name: translate(Msg.MENU_PERFORMANCE),
		action: linkTo.performance
	}]
};

export const btns = () => {
	return [{
			name: translate(Msg.MENU_IPO),
			action: linkTo.ipo
		},
		{
			name: translate(Msg.MENU_SCRAMBLE),
			action: linkTo.scramble
		},
		{
			name: translate(Msg.MENU_MARGIN),
			action: linkTo.trade
		},
		{
			name: translate(Msg.MENU_BLOCK),
			action: linkTo.block
		},
		// {
		// 	name: translate(Msg.MENU_SERVICE),
		// 	action: util.linkCustomerService
		// },
		{
			name: translate(Msg.MENU_LONGHU),
			action: linkTo.longhu
		},
		{
			name: translate(Msg.MENU_DASHBOARD),
			action: linkTo.dashboard
		},
		{
			name: translate(Msg.MENU_TREND),
			action: linkTo.trend
		}, {
			name: translate(Msg.MENU_DATA),
			action: linkTo.dataCenter
		},{
			name: translate(Msg.MENU_VIP),
			action: linkTo.vip
		}, {
			name: translate(Msg.MENU_ALL),
			action: linkTo.features
		},
	]
};