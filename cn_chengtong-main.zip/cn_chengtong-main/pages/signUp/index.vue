<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGCover(`sign_bg`)">
		<view style="display: flex;align-items: center;justify-content: center;padding:80px 0 0 0;">
			<image :src="`/static/sign_up_icon.png`" mode="widthFix" style="width: 132px;"></image>
		</view>

		<view style="padding:36px 20px;">
			<view class="form_input" style="margin: 15px 0;">
				<image src="/static/sign_user.svg" mode="aspectFit"></image>
				<input v-model="user" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.SIGN_ACCOUNT)"
					placeholder-class="placeholder"></input>
				<template v-if="user && user.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="user=''"></image>
				</template>
			</view>

			<view class="form_input" style="margin-bottom: 15px;">
				<image src="/static/sign_pwd.svg" mode="aspectFit"></image>
				<input v-model="password" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.SIGN_PWD)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>

			<view class="form_input" style="margin-bottom: 15px;">
				<image src="/static/sign_pwd.svg" mode="aspectFit"></image>
				<input v-model="verifyPassword" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.SIGN_PWD_CONFIRM)"
					placeholder-class="placeholder"></input>
				<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()"></image>
			</view>

			<view class="form_input" style="margin-bottom: 15px;">
				<image src="/static/sign_invite.svg" mode="aspectFit"></image>
				<input v-model="inviteCode" type="text" :placeholder="$t($msg.COMMON_ENTER+$msg.SIGN_INVITATION)"
					placeholder-class="placeholder"></input>
				<template v-if="inviteCode && inviteCode.length > 0">
					<image src="/static/del.svg" mode="aspectFit" @click="inviteCode=''"></image>
				</template>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;margin-top: 10px;">
				<view>
					<u-checkbox-group>
					    <!-- 去掉多余的 shape、iconColor 等，这些会和自定义图标冲突 -->
					    <u-checkbox 
					        v-model="isAgree"
					        :label="$t($msg.SIGN_AGREE)"
					        :labelColor="$theme.CHECKBOX_LABEL_COLOR"
					        labelSize="14px"
					        @change="changeAgree"
					    >
					        <!-- 自定义 icon 插槽 -->
					        <template #icon>
					            <!-- 只在选中时显示“√”，未选中则不显示 -->
					            <!-- <text v-if="isAgree" style="color: black; font-size:16px;">√</text> -->
								<image v-if="isAgree" src="/static/duigou.png" mode="widthFix" style="width: 14px;height: 14px;"></image>
					        </template>
					    </u-checkbox>
					</u-checkbox-group>
				</view>
				<view>
					<text style="margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkTerms()">
						{{$t($msg.SIGN_TERMS)}}
					</text>
				</view>
			</view>

			<view style="width: 100%;margin:21.5px auto;">
				<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit">
					<text>{{$t($msg.SIGN_TITLE_UP)}}</text>
				</BtnLock>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<view style="padding-right: 20px;">
					{{$t($msg.SIGN_EXIST_ACCOUNT)}}
				</view>
				<view @click="$linkTo.signIn()" :style="{color:$theme.PRIMARY}">
					{{$t($msg.SIGN_TITLE_IN)}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 是否掩码
				tag: '', // url携带tag值
				user: '', // 账号
				password: '', // 密码
				verifyPassword: '', // 确认密码
				inviteCode: '', // 默认为 url 携带code邀请码
				isAgree: false, // 同意隐私协议
				islock: false, // 按钮是否锁定
			}
		},
		onLoad(opt) {
			console.log(opt);
		},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = uni.getStorageSync('user');
			this.password = uni.getStorageSync('pwd');
		},
		onHide() {
			this.isAnimat = false;
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 跳转到首页 窄屏 关闭按钮 宽屏点击应用名称
			linkHome() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.home();
			},
			linkTerms() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.terms();
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.user,
						this.$msg.COMMON_ENTER + this.$msg.SIGN_ACCOUNT)) return false;
				if (!this.$util.checkField(this.password,
						this.$msg.COMMON_ENTER + this.$msg.SIGN_PWD)) return false;
				if (!this.$util.checkField(this.verifyPassword,
						this.$msg.COMMON_ENTER + this.$msg.SIGN_PWD_CONFIRM)) return false;
				if (!this.$util.checkField(this.inviteCode,
						this.$msg.COMMON_ENTER + this.$msg.SIGN_INVITATION)) return false;
				if (this.password != this.verifyPassword) {
					uni.showToast({
						title: this.$t(this.$msg.TIP_PWDDIFF),
						icon: 'none'
					})
					return false;
				}
				if (this.isAgree != true) {
					uni.showToast({
						title: this.$t(this.$msg.TIP_CHECK_AGREE),
						icon: 'none'
					})
					return false;
				}
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_REGISTER),
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user.trim(),
					password: this.password.trim(),
					confirmpass: this.verifyPassword.trim(),
					invite: this.inviteCode.trim(),
					code: 123456,
				});
				console.log('result:', result);
				if (!result) {
					this.islock = false;
					return false;
				}
				uni.showToast({
					title: this.$t(this.$msg.SIGN_TITLE_UP + ` ` + this.$msg.COMMON_SUCCESS),
					icon: 'success'
				})
				setTimeout(() => {
					this.islock = false;
					this.$linkTo.signIn();
				}, 1000);
			}
		}
	}
</script>

<style lang="scss" scoped>
	::v-deep.u-checkbox__icon-wrap {
		background-color: transparent !important;
	}
</style>