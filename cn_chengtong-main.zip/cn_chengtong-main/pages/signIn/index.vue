<template>
	<view class="bg_page_conver" :class="isAnimat?'fade_in':'fade_out'"
		style="background-image: url(/static/sign_bg.png);">

		<view style="padding: 24px 12px 0 0;display: flex;align-items: center;justify-content: flex-end;gap:4px;"  @click="qiehuan">
			
			<view>切换线路</view>
			<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(8)" @tap="openLine()">
			</image>
		</view>
		
		<view style="width: 100%;background: #000;height: 100%;z-index: 998;position: absolute;opacity: 0.8;" v-if="qiehuan_show"></view>
		<view style="position: absolute;background-color: #fff;border-radius: 5px;width: 90%;left: 5%;top: 10%;padding: 10px;z-index: 999;" v-if="qiehuan_show">
			<view>
				<view style="background-color: #f9264c;padding: 5px 10px;color: #fff;border-radius: 5px;margin-bottom: 5px;" class="flex flex-b" v-for="(item,index) in web" @click="qiehuan_url(item.url)">
					
					<view>{{item.name}}</view>
					<view style="color: #35f384;font-weight: 700;">{{item.duration}}ms</view>
				</view>
				
			</view>
		</view>
		
		<view style="padding:60px 0 0 0;text-align: center;">
			<image :src="`/static/sign_in_icon.png`" mode="widthFix" style="width: 132px;"></image>
		</view>

		<view style="padding:36px 20px;">
			<!-- <view class="sign_lgre" @click="openLgre()">
				<text class="sign_lgre_text"> {{curLang}}</text>
			</view> -->

			<template v-if="isPwdSign">
				<view class="form_input" style="margin-bottom: 15px;">
					<image src="/static/sign_user.svg" mode="aspectFit"></image>
					<input v-model="user" type="text" :placeholder="$msg.COMMON_ENTER+ $msg.SIGN_ACCOUNT"
						placeholder-class="placeholder"></input>
					<template v-if="user && user.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @click="user=''"></image>
					</template>
				</view>
				<view class="form_input" style="margin-bottom: 15px;">
					<image src="/static/sign_pwd.svg" mode="aspectFit"></image>
					<input v-model="password" :password="isMask" :placeholder="$msg.COMMON_ENTER+$msg.SIGN_PWD"
						placeholder-class="placeholder"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" @click="toggleMask()">
					</image>
				</view>
			</template>
			<template v-else>
				<view class="form_input" style="margin-bottom: 15px;">
					<image src="/static/sign_user.svg" mode="aspectFit"></image>
					<input v-model="user" type="text" :placeholder="$t($msg.COMMON_ENTER+ $msg.SIGN_MOBILE)"
						placeholder-class="placeholder"></input>
					<template v-if="user && user.length > 0">
						<image src="/static/del.svg" mode="aspectFit" @click="user=''"></image>
					</template>
				</view>
				<view class="form_input" style="margin-bottom: 15px;">
					<image src="/static/sign_pwd.svg" mode="aspectFit"></image>
					<input v-model="verCode" type="text" :placeholder="$t($msg.COMMON_ENTER+$msg.SIGN_VCODE)"
						placeholder-class="placeholder"></input>
					<template v-if="isGetting">
						<text class="ver_code"> {{seconds}}</text>
					</template>
					<template v-else>
						<text class="ver_code" @click="getVCode()"> {{$t($msg.SIGN_GET_VCODE)}}</text> </template>
				</view>
			</template>

			<view class="flex_row_between">
				<template v-if="isPwdSign">
					<!-- <view @click="isPwdSign=false">{{$t($msg.SIGN_LOGIN_VCODE)}}</view> -->
					<view style="margin-left: auto;cursor: pointer;" :style="{color:$theme.PRIMARY}" @click="handleService()">
						{{$t($msg.SIGN_FORGOT)}}
					</view>
				</template>
				<template v-else>
					<view @click="isPwdSign=true">{{$t($msg.SIGN_LOGIN_PWD)}}</view>
				</template>
			</view>

			<view style="width: 100%;margin:21.5px auto;">
				<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit">
					<text>{{$t($msg.SIGN_TITLE_IN)}}</text>
				</BtnLock>
			</view>

			<view class="flex_row_center">
				<view style="padding-right: 20px;"> {{$t($msg.SIGN_NO_ACCOUNT)}} </view>
				<view @click="linkSignUp()" :style="{color:$theme.PRIMARY}"> {{$t($msg.SIGN_NOW)}} </view>
			</view>
		</view>

		<!-- <u-picker :show="showLang" :columns="[lgres]" @change="chooseLgre" @cancel="showLang=false" @confirm="confirmLgre"
			:cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)" :cancelColor="$theme.MODAL_CANCEL"
			:confirmColor="$theme.PRIMARY" keyName="lang" visibleItemCount="9"></u-picker> -->
		<template v-if="showLine">
			<u-picker :show="showLine" :columns="[setApiResults]" @change="chooseLine" @cancel="showLine=false"
				@confirm="confirmLine" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
				:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
				visibleItemCount="9"></u-picker>
		</template>
	</view>
</template>

<script>
	import {
		encrypt,
		decrypt
	} from "@/common/crypto.js";
	// import { lgre, getLang, setLgre } from '@/localize/index.js';
	export default {
		data() {
			return {
				isAnimat: false,
				isMask: null,
				tag: '',
				user: '',
				password: '',
				verCode: '',
				islock: false,
				// showLang: false,
				isPwdSign: true,
				isGetting: false,
				seconds: 120,
				secondsInterval: null,

				apiResults: null, // 测速结果组
				curAPI: null, // 当前线路
				showLine: false, //
				
				apiRequested: false, // **防止 API 多次请求**
				murl:"",
				aurl:"",
				show:false,
				qiehuan_show:false,
				content:"",
				APIS : [
					{ url: `0ESwiu01MXLxh6XZHIsrhM5PV0mbfcUlqNqg1ZcapZA=`, name: "上证信息北京行情(联通)", },
					{ url: `MosO3zjPc3nTU3l9T438MrWX1weApQ66Gl+U1HenLNE=`, name: "上证信息成都行情(移动)" },
				],
				web:[]
			}
		},
		computed: {
			setApiResults() {
				if (this.apiResults && this.apiResults.length > 0) {
					return this.apiResults.map(v => { return { ...v, label: `${v.name} - ${v.duration}ms` } })
				}
			}
			// curLang() {
			// 	console.log(getLang());
			// 	return getLang();
			// },
			// lgres() {
			// 	return Object.values(lgre)
			// },
		},
		async onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = uni.getStorageSync('user');
			this.password = uni.getStorageSync('pwd');
			this.isGetting = false;
			this.secondsInterval = null;

			// }
		},
		onHide() {
			this.isAnimat = false;
			uni.setStorageSync('user', this.user);
			uni.setStorageSync('pwd', this.password);
			clearInterval(this.secondsInterval);
		},
		methods: {
			qiehuan(){
				this.show=false
				this.qiehuan_show=true
				this.testAPIS()
			},
			qiehuan_url(url){
				this.show=false
				this.qiehuan_show=false
				uni.setStorageSync('host',url);
				
				this.percentage=1
				this.apiRequested=false
				this.getAccount();
			},
			// 批量测试所有API域名
			async testAPIS(){
				uni.showLoading({
					title:"线路测速中,请稍等"
				})
				const apiTests = await this.APIS.map(v => this.testAPI(v));
				const apiResult = await Promise.all(apiTests); // 等待所有测试完成
				console.log(`testAPIS:`, apiTests, apiResult);
			
				const temp = apiResult.filter(v => v.duration != Infinity);
			
				console.log(3333,temp.sort((a, b) => a.duration - b.duration))
				this.web= temp.sort((a, b) => a.duration - b.duration)
				uni.hideLoading()
			},
			// 测试API域名的响应时间
			async testAPI(val) {
			    const startTime = Date.now();
			    try {
			        const url = decrypt(val.url);
			        const response = await uni.request({
			            url: `${url}/api/tool/api`,
			            method: 'GET'
			        });
			
			        const [err, res] = response;
			        console.log(`testAPI:`, err, res);
			
			        if (res && res.statusCode === 200) {
			            // 判断 URL 是否包含 "mockapi"
			            let status;
			            if (url.includes("mockapi")) {
			                status = res.data?.[0]?.status; // 访问数组第一项的 status
			            } else {
			                status = res.data?.status;
			            }
			
			            if (status === 200) {
			                const duration = Date.now() - startTime; // 计算时间
			                return { url: val.url, name: val.name, duration };
			            }
			        }
			        return { url: val.url, name: val.name, duration: Infinity };
			    } catch (error) {
			        console.error(`Error testing API ${val.url}:`, error);
			        return { url: val.url, name: val.name, duration: Infinity };
			    }
			},
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async getVCode() {
				// send get code api ,and if success
				// const result = await this.$http.getVerCode();
				// if (!result) return false;
				this.isGetting = true;
				this.secondsInterval = setInterval(() => {
					this.seconds = this.seconds - 1
					if (this.seconds == 0) {
						clearInterval(this.secondsInterval)
						this.isGetting = false;
						this.seconds = 120;
					}
				}, 1000);
			},

			handleService() {
				uni.showToast({ title: this.$msg.SIGN_SERVICE_TIP, icon: 'none', });
			},

			linkSignUp() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.signUp();
			},

			linkHome() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.home();
			},

			openLine() { this.showLine = true },
			chooseLine(e) { console.log(`chooseLine e:`, e); },
			confirmLine(e) {
				console.log(`confirmLine e:`, e);
				this.showLine = false;
				this.curAPI = e.value[0];
				// 替换api域名
				this.$http.setCurHost(this.curAPI.url);
				this.$forceUpdate();
				// this.$linkTo.launch();
				this.$linkTo.signIn();
			},

			// openLgre() {
			// 	this.showLang = true;
			// },
			// chooseLgre(e) {
			// 	// console.log(`changeMode e:`, e);
			// },
			// confirmLgre(e) {
			// 	// console.log(`confirmMode e:`, e);
			// 	this.showLang = false;
			// 	setLgre(e.value[0].code);
			// 	this.$forceUpdate();
			// 	window.location.reload();
			// },

			async handleSubmit() {
				if (!this.$util.checkField(this.user,
						this.$msg.COMMON_ENTER + this.$msg.SIGN_ACCOUNT)) return false;
				if (this.isPwdSign) {
					if (!this.$util.checkField(this.password,
							this.$msg.COMMON_ENTER + this.$msg.SIGN_PWD)) return false;
				} else {
					if (!this.$util.checkField(this.verCode,
							this.$msg.COMMON_ENTER + this.$msg.SIGN_VCODE)) return false;
				}

				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_LOGIN),
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user.trim(),
					password: this.password.trim(),
					verCode: this.verCode.trim(),
				});
				// console.log('result:', result);
				if (!result) {
					this.islock = false;
					return false;
				}
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$t(this.$msg.SIGN_TITLE_IN + ` ` + this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				clearInterval(this.secondsInterval);
				setTimeout(() => {
					this.$linkTo.home();
					this.islock = false;
				}, 1000);
			},
		}
	}
</script>