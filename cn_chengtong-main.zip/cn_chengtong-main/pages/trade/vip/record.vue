<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.VIP_RECORD)"> </CommonHeader>
		<view style="padding:10px 20px 0 20px;">
			<view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;">
				<block v-for="(v,k) in tabs" :key="k">
					<view @click="changeTab(k)" style="text-align: center;flex: 1;border-radius:22px;padding:8px 0;"
						:style="$theme.setStyleTab(curKey===k)">
						{{v}}
					</view>
				</block>
			</view>
		</view>

		<view class="right_in" style="padding:0 20px 60px 20px;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<view style="padding: 20px 0;font-size: 14px;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
						<view
							style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;">
							{{v.name}}
						</view>
						<!-- 	<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 8px;">
							<view >配售状态</view>
							<view :style="setStyle(v.status)">{{v.statusLabel}}</view>
						</view> -->
						<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
							<view class="flex_row_between" style="flex:1;">
								<view>抢筹价格</view>
								<view>{{$fmt.amount(v.price)}}</view>
							</view>
							<view class="flex_row_between" style="flex:1;">
								<view>股数</view>
								<view>{{$fmt.quantity(v.qty)}}</view>
							</view>
						</view>

						<template v-if="curKey===$C.KEY_SUCCESS">
							<view class="flex_row_between" style="padding-top: 4px;gap:10px;">
								<view class="flex_row_between" style="flex:1;">
									<view>中签股数</view>
									<view :style="{color:$theme.setRiseFall(-1)}">{{$fmt.quantity(v.successQTY)}}</view>
								</view>
								<view class="flex_row_between" style="flex:1;">
									<view>支付金额</view>
									<view :style="{color:$theme.setRiseFall(-1)}">{{$fmt.amount(v.pay)}}</view>
								</view>
							</view>
						</template>

						<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 4px;">
							<view>日期时间</view>
							<view>{{v.dt}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 4px;">
							<view>订单编号</view>
							<view>{{v.sn}}</view>
						</view>

						<view style="padding-top: 8px;">{{$t($msg.COMMON_DESC)}}</view>
						<view style="text-align: right;">{{v.desc}}</view>

					</view>
				</block>
			</template>
		</view>

		<!-- <template v-if="showBuyModal">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							付款
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit"
							style="margin-left: auto;padding-right: 6px;" :style="$theme.setImageSize(24)"
							@click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;">
						{{detail.name}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view >申购价格</view>
							<view>{{$fmt.amount(856.32)}}</view>
						</view>
						<view style="text-align: right;">
							<view >批准数量</view>
							<view>{{$fmt.amount(5000)}}</view>
						</view>
					</view>

					<view class="input_wrapper_1">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.5px solid ${$theme.BLACK_30}`}">付款金额</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.5px solid ${$theme.BLACK_30}`}">
								<input v-model="amount" type="number"
									:placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)"
									placeholder-class="placeholder" disabled=""
									style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>

					<Balance :balance="!user?'': $fmt.amount(user.money,$util.isUS(detail.type))" deposit />

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view >预计手續費</view>
							<view>{{$fmt.amount(10,$util.isUS(detail.type))}}</view>
						</view>
						<view style="text-align: right;">
							<view >预计總费用</view>
							<view>{{$fmt.amount(amount,$util.isUS(detail.type))}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
						付款
					</BtnLock>
				</view>
			</view>
		</template> -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null,
				curKey: null,
				tabs: {
					[this.$C.KEY_APPLY]: this.$msg.IPO_APPLY,
					[this.$C.KEY_SUCCESS]: this.$msg.IPO_SUCCESS,
				},
				// statusLabels: [`未公布`, `申购中`, `待付款`, `未付款，已过期`],
			}
		},
		computed: {},
		onLoad(opt) {
			this.curId = opt.id || this.curId;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.curKey = val;
				this.list = null;
				this.getList();
			},

			async getList() {
				// this.list = await this.$http.getIPODetail(this.curId);
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const tempURL = this.curKey === this.$C.KEY_APPLY ? `user_apply_log` : `user_success_log`;
				const result = await this.$http.get(`api/VipScramble/${tempURL}`);
				if (!result) return null;
				console.log(result);
				this.list = result.map(v => {
					return {
						id: v.id,
						name: v.goods.name,
						code: v.goods.code,
						price: v.price * 1 || 0,
						qty: v.apply_amount * 1 || 0,
						successQTY: v.success * 1 || 0,
						pay: this.$fmt.numer(v.success * v.scramble.price, this.$decimal),
						sn: v.order_sn,
						dt: v.created_at,
						status: v.status,
						// statusLabel: this.statusLabels[v.status],
					}
				});

				// this.list = [{
				// 	id: 1,
				// 	name: `巨轮智能`,
				// 	code: `sz002031`,
				// 	price: 44378.43,
				// 	qty: 50000,
				// 	pay: 0,
				// 	dt: `2024-01-20`,
				// 	sn: `abcfr1484621549895`,
				// 	type: 1,
				// 	status: 0,
				// 	statusLabel: `未公布`
				// }, {
				// 	id: 1,
				// 	name: `巨轮智能`,
				// 	code: `sz002031`,
				// 	price: 44378.43,
				// 	qty: 50000,
				// 	pay: 6598.32,
				// 	dt: `2024-01-20`,
				// 	sn: `abcfr1484621549895`,
				// 	type: 1,
				// 	status: 1,
				// 	statusLabel: `已付款`
				// }, {
				// 	id: 1,
				// 	name: `巨轮智能`,
				// 	code: `sz002031`,
				// 	price: 44378.43,
				// 	qty: 50000,
				// 	pay: 6598.32,
				// 	dt: `2024-01-20`,
				// 	sn: `abcfr1484621549895`,
				// 	type: 1,
				// 	status: 2,
				// 	statusLabel: `待付款`
				// }, {
				// 	id: 1,
				// 	name: `巨轮智能`,
				// 	code: `sz002031`,
				// 	price: 44378.43,
				// 	qty: 50000,
				// 	pay: 6598.32,
				// 	dt: `2024-01-20`,
				// 	sn: `abcfr1484621549895`,
				// 	type: 1,
				// 	status: 3,
				// 	statusLabel: `未付款，已过期`
				// }]
			},

			setStyle(val) {
				const temp = {
					0: `#FF9000`,
					1: `#42BF86`,
					2: `#42BF86`,
					3: `#F20105`,
				};
				return {
					color: temp[val]
				};
			},
			// showModal(val) {
			// 	this.showBuyModal = true;
			// 	this.detail = val;
			// 	this.amount = this.detail.pay;
			// 	this.getAccount();
			// },
			// modalClose() {
			// 	this.showBuyModal = false;
			// },
			// async getAccount() {
			// 	this.user = await this.$http.getAccount();
			// 	// this.levers = this.$util.leverList(this.user.ganggan);
			// },
			// async handleSubmit() {
			// 	if (!this.$util.checkField(this.qty,
			// 			this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
			// 	this.islock = true;
			// 	uni.showLoading({
			// 		title: this.$t(this.$msg.API_SUBMITING),
			// 	});
			// 	// const result = await this.$http.post(`api/goods-shengou/doOrder`, {
			// 	// 	id: this.detail.id,
			// 	// 	// num: this.qty,
			// 	// });
			// 	this.islock = false;
			// 	// if (!result) return false;
			// 	uni.showToast({
			// 		title: this.$t(this.$msg.COMMON_SUCCESS),
			// 		icon: 'success'
			// 	});
			// 	setTimeout(() => {
			// 		this.modalClose();
			// 	}, 1500)
			// },

		}
	}
</script>

<style>
</style>