<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.VIP_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(20)"
				@click="$linkTo.vipRecord()"></image>
		</CommonHeader>

		<view class="right_in" style="padding:0 0 60px 0;">
			<CommonList :list="list" @action="linkTo" />
		</view>

		<template v-if="showBuyModal">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							交易申请
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit" style="margin-left: auto;padding-right: 6px;"
							:style="$theme.setImageSize(20)" @click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;">
						{{detail.name}}
					</view>

					<view class="flex_row_between" style="gap:12px;font-size: 14px;padding: 16px 0;">
						<view class="flex" >
							<view style="font-size: 14px;">购买价格</view>
							<view style="margin-left: 5px;">{{$fmt.amount(detail.current_price)}}</view>
						</view>
						<view class="flex">
							<view style="font-size: 14px;">购买数量</view>
							<view style="margin-left: 5px;font-size: 14px;">{{$fmt.quantity(detail.min_num)}} - {{$fmt.quantity(detail.max_num)}}</view>
						</view>
					</view>

					<view class="form_input" style="border:none;padding:0;">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.5px solid ${$theme.BLACK_30}`}">数量</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.5px solid ${$theme.BLACK_30}`}">
								<input v-model="qty" type="number" :placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)"
									placeholder-class="placeholder" style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>

					<Balance :balance="!user?'': $fmt.amount(user.money)" style="font-size: 13px;" />

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view style="font-size: 13px;">交易手续费</view>
							<view>{{$fmt.amount(feeRate)}}</view>
						</view>
						<view style="text-align: right;">
							<view style="font-size: 13px;">购买金额</view>
							<view>{{$fmt.amount(total)}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22"> 抢筹 </BtnLock>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null,
				detail: null,
				user: null,
				qty: '',
				showBuyModal: false,
				fee: 1,
				curLever: 1,
				islock: false,
			}
		},
		computed: {
			total() {
				if (!this.detail || !this.qty || this.qty * 1 <= 0) return 0;
				return this.$fmt.numer(this.qty * this.detail.price / this.curLever, this.$decimal);
			},
			feeRate() {
				if (!this.detail || !this.qty || this.qty * 1 <= 0) return 0;
				return this.$fmt.numer(this.qty * this.detail.price * this.fee, this.$decimal)
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkTo(val) {
				this.showModal(val);
			},

			async showModal(val) {
				console.log(val);
				this.detail = val;
				this.showBuyModal = true;
				// this.qty = this.detail.max_num;
				this.user = await this.$http.getAccount();
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') * 1 || 0;
			},

			modalClose() {
				this.showBuyModal = false;
				this.qty = '';
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.qty,
						this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
				// this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/VipScramble/doOrder`, {
					id: this.detail.id,
					num: this.qty,
					price: this.detail.price,
					// ganggan: 1,
				});
				uni.showToast({
					title: result.message,
					icon: 'none'
				});
				// this.islock = false;
				if (!result) return false;
				this.modalClose();
			},

			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/VipScramble/calendar`);
				if (!result) return null;
				const temp = !result || result.filter(v => v.id && v.id > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					return {
						id: v.id,
						name: v.goods.name,
						code: v.goods.code,
						price: v.goods.current_price * 1 || 0,
						current_price: v.goods.current_price * 1 || 0,
						rate: v.goods.rate * 1 || 0,
						rateNum: v.goods.rate_num * 1 || 0,
						min_num: v.min_num * 1 || 0,
						max_num: v.max_num * 1 || 0,
						type: v.goods.project_type_id,
					}
				});
			}
		}
	}
</script>

<style>
</style>