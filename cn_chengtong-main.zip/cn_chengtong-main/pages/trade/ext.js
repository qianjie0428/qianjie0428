import * as linkTo from '@/common/linkTo.js';
import * as util from '@/common/util.js';
import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const btns = () => {
	return [{
			name: translate(Msg.MENU_NOR_BUY),
			icon: `menu_nor_buy`,
			action: linkTo.search
		},
		{
			name: translate(Msg.MENU_NOR_SELL),
			icon: `menu_nor_sell`,
			action: linkTo.position
		},
		{
			name: translate(Msg.MENU_IPO),
			icon: `menu_ipo`,
			action: linkTo.ipo
		}, {
			name: translate(Msg.MENU_SCRAMBLE),
			icon: `menu_scramble`,
			action: linkTo.scramble
		}, {
			name: translate(Msg.MENU_BLOCK),
			icon: `menu_block`,
			action: linkTo.block
		}, {
			name: translate(Msg.MENU_AH),
			icon: `menu_ah`,
			action: linkTo.ahCompare
		}, 
		// {
		// 	name: translate(Msg.MENU_BANK_IN),
		// 	icon: `menu_bank_in`,
		// 	action: linkTo.deposit
		// }, 
		// {
		// 	name: translate(Msg.MENU_BANK_OUT),
		// 	icon: `menu_bank_out`,
		// 	action: linkTo.withdraw
		// },
		{
			name: translate(Msg.MENU_NEWS_HOT),
			icon: `menu_hot`,
			action: linkTo.newsHot
		},
		{
			name: translate(Msg.MENU_TREND),
			icon: `menu_trend`,
			action: linkTo.trend
		}, {
			name: translate(Msg.MENU_DATA),
			icon: `menu_data`,
			action: linkTo.dataCenter
		}, {
			name: translate(Msg.MENU_HS_ETF),
			icon: `menu_hsetf`,
			action: linkTo.hsetf
		}
	]
};