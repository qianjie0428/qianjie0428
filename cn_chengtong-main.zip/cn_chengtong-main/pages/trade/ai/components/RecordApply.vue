<template>
	<view >
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view class="record_tr">
					<view>{{$t($msg.AI_STATUS)}}</view>
					<view :style="setStatus(v.status)" style="line-height: 1;font-size: 11px;">
						{{$t(v.statusTxt)}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.FLOW_MONEY)}}</view>
					<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.money,$util.isUS())}}</view>
				</view>
				<view class="record_tr">
					<view style="color: #121212;">{{v.sn}}</view>
					<view>{{v.dt}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordApply',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			// 申请状态样式
			setStatus(val) {
				return ext.setStatus(val);
			},
		}
	}
</script>

<style>
</style>