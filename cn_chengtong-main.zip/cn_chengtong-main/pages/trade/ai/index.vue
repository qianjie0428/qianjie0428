<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="page_header">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.AI_TITLE)" />

		<view style="margin:20px 8px 10px 8px;">
			<view class="tabs" style="background-color: #FFF;border-radius: 14px;">
				<block v-for="(v,k) in tabs" :key="k">
					<view :class="v.key===curKey?`tab_act`:``" @click="changeTab(v.key)"
						style="text-align: center;font-size: 12px;font-weight: bold;flex: 1;">
						{{v.name}}
					</view>
				</block>
			</view>
		</view>


		<view :class="$theme.random(curIndex)+`_in`" style="padding:0 8px 60px 8px;">
			<template v-if="curKey===$C.KEY_GOODS">
				<!-- <RecordTrade :list="list" /> -->
				<!-- ai_icon.png -->
				<view class="card_dark" style="padding-bottom: 20px;">
					<view style="display: flex;align-items: center;justify-content: center;padding:30px 0;">
						<image src="/static/ai_icon.png" mode="aspectFit" :style="$theme.setImageSize(160)"></image>
					</view>
					<view style="font: 14px;font-weight: 700;margin-bottom: 8px;color: #FFF;">
						{{$t($msg.AI_AMOUNT)}}
					</view>
					<view class="input_wrapper" style="border-radius: 12px;">
						<input v-model="amount" type="digit" :placeholder="$t($msg.COMMON_ENTER+ $msg.AI_AMOUNT)"
							placeholder-class="placeholder" style="flex:auto;"></input>
						<template v-if="amount && amount.length > 0">
							<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;"
								:style="$theme.setImageSize(16)" @click="amount=''"></image>
						</template>
					</view>
					<Balance :balance="!user?'': $fmt.amount(user.money,$util.isUS())" deposit />
					<BtnLock :isDisabled="islock" @click="handleSubmit">
						{{$t($msg.COMMON_SUBMIT)}}
					</BtnLock>
				</view>
				<view style="padding:28px 14px 40px 14px;color: #E9E9E9;">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$t($msg.AI_TITLE + $msg.COMMON_RULE)}}
					</view>
					<block v-for="(v,k) in rules" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{k+1 +`. `+ v}}</view>
					</block>
				</view>
			</template>
			<template v-if="curKey===$C.KEY_APPLY ||curKey===$C.KEY_SUCCESS">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<template v-if="curKey===$C.KEY_APPLY">
						<RecordApply :list="list" />
					</template>
					<template v-if="curKey===$C.KEY_SUCCESS">
						<RecordSuccess :list="list" />
					</template>
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import RecordApply from './components/RecordApply.vue';
	import RecordSuccess from './components/RecordSuccess.vue';
	export default {
		components: {
			RecordApply,
			RecordSuccess,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curKey: null,
				tabs: ext.tabs(),
				list: null,
				user: null,
				amount: '',
				rules: ext.rules(),
				islock: false,
			}
		},
		computed: {
			curIndex() {
				const tem = this.tabs.findIndex(v => v.key === this.curKey)
				return !tem || tem < 0 ? 0 : tem;
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || this.$C.KEY_GOODS;
			this.changeTab(this.curKey);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.list = null;
				this.curKey = val;
				if (this.curKey === this.$C.KEY_GOODS) this.getAccount();
				if (this.curKey === this.$C.KEY_APPLY) this.getApplys();
				if (this.curKey === this.$C.KEY_SUCCESS) this.getSuccess();
			},
			async getApplys() {
				this.list = await this.$http.getAIApplys();
			},
			async getSuccess() {
				this.list = await this.$http.getAISuccess();
			},
			async getAccount() {
				this.user = await this.$http.getAccount();
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.TIP_VALID)) return false;
				this.islock = true;
				const result = await uni.showModal({
					title: '',
					content: this.$t(this.$msg.AI_MODAL_CONTENT),
					cancelText: this.$t(this.$msg.COMMON_CANCEL),
					confirmText: this.$t(this.$msg.COMMON_CONFIRM),
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				if (result[1].confirm) this.buy();
			},

			async buy() {
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
				});
				// console.log(result);
				this.islock = false;
				if (!result) return false;
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				setTimeout(() => {
					this.amount = '';
					this.changeTab(this.$C.KEY_APPLY);
				}, 1000);
			},
		}
	}
</script>

<style>
</style>