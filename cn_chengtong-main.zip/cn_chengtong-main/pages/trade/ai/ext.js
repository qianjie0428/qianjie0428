import * as constants from '@/common/constants.js';
import * as theme from '@/common/theme.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return [{
		key: constants.KEY_GOODS,
		name: translate(Msg.AI_GOODS),
	}, {
		key: constants.KEY_APPLY,
		name: translate(Msg.AI_APPLY),
	}, {
		key: constants.KEY_SUCCESS,
		name: translate(Msg.AI_SUCCESS),
	}]
}

export const rules = () => {
	return [
		translate(Msg.AI_RULE0),
		translate(Msg.AI_RULE1),
		translate(Msg.AI_RULE2),
		translate(Msg.AI_RULE3),
	]
}

export const setStatus = (val) => {
	// 背景色
	const tempBG = [
		theme.convertRGBA('#FFB044', 9),
		theme.convertRGBA(theme.RISE, 9),
		theme.convertRGBA(theme.FALL, 9),
	];
	// 文字色
	const tempColor = [
		'#FFB044', theme.RISE, theme.FALL,
	];
	return {
		backgroundColor: tempBG[val],
		color: tempColor[val],
		borderRadius: `12rpx`,
		minWidth: `80rpx`,
		padding: `6rpx 16rpx`,
		fontSize: `24rpx`,
		textAlign: `center`,
	}
}