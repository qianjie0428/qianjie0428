<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view class="record_tr">
					<view style="font-size: 14px;font-weight: 700;"> {{v.name}} </view>
					<view class="tab_act" style="padding:4px 16px;line-height: 1.2;margin-top: 0;" @click="buy(v)">
						{{$t($msg.COMMON_BUY)}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.EA_MIN_AMOUNT)}}</view>
					<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.minAmount,$util.isUS())}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.EA_PROFIT_RATE)}}</view>
					<view :style="{color:$theme.PRIMARY}">{{$fmt.percent(v.syl)}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.EA_CYCLE)}}</view>
					<view style="color: #121212;">{{v.days}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'Goods',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			buy(val) {
				this.$emit('buy', val);
			}
		}
	}
</script>

<style>
</style>