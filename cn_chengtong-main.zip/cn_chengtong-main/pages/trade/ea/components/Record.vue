<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view class="record_tr" style="padding-bottom: 6px;">
					<view style="font-size: 14px;font-weight: 700;"> {{v.name}} </view>
					<!-- <view class="tab_act" style="padding:4px 16px;line-height: 1.2;margin-top: 0;" @click="sell(v)">
						{{$t($msg.COMMON_SELL)}}
					</view> -->
				</view>
				<view class="position">
					<view class="item">
						<view>{{$t($msg.EA_PRICE)}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.price,$util.isUS())}}</view>
					</view>
					<view class="item">
						<view>{{$t($msg.EA_GROWTH)}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$fmt.percent(v.fudu)}}</view>
					</view>
				</view>
				<view class="position">
					<view class="item">
						<view>{{$t($msg.EA_CYCLE)}}</view>
						<view>{{v.days}}</view>
					</view>
					<view class="item">
						<view>{{$t($msg.EA_FEE)}}</view>
						<view>{{v.fee}}</view>
					</view>
				</view>
				<view class="position">
					<view class="item">
						<view>{{$t($msg.EA_SDT)}}</view>
						<view>{{v.sdt}}</view>
					</view>
					<view class="item">
						<view>{{$t($msg.EA_END_DT)}}</view>
						<view>{{v.edt}}</view>
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'Record',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			// sell(val) {
			// 	this.$emit('sell', val);
			// }
		}
	}
</script>

<style>
</style>