<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="position_head">
		<header style="font-size: 15px;font-weight: 700;color: #FFF;text-align: center;padding-top: 24px;">交易</header>
		<!-- <template v-if="user">
			<AssetsCard :info="user" />
		</template> -->

		<view style="margin-top: 10px;background-color: #FFFFFF;padding-top: 16px;">
			<view class="btns">
				<block v-for="(v,k) in btns" :key="k">
					<view class="item" style="width: 25%;" @click="v.action">
						<image mode="aspectFit" :src="`/static/menu/${v.icon}.svg`" :style="$theme.setImageSize(30)" style="">
						</image>
						<text class="text-center" style="font-size: 14px;margin-top: 8px;padding-bottom: 16px;">{{v.name}}</text>
					</view>
				</block>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 10px;">
			<image src="/static/trade_bnner.png" mode="scaleToFill" :style="$theme.setImageSize(340,100)"></image>
		</view>

		<CommonTitle title="最新数据">
			<view :style="{color:$theme.BLACK_30}">{{$fmt.today()}} 已更新</view>
		</CommonTitle>
		<view
			style="padding:15px 20px;background-color: #FFFFFF;display: flex;align-items: center;justify-content: space-between;gap: 12px;font-size: 12px;">
			<block v-for="(v,k) in latestTabs" :key="k">
				<view style="flex:1;border-radius: 4px;padding:8px 0;text-align: center;"
					:style="$theme.setStyleTab(curLatest==k)" @click="changeTabLatest(k)">{{v}}</view>
			</block>
		</view>
		<view class="card_row" style="background-color: #FFFFFF;">
			<block v-for="(v,k) in latests" :key="k">
				<CardItem :detail="v" @action="linkTo" />
			</block>
		</view>

		<CommonTitle title="榜单"> </CommonTitle>

		<view style="background-color: #FFFFFF;padding:15px 20px;">
			<view style="display: flex;align-items: center;justify-content: space-around;gap: 20px;">
				<block v-for="(v,k) in tabsRanking" :key="k">
					<view style="flex:1;border-radius: 22px;padding:8px 0;text-align: center;"
						:style="$theme.setStyleTab(curRanking==k)" @click="changeRanking(k)">{{v}}</view>
				</block>
			</view>
			<Ranking :list="list" />
		</view>
		<view style="height: 80px;"></view>
		<FooterSmall :actKey="$C.KEY_TRADE"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import * as mock from '@/common/mock.js';
	import Ranking from './components/Ranking.vue';
	export default {
		components: {
			Ranking
		},
		data() {
			return {
				isAnimat: false,
				btns: ext.btns(),
				user: null,
				list: null,
				latests: null,
				latestTabs: {
					[1]: `全市场`,
					[2]: `沪市`,
					[3]: `深市`,
					[4]: `创业板`,
					[5]: `科创板`
				},
				curLatest: 0,
				tabsRanking: [`个股两融榜`, `ETF两融榜`],
				curRanking: 0,
			}
		},
		computed: {
			userAssets() {
				return {
					totalZichan: this.user.totalZichan,
					money: this.user.money,
					total: this.user.totalYingli,
					floatPL: this.user.holdYingli,
				}
			},
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
			this.curLatest = this.curLatest || Object.keys(this.latestTabs)[0];
			this.curRanking = this.curRanking || Object.keys(this.tabsRanking)[0];
			this.changeTabLatest(this.curLatest);
			this.changeRanking(this.curRanking);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccount();
			this.changeTabLatest(this.curLatest);
			this.changeRanking(this.curRanking);
			uni.stopPullDownRefresh();
		},
		methods: {
			linkTo(val) { return false },

			async changeRanking(val) {
				this.curRanking = val;
				//  个股两融榜 ETF两融
				const temp = val == 0 ? `api/app/stock_rzrq_rank` : `api/app/stock_rzrq_etf_rank`;
				const result = await this.$http.get(temp);
				if (!result) return null;
				console.log(result);
				this.list = result.map(v => {
					return {
						id: v.gid,
						name: v.name,
						code: v.code,
						price: v.rzrq_money * 1 || 0,
						rate: v.rzrq_rate * 1 || 0,
						rate1: v.rzrq_liutong_rate * 1 || 0,
					}
				})
			},
			async changeTabLatest(val) {
				console.log(1111,val)
				this.curLatest = val;
				// const result = await this.$http.get(``);
				// if (!result) return null;
				// console.log(result);
				const result = await this.$http.post(`api/goods/zhishu`, {
					gp_index: val,
					num:15,
				});
				if (!result) return null;
				// console.log(result, fmt.getLgre(gpindex));
				const temp = result.length <= 0 ? [] : result.map(v => {
					return {
						gid: v.gid,
						name: v.name,
						code: v.code,
						price: v.price * 1 || 0,
						rate: v.rate * 1 || 0,
						rateNum: v.rateNum * 1 || 0,
						industry: v.rateNum || '',
					}
				});
		
				 this.latests =temp

				// this.latests = await this.$http.getLatests(this.curLatest);
			},
		}
	}
</script>

<style>
</style>