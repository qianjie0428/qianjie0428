<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.BLOCK_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(32)"
				@click="$linkTo.blockRecord()" style="padding-right: 16px;"></image>
		</CommonHeader>

		<view class="left_in" style="padding:0 20px 60px 20px;">
			<Goods :list="list" @action="linkDetail" />
		</view>

		<template v-if="showBuyModal">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							交易申请
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit" style="margin-left: auto;padding-right: 6px;"
							:style="$theme.setImageSize(20)" @click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;">
						{{detail.name}}
					</view>

					<view class="flex_row_between" style="gap:12px;padding:16px 0;font-size: 14px;line-height: 1.6;">
						<view style="flex:1;display: flex;align-items: center;gap: 12px;">
							<view>购买价格</view>
							<view>{{$fmt.amount(detail.current_price*detail.zhekou)}}</view>
						</view>
						<view
							style="display: flex;justify-content: flex-end; text-align: right;">
							<view style="margin-right: 5px;">购买数量</view>
							<view>{{$fmt.quantity(detail.min_num)}} - {{$fmt.quantity(detail.max_num)}}</view>
						</view>
					</view>

					<view class="form_input" style="border:none;padding:0;">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.5px solid ${$theme.BLACK_30}`}">数量</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.5px solid ${$theme.BLACK_30}`}">
								<input v-model="qty" type="number" :placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)"
									placeholder-class="placeholder" style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>
					
					<view >
						<view style="padding: 10px 0px;">股票密码</view>
						<view style="border: 1px #bcbcbd solid;padding: 5px;border-radius: 5px;">
							<input v-model="password" type="number" placeholder="请输入股票密码"
								placeholder-class="placeholder" style="height: 24px;line-height: 24px;font-size: 14px;font-weight: 500;margin-left: 20px;"></input>
						</view>
						
					</view>
                    <Balance :balance="!user?'': $fmt.amount(user.money)"  style="margin-top: 5px;font-size: 13px;"/>
					<!-- <Balance :balance="!user?'': $fmt.amount(user.money)" deposit  style="margin-top: 5px;"/> -->

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<!-- <view>
							<view>预计手續費</view>
							<view>{{$fmt.amount(feeRate)}}</view>
						</view> -->
						<view>
							<view>购买金额</view>
							<view>{{$fmt.amount(total)}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22"> 购买 </BtnLock>
				</view>
			</view>
		</template>

		<!-- <template v-if="showAsk">
			<view class="overlay" style="background-color: transparent;" @click="showAsk=false"></view>
			<view class="modal_wrapper_center" style="background-color: #FFF;">
				<view style="line-height: 2.4;font-size: 18px;font-weight: 500;text-align: center;">
					{{$t($msg.BLOCK_PWD_TITLE)}}
				</view>

				<view class="input_wrapper" style="margin:10px 20px 0 20px;">
					<image src="/static/pwd_old.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
						style="padding-right: 12rpx;"></image>
					<input v-model="password" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.WITHDRAW_PWD)"
						placeholder-class="placeholder" style="flex:auto;"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" style="margin-left: auto;"
						:style="$theme.setImageSize(16)" @click="toggleMask()"></image>
				</view>
				<view style="margin:8px 20px 20px 0;text-align: right;font-size: 11px;color: #999;"
					@click="$util.linkCustomerService()"><text style="border-bottom: 0.1px solid #999;">
						{{$t($msg.BLOCK_PWD_TIP)}}</text></view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 3;margin-top: 8px;border-top: 0.1px solid #EEE;">
					<view style="flex: 1;text-align: center;border-right: 0.1px solid #EEE;" @click="cancel()">
						{{$t($msg.COMMON_CANCEL)}}
					</view>
					<view style="flex: 1;text-align: center;" :style="{color:$theme.PRIMARY}" @click="comfirm()">
						{{$t($msg.COMMON_CONFIRM)}}
					</view>
				</view>
			</view>
		</template> -->
	</view>
</template>

<script>
	import Goods from './components/Goods.vue';
	export default {
		components: {
			Goods
		},
		data() {
			return {
				isAnimat: false,
				list: null,
				detail: null,
				user: null,
				qty: '',
				levers: [],
				curLever: 1,
				showBuyModal: false,
				fee: 1,
				islock: false,
				password: '',
				// showAsk: false,
				// isMask: null,
			}
		},
		computed: {
			total() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * (this.detail.current_price*this.detail.zhekou)/ this.curLever, this.$decimal);
			},
			feeRate() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * (this.detail.current_price*this.detail.zhekou) * this.fee, this.$decimal)
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			// this.list = await this.$http.getBlockGoods();
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getList();
			// this.list = await this.$http.getBlockGoods();
			uni.stopPullDownRefresh();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},

			linkDetail(val) {
				this.showModal(val);
			},

			async showModal(val) {
				console.log(val);
				this.detail = val;
				// this.showAsk = true;
				this.showBuyModal = true;
				// this.qty = this.detail.max_num;
				this.user = await this.$http.getAccount();
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') * 1 || 0;
				// this.levers = this.$util.leverList(this.user.ganggan);
			},

			// cancel() {
			// 	this.showAsk = false;
			// 	this.detail = null;
			// 	this.password = '';
			// },
			// async comfirm() {
			// 	// 匹配密码，成功则显示购买弹层
			// 	if (this.password == this.detail.password) {
			// 		this.showBuyModal = true;
			// 		this.getAccount();
			// 		this.fee = await this.$http.getConfig();
			// 		this.showAsk = false;
			// 		this.password = '';
			// 	} else {
			// 		uni.showToast({
			// 			title: this.$t(this.$msg.COMMON_ENTER + this.$msg.BLOCK_PWD_TITLE),
			// 			icon: 'none'
			// 		});
			// 	}
			// },
			modalClose() {
				this.showBuyModal = false;
				this.qty = '';
			},
			async handleSubmit() {
				if (!this.$util.checkField(this.qty,
						this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.detail.id,
					num: this.qty,
					pay_pass: this.password,
					ganggan: this.curLever,
				});
				this.islock = false;
				if (!result) return false;
				this.modalClose();
			},

			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/goods-bigbill/list`);
				if (!result) return false;
				console.log(result);
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						current_price: item.goods.current_price * 1 || 0,
						id: item.id,
						price: item.price * 1 || 0,
						zhekou: item.zhekou ,
						rate_num: item.goods.rate_num * 1 || 0,
						rate: item.goods.rate * 1 || 0,
						min_num: item.min_num * 1 || 0,
						max_num: item.max_num * 1 || 0,
						type: item.goods.project_type_id,
						password: item.password,
					}
				});
			}
		}
	}
</script>

<style>
</style>