<template>
	<view class="table">
		<view class="table_header">
			<view class="table_th" style="width: 33%;">名称/代码</view>
			<view class="table_th" style="width: 27%;text-align: center;">购买价格</view>
			<view class="table_th" style="width: 20%;text-align: center;">购买数量</view>
			<view class="table_th" style="width: 20%;text-align: right;"></view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row">
					<view class="table_cell" style="width: 33%;">
						<view style="font-weight: 700;">{{v.name}}</view>
						<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
					</view>
					<view class="table_cell" style="width: 27%;text-align: center;">
						{{$fmt.amount(v.current_price*v.zhekou)}}
					</view>
					<view class="table_cell" style="width: 20%;text-align: center;">
						{{$fmt.quantity(v.min_num,$util.isUS(v.type))}}
					</view>
					<view class="table_cell" style="width: 20%;padding-left: 10px;" @click="linkTo(v)">
						<view class="rate" style="color: #FFF;" :style="{backgroundColor:$theme.setRiseFall(1)}">
							购买
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'Goods',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			linkTo(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>