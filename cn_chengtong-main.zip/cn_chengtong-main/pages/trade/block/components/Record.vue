<template>
	<view class="table">
		<view class="table_header">
			<view class="table_th" style="width: 33%;">名称/代码</view>
			<view class="table_th" style="width: 27%;text-align: center;">申购价</view>
			<view class="table_th" style="width: 20%;text-align: center;">购买数量</view>
			<view class="table_th" style="width: 20%;text-align: right;">申购</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row">
					<view class="table_cell" style="width: 33%;">
						<view style="font-weight: 700;">{{v.name}}</view>
						<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
					</view>
					<view class="table_cell" style="width: 27%;text-align: center;">
						{{$fmt.amount(v.price,$util.isUS(v.type))}}
					</view>
					<view class="table_cell" style="width: 20%;text-align: center;">
						{{$fmt.quantity(v.num,$util.isUS(v.type))}}
					</view>
					<view class="table_cell" style="width: 20%;padding-left: 10px;text-align: center;">
						<template v-if="v.status==0||v.status==2">
							<text :style="{color:$theme.colorStatus[v.status]}">
								{{[`等待`,`付款`,`完成`,`驳回`][v.status]}}
							</text>
						</template>
						<template v-if="v.status==3">
							<view @click="$util.linkCustomerService()" class="rate" style="color: #FFF;"
								:style="{backgroundColor:$theme.colorStatus[v.status]}">
								驳回</view>
						</template>
						<template v-if="v.status==1">
							<view class="rate" style="color: #FFF;" @click="linkTo(v)"
								:style="{backgroundColor:$theme.colorStatus[v.status]}">
								付款
							</view>
						</template>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Record",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			linkTo(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>