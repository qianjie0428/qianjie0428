import * as constants from '@/common/constants.js';
import * as theme from '@/common/theme.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return [{
		key: constants.KEY_GOODS,
		name: translate(Msg.COMMON_GOODS),
	}, {
		key: constants.KEY_APPLY,
		name: translate(Msg.COMMON_RECORD),
	}]
}
