<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.BLOCK_RECORD_TITLE)" />

		<view class="left_in" style="padding:0 20px 60px 20px;">
			<block v-for="(v,k) in list" :key="k">
				<view style="padding: 20px 0;font-size: 14px;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;">
						{{v.name}}
					</view>

					<view class="flex_row_between" style="gap:12px;font-size: 14px;padding-top: 8px;">
						<view class="flex_row_between" style="flex:1;">
							<view>{{$t($msg.BLOCK_PRICE)}}</view>
							<view>{{$fmt.amount(v.price)}}</view>
						</view>
						<view class="flex_row_between" style="flex:1;text-align: right;">
							<view>{{$t($msg.BLOCK_QTY)}}</view>
							<view>{{$fmt.quantity(v.num)}}</view>
						</view>
					</view>

					<view class="flex_row_between" style="padding-top: 4px;">
						<view>{{$t($msg.BLOCK_AMOUNT)}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.amount)}}</view>
					</view>
					<view class="flex_row_between" style="padding-top: 4px;">
						<view>{{$t($msg.BLOCK_PL)}}</view>
						<view :style="{color:$theme.setRiseFall(v.pl)}">
							{{$fmt.amount(v.pl)}}
						</view>
					</view>
					<view class="flex_row_between" style="padding-top: 4px;">
						<view>{{$t($msg.BLOCK_FLOAT_PL)}}</view>
						<view :style="{color:$theme.setRiseFall(v.floatPL)}">
							{{$fmt.amount(v.floatPL)}}
						</view>
					</view>

					<view class="flex_row_between" style="gap:12px;font-size: 14px;padding-top: 4px;">
						<view class="flex_row_between" style="flex:1;">
							<view>{{$t($msg.COMMON_LEVER)}}</view>
							<view>{{$fmt.numer(v.lever)}}</view>
						</view>
						<view class="flex_row_between" style="flex:1;text-align: right;">
							<view>{{$t($msg.COMMON_FEE)}}</view>
							<view>{{$fmt.amount(v.fee)}}</view>
						</view>
					</view>

					<view class="flex_row_between" style="padding-top: 4px;">
						<view>{{$t($msg.COMMON_DT)}}</view>
						<view>{{v.dt}}</view>
					</view>
					<view style="padding-top: 4px;">{{$t($msg.COMMON_DESC)}}</view>
					<view style="text-align: right;">{{v.desc}}</view>
				</view>
			</block>
		</view>

		<!-- <template v-if="showBuyModal">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							付款
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit" style="margin-left: auto;padding-right: 6px;"
							:style="$theme.setImageSize(20)" @click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;">
						{{detail.name}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view style="font-size: 12px;">申购价格</view>
							<view>{{$fmt.amount(detail.price)}}</view>
						</view>
						<view style="text-align: right;">
							<view style="font-size: 12px;">批准数量</view>
							<view>{{$fmt.quantity(detail.num)}}</view>
						</view>
					</view>

					<view class="form_input" style="border:none;padding:0;">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.5px solid ${$theme.BLACK_30}`}">付款金额</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.5px solid ${$theme.BLACK_30}`}">
								<input v-model="amount" type="number" :placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)"
									placeholder-class="placeholder" disabled="" style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>

					<Balance :balance="!user?'': $fmt.amount(user.money,$util.isUS(detail.type))" deposit />

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view style="font-size: 12px;">预计手續費</view>
							<view>{{$fmt.amount(detail.fee,$util.isUS(detail.type))}}</view>
						</view>
						<view style="text-align: right;">
							<view style="font-size: 12px;">预计總费用</view>
							<view>{{$fmt.amount(amount,$util.isUS(detail.type))}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
						付款
					</BtnLock>
				</view>
			</view>
		</template> -->
	</view>
</template>

<script>
	import Record from './components/Record.vue';
	export default {
		components: {
			Record
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: null,
				// detail: null,
				// user: null,
				// qty: '',
				// levers: [],
				// curLever: 1,
				// showBuyModal: false,
				// fee: 1,
				// islock: false,
				// detail: null,
				// amount: '',
			}
		},
		computed: {
			// total() {
			// 	return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price / this.curLever, this.$decimal);
			// },
			// feeRate() {
			// 	return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price * this.fee, this.$decimal)
			// }
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getList();
			// this.list = await this.$http.getBlockRecord();

			// const temp = await this.$http.getBlockRecord();
			// const tempData = [...temp, ...temp, ...temp, ...temp];
			// this.list = tempData.map((item, index) => {
			// 	return {
			// 		...item,
			// 		status: index
			// 	}
			// });
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getList();
			// this.list = await this.$http.getBlockRecord();
			uni.stopPullDownRefresh();
		},
		methods: {
			// linkTo(val) {
			// 	this.showModal(val);
			// },
			// async showModal(val) {
			// 	console.log(val);
			// 	this.detail = val;
			// 	// this.showAsk = true;
			// 	this.showBuyModal = true;
			// 	this.amount = this.detail.amount;
			// 	this.user = await this.$http.getAccount();
			// 	this.fee = this.detail.fee;
			// 	// this.levers = this.$util.leverList(this.user.ganggan);
			// },

			// modalClose() {
			// 	this.showBuyModal = false;
			// 	this.qty = '';
			// },
			// async handleSubmit() {
			// 	if (!this.$util.checkField(this.qty,
			// 			this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
			// 	this.islock = true;
			// 	uni.showLoading({
			// 		title: this.$t(this.$msg.API_SUBMITING),
			// 	});
			// 	const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
			// 		id: this.detail.id,
			// 		num: this.qty,
			// 		pay_pass: this.password,
			// 		ganggan: this.curLever,
			// 	});
			// 	this.islock = false;
			// 	if (!result) return null;
			// 	this.modalClose();
			// },

			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				if (!result) return null;
				console.log(result);
				const temp = !result || result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						name: item.goods.name,
						code: item.goods.code,
						num: item.num * 1 || 0,
						price: item.price * 1 || 0,
						current_price: item.goods.current_price * 1 || 0,
						amount: item.amount * 1 || 0,
						rate_num: item.goods.rate_num * 1 || 0,
						rate: item.goods.rate * 1 || 0,
						pl: item.yingkui * 1 || 0,
						floatPL: item.float_yingkui * 1 || 0,
						fee: item.buy_fee * 1 || 0,
						lever: item.double * 1 || 1,
						dt: item.created_at,
						desc: item.desc,
						type: item.goods.project_type_id,
						status: item.status,
					}
				});
			}
		}
	}
</script>

<style>
</style>