<template>
	<view class="table">
		<view class="table_header">
			<view class="table_th" style="width: 30%;">名称/代码</view>
			<view class="table_th" style="width: 30%;text-align: center;">发行价格</view>
			<view class="table_th" style="width: 40%;text-align: right;">申购时间</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row" @click="linkTo(v.id)">
					<view class="table_cell" style="width: 30%;">
						<view style="font-weight: 700;">{{v.name}}</view>
						<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
					</view>
					<view class="table_cell" style="width: 30%;text-align: center;">
						{{$fmt.amount(v.price)}}
					</view>
					<view class="table_cell" style="width: 40%;text-align: right;">
						{{v.subDT}}
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'Goods',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			linkTo(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>