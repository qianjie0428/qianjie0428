import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return [{
		key: constants.KEY_GOODS,
		name: translate(Msg.IPO_GOODS),
	}, {
		key: constants.KEY_APPLY,
		name: translate(Msg.IPO_APPLY),
	}, {
		key: constants.KEY_SUCCESS,
		name: translate(Msg.IPO_SUCCESS),
	}]
}