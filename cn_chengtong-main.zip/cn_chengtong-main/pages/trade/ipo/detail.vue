<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.IPO_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(20)"
				@click="$linkTo.ipoRecord()"></image>
		</CommonHeader>
		<view class="right_in" style="padding:10px 20px 60px 20px;">
			<template v-if="!detail || !detail.name">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<view style="background-color: #F6F6F6;border-radius: 8px;padding:14px;font-size: 16px;font-weight: 700;"
					:style="{border:`0.1px solid ${$theme.PRIMARY}`}">
					{{detail.name}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;padding-top: 20px;font-size: 14px;">
					<view style="font-weight: 500;">股票状态：</view>
					<view style="font-weight: 500;" :style="{color:$theme.statusStyle($theme.statusIPO,detail.status) }">
						{{statusLabels[detail.status]}}
					</view>
				</view>

				<view style="display: flex;align-items: center;padding-top: 20px;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">1</text>
					<view style="padding-left: 12px;">发行量</view>
					<view style="margin-left: auto;">{{$fmt.quantity(detail.publicQTY)}}</view>
				</view>
				<view style="border-left: 0.5px solid #FFE4E5;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="padding-left: 24px;">募集资金</view>
						<view>{{$fmt.amount(detail.raiseFunds)}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">2</text>
					<view style="padding-left: 12px;">申购日期</view>
					<view style="margin-left: auto;">{{detail.subDT}}</view>
				</view>
				<view style="border-left: 0.5px solid #FFE4E5;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="padding-left: 24px;">申购价格</view>
						<view>{{$fmt.amount(detail.price)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;">
						<view style="padding-left: 24px;">市盈</view>
						<view>{{$fmt.amount(detail.shiying)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 12px;">
						<view style="padding-left: 24px;">申请区间</view>
						<view>{{$fmt.quantity(detail.minQTY)}} - {{$fmt.quantity(detail.maxQTY)}}</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">3</text>
					<view style="padding-left: 12px;">公告日期</view>
					<view style="margin-left: auto;">{{detail.pushDT}}</view>
				</view>
				<view style="border-left: 0.5px solid #FFE4E5;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="padding-left: 24px;" :style="{color:$theme.BLACK_70}">公布中签结果及募集进度</view>
				</view>
				<!-- <view style="display: flex;align-items: center;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">4</text>
					<view style="padding-left: 12px;">认缴日期</view>
					<view style="margin-left: auto;">{{detail.payDT}}</view>
				</view>
				<view style="border-left: 0.5px solid #FFE4E5;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="padding-left: 24px;" :style="{color:$theme.BLACK_70}">申购中签后缴费时间</view>
				</view> -->
				<view style="display: flex;align-items: center;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">4</text>
					<view style="padding-left: 12px;">认缴日期</view>
					<view style="margin-left: auto;">{{detail.payDT}}</view>
				</view>
				<view style="border-left: 0.5px solid transparent;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="padding-left: 24px;" :style="{color:$theme.BLACK_70}">申购中签后缴费时间</view>
				</view>
				<!-- <view style="display: flex;align-items: center;font-size: 12px;">
					<text
						style="background-color: #FFE4E5;width: 24px;height: 24px;line-height: 24px;text-align: center;border-radius: 100%;font-size: 12px;">5</text>
					<view style="padding-left: 12px;">上市时间</view>
					<view style="margin-left: auto;">{{detail.onlieDT}}</view>
				</view>
				<view style="border-left: 0.5px solid transparent;margin-left: 12px;font-size: 12px;padding: 12px 0 36px 0;">
					<view style="padding-left: 24px;" :style="{color:$theme.BLACK_70}">股票计划上市时间</view>
				</view> -->

				<view style="display: flex;align-items: center;justify-content: space-around;font-size: 15px;">
					<view style="border-radius: 4px;padding:8px 40px;text-align: center;"
						:style="{color:$theme.PRIMARY,border:`0.1px solid ${$theme.PRIMARY}`}" @click="$linkTo.ipoRecord()">订单
					</view>
					<template v-if="detail.status==0 || detail.status==2">
						<view style="color:#FFFFFF;border-radius: 4px;padding:8px 40px;text-align: center;"
							:style="{backgroundColor:$theme.statusStyle($theme.statusIPO, detail.status)}">
							{{statusLabels[detail.status]}}
						</view>
					</template>
					<template v-else>
						<!-- <view @click="showModal()" style="color:#FFFFFF;border-radius: 4px;padding:8px 40px;text-align: center;"
							:style="{backgroundColor:$theme.statusStyle($theme.statusIPO,detail.status)}">
							申购</view> -->
							<view @click="handleSubmit" style="color:#FFFFFF;border-radius: 4px;padding:8px 40px;text-align: center;"
								:style="{backgroundColor:$theme.statusStyle($theme.statusIPO,detail.status)}">
								申购</view>
					</template>
				</view>
			</template>
		</view>

		<template v-if="showBuyModal && detail">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							交易申请
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit" style="margin-left: auto;padding-right: 6px;"
							:style="$theme.setImageSize(24)" @click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;"
						:style="{border:`0.1px solid ${$theme.PRIMARY}`}">
						{{detail.name}}
					</view>

					<view class="flex_row_between" style="gap:12px;font-size: 14px;padding: 16px 0;">
						<view class="flex_row_between" style="flex:1;">
							<view style="font-size: 12px;">申购价格</view>
							<view>{{$fmt.amount(detail.price)}}</view>
						</view>
						<view class="flex_row_between" style="flex:1;text-align: right;">
							<view style="font-size: 12px;">购买数量</view>
							<view>{{$fmt.quantity(detail.minQTY)}} - {{$fmt.quantity(detail.maxQTY)}}</view>
						</view>
					</view>

					<view class="form_input" style="border:none;padding:0;">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.1px solid ${$theme.BLACK_30}`}">数量</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.1px solid ${$theme.BLACK_30}`}">
								<input v-model="qty" type="number" :placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)" 
									placeholder-class="placeholder" style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>

					<Balance :balance="!user?'': $fmt.amount(user.money)" deposit />

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view style="font-size: 12px;">预计手續費</view>
							<view>{{$fmt.amount(feeRate)}}</view>
						</view>
						<view style="text-align: right;">
							<view style="font-size: 12px;">预计费用</view>
							<view>{{$fmt.amount(total)}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit" :bgColor="$theme.PRIMARY">
						{{$t($msg.COMMON_BUY)}}
					</BtnLock>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				curId: null,
				detail: null,
				showBuyModal: false,
				user: null,
				qty: '',
				levers: [],
				curLever: 1,
				fee: 0,
				islock: false,
				statusLabels: [`未开始`, `进行中`, `已结束`],
				curLever: 1,
			}
		},
		computed: {
			total() {
				if (!this.detail || !this.qty || this.qty * 1 <= 0) return 0;
				return this.$fmt.numer(this.qty * this.detail.price / this.curLever, this.$decimal);
			},
			feeRate() {
				if (!this.detail || !this.qty || this.qty * 1 <= 0) return 0;
				return this.$fmt.numer(this.qty * this.detail.price * this.fee, this.$decimal)
			}
		},
		onLoad(opt) {
			this.curId = opt.id || this.curId;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getDetail();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getDetail();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 如果沒有詳情接口，就使用該接口，根據curId過濾出來當前數據
			async getDetail() {
				const result = await this.$http.get(`api/goods-shengou/calendar`);
				if (!result) return null;
				console.log(result);
				const temp = result.filter(item => item.id == this.curId)[0];
				this.detail = {
					id: this.curId,
					name: temp.goods.name,
					code: temp.goods.code,
					price: temp.price * 1 || 0,
					shiying: temp.goods.shiying * 1 || 0,
					subDT: temp.shengou_date,
					onlieDT: temp.online_date,
					pushDT: temp.gb_date, // 公告
					payDT: temp.rj_date, // 认缴
					type: temp.goods.project_type_id,
					publicQTY: temp.fa_amount * 1 || 0, // 发行量
					raiseFunds: temp.fa_muji_zijin * 1 || 0, // 募集资金
					minQTY: temp.min_num * 1 || 0,
					maxQTY: temp.max_num * 1 || 0,
					// 0：未中签，1:申购中，2：申购中签，3：已认缴金额，4：中签弃奖，5已上市
					status: temp.status,
				};
				this.qty = this.detail.maxQTY;
			},

			async showModal() {
				this.showBuyModal = true;
				this.user = await this.$http.getAccount();
				// this.levers = this.$util.leverList(this.user.ganggan);
				const result = await this.$http.getConfig();
				this.fee = result.get('TransRate') * 1 || this.fee;
			},
			modalClose() {
				this.showBuyModal = false;
				this.qty = this.detail.maxQTY;
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.qty,
						this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					id: this.detail.id,
					num: this.detail.maxQTY,
				});
				if (!result) {
					this.islock = false;
					return false;
				}
				uni.showToast({ title: this.$t(this.$msg.COMMON_SUCCESS), icon: 'success' });
				setTimeout(() => {
					this.modalClose();
					this.islock = false;
					this.$linkTo.ipoRecord();
				}, 1500)
			},
		}
	}
</script>

<style>
</style>