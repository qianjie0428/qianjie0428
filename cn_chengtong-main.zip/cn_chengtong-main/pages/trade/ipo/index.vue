<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.IPO_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(20)"
				@click="$linkTo.ipoRecord()"></image>
		</CommonHeader>

		<view class="left_in" style="padding:0 20px 60px 20px;">
			<Goods :list="list" @action="linkDetail" />
		</view>
	</view>
</template>

<script>
	import Goods from './components/Goods.vue';
	export default {
		components: {
			Goods
		},
		data() {
			return {
				isAnimat: false,
				list: null,
			}
		},
		computed: {},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkDetail(val) {
				this.$linkTo.ipoDetail(val);
			},
			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/goods-shengou/calendar`);
				if (!result) return null;
				const temp = !result || result.filter(v => v.id && v.id > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(v => {
					return {
						id: v.id,
						name: v.goods.name,
						code: v.goods.code,
						price: v.price * 1 || 0,
						// 发行金额
						// issuanceAmount:  v.fa_amount * 1 || 0,
						subDT: v.shengou_date,
						// onlieDT:  v.online_date,
						type: v.goods.project_type_id,
					}
				});
			}
		}
	}
</script>

<style>
</style>