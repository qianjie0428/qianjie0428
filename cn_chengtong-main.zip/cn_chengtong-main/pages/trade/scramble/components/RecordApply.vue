<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table">
				<view
					style="display: flex;align-items: flex-start;justify-content: space-between; gap: 12px;width: 100%; ">
					<text style="font-size: 25rpx;font-weight: 300;"
						:style="{color:$theme.LOG_LABEL}">({{v.code}})</text>
					<view class="text_wrap" style="font-size: 14px;font-weight: 700;flex: 1; min-width: 0;">
						{{v.name}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.SCRAMBLE_PRICE)}}</view>
					<view :style="{color:$theme.PRIMARY}">{{$fmt.amount(v.price,$util.isUS(v.type))}}</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.IPO_APPLY_AMOUNT)}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$fmt.amount(v.applyAmount,$util.isUS(v.type))}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.SCRAMBLE_SUCCESS_AMOUNT)}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$fmt.amount(v.success,$util.isUS(v.type))}}
					</view>
				</view>
				<view class="record_tr">
					<view>{{$t($msg.SCRAMBLE_TOTAL_AMOUNT)}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$fmt.amount(v.total,$util.isUS(v.type))}}
					</view>
				</view>

				<view class="record_tr">
					<view style="color: #121212;">{{v.sn}}</view>
					<view style="color: #121212;">{{v.dt}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'RecordApply',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>