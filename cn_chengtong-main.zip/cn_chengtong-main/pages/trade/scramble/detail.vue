<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_SCRAMBLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" class="img_size" @click="$linkTo.scrambleRecord()"
				style="padding-right: 16px;"></image>
		</CommonHeader>
		<view class="right_in" style="padding:10px 20px 60px 20px;">
			<template v-if="!detail || !detail.name">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<view
					style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;">
					{{detail.name}}
				</view>
				<view style="padding-top: 20px;font-size: 14px;font-weight: 700;"> 发行信息： </view>

				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>发行量：</view>
					<view>{{$fmt.quantity(500000)}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>发行市赢率：</view>
					<view>{{$fmt.percent(32.89)}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>发行总数：</view>
					<view>{{$fmt.numer(6666.67)}}万股</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>网上发行：</view>
					<view>{{$fmt.numer(2156.99)}}万股</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>所属行业：</view>
					<view>元件</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>行业市赢率：</view>
					<view>{{$fmt.percent(40.62)}}</view>
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>公司简介：</view>
				</view>
				<view>
					是一家主要从事软件开发，硬件销售，系统集成，信息化建设，网络安全，安防产品研发生产的科技公司。
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between; padding-top: 20px;font-size: 12px;">
					<view>经营范围：</view>
				</view>
				<view>软件开发，硬件销售</view>
			</template>
		</view>

		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="showModal" className="btn_submit radius_22">
				配售
			</BtnLock>
		</view>

		<template v-if="showBuyModal && detail">
			<view class="overlay" @click="modalClose()"></view>
			<view class="modal_wrapper_center" style="background-color: #FFFFFF;">
				<view style="min-height: 30vh;">
					<view
						style="display: flex;align-items: center;border-bottom: 0.5px solid #979797;border-radius: 6px 6px 0 0;padding-bottom: 12px;">
						<view :style="$theme.setImageSize(16)"></view>
						<view style="flex: 1;text-align: center;color: #121212;font-size: 16px;">
							配售
						</view>
						<image src="/static/close_dark.svg" mode="aspectFit"
							style="margin-left: auto;padding-right: 6px;" :style="$theme.setImageSize(24)"
							@click.top="modalClose()"></image>
					</view>
					<view
						style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;font-size: 16px;font-weight: 700;margin-top: 12px;">
						{{detail.name}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view style="font-size: 14px;">现价</view>
						<view>{{$fmt.amount(856.32)}}</view>
					</view>

					<view class="form_input" style="border:none;padding:0;">
						<view
							style="font-weight: 500;font-size: 12px;border-radius:4px;padding:0 23px;margin-right: 20px;height: 36px;line-height: 36px;"
							:style="{border:`0.5px solid ${$theme.BLACK_30}`}">配售股数</view>
						<view style="flex:1;height: 36px;">
							<view style="font-weight: 500;font-size: 12px;border-radius:4px;padding: 6px 20px;"
								:style="{border:`0.5px solid ${$theme.BLACK_30}`}">
								<input v-model="qty" type="number" :placeholder="$t($msg.COMMON_ENTER+$msg.UNIT_SHARES)"
									placeholder-class="placeholder"
									style="height: 24px;line-height: 24px;"></input>
							</view>
						</view>
					</view>

					<Balance :balance="!user?'': $fmt.amount(user.money,$util.isUS(detail.type))" deposit />

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding:25px 0;font-size: 14px;line-height: 1.6;">
						<view>
							<view style="font-size: 12px;">预计费用</view>
							<view>{{$fmt.amount(total,$util.isUS(detail.type))}}</view>
						</view>
						<view style="text-align: right;">
							<view style="font-size: 12px;">预计手續費</view>
							<view>{{$fmt.amount(feeRate,$util.isUS(detail.type))}}</view>
						</view>
					</view>

					<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit">
						认购
					</BtnLock>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				curId: null,
				detail: null,
				showBuyModal: false,
				user: null,
				qty: '',
				levers: [],
				curLever: 1,
				fee: 1,
				islock: false,
			}
		},
		computed: {
			total() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price / this.curLever, this.$decimal);
			},
			feeRate() {
				return !this.qty ? 0 : this.$fmt.numer(this.qty * this.detail.price * this.fee, this.$decimal)
			}
		},
		onLoad(opt) {
			this.curId = opt.id || this.curId;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getDetail();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getDetail();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 如果沒有詳情接口，就使用該接口，根據curId過濾出來當前數據
			async getDetail() {
				// this.detail = await this.$http.getIPODetail(this.curId);
				this.list = await this.$http.getScrambleGoods();
				console.log(this.list);
				this.detail = this.list.filter(item => item.id == this.curId)[0];
			},

			async showModal() {
				this.showBuyModal = true;
				this.user = await this.$http.getAccount();
				// this.levers = this.$util.leverList(this.user.ganggan);
			},
			modalClose() {
				this.showBuyModal = false;
				this.qty = '';
			},

			async handleSubmit() {
				if (!this.$util.checkField(this.qty,
						this.$msg.COMMON_ENTER + this.$msg.UNIT_SHARES)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				// const result = await this.$http.post(`api/goods-scramble/doOrder`, {
				// 	id: this.detail.id,
				// 	// num: this.qty,
				// price: this.detail.price,
				// });
				this.islock = false;
				// if (!result) return false;
				uni.showToast({
					title: this.$t(this.$msg.COMMON_SUCCESS),
					icon: 'success'
				});
				setTimeout(() => {
					this.modalClose();
				}, 1500)
			},
		}
	}
</script>

<style>
</style>