<template>
	<view class="table">
		<view class="table_header">
			<view class="table_th" style="width: 33%;">名称/代码</view>
			<view class="table_th" style="width: 27%;text-align: center;">两融余额</view>
			<view class="table_th" style="width: 22%;text-align: center;">
				<view>两融余额</view>
				<view>增值率</view>
			</view>
			<view class="table_th" style="width: 18%;text-align: right;">
				<view>流通市值</view>
				<view>占比率</view>
			</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row">
					<view class="table_cell" style="width: 33%;">
						<view style="font-weight: 700;">{{v.name}}</view>
						<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
					</view>
					<view class="table_cell" style="width: 27%;text-align: center;">
						{{$fmt.decimalY(v.price)}}
					</view>
					<view class="table_cell" style="width: 22%;text-align: center;" :style="{color:$theme.setRiseFall(v.rate)}">
						{{$fmt.percent(v.rate)}}
					</view>
					<view class="table_cell" style="width: 18%;text-align: right;">
						{{$fmt.percent(v.rate1)}}
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Ranking",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>