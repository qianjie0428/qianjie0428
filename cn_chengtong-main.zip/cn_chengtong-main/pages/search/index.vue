<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFF;min-height: 100vh;">
		<header class="common_head" style="display: flex;align-items: center;padding: 20px 16px 12px 16px;height: auto;">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(24)" @click="$util.goBack()">
			</image>

			<view style="flex:1;padding:6px 12px;">
				<view
					style="border-radius: 18px;display: flex;align-items: center;gap: 12px;padding-left: 12px;line-height: 2.4;"
					:style="{backgroundColor:$theme.convertRGBA(`#FFFFFF`,30)}">
					<image src="/static/search.svg" mode="aspectFit" :style="$theme.setImageSize(16)" @click="search()">
					</image>
					<input v-model="keyword" type="text" placeholder="名称/代码/拼音首字母"
						:placeholder-style="$theme.setPlaceholder(`#FFF`)" style="color:#FFF;"></input>
					<template v-if="keyword && keyword.length > 0">
						<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;padding-right: 8px;"
							:style="$theme.setImageSize(24)" @click="keyword=''"></image>
					</template>
					<view style="width: 80px;text-align: center;border-radius: 22px;color: #FFF;"
						:style="{backgroundColor:$theme.convertRGBA(`#FFFFFF`,40)}" @click="search()">
						{{$t($msg.COMMON_SEARCH)}}
					</view>
				</view>
			</view>
		</header>

		<view style="background-color: #FFFFFF;margin-top: -10px;">
			<CommonTitle title="搜索历史">
				<image src="/static/clear.svg" mode="aspectFit" :style="$theme.setImageSize(20)" @click="clearKeywords()">
				</image>
			</CommonTitle>
		</view>

		<view style="display: flex;align-items: center;gap:12px;background-color: #FFF;padding: 20px;">
			<block v-for="(v,k) in keywords" :key="k">
				<view @click="selectedItem(v)">{{v}}</view>
			</block>
		</view>
		<view style="background-color: #F4F4F4;height: 10px;"></view>
		<view class="right_in" style="padding:0 0 100px 0;">
			<CommonList :list="list" @action="linkTo" />
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				keyword: '',
				keywords: [],
				list: null,
			}
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
			this.$linkTo.isAuth();
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.keywords = uni.getStorageSync("keywords") || this.keywords;
			uni.stopPullDownRefresh();
		},
		methods: {
			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val) {
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val.code);
			},
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = [];
				this.list = [];
			},
			selectedItem(item) {
				this.keyword = item;
				this.search();
			},
			async search() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.showToast({
						title: `请至少输入三个字符`,
						icon: 'none'
					})
					return false;
				}
				this.list = await this.$http.getSearch(this.keyword, 1);
				if (this.list && this.list.length > 0) {
					console.log('search result:', this.list)
					if (this.keywords.indexOf(this.keyword) < 0) {
						this.keywords.push(this.keyword);
						uni.setStorageSync("keywords", this.keywords)
					}
				}
			},
		}
	}
</script>

<style>
</style>