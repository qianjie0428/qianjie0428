import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const depositRules = () => {
	return [
		translate(Msg.DEPOSIT_RULE0),
		translate(Msg.DEPOSIT_RULE1),
	]
}

export const withdrawRules = () => {
	return [
		translate(Msg.WITHDRAW_RULE0),
		translate(Msg.WITHDRAW_RULE1),
		translate(Msg.WITHDRAW_RULE2),
		translate(Msg.WITHDRAW_RULE3),
		// translate(Msg.WITHDRAW_RULE4),
	]
}