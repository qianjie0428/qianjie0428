<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.WITHDRAW_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(32)"
				@click="$linkTo.flow($C.KEY_WITHDRAW)" style="padding-right: 16px;"></image>
		</CommonHeader>
		<view class="right_in" style="padding:0 0 100px 0;">

			<template v-if="user">
				<AssetsCard :info="userAssets" />
			</template>

			<view style="margin: 20px;">
				<view class="form_label"> 银证转出金额 </view>
				<view class="form_input">
					<input v-model="amount" type="digit" :placeholder="$t($msg.COMMON_ENTER+$msg.WITHDRAW_AMOUNT)"
						placeholder-class="placeholder" style="flex:auto;"></input>
					<template v-if="amount && amount.length > 0">
						<image src="/static/del.svg" mode="aspectFit" style="margin-left: auto;"
							:style="$theme.setImageSize(16)" @click="amount=''"></image>
					</template>
				</view>
				<view style="padding-top: 4px;font-size: 11px;margin-bottom: 16px;text-align: right;">
					{{$t($msg.WITHDRAW_TIPS)+`:`}}
					<text style="padding:4px 0 8px 4px;">{{$fmt.amount(100)}}</text>
				</view>

				<view class="form_label"> 银证转出密码 </view>
				<view class="form_input">
					<input v-model="password" :password="isMask" :placeholder="$t($msg.COMMON_ENTER+$msg.WITHDRAW_PWD)"
						placeholder-class="placeholder" style="flex:auto;"></input>
					<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" style="margin-left: auto;"
						:style="$theme.setImageSize(16)" @click="toggleMask()"></image>
				</view>

				<view :style="{color:$theme.BLACK_70}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$t($msg.WITHDRAW_TITLE + $msg.COMMON_RULE)}}
					</view>
					<block v-for="(v,k) in rules" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・`+ v}}</view>
					</block>
				</view>
			</view>
		</view>

		<view class="fixed_bottom">
			<BtnLock :isDisabled="islock" @click="handleSubmit" className="btn_submit radius_22">
				银证转出
			</BtnLock>
		</view>
	</view>
</template>

<script>
	import { messages } from '../../localize/index.js';
import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				user: null,
				amount: '',
				password: '',
				isMask: null, // 是否掩码
				rules: ext.withdrawRules(),
				islock: false,
			}
		},
		computed: {
			userAssets() {
				return {
					totalZichan: this.user.totalZichan,
					money: this.user.money,
					frozen: this.user.frozen,
				}
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('masking');
			this.user = await this.$http.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			async handleSubmit() {
				if (!this.$util.checkField(this.amount, this.$msg.TIP_VALID)) return false;
				if (!this.$util.checkField(this.password,
						this.$msg.COMMON_ENTER + this.$msg.WITHDRAW_PWD)) return false;
				this.islock = true;
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount.trim(),
					pay_pass: this.password.trim(),
					remakes: "",
				});
				this.islock = false;
				if (!result) return false;
				uni.showToast({
					// title:'提款请求验证后将进行提款',
					icon: 'success'
				});
				setTimeout(() => {
					// this.$linkTo.flow($C.KEY_WITHDRAW)
					uni.navigateTo({
						url:'/pages/settings/flow?tag=withdraw'
					})
				}, 1000)
			},
		}
	}
</script>

<style>
</style>