<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.DEPOSIT_TITLE)">
			<image src="/static/icon_record.svg" mode="aspectFit" :style="$theme.setImageSize(32)"
				@click="$linkTo.flow($C.KEY_DEPOSIT)" style="padding-right: 16px;"></image>
		</CommonHeader>
		<view class="right_in" style="padding:0 0 100px 0;">

			<template v-if="user">
				<AssetsCard :info="userAssets" />
			</template>



			<!-- 支付系统 -->
			<view v-if="Inv===0">
				<view style="padding: 0px 20px;font-weight: 500;margin-top: 20px;">通道密码 </view>
				<view style="padding: 16px;display: flex;align-items: center;justify-content: space-between;">
					<view style="flex:1;">
						<u-input placeholder="向客服索取密码" placeholder-class="placeholder" type="password" v-model="value3"
							style=""></u-input>
					</view>
					<view style="margin-left: 10px;">
						<view style="color:#FFF; font-weight: 900; background-color: #aaaa00;border-radius: 5px;
						padding: 4px 6px;" @click="testVerify()">
							验证</view>
					</view>
				</view>
			</view>
			<view v-if="Inv===1">
				<view class="make-collections" v-if="type == 1">
					<view class="call">
						<view class="beneficiaryName">银行名称:</view>
						<view class="">{{bankName}}</view>
						<view class="duplicate" @click="copy(bankName)">复制</view>
					</view>
				</view>

				<view class="make-collections" v-if="type == 1">
					<view class="call">
						<view class="beneficiaryName">银行分支:</view>
						<view class="">{{branch}}</view>
						<view class="duplicate" @click="copy(branch)">复制</view>
					</view>
				</view>

				<view class="make-collections" v-if="type == 1">
					<view class="call">
						<view class="beneficiaryName">帐户名称:</view>
						<view class="">{{bankNum}}</view>
						<view class="duplicate" @click="copy(bankNum)">复制</view>
					</view>
				</view>

				<view class="make-collections" v-if="type == 1">
					<view class="call">
						<view class="beneficiaryName">银行账户号码:</view>
						<view class="">{{accountName}}</view>
						<view class="duplicate" @click="copy(accountName)">复制</view>
					</view>
				</view>
			</view>


			<!-- 查看充值记录 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Charging record</view>
					<view class=""></view>
					<view class="duplicate" @tap="capitalDetails()">Check</view>
				</view>
			</view> -->

			<view style="margin:10px 15px;">
				<view v-if="Inv===0">
					<view class="form_label"> 银证转入金额 </view>
					<view class="flex_row_between" style="border: 1px #dadbde solid;padding: 10px;border-radius: 5px;">
						<input v-model="amount" type="digit" :placeholder="$t($msg.COMMON_ENTER+$msg.WITHDRAW_AMOUNT)"
							placeholder-class="placeholder"></input>
						<template v-if="amount && amount.length > 0">
							<image src="/static/del.svg" mode="aspectFit" :style="$theme.setImageSize(16)"
								@click="amount=''"></image>
						</template>
					</view>
					<view style="padding-top: 4px;font-size: 11px;margin-bottom: 16px;text-align: right;">
						{{$t($msg.DEPOSIT_TIPS)+`:`}}
						<text style="padding:4px 0 8px 4px;">{{$fmt.amount(low_cun)}}</text>
					</view>
				</view>

				<!-- // 上传截图 -->
				<view v-if="type == 1">
					<!-- <view class="bold">上传凭证</view> -->

					<!-- <view class=" text-center"
						style="font-size: 24rpx; padding: 10px;width: 100%;justify-content: center;display: flex;">
						点击上传转移成功证明</view> -->
					<!-- 	<view class="success">
					<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1"
						width="330" height="200" style="z-index: 10;">
						<view style="padding:10px 90px;">
							<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">点击上传转移成功证明。</view>
											
							<image src="/static/upload.png" mode="widthFix" style="width: 150px;"></image>
						</view>
						
				
				
					</u-upload>
				</view> -->

					<!-- <view @click="selectImg('front')"
						style="display: flex;align-items: center;justify-content: center;padding: 6px;border-radius: 8rpx;border: 1px solid #EAEAEA;background-color: #FCFDFF;">
						<template v-if="!frontURL">
							<view
								style="margin:20rpx;width:280px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
								<image src="/static/upload.png" mode="aspectFit" :style="$theme.setImageSize(96)">
								</image>
							</view>
						</template>
						<template v-else>
							<image :src="frontURL" style="margin:20rpx;width:280px;height:120px;">
							</image>
						</template>
					</view> -->
				</view>



				<view :style="{color:$theme.BLACK_70}">
					<view style="font: 14px;font-weight: 500;margin-top: 16px;margin-bottom: 16px;">
						{{$t($msg.DEPOSIT_TITLE + $msg.COMMON_RULE)}}
					</view>
					<block v-for="(v,k) in rules" :key="k">
						<view style="font-size: 12px;padding-bottom: 8px;">{{`・`+ v}}</view>
					</block>
				</view>
			</view>
		</view>
		<view class="fixed_bottom" v-if="Inv===0">
			<BtnLock :isDisabled="islock" @click="changeTab(1)" className="btn_submit radius_22">
				确认
			</BtnLock>
		</view>
		<!-- <view class="fixed_bottom" v-if="type == 2 || type == 3">
			<BtnLock :isDisabled="islock" @click="kj_recharge()" className="btn_submit radius_22">
				银证转入2
			</BtnLock>
		</view> -->
		<view v-if="Inv===1">
			<view class="fixed_bottom" v-if="type == 1">
				<BtnLock :isDisabled="islock" @click="to_recharge()" className="btn_submit radius_22">
					银证转入2
				</BtnLock>
			</view>
			<view class="fixed_bottom" v-if="type == 2 || type == 3">
				<BtnLock :isDisabled="islock" @click="kj_recharge()" className="btn_submit radius_22">
					银证转入3
				</BtnLock>
			</view>
		</view>


	</view>
</template>

<script>
	import {
		messages
	} from '../../localize/index.js';
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				user: null,
				amount: '',
				rules: ext.depositRules(),
				islock: false,
				frontURL: "",
				type: 1,
				low_cun: '',
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				utr: "",
				fileList6: [],
				userInfo: {},
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				bankName: '',
				ifscCode: '',
				branch: '',
				accountName: '',
				bankNum: '',
				current: 0,
				// list1: [{
				// 		name: 'Channel 1'
				// 	},
				// 	{
				// 		name: 'Channel 2'
				// 	},
				// ],
				Inv: 0,
				islock: false,
				// items: ['Channel 1', 'Channel 2']
			}
		},
		computed: {
			userAssets() {
				return {
					totalZichan: this.user.totalZichan,
					money: this.user.money,
					frozen: this.user.frozen,
				}
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.user = await this.$http.getAccount();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.user = await this.$http.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			async handleSubmit() {
				this.islock = true;
				if (!this.$util.checkField(this.amount, this.$msg.TIP_VALID)) return false;
				this.islock = false;
				// this.$util.linkCustomerService();
			},


			setStorage() {
				uni.setStorageSync('front', this.frontURL);
			},
			getStorage() {
				this.frontURL = uni.getStorageSync('front') || this.frontURL;
			},
			async getAccount() {
				const result = await this.$http.getAccount();
				this.frontURL = result.front_image || '';
			},
			async selectImg(val) {
				this.setStorage();
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				// console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				// console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				// console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.getStorage();
				if (val == 'front') {
					this.frontURL = reultURL;
					console.log(`frontURL:`, this.frontURL);
				}
				if (val == 'back') {
					this.backURL = reultURL;
					console.log(`backURL:`, this.backURL);
				}
			},

			//复制
			async copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('请联系客服索取密码');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: '复制成功',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},


			// //选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			async changeTab(newInv) {
				// 检查密码是否为空
				if (this.value3 === '') {
					uni.$u.toast('请验证通道密码');
					return false;
				}

				// 调用接口验证密码，并获取充值信息
				const result = await this.$http.post('api/app/getRechargeInfo', {
					password: this.value3
				});
				console.log('result:', result);

				// 如果返回结果为数组，认为密码错误
				if (Array.isArray(result)) {
					console.log('jinrule');
					uni.showToast({
						title: '密码错误',
						icon: 'none'
					});
					return false; // 密码错误时终止执行
				}

				// 更新各项银行信息，若接口返回为空则保持原值
				this.bankName = result.bank_name || this.bankName;
				// this.ifscCode = result.data.data.ifsc || this.ifscCode;
				this.branch = result.bank_branch || this.branch;
				this.accountName = result.bankno || this.accountName;
				this.bankNum = result.bank_user || this.bankNum;
				this.low_cun = result.low_cun || this.low_cun;

				// 设置 type，若 result.type 不在 [1,2,3] 中则默认设置为 1
				this.type = [1, 2, 3].includes(result.type) ? result.type : 1;

				// 如果输入金额小于最低转入金额，则提示并中断
				if (this.amount < this.low_cun) {
					uni.$u.toast('最低转入金额' + this.low_cun);
					return false;
				}

				// 切换选项卡，将 Inv 设置为 newInv
				this.Inv = newInv;
			},
			//通道支付
			async to_recharge() {
				uni.showLoading({
					title: "正在充值，请稍候......",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				if (this.value3 == '') {
					uni.$u.toast('请输入密码');
					return false;
				}
				if (this.bankName == '') {
					uni.$u.toast('请验证银行卡信息');
					return false;
				}
				if (this.amount < this.low_cun) {
					uni.$u.toast('最低转入金额' + this.low_cun);
					return false;
				}
				// if (this.frontURL == '') {
				// 	uni.$u.toast('请上传凭证');
				// 	return false;
				// }
				let res = await this.$http.post('api/app/recharge', {
					money: this.amount,
					image: this.frontURL,
				});
				console.log(111, res)

				uni.showToast({
					title: "提交成功,请等待审核",
					icon: 'none'
				})
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/settings/flow',
					});
				}, 2000);

				this.value3 = ''
				this.amount = ""
				this.frontURL = ""

			},

			//快捷支付
			async kj_recharge() {

				if (this.value3 == '') {
					uni.$u.toast('请输入密码');
					return false;
				}

				if (this.amount < this.low_cun) {
					uni.$u.toast('最低转入金额' + this.low_cun);
					return false;
				}
				let list = await this.$http.post('api/pay/rujin', {
					amount: this.amount,
					channel: this.type,
					// image: this.frontURL,
				});
				let payData = list.payData;
				if (payData) {
					console.log(1111, payData)
					window.location.href = payData
				}

			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},

			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {
				if (this.value3 == '') {
					uni.$u.toast('请输入密码');
					return false;
				}
				const result = await this.$http.post('api/app/getRechargeInfo', {
					password: this.value3
				});
				console.log(`result:`, result);
				if (Array.isArray(result)) {
					console.log('jinrule');
					uni.showToast({
						title: `密码错误`,
						icon: 'none'
					})
				}

				this.bankName = result.bank_name || this.bankName;
				// this.ifscCode = result.data.data.ifsc || this.ifscCode;
				this.branch = result.bank_branch || this.branch;
				this.accountName = result.bankno || this.accountName;
				this.bankNum = result.bank_user || this.bankNum;
				this.low_cun = result.low_cun || this.low_cun;

				this.type = [1, 2, 3].includes(result.type) ? result.type : 1;
				// console.log(this.type,88888)

			},
		},
	}
</script>

<style lang="scss">
	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				background-color: #aaaa00;
				border-radius: 5px;
				padding: 4px 6px;
				color: #FFF;
			}
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		background: #f8f7fc;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #000;
				font-weight: 700;
			}

			.duplicate {
				background-color: #fbf3ec;
				border-radius: 5px;
				padding: 4px 6px;
				color: #FFF;
			}
		}
	}
</style>