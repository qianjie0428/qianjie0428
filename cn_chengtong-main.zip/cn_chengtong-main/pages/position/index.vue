<template>
	<view :class="isAnimat?'fade_in':'fade_out'" class="position_head">
		<view style="font-size: 15px;font-weight: 700;color: #FFF;text-align: center;padding-top: 24px;">持仓</view>

		<!-- 		<view style="padding:30px 20px 0 20px;">
			<view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;">
				<block v-for="(v,k) in tabs" :key="k">
					<view @click="changeTab(k)" style="text-align: center;flex: 1;border-radius:22px;padding:8px 0;"
						:style="$theme.setStyleTab(curKey===k)">
						{{v}}
					</view>
				</block>
			</view>
		</view> -->

		<view class="right_in" style="padding:0 0 60px 0;">
			<!-- <template v-if="curKey===$C.KEY_ROI"> -->
			<!-- <CommonTitle title="投资收益"> </CommonTitle>
			<template>
				<view class="assets_card">
					<view style="padding: 20px;">
					<view style="display: flex;justify-content: space-between;">
							<view>购买金额</view>
							<view>评估收益率</view>
					</view>
					<view style="display: flex;justify-content: space-between;">
							<view>{{$fmt.amount(userinfo.frozen)}}</view>
							<view>{{(userinfo.holdYingli/userinfo.frozen*100).toFixed(2)}}%</view>
					</view>
					</view>
					<view style="padding:0px 20px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>评估收益</view>
						<view>总资产</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.amount(userinfo.holdYingli)}}</view>
						<view>{{$fmt.amount(userinfo.totalZichan)}}</view>
					</view>
					</view>
					
				</view>
			</template> -->

			<!-- 				<view style="height: 10px;width: 100%;background-color: #F5F5F5;"></view>
				<CommonTitle title="投资收益趋势"> </CommonTitle>

				<view
					style="display: flex;align-items: center;justify-content: space-between;gap: 12px;font-size: 12px;padding:20px;">
					<block v-for="(v,k) in months" :key="k">
						<view style="flex:1;border-radius: 22px;padding:4px 0;text-align: center;"
							:style="$theme.setStyleTab(curTab==k)" @click="changeMonth(k)">{{v}}
						</view>
					</block>
				</view>

				<view style="text-align: center;line-height: 9;">曲线图表</view>

			</template>

			<template v-if="curKey===$C.KEY_HOLD||curKey===$C.KEY_RECORD"> -->

			<view style="padding:30px 20px 0 20px;">
				<view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;">
					<block v-for="(v,k) in tabs" :key="k">
						<view @click="changeTab(k)" style="text-align: center;flex: 1;border-radius:22px;padding:8px 0;"
							:style="$theme.setStyleTab(curKey===k)">
							{{v}}
						</view>
					</block>
				</view>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<Position :list="list" @sell="handleSell"></Position>
			</template>
			<!-- </template> -->
		</view>

		<template v-if="showAsk">
			<view class="overlay" @click="showAsk=false"></view>
			<view class="modal_wrapper_center" style="background-color: #FFF;">
				<view style="line-height: 2.4;font-size: 18px;font-weight: 500;text-align: center;">
					{{$t($msg.POSITION_ASK)}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 3;margin-top: 8px;border-top: 0.1px solid #EEE;">
					<view style="flex: 1;text-align: center;border-right: 0.1px solid #EEE;" @click="cancel()">
						{{$t($msg.COMMON_CANCEL)}}
					</view>
					<view style="flex: 1;text-align: center;" :style="{color:$theme.PRIMARY}" @click="comfirm()">
						{{$t($msg.COMMON_CONFIRM)}}
					</view>
				</view>
			</view>
		</template>

		<FooterSmall :actKey="$C.KEY_POSITION"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import Position from './components/Position.vue';
	export default {
		components: {
			Position
		},
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					// [this.$C.KEY_ROI]: `投资收益`,
					[this.$C.KEY_HOLD]: `持有`,
					[this.$C.KEY_RECORD]: `交易记录`,
				},
				roi: null,
				months: [`近1个月`, `近3个月`, `近6个月`, `全部`],
				curTab: 0,


				curPage: 1,
				maxPage: 1,
				list: null,
				showAsk: false,
				curId: null,
				userinfo: null,
				timer: null,
			}
		},
		computed: {},
		onLoad() {
			this.clearTimer();
		},
		onShow() {
			
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.changeTab(this.curKey);
			this.getuser();
			this.getList();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
			this.getList();
			this.getuser();
		},
		onReachBottom() {
			this.curPage = this.curPage + 1;
			this.getList();
			this.getuser();
		},
		methods: {
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					this.getList();
					this.getuser();
				}, 3000);
			},
			async changeTab(val) {
				this.list = null;
				this.curKey = val;
				this.curPage = 1;
				this.maxPage = 1;
				// if (this.curKey === this.$C.KEY_ROI) 
				// this.roi = await this.$http.getROI();
				// if (this.curKey === this.$C.KEY_HOLD || this.curKey === this.$C.KEY_RECORD) 
				this.getuser();
				// this.getAccount();
			},
			changeMonth(val) {
				this.curTab = val;
			},

			handleSell(val) {
				this.showAsk = true;
				this.curId = val;
			},
			cancel() {
				this.showAsk = false;
			},
			async getuser() {
				let list = await this.$http.get('api/user/info', {
					
				})
				console.log(2222,list)
				this.userinfo = list; 
			},
			async comfirm() {
				uni.showLoading({
					title: this.$t(this.$msg.API_SUBMITING),
				});
				const result = await this.$http.post(`api/user/sell`, { id: this.curId });
				if (!result) {
					setTimeout(() => {
						this.cancel();
						this.changeTab(this.curKey);
					}, 1000)
					return null;
				}
				uni.showToast({ icon: 'success' });
				setTimeout(() => {
					this.cancel();
					this.changeTab(this.curKey);
				}, 1000)
			},

			async getList() {
				// uni.showLoading({
				// 	title: this.$t(this.$msg.API_REQUEST_DATA),
				// })
				const result = await this.$http.post(`api/user/order`, {
					page: this.curPage,
					status: this.curKey === this.$C.KEY_HOLD ? 1 : 2, // 1持仓，2历史
					// gp_index: 0,
				});
				if (!result) return false;
				console.log(`hold result:`, result);
				this.maxPage = result.last_page;
				const temp = !result.data || result.data.length <= 0 ? [] : result.data;
				const ids = !this.list ? [] : this.list.map(v => v.id);
				let tempList = [];
				if (this.curKey == this.$C.KEY_HOLD)
					tempList = !temp || temp.length <= 0 ? [] :
					temp.filter(v => v.goods_info && v.order_buy && v.order_buy.id > 0);
				else
					tempList = !temp || temp.length <= 0 ? [] :
					temp.filter(v => v.goods_info && v.order_buy && v.order_buy.id > 0 && v.order_sell && v.order_sell.id > 0);

				const filterList = tempList.length <= 0 ? [] : tempList.filter(v => !ids.includes(v.id));
				console.log(filterList);
				// 格式化所需数据
				const fmtList = filterList.map(v => {
					const type = v.goods_info.project_type_id;
					// const curcode = type == 1 ? v.goods_info.ncode : v.goods_info.bcode;
					const curcode = v.goods_info.code || '';
					const buyPrice = v.order_buy.price * 1 || 0;
					const buyPL = v.order_buy.yingkui * 1 || 0;
					const sellPrice = v.status == 1 ? 0 : (v.order_sell.price * 1 || 0);
					const sellPL = v.status == 1 ? 0 : (v.order_sell.yingkui * 1 || 0);
					const curPrice = v.goods_info.current_price * 1 || 0;
					const buyNum = v.order_buy.num * 1 || 0;
					return {
						id: v.id,
						status: v.status,
						name: v.goods_info.name || '',
						curcode,
						numCode: v.goods_info.number_code || '',
						type: type,
						buyNum: v.order_buy.num * 1 || 0,
						buyPrice,
						curPrice,
						sellPrice,
						buyFee: v.order_buy.buy_fee * 1 || 0,
						sellFee: v.status == 1 ? 0 : (v.order_sell.sell_fee * 1 || 0),
						buyAmount: v.order_buy.amount * 1 || 0,
						buyFloatPL: v.order_buy.float_yingkui * 1 || 0,
						sellFloatPL: v.status == 1 ? 0 : (v.order_sell.float_yingkui * 1 || 0),
						buyPLRate: this.$fmt.numer((curPrice - buyPrice) / buyPrice * 100, this.$rate) * 1,
						sellPLRate: v.status == 1 ? '' : this.$fmt.numer((sellPrice - buyPrice) / buyPrice *
							100, this.$rate) * 1,
						buyTotal: this.$fmt.numer(curPrice * buyNum, this.$decimal) * 1,
						sellTotal: this.$fmt.numer(sellPrice * buyNum, this.$decimal) * 1,
						double: v.order_buy.double || 1,
						// 1买 2卖
						plAmount: v.status == 1 ? buyPL : sellPL,
						buyDT: v.order_buy.created_at || '',
						sellDT: v.status == 1 ? '' : (v.order_sell.created_at || ''),
						sn: v.order_sn || '',
					}
				});
				if (!this.list || this.list.length <= 0) this.list = fmtList;
				else this.list.push(...fmtList);
				console.log(this.list);
			},

			async getAccount() {
				this.user = await this.$http.getAccount();
				// this.totalPL = this.user.totalYingli * 1 > 0 ? this.user.totalYingli * 1 : this.user.can_ti_money * 1;
				// this.holdPL = this.user.holdYingli * 1 || this.holdPL;
			}
		}
	}
</script>

<style>
</style>