<template>
	<view style="padding: 0 14px;">
		<block v-for="(v,k) in list" :key="k">
			<view class="record_item record_table" style="padding: 14px 0;font-size: 14px;"
				:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
				<view
					style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;display: flex;align-items: center;">
					<text style="font-size: 16px;font-weight: 700;"> {{v.name}}</text>
					<text style="padding-left: 12px;font-size: 11px;font-weight: 300;"
						:style="{color:$theme.FLAT}">({{v.curcode}})</text>
					<view style="margin-left: auto;">
						<template v-if="v.status==1">
							<view style="flex:1;text-align: center;line-height: 2;" @tap="sell(v.id)"
								:style="{backgroundColor:$theme.convertRGBA($theme.setRiseFall(1),10),color:$theme.setRiseFall(1)}">
								卖出
							</view>
						</template>
						<template v-if="v.status==2">
							<!-- <view style="flex:1;text-align: center;line-height: 2;" @tap="buy(v.curcode)"
								:style="{backgroundColor:$theme.convertRGBA($theme.setRiseFall(1),10),color:$theme.setRiseFall(1)}">
								{{$t($msg.COMMON_BUY)}}
							</view> -->
						</template>
					</view>
				</view>

				<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
					<view class="flex_row_between" style="flex:1;">
						<view>{{$t($msg.POSITION_BUY_PRICE)}}</view>
						<view>{{$fmt.amount(v.buyPrice)}} </view>
					</view>
					<view class="flex_row_between" style="flex:1;">
						<view>
							{{$t(v.status==1?$msg.POSITION_CUR_PRICE:$msg.POSITION_SELL_PRICE)}}
						</view>
						<template v-if="v.status==1">
							<view> {{$fmt.amount(v.curPrice)}} </view>
						</template>
						<template v-if="v.status==2">
							<view> {{$fmt.amount(v.sellPrice)}} </view>
						</template>
					</view>
				</view>

				<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
					<view class="flex_row_between" style="flex:1;">
						<view>{{$t($msg.POSITION_BUY_QTY)}}</view>
						<view>{{$fmt.numer(v.buyNum)}} </view>
					</view>
					<view class="flex_row_between" style="flex:1;">
						<view>{{v.status==1?$msg.POSITION_BUY_FEE:`卖出手续费`}}</view>
						<template v-if="v.status==1">
							<view>{{$fmt.amount(v.buyFee)}} </view>
						</template>
						<template v-else>
							<view>{{$fmt.amount(v.sellFee)}} </view>
						</template>
					</view>
				</view>
				<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
					<view class="flex_row_between" style="flex:1;">
						<view>{{$t($msg.POSITION_BUY_AMOUNT)}}</view>
						<view>{{$fmt.amount(v.buyAmount)}} </view>
					</view>
					<view class="flex_row_between" style="flex:1;">
						<view> {{$t($msg.POSITION_PL_RATE)}} </view>
						<template v-if="v.status==1">
							<view :style="{color:$theme.setRiseFall(v.buyPLRate)}">
								{{$fmt.percent(v.buyPLRate)}}
							</view>
						</template>
						<template v-if="v.status==2">
							<view :style="{color:$theme.setRiseFall(v.sellPLRate)}">
								{{$fmt.percent(v.sellPLRate)}}
							</view>
						</template>
					</view>
				</view>

				<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
					<view class="flex_row_between" style="flex:1;">
						<view> {{$t($msg.POSITION_TOTAL)}} </view>
						<template v-if="v.status==1">
							<view> {{$fmt.amount(v.buyTotal)}} </view>
						</template>
						<template v-if="v.status==2">
							<view> {{$fmt.amount(v.sellTotal)}} </view>
						</template>
					</view>
					<view class="flex_row_between" style="flex:1;">
						<view>{{$t($msg.POSITION_PL)}}</view>
						<view :style="{color:$theme.setRiseFall(v.plAmount)}">
							{{$fmt.amount(v.plAmount)}}
						</view>
					</view>
				</view>

				<view class="flex_row_between" style="padding-top: 8px;gap:10px;">
					<view class="flex_row_between" style="flex:1;">
						<view> {{$t($msg.POSITION_FLOAT_PL)}} </view>
						<template v-if="v.status==1">
							<view :style="{color:$theme.setRiseFall(v.buyFloatPL)}">
								{{$fmt.amount(v.buyFloatPL)}}
							</view>
						</template>
						<template v-if="v.status==2">
							<view :style="{color:$theme.setRiseFall(v.sellFloatPL)}">
								{{$fmt.amount(v.sellFloatPL)}}
							</view>
						</template>
					</view>
					<view class="flex_row_between" style="flex:1;">
						<!-- <view>{{$t($msg.POSITION_LEVER)}}</view>
						<view>{{$fmt.numer(v.double)}} </view> -->
					</view>
				</view>

				<view class="flex_row_between" style="font-size: 14px;padding-top: 8px;">
					<view>{{v.status==1?`购买时间`:`卖出时间`}}</view>
					<view>{{v.status==1? v.buyDT:v.sellDT}}</view>
				</view>
				<view class="flex_row_between" style="font-size: 14px;padding-top: 8px;">
					<view>订单编号</view>
					<view>{{v.sn}}</view>
				</view>

				<!-- <view style="display: flex;align-items: center;justify-content: space-between;gap: 20px;margin-top: 10px;">
					<view class="tab_act"
						style="flex:1;text-align: center;background: linear-gradient(to bottom, #0F1C4E, #063B8E);line-height: 2;"
						@tap="$linkTo.stockDetail(v.curcode)">
						{{$t($msg.STOCK_TITLE)}}
					</view>
					<template v-if="v.status==1">
						<view class="tab_act" style="flex:1;text-align: center;line-height: 2;" @tap="sell(v.id)">
							{{$t($msg.COMMON_SELL)}}
						</view>
					</template>
					<template v-if="v.status==2">
						<view class="tab_act" style="flex:1;text-align: center;line-height: 2;" @tap="buy(v.curcode)">
							{{$t($msg.COMMON_BUY)}}
						</view>
					</template>
				</view> -->
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "PositionBak",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			sell(val) {
				this.$emit('sell', val);
			},
			buy(val) {
				this.$linkTo.stockDetail(val, 'buy');
			}
		}
	}
</script>

<style>
</style>