<template>
	<view style="padding: 0 14px;">
		<block v-for="(v,k) in list" :key="k">
			<view style="padding: 20px 0;font-size: 14px;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
				<view
					style="background-color: #F6F6F6;border-radius: 8px;border:0.5px solid #D7060F;padding:14px;display: flex;align-items: center;">
					<text style="font-size: 16px;font-weight: 700;"> {{v.name}}</text>
					<text style="padding-left: 12px;font-size: 11px;font-weight: 300;"
						:style="{color:$theme.FLAT}">({{v.curcode}})</text>
					<view style="margin-left: auto;">
						<template v-if="v.status==1">
							<view style="flex:1;text-align: center;line-height: 2;" @tap="sell(v.id)"
								:style="{backgroundColor:$theme.convertRGBA($theme.setRiseFall(1),10),color:$theme.setRiseFall(1)}">
								{{$t($msg.COMMON_SELL)}}
							</view>
						</template>
						<template v-if="v.status==2">
							<view style="flex:1;text-align: center;line-height: 2;" @tap="buy(v.curcode)"
								:style="{backgroundColor:$theme.convertRGBA($theme.setRiseFall(1),10),color:$theme.setRiseFall(1)}">
								{{$t($msg.COMMON_BUY)}}
							</view>
						</template>
					</view>
				</view>

				<view style="width: 100%;">
					<view style="width: 25%;">
						<view>收益</view>
						<view :style="{color:$theme.setRiseFall(v.plAmount)}">
							{{$fmt.amount(v.plAmount,$util.isUS(v.type))}}
						</view>
					</view>
					<view style="width: 25%;text-align: center;">
						<view>收益率</view>
						<view :style="{color:$theme.setRiseFall(v.buyPLRate)}">
							{{$fmt.amount(v.buyPLRate,$util.isUS(v.type))}}
						</view>
					</view>
					<view style="width: 25%;text-align: center;">
						<view>数量</view>
						<view>{{$fmt.quantity(v.buyNum)}}</view>
					</view>
					<view style="width: 25%;text-align: center;">
						<view>成交金额</view>
						<view>{{$fmt.amount(v.buyAmount,$util.isUS(v.type))}}</view>
					</view>
					<view style="width: 25%;text-align: center;">
						<view>成交日期</view>
						<view>{{v.status == 1? v.buyDT:v.sellDT}}</view>
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'Position',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			sell(val) {
				this.$emit('sell', val);
			},
			buy(val) {
				this.$linkTo.stockDetail(val, 'buy');
			}
		}
	}
</script>

<style>
</style>