import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const tabs = () => {
	return {
		[constants.KEY_ROI]: `投资收益`,
		[constants.KEY_HOLD]: `持有`,
		[constants.KEY_RECORD]: `买卖明细`,
	}
}