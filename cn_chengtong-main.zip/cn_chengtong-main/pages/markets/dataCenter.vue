<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_DATA)" />

		<view class="right_in" style="padding:0 0 60px 0;">
			<view class="data_center_head">
				<view style="font-size: 14px;font-weight: 500;padding:10px 16px;">
					两融市场数据（{{detail? detail.dt :$fmt.todayHMS()}}）
				</view>
				<view style="width: 100%;height: 0.5px;" :style="{backgroundColor:$theme.BLACK_30}"></view>

				<template v-if="detail">
					<view
						style="margin:10px 16px 0 16px;display: flex;align-items: center;justify-content:space-between;line-height: 1.6;text-align: center;font-size: 15px;"
						:style="{color:$theme.BLACK_70}">
						<view>
							<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
								{{$fmt.decimalY(detail.amount)}}
							</view>
							<view>两融余额</view>
						</view>
						<view>
							<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
								{{$fmt.decimalY(detail.amount1)}}
							</view>
							<view>融资余额</view>
						</view>
						<view>
							<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
								{{$fmt.decimalY(detail.amount2)}}
							</view>
							<view>融劵余额</view>
						</view>
					</view>
				</template>
			</view>
			<view style="background-color: #F4F4F4;height: 10px;width: 100%;"></view>

			<view class="table">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(v,k) in list" :key="k">
						<view class="table_row" style="padding:10px 20px;" @click="linkTo(v)">
							<view class="table_cell" style="width: 25%;">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
							</view>
							<view class="table_cell" style="width: 15%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
							<view class="table_cell" style="width: 34%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.amount(v.amount)}}亿
							</view>
							<view class="table_cell" style="width: 26%;text-align: right;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.amount(v.amount1)}}万
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				detail: null,
				list: null,
				timer: null,
			}
		},
		
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			// this.getDetail();
			// this.getList();
			this.onSetTimeout();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkTo(val) { return false; },

			onSetTimeout() {
				// this.timer = setInterval(() => {
					console.log("setInterval");
					this.getDetail();
					this.getList();
				// }, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			async getDetail() {
				const result = await this.$http.get(`api/app/datacenter_panel`);
				if (!result) return null;
				console.log(result);
				this.detail = {
					dt: result.rzrq_date || '',
					amount: result.rzrq_money * 1 || 0,
					amount1: result.rq_money * 1 || 0,
					amount2: result.rz_money * 1 || 0,
				}
			},

			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/app/datacenter`);
				if (!result) return null;
				console.log(result);
				this.list = result.map(v => {
					return {
						id: v.code,
						name: v.name,
						code: v.code,
						rate: v.rate * 1 || 0,
						amount: v.rongzi_money / 100000000 || 0,
						amount1: v.rongquan_money / 10000 || 0,
					}
				})
				console.log(this.list);
			}
		}
	}
</script>

<style>
</style>