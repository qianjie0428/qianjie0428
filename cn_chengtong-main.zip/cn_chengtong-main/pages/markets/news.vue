<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_NEWS_HOT)" />
		<view class="home_news_tabs">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;padding:0;" @touchmove.stop>
				<view style="display: flex;margin:0 4px;">
					<block v-for="(v,k) in $msg.NEWS_TABS" :key='k'>
						<view style="font-size: 15px;padding-right: 12px;" @click="changeTab(k)">
							<view style="padding-bottom: 12px;" :style="{ color:curTab==k?$theme.PRIMARY : $theme.TXT_UNACT }">{{v}}
							</view>
							<view style="width: 28px;height: 3px; margin:0 auto; border-radius: 24px;"
								:style="{ backgroundColor:curTab==k?$theme.PRIMARY : $theme.TRANSPARENT }">
							</view>
						</view>
					</block>
				</view>
			</scroll-view>
		</view>
		<view class="right_in" style="padding:0 0 60px 0;">
			<template v-if="!news || news.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in news" :key="k">
					<view class="news_item" @click="$linkTo.openNews(v.url)">
						<!-- 	<image :src="v.pic" mode="scaleToFill" :style="$theme.setImageSize(60)"
							style="border-radius: 6px;">
						</image> -->
						<view style="flex:1;padding-left:0;display: flex;flex-direction: column;justify-content: space-between;">
							<view><text>{{v.title}}</text> </view>
							<view style="flex:0 0 auto;display: flex;justify-content: space-between;font-size: 12px;"
								:style="{color:$theme.TXT_UNACT}">
								<view>{{v.origin}}</view>
								<view>{{$fmt.quantity(v.read)+` `+$t($msg.COMMON_READ)}}</view>
								<view>{{v.dt}}</view>
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				news: null,
				curTab: 0,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(v) {
				this.curTab = v;
				this.getNews();
			},
			async getNews() {
				this.news = await this.$http.getNews(this.curTab) || this.news;
			},
		}
	}
</script>

<style>
</style>