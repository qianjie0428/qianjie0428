<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #F4F4F4;min-height: 100vh;">
		<header class="common_head" style="display: flex;align-items: center;height: 64px;">
			<view style="padding:0 0 0 16px;">
				<block v-for="(v,k) in tabs" :key="k">
					<text style="font-size: 16px;color: #FFF;padding-bottom: 3px; margin-right: 24px;" @click="changeTab(k)"
						:style="{borderBottom:`4px solid ${curTab===k?`#FFF`:$theme.TRANSPARENT}`}">
						{{v}}</text>
				</block>
			</view>
			<view style="margin-left: auto;padding-right: 16px;">
				<view style="border-radius: 18px;padding:6px 12px;display: flex;align-items: center;"
					:style="{backgroundColor:$theme.convertRGBA(`#FFFFFF`,30)}" @click="$linkTo.search()">
					<image src="/static/search.svg" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
					<view style="padding-left: 12px;" :style="{color:$theme.convertRGBA(`#FFFFFF`,30)}">
						{{$t($msg.COMMON_SEARCH)}}
					</view>
				</view>
			</view>
		</header>

		<template v-if="curTab===$C.KEY_TRACK">
			<view class="right_in" style="padding:0 20px 60px 20px;">
				<Track :list="tracks" @action="linkTo" />
			</view>
		</template>

		<template v-if="curTab===$C.KEY_MARKET">
			<view
				style="display: flex;align-items: center;justify-content: space-between;padding:15px 20px;background-color: #FFF;">
				<block v-for="(v,k) in marketTabs" :key="k">
					<view style="font-size: 12px;border-radius: 4px;padding:4px 8px;" @click="changeTabMarket(k)"
						:style="setStyle(k===curKey)">{{v}}</view>
				</block>
			</view>

			<view class="left_in" style="padding:0 0 60px 0;margin-top: 10px;">
					
					<template v-if="curKey===$C.KEY_INDI">
						<CommonList :list="zhishu_list"  />
					</template>
					
				<template v-else-if="!list || Object.keys(list).length<=0">	
					<EmptyData></EmptyData>
				</template>
				
				
				<template v-else="list || Object.keys(list).length>0">
					<template v-if="curKey===$C.KEY_HS">
						
						<template v-if="zhishu_list && zhishu_list && zhishu_list.length>0">
							<view class="card_row" style="padding-top: 12px;">
								<block v-for="(v,k) in zhishu_list" :key="k">
									<CardItem :detail="v"  v-if="k<6"/>
								</block>
							</view>
						</template>
						
						<view style="display: flex;align-items: center;justify-content: space-between;padding:4px 16px 10px 16px;">
							<block v-for="(v,k) in hsTabs" :key="k">
								<view @click="changeTabHS(k)" style="padding-bottom: 4px;">
									<text style="text-align: center;font-size: 12px;padding:8px;" :style="$theme.setTabStyle(curHS===k)">
										{{v}}</text>
								</view>
							</block>
						</view>
						
						<HSList :list="list" @action="linkTo" />
					</template>

					

					<template v-if="curKey===$C.KEY_HK && Object.keys(list).length>0">
						<view class="card_row" style="padding-top: 12px;">
							<block v-for="(v,k) in list.indis" :key="k">
								<CardItem :detail="v"  />
								
							</block>
						</view>
						<CommonList :list="list.stocks" />
						<view style="text-align: center;line-height:3;font-size: 14px;background-color: #FFF;"
							:style="{color:$theme.BLACK_70}" @click="$linkTo.marketCommon($C.KEY_HK)">查看更多 <image
								src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
							</image>
						</view>
					</template>

					<template v-if="curKey===$C.KEY_US">
						<CommonTitle title="指数">
							<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;"
								:style="{color:$theme.BLACK_30}" @click="$linkTo.marketCommon($C.KEY_US_INDI)">
								<text>更多 </text>
								<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
								</image>
							</view>
						</CommonTitle>
						<view style="background-color: #FFF;padding-top: 10px;"
							:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}"></view>
						<view class="card_row" style="background-color: #FFF;padding-top: 10px;">
							<block v-for="(v,k) in zhishu_list" :key="k">
								<CardItem :detail="v"  />
							</block>
						</view>
						<CommonTitle title="期货">
							<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;"
								:style="{color:$theme.BLACK_30}" @click="$linkTo.marketCommon($C.KEY_FUTURE)">
								<text>更多 </text>
								<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
								</image>
							</view>
						</CommonTitle>
						<view style="background-color: #FFF;padding-top: 10px;"
							:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}"></view>
						<view class="card_row" style="background-color: #FFF;padding-top: 10px;">
							<block v-for="(v,k) in list.futures" :key="k">
								<CardItem :detail="v" />
							</block>
						</view>
						<CommonTitle title="美股">
							<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;"
								:style="{color:$theme.BLACK_30}" @click="$linkTo.marketCommon($C.KEY_MARKET_ALL)">
								<text>更多 </text>
								<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
								</image>
							</view>
						</CommonTitle>
						<view style="margin-top: 0px;background-color: #FFF;"></view>
						<template v-if="list && list.stocks && list.stocks.length>0">
							<USStockList :list="list.stocks"  />
							<!-- <view class="card_row" style="padding-top: 12px;">
								<block v-for="(v,k) in list.stocks" :key="k">
									<CardItem :detail="v" @action="indiLinkTo" />
								</block>
							</view> -->
						</template>
						<!-- <CommonTitle title="ETF">
								<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;"
									:style="{color:$theme.BLACK_30}" @click="$linkTo.marketCommon($C.KEY_US_ETF)">
									<text>更多 </text>
									<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
									</image>
								</view>
							</CommonTitle>
						
							<view style="background-color: #FFF;padding-top: 10px;"
								:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}"></view>
							<view class="card_row" style="background-color: #FFF;padding-top: 10px;">
								<block v-for="(v,k) in list.usetfs" :key="k">
									<CardItem :detail="v" @action="usLinkTo" />
								</block>
							</view>
						
							<CommonTitle title="板块">
								<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;"
									:style="{color:$theme.BLACK_30}" @click="$linkTo.marketCommon($C.KEY_US_PLATE)">
									<text>更多 </text>
									<image src="/static/arrow_right.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
									</image>
								</view>
							</CommonTitle>
						
							<view style="background-color: #FFF;padding-top: 10px;"
								:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}"></view>
							<view class="card_row" style="background-color: #FFF;padding-top: 10px;">
								<block v-for="(v,k) in list.usblocks" :key="k">
									<CardItem :detail="v" @action="usLinkTo" />
								</block>
							</view> -->
					</template>

					<!-- <template v-if="curKey===$C.KEY_HS||curKey===$C.KEY_US">
						<template v-if="pmdInfo && pmds.length>0">
							<CommonTitle title="涨跌幅分布">
								<view style="font-size: 12px;" :style="{color:$theme.BLACK_30}">{{$fmt.todayHMS()}}</view>
							</CommonTitle>
							<PMD :info="pmdInfo" :list="pmds" :show="curKey===$C.KEY_HS" />
						</template>
					</template> -->

					<!-- <template v-if="curKey===$C.KEY_HS"> -->
					<!-- <template v-if="fundFlows && fundFlows.length>0">
							<CommonTitle title="资金流向" />
							<template v-if="list && list.length>0">
								<FundFlowCurves :list="fundFlows" />
							</template>
							<FundFlow :list="fundFlows" />
						</template> -->

					<!-- <template v-if="curKey===$C.KEY_INDI && kplDashboardDetail">
						<CommonTitle title="市场概述" />
						<KPIDashboard :info="kplDashboardDetail" />
					</template> -->

				</template>
			
			</view>
		</template>

		<FooterSmall :actKey="$C.KEY_MARKET"></FooterSmall>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	// import * as mock from '@/common/mock.js';
	import HSList from './components/HSList.vue';

	import Track from './components/Track.vue';
	// import FundFlow from './components/FundFlow.vue';
	// import PMD from './components/PMD.vue';
	// import KPIDashboard from './components/KPIDashboard.vue';
	// import FundFlowCurves from './components/FundFlowCurves.vue';
	export default {
		components: {
			HSList,
			Track,
			// FundFlow,
			// FundFlowCurves,
			// PMD,
			// KPIDashboard,
		},
		data() {
			return {
				isAnimat: false,
				zhishu_list:[],
				tabs: {
					[this.$C.KEY_MARKET]: this.$msg.MENU_MARKET,
					[this.$C.KEY_TRACK]: this.$msg.MENU_TRACK,
				},
				curTab: null,
				marketTabs: {
					[this.$C.KEY_HS]: this.$msg.MARKET_HS,
					[this.$C.KEY_INDI]: this.$msg.MARKET_INDI,
					[this.$C.KEY_HK]: this.$msg.MARKET_HK,
					[this.$C.KEY_US]: this.$msg.MARKET_US,
				},
				curKey: null,

				hsTabs: {
					[this.$C.KEY_RISE]: `涨幅`,
					[this.$C.KEY_FALL]: `跌幅`,
					[this.$C.KEY_INFLOW]: `主力净流入`,
					[this.$C.KEY_VOL]: `成交额`,
				},
				curHS: null,

				tracks: null,
				list: null,

				fundFlows: null,
				pmds: null,
				pmdInfo: null,
				hsBest: null,
				kplDashboardDetail: null,

				timer: null,
			}
		},
		computed: {},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curTab = this.curTab || Object.keys(this.tabs)[0];
			this.curKey = this.curKey || Object.keys(this.marketTabs)[0];
			
			this.getzhishu()
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		async onPullDownRefresh() {
			this.clearTimer();
			this.fundFlows = null;
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.clearTimer();
				this.curTab = val;
				if (this.curTab === this.$C.KEY_MARKET) this.changeTabMarket(this.curKey);
				if (this.curTab === this.$C.KEY_TRACK) this.tracks = await this.$http.getTrack();
			},

			async changeTabMarket(val) {
				this.clearTimer();
				this.curKey = val;
				this.list = null;
				console.log(22222)
				if (this.curKey === this.$C.KEY_HS) {
					this.curHS = Object.keys(this.hsTabs)[0] || this.curHS;
					this.changeTabHS(this.curHS);
				} else {
					this.getSomeData();
					this.onSetTimeout();
				}
			},

			changeTabHS(val) {
				this.clearTimer();
				this.curHS = val;
				this.getHSStocks();
				this.onSetTimeout();
			},

			async getHSStocks() {
				this.list = await this.$http.getGoodsList(this.curHS);
				this.getzhishu()
			},
			async getzhishu() {
				const result = await this.$http.post(`api/goods/zhishu`);
				if (!result) return false;
				
				this.zhishu_list = result
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					if (this.curKey === this.$C.KEY_HS) this.getHSStocks();
					else this.getSomeData();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			async getSomeData() {
				if (this.curKey === this.$C.KEY_HK) {
					const indis = await this.$http.getHKIndis();
					if (!this.list) this.list = {}; // 初始化为对象
					this.$set(this.list, 'indis', indis);
					const stocks = await this.$http.getHKStocks();
					this.$set(this.list, 'stocks', stocks);
				}
				this.getzhishu()
				if (this.curKey === this.$C.KEY_US) {
					console.log(111);
					if (!this.list) this.list = {}; // 初始化为对象
					const usIndis = await this.$http.getUSIndi(3);
					this.$set(this.list, 'indis', usIndis);
					const futures = await this.$http.getUSFuture(3);
					this.$set(this.list, 'futures', futures);
					const usStocks = await this.$http.getUSStocks();
					this.$set(this.list, 'stocks', usStocks);

					// const usetfs = await this.$http.getGoodsList(this.$C.KEY_US_ETF, 3);
					// const usblocks = await this.$http.getGoodsList(this.$C.KEY_US_BLOCK, 3);
					// console.log(`usIndis:`, usIndis);
					// this.list = { usIndis, futures, usetfs, usblocks };
				}

				// if (this.curKey === this.$C.KEY_INDI) {
				// 	const hsIndis = await this.$http.getGoodsList(this.$C.KEY_HS_INDI);
				// 	this.list = { hsIndis };
				// 	this.kplDashboardDetail = await this.$http.getKPIDashboardDetail();
				// 	console.log(this.kplDashboardDetail);
				// }

				// if (this.curKey === this.$C.KEY_HS || this.curKey === this.$C.KEY_US) {
				// 	this.fundFlows = await this.$http.getFundFlow();
				// 	this.pmdInfo = await this.$http.getPMDDetail();
				// 	this.pmds = [1, 3, 5];
				// }
			},

			// 当前默认行为：携带数据id，跳转到stockDetail页面
			indiLinkTo(val) { return false; },
			linkTo(val) {
				console.log(`linkTo:`, val);
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val.code, val.gid);
			},
			setStyle(val) {
				return {
					color: val ? `#FFF` : this.$theme.convertRGBA(`#000000`, 70),
					backgroundColor: val ? this.$theme.PRIMARY : `#F4F4F4`,
				}
			}
		}
	}
</script>

<style>
</style>