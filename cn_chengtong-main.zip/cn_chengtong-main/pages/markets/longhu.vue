<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_LONGHU)" />

		<view class="right_in" style="padding:0 20px 60px 20px;">
			<view class="table">
				<view class="table_header">
					<view class="table_th" style="width: 35%;">名称/代码</view>
					<view class="table_th" style="width: 25%;text-align: center;">涨幅</view>
					<view class="table_th" style="width: 40%;text-align: right;">
						<view>买入额(万)</view>
						<view>卖出额(万)</view>
					</view>
				</view>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(v,k) in list" :key="k">
						<view class="table_row">
							<view class="table_cell" style="width: 35%;">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
							</view>
							<view class="table_cell" style="width: 25%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
							<view class="table_cell" style="width: 40%;text-align: right;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								<view> {{$fmt.decimalW(v.amount)}} </view>
								<view>{{$fmt.decimalW(v.amount1)}}</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null,
				timer: null,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
			uni.stopPullDownRefresh();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getList();
				}, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			async getList() {
				const result = await this.$http.get(`api/app/longhubang`);
				if (!result) return false;
				console.log(result);
				this.list = result.map(v => {
					return {
						name: v.name,
						code: v.code,
						rate: v.rate * 1 || 0,
						amount: v.buy_amount * 1 || 0,
						amount1: v.sell_amount * 1 || 0,
					}
				})
			}
		}
	}
</script>

<style>
</style>