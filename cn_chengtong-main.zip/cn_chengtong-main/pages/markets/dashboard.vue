<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_DASHBOARD)" />

		<view class="right_in" style="padding:0 20px 60px 20px;">
			<view class="table">
				<view class="table_header">
					<view class="table_th" style="width: 25%;">名称/代码</view>
					<view class="table_th" style="width: 20%;text-align: center;">涨幅</view>
					<view class="table_th" style="width: 30%;text-align: center;">成交量</view>
					<view class="table_th" style="width: 25%;text-align: right;">金额</view>
				</view>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(v,k) in list" :key="k">
						<view class="table_row">
							<view class="table_cell" style="width: 25%;">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
							</view>
							<view class="table_cell" style="width: 20%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
							<view class="table_cell" style="width: 30%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								{{$fmt.decimal(v.amount)}}
							</view>
							<view class="table_cell" style="width: 25%;text-align: right;">
								{{$fmt.amount(v.amount1)}}
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/app/fundflow`);
				if (!result) return false;
				console.log(result);
				// return result;
				this.list = result.map(v => {
					return {
						name: v.name,
						code: v.code,
						rate: v.rate * 1 || 0,
						amount: v.big * 1 || 0,
						amount1: v.zhuli * 1 || 0,
					}
				})
			}
		}
	}
</script>

<style>
</style>