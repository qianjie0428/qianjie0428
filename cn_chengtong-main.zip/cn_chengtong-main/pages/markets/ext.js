import * as linkTo from '@/common/linkTo.js';
import * as util from '@/common/util.js';
import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

// export const tabs = () => {
// 	return {
// 		[constants.KEY_MARKET]: translate(Msg.MENU_MARKET),
// 		[constants.KEY_TRACK]: translate(Msg.MENU_TRACK),
// 	}
// }

// export const marketTabs = () => {
// 	return {
// 		[constants.KEY_HS]: translate(Msg.MARKET_HS),
// 		[constants.KEY_KPI]: translate(Msg.MARKET_KPI),
// 		[constants.KEY_HK]: translate(Msg.MARKET_HK),
// 		[constants.KEY_US]: translate(Msg.MARKET_US),
// 	}
// };

// export const tabsCommon = () => {
// 	return {
// 		[constants.KEY_KPI]: {
// 			name: `指数`,
// 			// 如果是相同api不通参数，则此处写不通的参数部分
// 			api: `goods/kpi`,
// 		},
// 		[constants.KEY_MARKET_ALL]: {
// 			name: `全市场`,
// 			api: `goods/all`,
// 		},
// 		[constants.KEY_HK]: {
// 			name: `港股`,
// 			api: `goods/hk`,
// 		},
// 		[constants.KEY_US_KPI]: {
// 			name: `美股 指数`,
// 			api: `goods/uskpi`,
// 		},
// 		[constants.KEY_US_ETF]: {
// 			name: `美股ETF`,
// 			api: `goods/usetf`,
// 		},
// 		[constants.KEY_FUTURE]: {
// 			name: `期货`,
// 			api: `goods/future`,
// 		},
// 		[constants.KEY_US_PLATE]: {
// 			name: `板块`,
// 			api: `goods/plate`,
// 		},
// 		[constants.KEY_GEM]: {
// 			name: `创业板`,
// 			api: `goods/gem`,
// 		},
// 	}
// }



export const reportTabs = () => {
	return [{
		key: constants.KEY_TAB_REPORT,
		name: `研报`,
	}, {
		key: constants.KEY_TAB_REPORTS,
		name: `金麒麟榜单`,
	}]
}

export const reportTabsList = () => {
	return [{
		key: constants.KEY_REPORT_TAB_BEST,
		name: `最佳分析师`,
	}, {
		key: constants.KEY_REPORT_TAB_ELITE,
		name: `精英分析师`,
	}, {
		key: constants.KEY_REPORT_TAB_STAR,
		name: `未来之星`,
	}]
}