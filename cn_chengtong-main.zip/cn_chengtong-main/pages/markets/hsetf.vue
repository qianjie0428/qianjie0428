<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_HS_ETF)" />

		<view class="right_in" style="padding:0 0 60px 0;">
			<!-- 			<view
				style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 15px;background-color: #FFF;padding:10px 20px;"
				:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
				<view style="flex:1;">涨幅</view>
				<view style="flex:1;">成交量</view>
				<view style="flex:1;">规模</view>
				<view style="margin-left: auto;text-align: right;">折价/溢价率</view>
			</view> -->

			<view style="padding:10px 20px;border-bottom: 0.5px solid #979797;font-size: 13px;text-align: right;">
				更新时间 {{$fmt.todayHMS()}}
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<view style="padding:10px 20px;border-bottom: 0.5px solid #979797;font-size: 14px;">
						<view style="display: flex;align-items: center;font-weight: 700;">
							<view style="font-size: 15px;font-weight: 900;">{{v.name}}</view>
							<view style="margin-left: auto;" :style="{color:$theme.setRiseFall(v.rate)}">
								<text style="padding-right: 12px;">{{$fmt.amount(v.price)}}</text>
								<text style="">{{$fmt.percent(v.rate)}}</text>
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;gap: 10px;padding-top: 12px;">
							<view style="width: 40%;">
								<view style="font-size: 12px;">成交量</view>
								<view style="font-weight: 700;">{{$fmt.decimalW(v.amount)}}</view>
							</view>
							<view style="width: 30%;text-align: center;">
								<view style="font-size: 12px;">规模</view>
								<view style="font-weight: 700;">{{$fmt.amount(v.amount1)+`亿`}}</view>
							</view>
							<view style="width: 30%;text-align: right;">
								<view style="font-size: 12px;">溢价</view>
								<view style="font-weight: 700;">{{$fmt.amount(v.amount2)+`亿`}}</view>
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null,
				timer: null,
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.getList();
			this.onSetTimeout();

		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		async onPullDownRefresh() {
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/app/etf`);
				if (!result) return null;
				console.log(result);
				this.list = result.map(v => {
					return {
						name: v.name,
						code: v.code,
						price: v.current_price * 1 || 0,
						rate: v.rate * 1 || 0,
						rateNum: v.rate_num * 1 || 0,
						amount: v.cj_amount * 1 || 0,
						amount1: v.trans_amount / 100000000 || 0,
						amount2: 0,
					}
				})

				// this.list = await this.$http.getGoodsList(this.$C.KEY_HSETF_S);
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getList();
				}, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>