<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" title="次新股" />

		<view class="right_in" style="padding:0 20px 60px 20px;">
			<view class="table">
				<view class="table_header">
					<view class="table_th" style="width: 24%;">名称/代码</view>
					<view class="table_th" style="width: 22%;text-align: center;">
						<view>最新价</view>
						<view>涨跌幅</view>
					</view>
					<view class="table_th" style="width: 22%;text-align: center;">
						<view>收盘价</view>
						<view>涨跌数</view>
					</view>
					<view class="table_th" style="width: 32%;text-align: right;">
						<view>成交额</view>
						<view>上市日期</view>
					</view>
				</view>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(v,k) in list" :key="k">
						<view class="table_row" @click="linkTo(v)">
							<view class="table_cell" style="width:24%;">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
							</view>
							<view class="table_cell" style="width: 22%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rate)}">
								<view>{{$fmt.amount(v.price)}}</view>
								<view>{{$fmt.percent(v.rate)}}</view>
							</view>
							<view class="table_cell" style="width: 22%;text-align: center;">
								<view>{{$fmt.amount(v.close)}}</view>
								<view :style="{color:$theme.setRiseFall(v.rate)}">{{$fmt.numer(v.rateNum)}}</view>
							</view>
							<view class="table_cell" style="width: 32%;text-align: right;">
								<view> {{$fmt.amount(v.amount1)}} 万</view>
								<view>{{v.online}}</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				list: null,
				timer: null,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkTo(val) {
				this.$linkTo.stockDetail(val.code, val.gid)
			},
			async getList() {
				const result = await this.$http.get(`api/app/cixingu`);
				if (!result) return null;
				console.log(result);
				this.list = result.map(v => {
					return {
						gid: v.gid,
						name: v.name,
						code: v.code,
						price: v.current_price * 1 || 0,
						rate: v.rate * 1 || 0,
						rateNum: v.rate_num * 1 || 0,
						totalRate: 0,
						online: v.shangshi_date || '',
						amount1: v.trans_amount / 10000 || 0,
						close: v.close * 1 || 0,
					}
				})
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getList();
				}, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>