<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_AH)" />

		<view class="right_in" style="padding:0 20px 60px 20px;">
			<view class="table">
				<view class="table_header">
					<view class="table_th" style="width: 40%;">名称/代码</view>
					<view class="table_th" style="width: 20%;text-align: center;">A 股</view>
					<view class="table_th" style="width: 20%;text-align: center;">H 股</view>
					<view class="table_th" style="width: 20%;text-align: right;">溢價</view>
				</view>

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(v,k) in list" :key="k">
						<view class="table_row">
							<view class="table_cell" style="width: 40%;">
								<view style="font-weight: 700;">{{v.name}}</view>
								<view :style="{color:$theme.BLACK_70}">{{v.codeA}}/{{v.codeH}}</view>
							</view>
							<view class="table_cell" style="width: 20%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rateA)}">
								<view>{{$fmt.amount(v.priceA)}}</view>
								<view>{{$fmt.percent(v.rateA)}}</view>
							</view>
							<view class="table_cell" style="width: 20%;text-align: center;"
								:style="{color:$theme.setRiseFall(v.rateH)}">
								<view>{{$fmt.amount(v.priceH)}}</view>
								<view>{{$fmt.percent(v.rateH)}}</view>
							</view>
							<view class="table_cell" style="width: 20%;text-align: right;"
								:style="{color:$theme.setRiseFall(v.premium)}">
								{{$fmt.percent(v.premium)}}
							</view>
						</view>
					</block>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				list: null,
				timer: null,
			}
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.getList();
			this.onSetTimeout();
			uni.stopPullDownRefresh();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getList();
				}, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			async getList() {
				uni.showLoading({ title: this.$msg.API_REQUEST_DATA });
				const result = await this.$http.get(`api/app/ah_compare`);
				if (!result) return false;
				console.log(result);
				// return result;
				this.list = result.map(v => {
					return {
						name: v.name,
						codeA: v.a_code,
						codeH: v.h_code,
						rateA: v.a_rate * 1 || 0,
						rateH: v.h_rate * 1 || 0,
						priceA: v.a_price * 1 || 0,
						priceH: v.h_price * 1 || 0,
						premium: v.yijia * 1 || 0,
					}
				})
			}
		}
	}
</script>

<style>
</style>