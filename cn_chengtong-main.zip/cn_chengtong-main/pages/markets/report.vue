<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<web-view src="https://finance.sina.cn/zt_d/2024bestanalyst?from=wap#j-part1"></web-view>

		<!-- <CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_REPORT)" />

		<view :class="curKey===$C.KEY_TAB_REPORT?`report_head`: `report_head_1`"> </view>

		<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 15px;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @click="changeTab(v.key)">
					<view style="padding-bottom: 12px;font-size: 20px;" :style="setStyle(curKey===v.key)">
						{{v.name}}
					</view>
					<view style="width: 28px;height: 3px; margin:0 auto; border-radius: 24px;"
						:style="{ backgroundColor:curKey===v.key?$theme.PRIMARY : $theme.TRANSPARENT }">
					</view>
				</view>
			</block>
		</view>

		<view :class="$theme.random(curIndex)+`_in`" style="padding:0 0 60px 0;">
			<template v-if="curKey===$C.KEY_TAB_REPORT">
				<ReportList :list="reports" />
			</template>

			<template v-if="curKey===$C.KEY_TAB_REPORTS">
				<view style="margin: 20px;">
					<view style="display: flex;align-items: center;justify-content: flex-end;padding-bottom: 12px;"
						:style="{color:$theme.BLACK_70}" @click="openPickerYear()">
						<view style="padding-right: 12px;">评选年份</view>
						<view style="padding:0 12px;"> {{curYear}} </view>
						<image src="/static/arrow_down.svg" mode="aspectFit" :style="$theme.setImageSize(8)"></image>
					</view>

					<view
						style="border:1px solid #FFCE62;border-radius: 16px 16px 0 0;display: flex;align-items: center;justify-content: space-between;">
						<view style="flex:1;text-align: center;padding:8px 16px;border-radius: 16px 0 0 0;"
							:style="setStyleTab(curTabKey === $C.KEY_REPORT_TAB_BEST)"
							@click="changeListTab($C.KEY_REPORT_TAB_BEST)">
							最佳分析师</view>
						<view
							style="border-left:1px solid #FFCE62;border-right:1px solid #FFCE62;flex:1;text-align: center;padding:8px 16px;"
							:style="setStyleTab(curTabKey === $C.KEY_REPORT_TAB_ELITE)"
							@click="changeListTab($C.KEY_REPORT_TAB_ELITE)">
							精英分析师</view>
						<view style="flex:1;text-align: center;padding:8px 16px;border-radius: 0 16px 0 0;"
							:style="setStyleTab(curTabKey === $C.KEY_REPORT_TAB_STAR)"
							@click="changeListTab($C.KEY_REPORT_TAB_STAR)">
							未来之星</view>
					</view>

					<template v-if="curTabKey===$C.KEY_REPORT_TAB_BEST ||curTabKey===$C.KEY_REPORT_TAB_ELITE">
						<view style="padding: 10px 0;font-weight: 700;width: 100%;">
							<view style="display:inline-block; width: 10%;">排行</view>
							<view style="display:inline-block;width: 25% ;">機構</view>
							<view style="display:inline-block;width: 65%;text-align: right;">姓名</view>
						</view>
						<view
							style="border-top: 0.5px solid #FFCE62;background-color: #F9F9F9;padding:10px 0 10px 10px;font-size: 12px;font-weight: 500;"
							:style="{color:$theme.PRIMARY}">
							宏观经济研究
						</view>

						<template v-if="!list || list.length<=0">
							<EmptyData></EmptyData>
						</template>
						<template v-else>
							<block v-for="(v,k) in list" :key="k">
								<view
									style="margin-bottom: 10px;width: 100%;padding: 8px 0;border-bottom: 0.5px solid #979797;">
									<view style="display:inline-block; width: 10%;vertical-align: top;">{{k+1}}</view>
									<view style="display:inline-block;width: 25%;vertical-align: top;">{{v.name}}</view>
									<view style="display:inline-block;width: 65%;">
										<block v-for="(sub,index) in v.persons" :key="index">
											<text style="width:54px;line-height: 2;display: inline-block;">{{sub}}
											</text>
										</block>
									</view>
								</view>
							</block>
						</template>
					</template>

					<template v-if="curTabKey===$C.KEY_REPORT_TAB_STAR">
						<view
							style="display: flex;align-items: center;justify-content: space-between; padding: 10px 0;font-weight: 700;border-bottom: 0.5px solid #FFCE62;">
							<view style="">機構</view>
							<view style="text-align: right;">姓名</view>
						</view>
						<template v-if="!list || list.length<=0">
							<EmptyData></EmptyData>
						</template>
						<template v-else>
							<block v-for="(v,k) in list" :key="k">
								<view
									style="margin-bottom: 10px;display: flex;align-items: center;justify-content: space-between; padding: 16px 0;border-bottom: 0.5px solid #979797;">
									<view style="font-weight: 700;">{{v.name}}</view>
									<view style="text-align: right;">{{v.persons}}</view>
								</view>
							</block>
						</template>
					</template>
				</view>
			</template>
		</view>

		<u-picker :show="showPickerYear" :columns="[years]" @change="chooseYear" @cancel="showPickerYear=false"
			@confirm="confirmYear" :cancelText="$t($msg.COMMON_CANCEL)" :confirmText="$t($msg.COMMON_CONFIRM)"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker> -->
	</view>
</template>

<script>
	// import * as ext from './ext.js';
	// import ReportList from './components/ReportList.vue';
	export default {
		// components: {
		// 	ReportList
		// },
		data() {
			return {
				isAnimat: false,
				// 		curKey: null,
				// 		tabs: ext.reportTabs(),
				// 		listTabs: ext.reportTabsList(),
				// 		reports: null,
				// 		curTabKey: null,
				// 		list: null,
				// 		curYear: '',
				// 		years: [`2015`, `2016`, `2017`, `2018`, `2019`, `2020`, `2021`, `2022`, `2023`, `2024`, `2025`],
				// 		showPickerYear: false,
			}
		},
		// computed: {
		// 	curIndex() {
		// 		const tem = this.tabs.findIndex(v => v.key === this.curKey)
		// 		return !tem || tem < 0 ? 0 : tem;
		// 	},
		// },
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			// 	this.curKey = this.curKey || this.tabs[0].key;
			// 	this.changeTab(this.curKey);
			// 	this.curTabKey = this.curTabKey || this.listTabs[0].key;
			// 	this.curYear = this.$fmt.setToYear();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			// this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		// methods: {
		// 	async changeTab(val) {
		// 		this.curKey = val;
		// 		if (this.curKey === this.$C.KEY_TAB_REPORT)
		// 			this.reports = await this.$http.getReport();
		// 		if (this.curKey === this.$C.KEY_TAB_REPORTS)
		// 			this.changeListTab(this.curTabKey);
		// 	},
		// 	async changeListTab(val) {
		// 		this.curTabKey = val;
		// 		if (this.curTabKey === this.$C.KEY_REPORT_TAB_BEST)
		// 			this.list = await this.$http.getReporeRanking(this.curYear);
		// 		if (this.curTabKey === this.$C.KEY_REPORT_TAB_ELITE)
		// 			this.list = await this.$http.getReporeRanking(this.curYear);
		// 		if (this.curTabKey === this.$C.KEY_REPORT_TAB_STAR)
		// 			this.list = await this.$http.getReportStar(this.curYear);
		// 	},

		// 	openPickerYear() {
		// 		this.showPickerYear = true;
		// 	},
		// 	chooseYear(e) {
		// 		console.log(e);
		// 	},
		// 	confirmYear(e) {
		// 		console.log(e);
		// 		this.curYear = e.value[0];
		// 		this.changeListTab(this.curTabKey);
		// 		this.showPickerYear = false;
		// 	},

		// 	setStyleTab(val) {
		// 		return {
		// 			backgroundColor: val ? `#FFCE62` : this.$theme.TRANSPARENT,
		// 			color: val ? `#FFF` : this.$theme.BLACK_70
		// 		}
		// 	},

		// 	setStyle(val) {
		// 		return {
		// 			color: val ? this.$theme.PRIMARY : this.$theme.BLACK_70,
		// 			fontWeight: val ? `700` : `500`
		// 		}
		// 	}
		// }
	}
</script>

<style>
</style>