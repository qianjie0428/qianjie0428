<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<web-view src="https://corvette.upchina.com/marketvane?channel=srup-v7"></web-view>
		<!-- <view class="trend_head" style="">
				<view style="flex: 1;font-size: 14px;font-weight: 700;">
					大盘当前 <text style="color:#FFAA0F;padding:0 8px;font-size: 16px;">風向暫無反轉信號</text> ,以上信息仅提供投资者参考，不构成
					具体投资建议，据此操作，风险自担。
				</view>
				<image src="/static/trend_right.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
			</view>

			<CommonTitle title="历史回测">
				<view :style="{color:$theme.BLACK_70}">2016/08/29~{{$fmt.today()}}</view>
			</CommonTitle>

			<template v-if="detail">
				<view
					style="margin:15px 20px;background-color: #FFFCF8;display: flex;align-items: center;justify-content: space-around;padding:16px 0;line-height: 1.6;text-align: center;"
					:style="{color:$theme.BLACK_70}">
					<view>
						<view>累计收益率</view>
						<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">{{$fmt.percent(detail.rate)}}
						</view>
					</view>
					<view>
						<view>年化收益率</view>
						<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
							{{$fmt.percent(detail.rate1)}}
						</view>
					</view>
				</view>

				<view
					style="margin:0 20px 20px 20px;display: flex;align-items: center;justify-content:space-between;line-height: 1.6;text-align: center;"
					:style="{color:$theme.BLACK_70}">
					<view>
						<view>最大回撤</view>
						<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
							{{$fmt.percent(detail.rate2)}}
						</view>
					</view>
					<view>
						<view>波动率</view>
						<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
							{{$fmt.percent(detail.rate3)}}
						</view>
					</view>
					<view>
						<view>夏普比率</view>
						<view style="font-weight: 700;" :style="{color:$theme.BASIC_DARK}">
							{{$fmt.percent(detail.rate4)}}
						</view>
					</view>
				</view>
			</template>

			<CommonTitle title="收益曲线">
				<view style="flex:1;display: flex;align-items: center;justify-content: flex-end;">
					<text style="border-radius: 100%;width: 4px;height: 4px;background-color: #0000FF;"></text>
					<text style="padding:0 16px 0 6px;">本策略</text>
					<text style="border-radius: 100%;width: 4px;height: 4px;"
						:style="{backgroundColor:$theme.BLACK_70}"></text>
					<text style="padding-left: 6px;">沪深300</text>
				</view>
			</CommonTitle>

			<view style="text-align: center;line-height: 5;">曲線圖</view>

			<view style="font-size: 11px;color: #666;padding:20px;">
				<view>回溯说明:
					本历史回测教据基于上证指教历史行情数据计算，根据上证指教历史上出现的风向可够转强或转弱信号，按指数点位进行模拟调仓操作，并计算回测累积收益幸等数据，注:在出现连续风向可够转强或转弱信号时，该回测教据仅选取最后出现的信号进行调仓提作，仅代表历史业绩，不代表未来业绩，不构成对未来的投资建议。
				</view>
				<view style="padding-top: 8px;">
					免责声明:以上信息由第三方提供，所有信息、数据均来源于上海证券交易所、深圳证券交易所等公开信息，公司力求但不保证信息的及时性、准确性和完整性。以上信息仅提供投资者参考，不构成具体没资这议，据此探作，风险自组!
				</view>
			</view> -->
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false,
				// detail: null,
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			// this.detail = await this.$http.getTrend();
		},
		onHide() {
			this.isAnimat = false;
		},
		async onPullDownRefresh() {
			// this.detail = await this.$http.getTrend();
			uni.stopPullDownRefresh();
		},
		methods: {}
	}
</script>

<style lang="scss" scoped>
	iframe {
		width: 600px !important;
		height: 100% !important;
	}

	::v-deep .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>