<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color:#FFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="$t($msg.MENU_PERFORMANCE)" />

		<view
			style="display: flex;align-items: center;justify-content: space-between;padding:14px 20px;background-color: #FFF;">
			<block v-for="(v,k) in tabs" :key="k">
				<view @click="changeTab(k)"
					:style="{color:curKey===k?$theme.BASIC_DARK :$theme.BLACK_30,fontWeight: curKey===k?`700`:`500` }">
					{{v}}
				</view>
			</block>
		</view>

		<view
			style="display: flex;align-items: center;justify-content: space-between;padding:14px 20px;background-color:#F3F4F6;"
			:style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
			<block v-for="(v,k) in markets" :key="k">
				<view @click="changeMarket(v.key)">
					<view style="padding-bottom: 4px;font-size: 12px;" :style="setStyle(curMarket===v.key)"> {{v.value}} </view>
					<view style="width: 20px;height: 3px; margin:0 auto; border-radius: 24px;"
						:style="{ backgroundColor:curMarket===v.key?$theme.PRIMARY : $theme.TRANSPARENT }">
					</view>
				</view>
			</block>
		</view>

		<view class="left_in" style="padding:0 0 48px 0;">
			<template v-if="curKey===$C.KEY_PER_TAB_HOME">
				<view class="flex_row_between" style="background-color: #FFF;padding:20px 14px 8px 14px;"
					:style="{color:$theme.BLACK_70}">
					<view style="padding-left: 6px;border-left: 3px solid #D7060F;font-weight: 700;">业绩预告</view>
					<view :style="{color:$theme.BLACK_30}" @tap="changeTab($C.KEY_PER_TAB_FCST)">...</view>
				</view>
			</template>

			<view style="display: flex;align-items: center;background-color: #FFF;padding:14px;font-size: 12px;">
				<template v-if="quarters && quarters.length>0">
					<view style="color:#000;">季度：</view>
					<view style="padding-right: 24px;" @tap="openQuarter()">
						<text style="padding-right: 6px;">{{!curQuarter?'':curQuarter.value}}</text>
						<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(8)">
						</image>
					</view>
				</template>
				<template v-if="types && types.length>0">
					<view style="color:#000;">类型：</view>
					<view @tap="openTypes()">
						<text style="padding-right: 6px;">{{!curType?'':curType.value}}</text>
						<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(8)">
						</image>
					</view>
				</template>
				<view style="margin-left: auto;">
					共 <text :style="{color:$theme.PRIMARY}">{{` ${!list||list.length<=0?0:list.length} `}}</text> 条
				</view>
			</view>

			<template v-if="curKey===$C.KEY_PER_TAB_HOME">
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<PERFcst :list="setFsct"></PERFcst>
					<view
						style="display: flex;align-items: center;justify-content: center;gap:2px;background-color: #FFF;padding-bottom: 10px;"
						@tap="changeTab($C.KEY_PER_TAB_FCST)">
						<view style="text-align: center;" :style="{color:$theme.BLACK_70}">查看更多</view>
						<image src="/static/arrow_right_line.svg" mode="scaleToFill" :style="$theme.setImageSize(8)"> </image>
					</view>
				</template>
			</template>

			<template v-if="curKey===$C.KEY_PER_TAB_HOME">
				<view style="background-color:#F3F4F6;height: 14px;"></view>
				<view class="flex_row_between" style="background-color: #FFF;padding:20px 14px;"
					:style="{color:$theme.BLACK_70}">
					<view style="padding-left: 6px;border-left: 3px solid #D7060F;font-weight: 700;">业绩快报</view>
					<view :style="{color:$theme.BLACK_30}" @tap="changeTab($C.KEY_PER_TAB_QR)">...</view>
				</view>
				<view style="display: flex;align-items: center;background-color: #FFF;padding:14px;font-size: 12px;">
					<template v-if="quarters && quarters.length>0">
						<view style="color:#000;">季度：</view>
						<view @tap="openQuarterQR()">
							<text style="padding-right: 6px;">{{!curQuarterQR?'':curQuarterQR.value}}</text>
							<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(8)">
							</image>
						</view>
					</template>
					<view style="margin-left: auto;">
						共 <text :style="{color:$theme.PRIMARY}">{{` ${!list1||list1.length<=0?0:list1.length} `}}</text> 条
					</view>
				</view>
				<template v-if="!list1 || list1.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<PERQR :list="setQR"></PERQR>
					<view
						style="display: flex;align-items: center;justify-content: center;gap:2px;background-color: #FFF;padding-bottom: 10px;"
						@tap="changeTab($C.KEY_PER_TAB_QR)">
						<view style="text-align: center;" :style="{color:$theme.BLACK_70}">查看更多</view>
						<image src="/static/arrow_right_line.svg" mode="scaleToFill" :style="$theme.setImageSize(8)"> </image>
					</view>
				</template>
			</template>

			<!-- <template v-if="curKey===$C.KEY_PER_TAB_FCST">
				<view style="background-color: #FFF9F9;padding:20px;margin-top: 10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;"
						:style="{color:$theme.BLACK_70}">
						<view style="padding-left: 6px;border-left: 3px solid #D7060F;font-weight: 700;">业绩走势</view>
						<view :style="{color:$theme.BLACK_30}">...</view>
					</view>
					<view>柱狀圖</view>
				</view>
			</template> -->

			<template v-if="curKey===$C.KEY_PER_TAB_FCST || curKey===$C.KEY_PER_TAB_QR ||curKey===$C.KEY_PER_TAB_PEND">
				<view style="background-color: #FAFCFF;min-height: 100vh;">
					<template v-if="!list || list.length<=0">
						<EmptyData></EmptyData>
					</template>
					<template v-else>
						<template v-if="curKey===$C.KEY_PER_TAB_FCST">
							<PERFcst :list="list" />
						</template>
						<template v-if="curKey===$C.KEY_PER_TAB_QR">
							<PERQR :list="list" />
						</template>
						<template v-if="curKey===$C.KEY_PER_TAB_PEND">
							<PERPend :list="list" />
						</template>
					</template>
				</view>
			</template>


			<!-- <template v-if="curKey===$C.KEY_PER_TAB_RELEASED">
				<view style="background-color: #FFF9F9;padding:20px;margin-top: 10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;"
						:style="{color:$theme.BLACK_70}">
						<view style="padding-left: 6px;border-left: 3px solid #D7060F;font-weight: 700;">业绩走势</view>
						<view :style="{color:$theme.BLACK_30}">...</view>
					</view>
					<view>柱狀圖</view>
				</view>
				<view style="background-color: #FFF;padding:0 20px;margin-top: 10px;">
					<view style="display: flex;align-items: center;padding-top: 13px;">
						<view style="padding-right: 12px;">
							<text style="padding-right: 6px;">全A</text>
							<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
							</image>
						</view>
						<view style="padding-right: 12px;">
							<text style="padding-right: 6px;">2024三季报</text>
							<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
							</image>
						</view>
						<view style="padding-right: 12px;">
							<text style="padding-right: 6px;">营业收入</text>
							<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
							</image>
						</view>
						<view>
							<text style="padding-right: 6px;">净利润</text>
							<image src="/static/arrow_down_line.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
							</image>
						</view>
						<view style="margin-left: auto;" :style="{color:$theme.PRIMARY}">共366条</view>
					</view>
				</view>

				<view
					style="background-color: #FAFCFF;display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
					<view>簡稱</view>
					<view style="text-align: center;">
						<view>营业收入</view>
						<view>同比</view>
					</view>
					<view style="text-align: center;">
						<view>歸母淨利潤</view>
						<view>同比</view>
					</view>
					<view>日期</view>
				</view>

				<view style="background-color: #FFF;padding:10px 20px;font-size: 12px;">
					<template v-if="!list || list.length<=0">
						<EmptyData></EmptyData>
					</template>
					<template v-else>
						<block v-for="(v,k) in list" :key="k">
							<view
								style="margin-bottom: 10px;display: flex;align-items: center;justify-content: space-between; padding: 6px 0;border-bottom: 0.5px solid #979797;">
								<view>
									<view style="font-weight: 700;font-size: 13px;">{{v.name}}</view>
									<view style="font-weight: 100;">{{v.code}}</view>
								</view>
								<view>
									<view>{{v.val}}</view>
									<view :style="{color:$theme.PRIMARY}">{{v.val1}}</view>
								</view>
								<view>
									<view>{{v.val}}</view>
									<view :style="{color:$theme.PRIMARY}">{{v.val1}}</view>
								</view>
								<view>{{v.dt}}</view>
							</view>
						</block>
					</template>
					<view style="text-align: center;" :style="{color:$theme.BLACK_30}">查看更多 <image
							src="/static/arrow_right_line.svg" mode="aspectFit" :style="$theme.setImageSize(6)"
							style="padding-left: 8px;">
						</image>
					</view>
				</view>
			</template> -->
		</view>

		<template v-if="showQuartersQR">
			<u-picker :show="showQuartersQR" :columns="[quarters]" @change="chooseQuarteQR" @cancel="showQuartersQR=false"
				@confirm="confirmQuarteQR" :cancelText="$msg.COMMON_CANCEL" :confirmText="$msg.COMMON_CONFIRM"
				:cancelColor="$theme.CANCEL" :confirmColor="$theme.PRIMARY" keyName="value" visibleItemCount="9"></u-picker>
		</template>

		<template v-if="showQuarters">
			<u-picker :show="showQuarters" :columns="[quarters]" @change="chooseQuarte" @cancel="showQuarters=false"
				@confirm="confirmQuarte" :cancelText="$msg.COMMON_CANCEL" :confirmText="$msg.COMMON_CONFIRM"
				:cancelColor="$theme.CANCEL" :confirmColor="$theme.PRIMARY" keyName="value" visibleItemCount="9"></u-picker>
		</template>

		<template v-if="showTypes">
			<u-picker :show="showTypes" :columns="[types]" @change="chooseType" @cancel="showTypes=false"
				@confirm="confirmType" :cancelText="$msg.COMMON_CANCEL" :confirmText="$msg.COMMON_CONFIRM"
				:cancelColor="$theme.CANCEL" :confirmColor="$theme.PRIMARY" keyName="value" visibleItemCount="9"></u-picker>
		</template>
	</view>
</template>

<script>
	import PERFcst from './components/PERFcst.vue';
	import PERQR from './components/PERQR.vue';
	import PERPend from './components/PERPend.vue';
	export default {
		components: { PERFcst, PERQR, PERPend },
		data() {
			return {
				isAnimat: false,
				curKey: null,
				tabs: {
					[this.$C.KEY_PER_TAB_HOME]: `首页`,
					[this.$C.KEY_PER_TAB_FCST]: `业绩预告`,
					[this.$C.KEY_PER_TAB_QR]: `业绩快报`,
					[this.$C.KEY_PER_TAB_PEND]: `待披露`,
				},
				list: null,

				// 首页 业绩快报
				list1: null,
				curQuarterQR: null,
				showQuartersQR: false,

				markets: [],
				curMarket: null,
				quarters: [],
				curQuarter: null,
				showQuarters: false,
				types: [],
				curType: null,
				showTypes: false,
			}
		},
		computed: {
			setFsct() {
				if (!this.list || this.list.length <= 0) return [];
				return this.list.length <= 6 ? this.list : this.list.slice(0, 6);
			},
			setQR() {
				if (!this.list1 || this.list1.length <= 0) return [];
				return this.list1.length <= 6 ? this.list1 : this.list1.slice(0, 6);
			}
		},
		async onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.curKey = this.curKey || Object.keys(this.tabs)[0];
			this.markets = await this.$http.getPERMarket();
			this.quarters = await this.$http.getPERQuarter();
			this.types = await this.$http.getPERType();

			if (this.markets.length > 0) {
				this.changeTab(this.curKey);
			}

		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.curKey = val;
				this.curMarket = null;
				this.changeMarket(this.curMarket);
			},

			async changeMarket(val) {
				console.log(val);
				this.curMarket = val;
				this.list = null;
				this.list1 = null;
				this.curQuarter = null;
				this.curType = null;
				this.curQuarterQR = null;

				if (this.markets.length > 0) this.curMarket = this.curMarket || this.markets[0].key;
				if (this.quarters.length > 0) this.curQuarter = this.quarters[0];
				if (this.types.length > 0) this.curType = this.types[0];

				this.getCurTabData();
			},
			// tab切换、选择器变动，皆调用该函数
			async getCurTabData() {
				if (this.curKey === this.$C.KEY_PER_TAB_HOME) {
					console.log(this.curMarket, this.markets[this.curMarket])
					if (this.quarters.length > 0) this.curQuarterQR = this.quarters[0];
					this.list = await this.$http.getPERList(`api/app/yj_yugao`, {
						market: this.markets[this.curMarket].key || '',
						jidu: this.curQuarter.key || '',
						type: this.curType.key || ''
					});
					this.list1 = await this.$http.getPERList(`api/app/yj_kuaibao`, {
						market: this.markets[this.curMarket].key || '',
						jidu: this.curQuarter.key || '',
						type: ''
					});
				} else {
					let temp = '';
					if (this.curKey === this.$C.KEY_PER_TAB_FCST) temp = `api/app/yj_yugao`;
					if (this.curKey === this.$C.KEY_PER_TAB_QR) temp = `api/app/yj_kuaibao`;
					if (this.curKey === this.$C.KEY_PER_TAB_PEND) temp = `api/app/yj_pilu`;
					this.list = await this.$http.getPERList(temp, {
						market: this.markets[this.curMarket].key || '',
						jidu: this.curQuarter.key || '',
						type: this.curType.key || ''
					});
				}
			},

			openQuarterQR() { this.showQuartersQR = true },
			chooseQuarteQR(e) { console.log(`chooseQuarteQR e:`, e); },
			confirmQuarteQR(e) {
				console.log(`confirmQuarteQR e:`, e);
				this.showQuartersQR = false;
				this.curQuarterQR = e.value[0];
				this.getCurTabData();
			},

			openQuarter() { this.showQuarters = true },
			chooseQuarte(e) { console.log(`chooseQuarte e:`, e); },
			confirmQuarte(e) {
				console.log(`confirmQuarte e:`, e);
				this.showQuarters = false;
				this.curQuarter = e.value[0];
				this.getCurTabData();
			},
			openTypes() { this.showTypes = true },
			chooseType(e) { console.log(`chooseType e:`, e); },
			confirmType(e) {
				console.log(`confirmType e:`, e);
				this.showTypes = false;
				this.curType = e.value[0];
				this.getCurTabData();
			},

			setStyle(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.BLACK_70,
					fontWeight: val ? `700` : `500`
				}
			}
		}
	}
</script>

<style>
</style>