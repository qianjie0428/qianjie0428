<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFF;min-height: 100vh;">
		<CommonHeader :layout="$C.HEADER_1" :title="setTitle" />
		<view class="right_in" style="padding:0 0 60px 0;">
			<!-- <CommonList :list="list" @action="linkTo" /> -->
			<USStockList :list="list" @action="linkTo" />
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isAnimat: false,
				curKey: null,
				list: null,
				tabs: {
					// 如果是相同api不通参数，则此处写不通的参数部分
					[this.$C.KEY_US_INDI]: `美股 指数`,
					[this.$C.KEY_FUTURE]: `期货`,

					[this.$C.KEY_INDI]: `指数`,
					[this.$C.KEY_MARKET_ALL]: `全市场`,
					[this.$C.KEY_HK]: `港股`,

					[this.$C.KEY_US_ETF]: `美股ETF`,

					[this.$C.KEY_US_PLATE]: `板块`,
					[this.$C.KEY_GEM]: `创业板`,
				},
				timer: null,
			}
		},
		computed: {
			setTitle() {
				return this.tabs[this.curKey];
			},
		},
		onLoad(opt) {
			this.curKey = opt.tag || this.curKey;
		},
		onShow() {
			this.$linkTo.isAuth();
			this.isAnimat = true;
			this.clearTimer();
			this.changeTab(this.curKey);
			console.log(this.tabs);
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			this.clearTimer();
		},
		onUnload() {
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.changeTab(this.curKey);
			uni.stopPullDownRefresh();
		},
		methods: {
			async changeTab(val) {
				this.clearTimer();
				console.log(`curKey`, this.curKey);
				this.curKey = val;
				this.getList();
				this.onSetTimeout();
			},
			async getList() {

				if (this.curKey === this.$C.KEY_US_INDI) this.list = await this.$http.getUSIndi();
				if (this.curKey === this.$C.KEY_FUTURE) this.list = await this.$http.getUSFuture();
			},

			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getList();
				}, 2000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			// 当前默认行为：携带数据id，跳转到stockDetail页面
			linkTo(val) {
				// 可根据curKey 对跳转行为做分别处理
				this.$linkTo.stockDetail(val);
			}
		}
	}
</script>

<style>
</style>