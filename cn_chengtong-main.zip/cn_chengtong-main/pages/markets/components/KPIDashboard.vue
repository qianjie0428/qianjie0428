<template>
	<view style="background-color: #FFFFFF;padding:15px 20px;">
		<view style="display: flex;align-items: center;justify-content: space-around;background-color: #FFF;">
			<view style="text-align: center;">
				<view>恒生</view>
				<view>{{$fmt.amount(31255.321)}}</view>
			</view>
			<canvas canvas-id="gauge" id="gauge" class="charts"></canvas>
			<view style="text-align: center;">
				<view>纳斯达克</view>
				<view>{{$fmt.amount(31255.321)}}</view>
			</view>
		</view>

		<view style="font-size: 11px;">恒生活跃买卖量</view>

		<Proportion :info="setInfo" />

		<view style="display: flex;align-items: center;line-height: 2.4;">
			<image src="/static/arrow_sell.png" mode="heightFix" style="height: 14px;"> </image>
			<text style="padding-left: 8px;" :style="{color:$theme.setRiseFall(-1)}">买入 {{$fmt.amount(info.buy)}}</text>
			<text style="padding-right: 8px;margin-left: auto;" :style="{color:$theme.setRiseFall(1)}">
				卖出 {{$fmt.amount(info.sell)}}
			</text>
			<image src="/static/arrow_buy.png" mode="heightFix" style="height: 14px;"> </image>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {
		gauge
	} from '@/common/uchartConf.js';
	export default {
		name: `KPIDashboard`,
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
				chart: null,
			}
		},
		computed: {
			setInfo() {
				return {
					left: this.info.buy,
					right: this.info.sell
				}
			},
			fmtData() {
				console.log(`fundFlowCurves:`, this.info);
				return {
					categories: [{
						"value": 0.25,
						"color": "#FF0000"
					}, {
						"value": 0.5,
						"color": "#FF6D00"
					}, {
						"value": 0.75,
						"color": "#FFE200"
					}, {
						"value": 1,
						"color": "#7AFF63"
					}],
					series: [{
						"name": "",
						"data": 74
					}]
				}

			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(200);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(160);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			genCharts() {
				const ctx = uni.createCanvasContext("gauge", this);
				this.chart = new uCharts(gauge(ctx,
					this.fmtData,
					this.cWidth,
					this.cHeight))
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		width: 200upx;
		height: 160upx;
	}
</style>