<template>
	<view class="table" style="background-color: #FFF;padding: 0 20px;">
		<view class="table_header">
			<view class="table_th" style="width: 24%;">名称/代码</view>
			<view class="table_th" style="width: 25%;">最新价</view>
			<view class="table_th" style="width: 20%">涨幅</view>
			<view class="table_th" style="margin-left: auto;">所属行业</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row" @click="linkTo(v)">
					<view class="table_cell" style="width: 24%;">
						<view style="font-weight: 700;">{{v.name}}</view>
						<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
					</view>
					<view class="table_cell" style="width: 25%;"> {{$fmt.amount(v.price,v.lgre)}} </view>
					<view class="table_cell" style="width: 20%;" :style="{color:$theme.setRiseFall(v.rate)}">
						{{$fmt.percent(v.rate)}}
					</view>
					<view class="table_cell" style="margin-left: auto;">{{v.industry}} </view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "HSList",
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			linkTo(val) {
				console.log(val);
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>