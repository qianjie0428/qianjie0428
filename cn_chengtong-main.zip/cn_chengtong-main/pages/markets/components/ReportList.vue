<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view style="padding: 12px 20px;margin-bottom: 10px;background-color: #FAFCFF;">
					<view style="	display: flex;	align-items: stretch;" @click="$linkTo.openNews(v.url)">
						<image :src="v.pic" mode="scaleToFill" :style="$theme.setImageSize(60)"
							style="border-radius: 6px;">
						</image>
						<view
							style="flex:1;padding-left: 12px;display: flex;flex-direction: column;justify-content: space-between;">
							<view><text>{{v.title}}</text> </view>
							<view style="flex:0 0 auto;display: flex;justify-content: space-between;font-size: 11px;"
								:style="{color:$theme.BLACK_30}">
								<view>{{v.origin}}</view>
								<view>{{v.dt}}</view>
							</view>
						</view>
					</view>
					<view style="padding-top: 12px;">
						<image src="/static/persons.svg" mode="aspectFit" :style="$theme.setImageSize(16)">
						</image> <text style="padding-left: 12px;">{{v.persons}}</text>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "ReportList",
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style>
</style>