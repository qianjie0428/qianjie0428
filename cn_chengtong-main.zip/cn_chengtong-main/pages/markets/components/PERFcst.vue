<template>
	<view style="background-color: #FAFCFF;">
		<view style="display: flex;align-items: center;padding:10px 14px;">
			<view style="width: 24%;">简称</view>
			<view style="width: 26%;">类型</view>
			<view style="text-align: center;width: 30%;">
				<view>归母淨利潤</view>
				<view>同比</view>
			</view>
			<view style="width: 20%;text-align: right;">日期</view>
		</view>
		<view>
			<block v-for="(v,k) in list" :key="k">
				<view
					style="margin-bottom: 10px;display: flex;align-items: center;padding: 6px 14px;border-bottom: 0.5px solid #979797;">
					<view style="width: 24%;">
						<view style="font-weight: 700;font-size: 13px;">{{v.name}}</view>
						<view style="font-weight: 100;">{{v.code}}</view>
					</view>
					<view style="width: 26%;">{{v.type}}
						<image src="/static/info.svg" mode="aspectFit" :style="$theme.setImageSize(12)">
						</image>
					</view>
					<view style="width: 30%;">
						<view>{{v.val}}</view>
						<view :style="{color:$theme.setRiseFall(v.rateLow)}">
							{{`${$fmt.percent(v.rateLow)}~${$fmt.percent(v.rateUp)}`}}
						</view>
					</view>
					<view style="width: 20%;text-align: right;">{{v.dt}}</view>
				</view>
			</block>
		</view>
		<!-- <view style="text-align: center;" :style="{color:$theme.BLACK_30}">查看更多 <image src="/static/arrow_right_line.svg"
				mode="aspectFit" :style="$theme.setImageSize(6)" style="padding-left: 8px;">
			</image>
		</view> -->
	</view>
</template>

<script>
	export default {
		name: "PERFcst",
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style>
</style>