<template>
	<view style="background-color: #FFFFFF;padding:15px 20px;">
		<view class="container" style="padding-bottom: 0;">
			<block v-for="(v,k) in fmtData" :key="k">
				<view class="bar" :style="{ height: getBarHeight(v) + '%', backgroundColor: getBarColor(k) }">
					<view style="margin-top:-20px;text-align: center;font-size: 11px;" :style="{color:getBarColor(k)}">
						{{v}}
					</view>
				</view>
			</block>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;gap:8px;padding:0 4px;">
			<block v-for="(v,k) in fmtData" :key="k">
				<template v-if="k==0">
					<image src="/static/arrow_up.svg" mode="aspectFit" :style="$theme.setImageSize(18)"></image>
				</template>
				<template v-if="k==fmtData.length-1">
					<image src="/static/arrow_down_fall.svg" mode="aspectFit" :style="$theme.setImageSize(18)"></image>
				</template>
			</block>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
			<view :style="{color:$theme.RISE}">上涨{{$fmt.numer(info.rise)}}支</view>
			<view :style="{color:$theme.FALL}">下跌{{$fmt.numer(info.fall)}}支</view>
		</view>

		<Proportion :info="setInfo" />

		<template v-if="show">
			<view style="display: flex;align-items: center;justify-content: space-between;gap:12px;padding-top: 12px;">
				<view
					style="flex:1;background-color: #F6F6F6;border-radius: 4px;padding:12px;display: flex;align-items:center;justify-content: space-between;">
					<view>
						<view>今日收益率</view>
						<view>
							<text :style="{color:$theme.RISE}">{{$fmt.percent(info.todayPLRate)}}</text>
							<text :style="{color:$theme.FALL}">{{$fmt.percent(info.todayLossRate)}}</text>
						</view>
					</view>
					<view>
						<view>
							<image src="/static/line_fall.png" mode="heightFix" style="height: 16px;">
							</image>
						</view>
						<view>
							<image src="/static/line_rise.png" mode="heightFix" style="height: 16px;">
							</image>
						</view>
					</view>
				</view>
				<view style="flex:1;background-color: #F6F6F6;border-radius: 4px;padding:12px;">
					<view style="display: flex;align-items:center;justify-content: space-between;">
						<view>今日交易额</view>
						<view>{{$fmt.amount(info.todayTrade)}}亿</view>
					</view>
					<view style="display: flex;align-items:center;justify-content: space-between;">
						<view>今日收益</view>
						<view :style="{color:$theme.setRiseFall(info.todayPL)}">{{$fmt.amount(info.todayPL)}}</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: `PMD`,
		props: {
			info: {
				type: Object,
				default: {}
			},
			list: {
				type: Array,
				default: []
			},
			show: {
				type: Boolean,
				default: false,
			}
		},
		computed: {
			maxValue() {
				return Math.max(...this.fmtData) + 10; // 找到最大值并加10
			},
			fmtData() {
				console.log(`pmdCol:`, this.list);
				return [1000, 3000, 5000, 7000, 9000, 50, 1300, 1100, 1700, 1500, 1900]
			},
			setInfo() {
				return {
					left: this.info.rise,
					right: this.info.fall
				}
			}
		},
		created() {},
		mounted() {},
		methods: {
			getBarHeight(value) {
				return ((value / this.maxValue) * 100).toFixed(2); // 计算高度百分比
			},
			getBarColor(k) {
				// 可根据需要改变颜色
				return k < 5 ? this.$theme.RISE : k > 5 ? this.$theme.FALL : this.$theme.FLAT;
			},
		}
	}
</script>
<style lang="scss" scoped>
	.container {
		display: flex;
		align-items: flex-end;
		justify-content: space-between;
		height: 100px;
		gap: 6px;
		padding: 10px 0;
		background-color: #fff;
	}

	.bar {
		flex: 1;
		animation: grow 0.1s ease-in;
		color: #fff;
		background-color: #fff;
	}

	@keyframes grow {
		from {
			height: 0%;
		}

		to {
			height: inherit;
		}
	}
</style>