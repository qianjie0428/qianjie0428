<template>
	<view style="background-color: #FAFCFF;">
		<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 14px;">
			<view style="width: 30%;">简称</view>
			<view style="text-align: center;width: 30%;">预约披露日期</view>
			<view style="width: 40%;text-align: right;">预约披露类型</view>
		</view>
		<view>
			<block v-for="(v,k) in list" :key="k">
				<view
					style="margin-bottom: 10px;display: flex;align-items: center;justify-content: space-between; padding: 6px 14px;border-bottom: 0.5px solid #979797;">
					<view style="width: 30%;">
						<view style="font-weight: 700;font-size: 13px;">{{v.name}}</view>
						<view style="font-weight: 100;">{{v.code}}</view>
					</view>
					<view style="width: 30%;">{{v.subDT}}</view>
					<view style="width: 40%;text-align: right;">{{v.market}}</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: "PERPend",
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style>
</style>