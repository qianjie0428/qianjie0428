<template>
</template>

<script>
	export default {
		name: "HSAllList",
	}
</script>

<style>
</style>