<template>
	<view style="padding:15px 20px;background-color: #FFF;">
		<view style="padding-bottom: 15px;width: 100%;" :style="{borderBottom:`0.5px solid ${$theme.BLACK_30}`}">
			<view style="display: inline-block;width: 20%;">类别</view>
			<view style="display: inline-block;width: 25%;text-align: center;">净流入</view>
			<view style="display: inline-block;width: 30%;text-align: center;">流入</view>
			<view style="display: inline-block;width: 25%;text-align: right;">流出</view>
		</view>
		<block v-for="(v,k) in list" :key="k">
			<view style="width: 100%;padding-top: 8px;font-size: 12px;">
				<view style="display: inline-block;width: 20%;">
					<view style="width: 10px;height: 10px;display: inline-block;" :style="{backgroundColor:v.color}">
					</view>
					<text style="padding-left: 6px;">{{v.name}}</text>
				</view>
				<view style="display: inline-block;width: 25%;text-align: center;"
					:style="{color:$theme.setRiseFall(v.amount)}">{{$fmt.amount(v.amount)}}亿</view>
				<view style="display: inline-block;width: 30%;text-align: center;">
					{{$fmt.amount(v.amount1)}}亿
				</view>
				<view style="display: inline-block;width: 25%;text-align: right;">
					{{$fmt.amount(v.amount2)}}亿
				</view>
			</view>
		</block>
		<view style="font-size: 10px;padding-top: 12px;">特此说明你：本功能仅提供客观数据统计结果，不构成任何投资建议。</view>
	</view>
</template>

<script>
	export default {
		name: `FundFlow`,
		props: {
			list: {
				type: Array,
				default: []
			}
		}
	}
</script>

<style>
</style>