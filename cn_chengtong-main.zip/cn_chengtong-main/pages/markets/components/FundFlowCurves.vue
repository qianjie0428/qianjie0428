<template>
	<view style="display: flex;align-items: center;justify-content: center;background-color: #FFF;">
		<canvas canvas-id="fundFlowCurves" id="fundFlowCurves" class="charts"></canvas>
	</view>
</template>

<script>
	import * as mock from '@/common/mock.js';
	import uCharts from '@/common/u-charts.js';
	import {
		curvesLR
	} from '@/common/uchartConf.js';
	export default {
		name: 'FundFlowCurves',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
				chart: null,
			}
		},
		computed: {
			fmtData() {
				console.log(`fundFlowCurves:`, this.list);
				const tempCategories = [`05:00`, `09:00`, `13:00`, `15:00`, `17:00`];
				let tempA = [];
				let tempB = [];
				let tempC = [];
				let tempD = [];

				this.list.forEach((v, k) => {
					tempA = mock.getFundFlowCurves(v.amount1);
					tempB = mock.getFundFlowCurves(v.amount1);
					tempC = mock.getFundFlowCurves(v.amount1);
					tempD = mock.getFundFlowCurves(v.amount1);
				})

				return {
					categories: tempCategories,
					series: [{
						name: 'tempA',
						data: tempA,
						color: this.list[0].color,
						pointShape: 'diamond',
						index: 1
					}, {
						name: 'tempB',
						data: tempB,
						pointShape: 'circle',
						color: this.list[1].color,
						index: 0
					}, {
						name: 'tempC',
						data: tempC,
						pointShape: 'circle',
						color: this.list[2].color,
						index: 0
					}, {
						name: 'tempD',
						data: tempD,
						pointShape: 'circle',
						color: this.list[3].color,
						index: 0
					}],
				}

				// //  "year": 2023, "month": 11, "total_dayshouyi": 1017090
				// const temp = this.list.map(item => {
				// 	return {
				// 		timestamp: new Date(`${item.year}/${item.month}`).getTime(),
				// 		value: item.total_dayshouyi
				// 	}
				// });
				// // console.log(temp);
				// const tempSort = temp.sort((a, b) => a.timestamp - b.timestamp);

				// let tempCategories = []; // 存储时轴
				// // let tempSeries = []; // 存储数据
				// let series1 = [];
				// let series2 = [];
				// // 决定时轴显示及空字符间隙
				// const divisor = parseInt(temp.length / 10);

				// tempSort.forEach((item, index) => {
				// 	// if (divisor > 0) {
				// 	// 	if (index % divisor === 0) {
				// 	// 		tempCategories.push(item.timestamp);
				// 	// 		tempSeries.push(item.value);
				// 	// 	}
				// 	// } else {
				// 	tempCategories.push(this.$util.formatMonth(item.timestamp));
				// 	series1.push(item.value > 0 ? item.value : 0);
				// 	series2.push(item.value < 0 ? item.value : 0);
				// 	// }
				// })
				// return {
				// 	categories: tempCategories,
				// 	series: [{
				// 		name: 'Profit',
				// 		data: series1,
				// 		color: this.$theme.RISE
				// 	}, {
				// 		name: 'Loss',
				// 		data: series2,
				// 		color: this.$theme.FALL
				// 	}],
				// }
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			this.genCharts();
		},
		methods: {
			genCharts() {
				const ctx = uni.createCanvasContext("fundFlowCurves", this);
				this.chart = new uCharts(curvesLR(ctx,
					this.fmtData,
					this.cWidth,
					this.cHeight))
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>