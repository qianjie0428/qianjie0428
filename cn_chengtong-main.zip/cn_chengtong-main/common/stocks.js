export const stocks = [{
		name: '中国工商银行',
		code: '1398'
	}, {
		name: '阿里巴巴',
		code: '9988'
	},
	{
		name: '腾讯控股',
		code: '0700'
	},
	{
		name: '百度',
		code: 'BIDU'
	},
	{
		name: '京东商城',
		code: '9618'
	},
	{
		name: '拼多多',
		code: 'PDD'
	},
	{
		name: '中国移动',
		code: '0941'
	},
	{
		name: '中国石化',
		code: '0386'
	},
	{
		name: '中国建设银行',
		code: '0939'
	},
	{
		name: '华能国际电力',
		code: '0902'
	},
	{
		name: '中国人民保险',
		code: '1339'
	},
	{
		name: '中国中铁',
		code: '601390'
	},
	{
		name: '中国石油',
		code: '601857'
	},
	{
		name: '中国平安',
		code: '601318'
	},
	{
		name: '中国银行',
		code: '601988'
	},
	{
		name: '中国联通',
		code: '600050'
	},
	{
		name: '格力电器',
		code: '000651'
	},
	{
		name: '海通证券',
		code: '600837'
	},
	{
		name: '招商银行',
		code: '600036'
	},
	{
		name: '第一创业',
		code: '300001'
	},
	{
		name: '南方航空',
		code: '600029'
	},
	{
		name: '中信建投',
		code: '601066'
	},
	{
		name: '华仪电气',
		code: '600290'
	},
	{
		name: '大胜股份',
		code: '603010'
	},
	{
		name: '达华智能',
		code: '002512'
	},
	{
		name: '太极集团',
		code: '600129'
	},
	{
		name: '四川长虹',
		code: '600839'
	},
	{
		name: '特锐德',
		code: '300001'
	},
	{
		name: '东吴证券',
		code: '601555'
	}
];