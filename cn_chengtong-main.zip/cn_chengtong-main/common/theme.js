import {
	KEY_LEFT,
	KEY_RIGHT
} from '@/common/constants.js';
import {
	isOdd
} from '@/common/util.js';

// 基础色值对象
export const TRANSPARENT = `var(--transparent)`;
export const PRIMARY = `var(--primary)`;
export const SECOND = `var(--second)`;
export const PRIMARY_TXT = `var(--primary_txt)`;
export const SUCCESS = `var(--success)`;
export const ERROR = `var(--error)`;
export const WARN = `var(--warn)`;
export const INFO = `var(--info)`;
export const PRIMARY_RGBA = `var(--primary-rgba)`;
export const SUCCESS_RGBA = `var(--success-rgba)`;
export const ERROR_RGBA = `var(--error-rgba)`;
export const WARN_RGBA = `var(--warn-rgba)`;
export const INFO_RGBA = `var(--info-rgba)`;
export const WHITE = `var(--white)`;
export const CANCEL = `var(--cancel)`;
export const BLACK_10 = `var(--black-10)`;
export const BLACK_30 = `var(--black-30)`;
export const BLACK_70 = `var(--black-70)`;
export const WHITE_30 = `var(--white-30)`;
export const WHITE_50 = `var(--white-50)`;
export const WHITE_80 = `var(--white-80)`;


// export const PRIMARY_C = `#D7060F`;

// // checkbox 边框及勾选
// export const CHECKBOX_COLOR_ACTIVE = PRIMARY;
// export const CHECKBOX_LABEL_COLOR = '#1f212d'; // checkbox 文字
// export const TRANSPARENT = 'transparent'; // 使用父级元素颜色
// export const BASIC_LIGHT = `#F8F8F8`;

// export const BTN_UNLOCK = `#FFFFFF`;
// export const BTN_LOCK = `#CCC`;


export const fundsStatus = [PRIMARY_RGBA, SUCCESS_RGBA, ERROR_RGBA, ERROR_RGBA];
export const fundsStatusLabel = [PRIMARY, SUCCESS, ERROR, ERROR];

export const statusBG = [PRIMARY_RGBA, SUCCESS_RGBA, ERROR_RGBA, ERROR_RGBA];
export const statusLabel = [PRIMARY, SUCCESS, ERROR, ERROR];

export const statusIPO = [INFO, PRIMARY, SUCCESS];

export const statusStyle = (arr, val = 0) => {
	return arr[val]
}

/**
 * @function 涨跌值样式设置
 * @param {number} num 数值
 * @description 所有涨幅通用。[-1跌,0平,1涨]
 * @example
 */
export const setRiseFall = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	return [SUCCESS, INFO, ERROR][index + 1]
};

export const setRiseFallRGBA = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	return [SUCCESS_RGBA, TRANSPARENT, ERROR_RGBA][index + 1]
};

export const setRiseFallImg = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	return [`line_fall_g`, `line_flat`, `line_rise_r`][index + 1];
}

export const setDuration = (num) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const index = num == Infinity ? 0 : num < 500 ? -1 : 1;
	return [SUCCESS, INFO, ERROR][index + 1]
};

export const setTabStyle = (val) => {
	return {
		color: val ? PRIMARY : BLACK_70,
		fontWeight: val ? `700` : `500`,
		borderBottom: `3px solid ${val?PRIMARY:TRANSPARENT}`,

	}
}

// 渐变设置
export const linerGradient = (deg, from, to) => {
	return `linear-gradient(${deg}deg, ${from} ,${to})`
};

// 计算设计图上带有透明度的值输出为RGBA
export const convertRGBA = (hex, opacity) => {
	// console.log(hex);
	// const r = parseInt(hex.slice(1, 3), 16);
	// const g = parseInt(hex.slice(3, 5), 16);
	// const b = parseInt(hex.slice(5, 7), 16);
	// const a = opacity / 100;
	// return `rgba(${r},${g},${b},${a})`;
};



// 按钮或card元素的边框。
export const BASIC_BORDER = `#EAECEF`;

export const random = (val) => {
	return isOdd(val) ? KEY_LEFT : KEY_RIGHT;
}

// 设置按钮状态，避免重复点击
export const btnStatus = (val, bg) => {
	return {
		cursor: val ? 'not-allowed' : 'pointer',
		// Disabled color
		color: val ? BTN_LOCK : BTN_UNLOCK,
		backgroundColor: val ? convertRGBA(bg, 70) : bg
	};
}

// 设置图片尺寸（自定义size）
export const setImageSize = (w = 24, h = 0) => {
	const _h = h > 0 ? h : w;
	return {
		width: `${w}px`,
		// 若为设置h值，则视为高=宽
		height: `${_h}px`,
	};
};

// 设置页面背景,返回style对象，动态替换页面背景图
export const setBGCover = (url) => {
	return {
		backgroundImage: `url(/static/${url}.png)`,
		backgroundRepeat: 'no-repeat',
		backgroundPosition: '0 0',
		backgroundSize: 'cover',
		width: '100%',
		minHeight: '100vh',
		padding: 0,
		margin: 0,
	}
};

// 设置input输入框， 背景及边框根据主题切换
export const setInputStyle = (val) => {
	return {
		backgroundColor: INPUT_BG,
		border: `1px solid ${INPUT_BORDER }`
	}
};

// 设置input的placeholder样式
export const setPlaceholder = (color = '', fontsize = '') => {
	return `color:${color == '' ?TXT_UNACT : color};font-size:${fontsize==''?12:fontsize}px;font-weight:300;`;
};

// /**
//  * @function 涨跌值样式设置
//  * @param {number} num 数值
//  * @param {string} isbg 是否需要背景
//  * @description 所有涨幅通用。[-1跌,0平,1涨]
//  * @example
//  * $theme.setRiseFall(0.111)
//  * $theme.setRiseFall(-1.111,true)
//  */
// export const setRiseFall = (num) => {
// 	// 检查传入值的合法性
// 	num = !num || isNaN(num) ? 0 : Number(num);
// 	const temp = [FALL, FLAT, RISE];
// 	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
// 	return temp[index + 1]
// };

export const setStyleTab = (val) => {
	return {
		color: val ? `#FFF` : BLACK_70,
		backgroundColor: val ? PRIMARY : `#F4F4F4`,
	}
}


// 定义颜色数组
export const colors = [
	PRIMARY,
	'#0ECB81',
	'#FF5722',
	'#3F51B5',
	'#9C27B0',
	'#FFC107',
	'#4CAF50',
	'#E91E63',
	'#FF9600',
	'#935EBD',
	'#2196F3',
	'#E11D74',
	'#01C5C4',
];

// 随机一个颜色值作为无LOGO时的背景底色
export const randomBGColor = () => {
	// 随机选择一个颜色
	const randomIndex = Math.floor(Math.random() * colors.length);
	return convertRGBA(colors[randomIndex], 80)
}

// 状态的颜色值
export const colorStatus = [
	`#FF9000`,
	`#42BF86`,
	`#42BF86`,
	`#F20105`,
];

export const flowStatus = [
	`#FF9000`,
	`#42BF86`,
	`#F20105`,
	`#F20105`,
]

export const ipoStatus = [
	`#FF9000`,
	`#42BF86`,
	`#F20105`,
]