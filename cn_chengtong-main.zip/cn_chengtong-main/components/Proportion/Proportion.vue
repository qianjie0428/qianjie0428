<template>
	<view style="display: flex;align-items: center;height: 4px;width: 100%;border-radius: 4px;margin-top: 6px;">
		<view style="height: 4px;" :style="{ width: leftBarWidth,
	backgroundImage: `linear-gradient(125deg, ${$theme.RISE} 50%, ${$theme.RISE} 97%, rgb(255,255,255) 90%)` }">
		</view>
		<view style="width: 4px;"></view>
		<view style="height: 4px;" :style="{ width: rightBarWidth,
	backgroundImage: `linear-gradient(-45deg, ${$theme.FALL} 50%, ${$theme.FALL} 95%, rgb(255,255,255) 90%)`  }">
		</view>
	</view>
</template>

<script>
	export default {
		name: "Proportion",
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		computed: {
			total() {
				return [this.info.left, this.info.right].reduce((a, b) => a + b, 0);
			},
			leftBarWidth() {
				return `${(this.info.left / this.total) * 100}%`; // 计算左边元素的宽度占比
			},
			rightBarWidth() {
				return `${(this.info.right / this.total) * 100}%`; // 计算右边元素的宽度占比
			}
		}
	}
</script>

<style>

</style>