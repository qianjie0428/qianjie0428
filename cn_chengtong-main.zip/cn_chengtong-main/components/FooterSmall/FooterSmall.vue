<template>
	<footer class="footer">
		<view class="tabbar">
			<block v-for="(v,k) in navs" :key="k">
				<!-- <template v-if="k==2">
					<view class="tab special">
						<view :style="setStyleNav(curActive ==v.key)" @click="v.action">
							<image mode="aspectFit" :src="`/static/tabbar_${k}.png`" :style="$theme.setImageSize(48)">
							</image>
						</view>
					</view>
				</template>
				<template v-else> -->
				<view class="tab ">
					<view :style="setStyleNav(curActive ==v.key)" @click="v.action">
						<image mode="aspectFit" :src="`/static/footer/${k+(curActive ==v.key?`_act`:``)}.png`"
							:style="$theme.setImageSize(18)"></image>
					</view>
				</view>
				<!-- </template> -->
			</block>
		</view>
		<view class="tabbar_label">
			<block v-for="(v,k) in navs" :key="k"> 
				<view style="font-size: 12.48px;flex:1;text-align: center;"
					:style="{color: curActive ==v.key ? $theme.PRIMARY : '#838b9c'}"  @click="v.action">
					{{ v.name}}
				</view>
			</block>
		</view>
	</footer>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		name: "FooterSmall",
		props: {
			actKey: {
				type: String,
				default: 'home'
			}
		},
		data() {
			return {
				curActive: 0,
				navs: ext.navs(),
			};
		},
		computed: {},

		beforeMount() {
			this.curActive = this.actKey;
			// // 根据url，找到包含当前url在数组的下标。 
			// const curURL = this.$route.fullPath.slice(7).split('/');
			// const temp = this.navs.findIndex(item => item.url.split('/')[0] == curURL[0]);
			// this.curActive = temp;
		},
		methods: {
			// // 跳转到 指定页面
			// linkTo(val) {
			// 	console.log(`val111:`, val);
			// 	uni.navigateTo({
			// 		url: this.$linkTo.PAGES + val,
			// 	})
			// },

			// // footer 主题样式
			// setStyle() {
			// 	return {
			// 		position: 'fixed',
			// 		bottom: 0,
			// 		left: 0,
			// 		right: 0,
			// 		padding: `8px 0`,
			// 		backgroundColor: `#FFFFFF`,
			// 		box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1),
			// 		zIndex: 9,
			// 	}
			// },
			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? '#546bff' : '#838b9c',
					textAlign: `center`,
				}
			}
		}
	}
</script>

<style>

</style>