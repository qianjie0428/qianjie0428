import * as linkTo from '@/common/linkTo.js';
import * as util from '@/common/util.js';
import * as constants from '@/common/constants.js';
import {
	translate
} from '@/localize/index.js';
import {
	Msg,
} from '@/localize/index.js';

export const navs = () => {
	return [{
		key: constants.KEY_HOME,
		name: translate(Msg.MENU_HOME),
		action: linkTo.home,
	}, {
		key: constants.KEY_MARKET,
		name: translate(Msg.MENU_MARKET),
		action: linkTo.markets,
	}, {
		key: constants.KEY_TRADE,
		name: translate(Msg.MENU_TRADE),
		action: linkTo.trade,
	}, {
		key: constants.KEY_POSITION,
		name: translate(Msg.MENU_POSITION),
		action: linkTo.position,
	}, {
		key: constants.KEY_ACCOUNT,
		name: translate(Msg.MENU_MINE),
		action: linkTo.settings,
	}]
}