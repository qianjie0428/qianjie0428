<template>
	<view class="card_item" @click="linkTo(detail)">
		<header class="card_item_header ellipsis" :style="{backgroundColor:$theme.setRiseFall(detail.rate)}">
			{{detail.name}}
		</header>

		<template v-if="detail.price!=null">
			<view style="text-align: center;padding-top: 10px;font-weight: 700;font-size: 13px;"
				:style="{color:$theme.setRiseFall(detail.rate)}">
				{{$fmt.amount(detail.price,detail.lgre)}}
			</view>
		</template>
		<template v-if="detail.subTitle">
			<view style="text-align: center;padding-top: 10px;" :style="{color:$theme.BLACK_70}">
				{{detail.subTitle}}{{$fmt.percent(detail.rate)}}
			</view>
		</template>

		<template v-if="detail.rateNum!=null">
			<view class="card_item_rate" :style="{color:$theme.setRiseFall(detail.rate)}">
				<view>{{$fmt.amount(detail.rateNum,detail.lgre)}}</view>
				<view>{{$fmt.percent(detail.rate)}}</view>
			</view>
		</template>

		<template v-if="detail.tip">
			<view style="text-align: center;padding-top: 10px;" :style="{color:$theme.BLACK_70}">
				{{detail.tip}}
			</view>
		</template>
		<template v-if="detail.line">
			<view style="text-align: center;">
				<image :src="`/static/${$theme.setRiseFallImg(detail.rate)}.png`" mode="scaleToFill"
					:style="$theme.setImageSize(96,40)">
				</image>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CardItem",
		props: {
			detail: {
				type: Object,
				default: {}
			}
		},
		methods: {
			linkTo(val) {
				this.$emit(`action`, val);
			}
		}
	}
</script>

<style>

</style>