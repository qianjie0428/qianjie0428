<template>
	<header :class="layout===$C.HEADER_1?`common_head`:``" :style="{paddingTop:layout!==$C.HEADER_1?`24px`:`10px`}">
		<template v-if="layout===$C.HEADER_1">
			<image src="/static/back.svg" mode="aspectFit" :style="$theme.setImageSize(16)" class="btn_back"
				@click="$util.goBack()"></image>
			<view class="dynamic_title" :class="`slide_in_${dir}`">{{title}}</view>
			<template v-if="msg">
				<view class="btn_notify" @click="$linkTo.notify()">
					<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(20)"></image>
				</view>
			</template>
			<slot></slot>
		</template>

		<template v-if="layout===$C.HEADER_2 || layout===$C.HEADER_3">
			<image :src="avatar==''?`/static/logo1.png`: avatar" mode=""
				class="btn_menu" style="border-radius:50px ;width: 45px;height: 45px;" @click="$linkTo.settings()"></image>
		</template>

		<template v-if="layout===$C.HEADER_2">
			<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(24)" class="btn_notify"
				style="padding-left: 12px;" @click="$linkTo.notify()"></image>
			<view class="dynamic_data" style="padding-left: 12px;" :class="`slide_in_${dir}`">
				<view style="border-radius: 12px;line-height: 2;width: max-content;margin-left: auto;"
					:style="{backgroundColor:$theme.WHITE_50}">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-left:9px;">
						<view style="padding-right:9px;">{{$fmt.amount(total,$util.isUS())}}</view>
						<view style="border-radius: 12px;padding:0 9px;min-width: 80px;background-color: aliceblue;"
							:style="{color:$theme.setRiseFall(hold)}">
							{{$fmt.amount(hold,$util.isUS())}}
							<!-- <image :src="`/static/fill_${hold>0?`up`:`down`}.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)" style="padding-left: 12rpx;"></image> -->
						</view>
					</view>
				</view>
			</view>
		</template>

		<template v-if="layout===$C.HEADER_3">
			<view class="dynamic_data" style="padding-left: 12px;" :class="`slide_in_${dir}`">
				<view style="border-radius: 12px;line-height: 2;width: max-content;margin:0 auto;"
					:style="{backgroundColor:$theme.WHITE_50}">
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding-left:9px;">
						<view style="padding-right:9px;" :style="{color:$theme.WHITE}">{{$fmt.amount(total,$util.isUS())}}</view>
						<view style="border-radius: 12px;padding:0 9px;min-width: 80px;background-color: aliceblue;"
							:style="{color:$theme.setRiseFall(hold)}">
							{{$fmt.amount(hold,$util.isUS())}}
						</view>
					</view> -->
				</view>
			</view>
			<image src="/static/notify.png" mode="aspectFit" :style="$theme.setImageSize(36)" class="btn_notify"
				style="padding-right: 12px;" @click="$linkTo.notify()"></image>
		</template>
	</header>
</template>

<script>
	import { KEY_LEFT } from '@/common/constants.js';
	/**
	 * 1. 回退按钮、动态标题、消息按钮
	 * 2. menu按钮图标、消息按钮、动态数据
	 * 3. menu按钮图标 、动态数据、消息按钮
	 */
	export default {
		name: "CommonHeader",
		props: {
			layout: {
				type: String,
				required: true
			},
			title: {
				type: String,
				default: ''
			},
			// 动态数据 total
			total: {
				type: Number,
				default: 0,
			},
			// 动态数据 hold
			hold: {
				type: Number,
				default: 0,
			},
			// 标题动画方向
			dir: {
				type: String,
				default: KEY_LEFT,
			},
			msg: {
				type: Boolean,
				default: false
			},
			// avatar
			avatar: {
				type: String,
				default: ''
			},
		},
	}
</script>

<style lang="scss" scoped>
	header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20px 16px 0 16px;
		// position: relative;
		// overflow: hidden;
	}

	.btn_back,
	.btn_notify,
	.btn_menu {
		// flex: 0 1 auto;
		// cursor: pointer;
	}

	.dynamic_title {
		flex: 1;
		text-align: center;
		position: relative;
		color: #FFF;
		font-size: 32rpx;
	}

	.dynamic_data {
		flex: 1;
		text-align: center;
		position: relative;
	}
</style>