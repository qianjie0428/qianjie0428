<template>
	<view class="table" style="background-color: #FFF;padding: 0 20px;">
		<view class="table_header">
			<view class="table_th" style="width: 25%;">名称/代码</view>
			<view class="table_th" style="width: 30%;text-align: center;">最新价</view>
			<view class="table_th" style="width: 20%;text-align: center;">涨跌</view>
			<view class="table_th" style="width: 25%;text-align: right;">涨跌幅</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view class="table_row" style="display:block;" @click="linkTo(v)">
					<view style="font-weight: 700;">{{v.name}}</view>
					<view style="display: flex;align-items: center;">
						<view class="table_cell" style="width: 25%;">
							<view :style="{color:$theme.BLACK_70}">{{v.code}}</view>
						</view>
						<view class="table_cell" style="width: 30%;text-align: center;">
							{{$fmt.amount(v.price,v.lgre)}}
						</view>
						<view class="table_cell" style="width: 20%;text-align: center;" :style="{color:$theme.setRiseFall(v.rate)}">
							{{$fmt.amount(v.rateNum,v.lgre)}}
						</view>
						<view class="table_cell" style="margin-left: auto;">
							<view class="rate" style="color: #FFF;" :style="{backgroundColor:$theme.setRiseFall(v.rate)}">
								{{$fmt.percent(v.rate)}}
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: "USStockList",
		props: {
			list: {
				type: Array,
				default: () => {
					[]
				}
			}
		},
		methods: {
			linkTo(val) {
				console.log(val);
				this.$emit('action', val);
			}
		}
	}
</script>

<style>

</style>