<template>
	<view class="flex" style="font-size: 14px;"
		:style="{color:$theme.BLACK_70}">
		<view>可用资金: </view>
		<view style="margin-left: 5px;font-size: 14px;">{{balance}}</view>
		<template v-if="deposit">
			<view style="border-bottom: 1px solid #121212;font-size: 12px;" @click="$linkTo.deposit()">
				{{$t($msg.DEPOSIT_TITLE)}}
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "Balance",
		props: {
			// 余额值
			balance: {
				type: [Number, String],
				default: 0
			},
			// 是否需要快捷充值入口
			deposit: {
				type: Boolean,
				default: false
			},
		},
	}
</script>

<style>

</style>