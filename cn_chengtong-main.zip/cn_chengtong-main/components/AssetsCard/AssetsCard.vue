<template>
	<view class="assets_card">
		<view style="text-align: center;padding-top:  20px;">总资产（元）
			<image :src="`/static/mask_${isMask?`hide`:`show`}.svg`" mode="aspectFit" :style="$theme.setImageSize(16)"
				@click="toggleMask()"></image>
		</view>
		<view style="text-align: center;font-size: 24px;font-weight: 900;" :style="{color:$theme.PRIMARY}">
			{{isMask?hideData:$fmt.amount((info.totalZichan||0),$util.isUS()) }}
		</view>
		<view style="display: flex;align-items: center;justify-content: space-between;padding: 20px;gap:8px;">
			<view style="flex:1;">
				<view>可用资金</view>
				<view>{{isMask?hideData:($fmt.amount((info.money),$util.isUS())) }}</view>
			</view>
			<template v-if="info && info.total">
				<view style="text-align: center;flex:1;">
					<view>股票市值</view>
					<view>{{isMask?hideData:($fmt.amount((info.total),$util.isUS())) }}</view>
				</view>
			</template>
			<template v-if="info && info.floatPL">
				<view style="text-align: right;flex:1;">
					<view>浮动盈亏</view>
					<view :style="{color:$theme.setRiseFall(info.floatPL)}">
						{{isMask?hideData:($fmt.amount((info.floatPL),$util.isUS())) }}
					</view>
				</view>
			</template>
			<template v-if="info && info.frozen">
				<view style="text-align: right;flex:1;">
					<view>冻结资金</view>
					<view> {{isMask?hideData:($fmt.amount(info.frozen,$util.isUS())) }}</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		name: "AssetsCard",
		props: {
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isMask: null, // 是否掩码
				hideData: `*****`,
			};
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking');
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
		}
	}
</script>

<style>

</style>