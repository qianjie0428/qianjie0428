<template>
	<view
		style="display: flex;align-items: center;justify-content: space-between;background-color: #FFFFFF;padding:14px 20px 0 20px;margin-top: 10px;">
		<view style="width: 4px;height: 16px;" :style="{backgroundColor:$theme.PRIMARY}"></view>
		<view style="flex:1;font-size: 16px;font-weight:500;padding-left: 8px;" :style="{color:color}">{{title}}</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "CommonTitle",
		props: {
			title: {
				type: String,
				required: true
			},
			color: {
				type: String,
				default: `#000000`
			}
		}
	}
</script>

<style>

</style>