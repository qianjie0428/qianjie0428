<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');
			uni.hideTabBar();
		},
		onShow: function() {
			console.log('App Show');
			uni.hideTabBar();
		},
		onHide: function() {
			console.log('App Hide');
			uni.hideTabBar();
		}
	}
</script>

<style lang="scss">
	@import "@/node_modules/uview-ui/index.scss";
	@import "@/common/animate.css";
	@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@100..900&display=swap');
	@import "@/common/style.css";
	// 字體備選方案，用於非google通行地區
	// @import "@/static/fonts/Roboto/index.css";

	// @media screen and (max-device-width:375px) {
	// 	page {
	// 		width: 100vw;
	// 	}
	// }

	// @media screen and (min-device-width:376px) and (max-device-width:750px) {
	// 	page {
	// 		width: 100vw;
	// 		margin: 0 auto;
	// 	}
	// }

	// @media screen and (min-device-width:751px) {
	// 	page {
	// 		width: 750px;
	// 		margin: 0 auto;
	// 	}
	// }
	
	
	
	* {
		font-family: "PingFang SC", "Microsoft YaHei", "SimSun", "Arial", sans-serif;
		font-optical-sizing: auto;
		font-style: normal;
		box-sizing: border-box;
	}
</style>