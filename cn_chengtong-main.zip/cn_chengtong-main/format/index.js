import * as constants from '@/common/constants.js';
import { lgre } from '@/localize/lgre.js';
import {
	fmtText,
	textLong
} from './text.js';
import {
	setToYear,
	today,
	todayHMS
} from './date.js';

import {
	percent,
	numer,
	crypto,
	amount,
	quantity,
	isNumer,
	decimal,
	decimalW,
	decimalY,
} from './number.js';


export const fmt = {
	fmtText,
	textLong,
	setToYear,
	today,
	todayHMS,
	percent,
	numer,
	crypto,
	amount,
	quantity,
	isNumer,
	decimal,
	decimalW,
	decimalY,
	getLgre: (val = '') => {
		// console.log(`getLgre:`, val);
		// if (constants.US_GPINDEX.includes(val)) return 'en-US';
		// if (constants.HK_GPINDEX.includes(val)) return 'zh-HK';
		return 'zh-CN';
	}
}

export default fmt;

// /**
//  * 
//  * @type {object} fmtConfig
//  * @type {string} fmtConfig:{object}
//  * @type {string} color:显示值颜色
//  * @type {number} rate:显示值汇率
//  * @type {number} decimal:显示值限制小数的位数
//  * @description {货币代码:颜色代码}
//  * 需要格式化为哪些loacale。比如，意大利的欧元美元双显。扩展为遍历输出多显.
//  * 按照用户需求，调整此处需要遍历渲染的货币。
//  */
// /**
//  * @function 数据多种显示配置
//  * @return {object} 用于多显格式化的配置对象
//  * @type {number} rate:显示值汇率
//  * @type {number} decimal:显示值限制小数的位数
//  * @description 其他设置也可以在外部为变量赋值后，再按需调整
//  * @example
//  * this.$fmt.fmtConfig();
//  */
// export const fmtConfig = () => {
// 	let temp = {};
// 	Object.keys(localize).forEach((key, index) => {
// 		console.log(key);
// 		// 确保 temp[key] 被初始化为一个对象
// 		temp[key] = {}; // 初始化为一个新对象
// 		temp[key].rate = 1; // 默认 1
// 		temp[key].decimal = 4; // 默认小数位数 -1视为不主动限制
// 	});

// 	// 其他设置写在外面，减少遍历时多次多种 if 判断
// 	// temp['en-US'] = temp['en-US'] || {}; // 确保存在 'en-US' 对应的对象
// 	// temp['en-US'].decimal = 4; // 视为主动限制小数位数

// 	return temp;
// };


// // 函数: 将指定 locale 对象放在第一位
// export const prioritizeLocale = (config, locale = 'en-US') => {
// 	const keys = Object.keys(config);

// 	// 如果 locale 存在于 config 中，将其放在数组的开头
// 	if (keys.includes(locale)) {
// 		const prioritizedConfig = {
// 			[locale]: config[locale]
// 		};
// 		prioritizedConfig[locale].color = '';

// 		// 将其余的 locale 追加到新对象中
// 		keys.forEach((key, index) => {
// 			if (key !== locale) {
// 				prioritizedConfig[key] = config[key];
// 				prioritizedConfig[key].color = theme.colors[index];
// 			}
// 		});
// 		return prioritizedConfig;
// 	}
// 	// 如 locale 不在 config 中，返回原对象
// 	return config;
// };