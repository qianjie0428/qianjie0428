import Vue from 'vue';
import {
	Msg,
	setLocale,
	getLgre,
	setLgre,
	getCurrency
} from '@/localize/index.js';

/**
 * @function check number
 * @param {string} val 需check的数值
 * @example
 * fmt.isNumer(1.35);
 */
export const isNumer = (val) => {
	console.log(val);
	// 检查值是否为 null 或 undefined 均返回 false
	if (val == null) return false;
	// 检查值是否为数字类型
	if (typeof val === 'number' && !isNaN(val)) return true;
	// 如果是字符串，尝试转换为数字并判断
	if (typeof val === 'string' && val.trim() !== '') {
		const numValue = parseFloat(val);
		return !isNaN(numValue);
	}
	// 其他类型返回 false
	return false;
}



/**
 * @function 按照lgre格式化百分数
 * @param {string} val 需格式化的数值
 * @param {string} locale [lg-re]
 * @return {string} 格式化后的百分数
 * @description 只在类似情况下使用该函数。
 * @example
 * fmt.percent(1.35);
 */
export const percent = (val, locale = getLgre()) => {
	const fmt = new Intl.NumberFormat(locale, {
		style: "percent",
		minimumFractionDigits: 0,
		maximumFractionDigits: Vue.prototype.$rate,
	});
	
	return fmt.format(val / 100);
}

/**
 * @function 格式化数字值
 * @param {string} str 需格式化的字符串
 * @param {number} decimal 保留小数位数
 * @return {string} 格式化为指定小数位数的string类型数值
 * @description 通常用于不限制位数或指定位数的数值。
 * @example
 * fmt.number(`0.000013579`)
 * fmtn.umber(`13579.111111`, 5)
 */
export const numer = (str, decimal = -1) => {
	// 非数字 135.00
	str = !str || isNaN(str) ? "0" : str;
	// 四舍五入到指定小数位：或原样输出
	return decimal > -1 ? parseFloat(str).toFixed(decimal) : str;
};

export const decimal = (num, unit = true, locale = Vue.prototype.$DEF_LGRE) => {
	num = numer(num) || 0;
	const units = ['万', '亿'];
	let unitIndex = -1;
	if (unit) {
		// 根据数值大小确定单位
		while (num >= 10000 && unitIndex < units.length - 1) {
			num /= 10000;
			unitIndex++;
		}
		num = Number(num.toFixed(2)) || 0;
	}
	const temp = new Intl.NumberFormat(locale, {
		style: "decimal", // 用于普通数字
		minimumFractionDigits: 0,
		maximumFractionDigits: 0, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
	}).format(num);

	return unit ? temp + `${units[unitIndex] || ''}` : temp;
};

export const decimalW = (num, locale = Vue.prototype.$DEF_LGRE) => {
	num = numer(num) || 0;
	num /= 10000;
	num = Number(num.toFixed(2)) || 0;
	// console.log(num)

	const temp = new Intl.NumberFormat(locale, {
		style: "decimal", // 用于普通数字
		minimumFractionDigits: 0,
		maximumFractionDigits: Vue.prototype.$decimal, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
	}).format(num);

	return temp + `万`;
};

export const decimalY = (num, locale = Vue.prototype.$DEF_LGRE) => {
	num = numer(num) || 0;
	num /= 100000000;
	num = Number(num.toFixed(2)) || 0;
	// console.log(num)

	const temp = new Intl.NumberFormat(locale, {
		style: "decimal", // 用于普通数字
		minimumFractionDigits: 0,
		maximumFractionDigits: Vue.prototype.$decimal, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
	}).format(num);

	return temp + `亿`;
};


/**
 * @function 格式化传入值为指定货币格式
 * @param {string} str 需格式化的字符串
 * @param {string} currency 货币代码
 * @param {string} locale lgre
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description
 * @example
 * fmt.currency(`13579.00`);
 * fmt.currency(`13579.11`);
 * fmt.currency(`13579.1111`);
 * fmt.currency(fmtNumber(`13579.111111`, 5));
 */
export const amount = (str, locale = Vue.prototype.$DEF_LGRE) => {
	// console.log(`amount:`, str, locale);
	if(!str||str=='--'){
		console.log(111)
		return "--"
	}
	// 转为字符串
	str = typeof str == "string" ? str : str.toString();
	// 获取整数和小数部分
	const [intPart, decimalPart = ""] = str.split(".");
	
	// 当前货币
	// const curCurrency = getCurrency();
	// // console.log(`fmtCurrency curCurrency:`, curCurrency);
	// 小数位数最小值。传入值小数部分的长度&& 小数*1是否＞0
	//   const min = decimalPart.length > 0 && decimalPart * 1 > 0 ? 0 : 2;
	// console.log(`fmtCurrency min:`, min);
	// 小数位数最大值
	// const max = decimalPart.length || Vue.prototype.$decimal;
	// console.log(`fmtCurrency max:`, max)
	// 再把整数和小数拼起来。
	const temp = intPart + "." + decimalPart;
	// console.log(`fmtCurrency temp:`, temp);
	// console.log(locale);
	// console.log(getCurrency(locale));
	return new Intl.NumberFormat(locale, {
		// style: "currency", // 用于以特定货币格式化数字。
		// 指定要使用的货币代码（如 'USD'、'EUR'、'CNY' 等）
		currency: getCurrency(locale),
		// 定义货币的显示形式（如 'symbol' 显示符号，'code' 显示货币代码，'name' 显示货币名称）。
		// currencyDisplay: "symbol",
		// currencyDisplay: "narrowSymbol",
		minimumFractionDigits: 2,
		maximumFractionDigits: Vue.prototype.$decimal, // 显示最多位小数
		// unit: "kilometer-per-hour", // 单位
	}).format(temp);
	// .format(intPart) + (decimalPart ? '.' + decimalPart : '')
};



/**
 * @function 格式化量值(整数)如股票购买的股数
 * @param {number} num 需格式化的数值
 * @param {string} locale 货币代码
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description 只在类似情况下使用该函数。
 * @example
 * fmtQTY(`13579.00`);
 * fmtQTY(`13579`);
 */
export const quantity = (num, locale = getLgre()) => {
	//   num = !num || isNaN(num) ? 0 : Number(num);
	return new Intl.NumberFormat(locale, {
		style: "decimal", // 用于普通数字
		minimumFractionDigits: 0,
		maximumFractionDigits: 0, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
	}).format(numer(num));
};