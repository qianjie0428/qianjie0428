import Vue from 'vue';
import {
	lgre
} from '@/localize/lgre.js';
import {
	fmtText
} from '@/format/text';

import enUS from './en-US.json';
import zhTW from './zh-TW.json';
import zhCN from './zh-CN.json';

// 默认 lgre
// export const DEF_LGRE = 'en-US';
export const ignore = ["zh-TW", "zh-CN", "ja-JP", "ko-KR", "ar-IL"];
export {
	lgre
};

export const messages = {
	'en-US': enUS,
	'zh-TW': zhTW,
	'zh-CN': zhCN,
}

export const Msg = Object.create(null);
// Msg.lgre = uni.getStorageSync('locale') || 'en-US';

/**
 * @function set current locale
 */
export const setLocale = (locale) => {
	locale = !locale ? getLgre() : locale;
	Object.keys(messages[locale]).forEach(function(k) {
		Msg[k] = messages[locale][k];
	});
	Vue.prototype.$msg = Msg;
	// console.log(`setLocale msg:`, Vue.prototype.$msg);
}

export const translate = (val) => {
	return val;
}


export const setLgre = (locale = Vue.prototype.$DEF_LGRE) => {
	console.log(locale);
	uni.setStorageSync('lgre', locale);
}

export const getLgre = () => {
	return uni.getStorageSync('lgre') || Vue.prototype.$DEF_LGRE;
}

export const getTimeZone = (val = Vue.prototype.$DEF_LGRE) => {
	return lgre[val].timeZone;
}

export const getCurrency = (val = Vue.prototype.$DEF_LGRE) => {
	return lgre[val].currency;
}

export const getLang = (val = Vue.prototype.$DEF_LGRE) => {
	return lgre[val].lang;
}